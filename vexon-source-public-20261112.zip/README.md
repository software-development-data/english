# Vexon — Soloworks primary web app

This repository now contains the Vexon application as its primary project. It is a Next.js 16 + TypeScript + Prisma app using SQLite.

## Run locally

1. Install Node.js 20.9+ and npm (or Bun).
2. Install dependencies with `npm install`.
3. Copy `.env.example` to `.env` and set `DATABASE_URL="file:../db/custom.db"`.
4. Run `npx prisma db push` to create the local schema, then `npm run dev`.

Production uses Next.js standalone output; configure a Node.js web app and set the database path in the host's environment. Do not commit `.env`, production databases, payment credentials, or private keys.

## Related sites

The companion package keeps English Quest at `english.soloworks.pro` and a separate payment site at `pay.soloworks.pro`. English Quest configuration and database dumps are not part of this public repository. Payment remains disabled until a provider/account and server-side verification are configured.
