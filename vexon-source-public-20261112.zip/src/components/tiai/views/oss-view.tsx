'use client'

// ============ THƯ VIỆN NGUỒN MỞ AI (gifhub tổng hợp) ============
// Kho repo mã nguồn mở tuyển chọn: sinh video, dựng phim AI, lipsync,
// Company OS, AI Agent… Vexon AI cũng tự tra thư viện này khi tư vấn.

import { useMemo, useState } from 'react'
import { OSS_GROUPS } from '@/lib/tiai/oss-repos'
import { ToolIcon } from '@/components/tiai/shared'
import { ArrowLeft, ExternalLink, Library, Search, Sparkles } from 'lucide-react'
import { useView } from '@/lib/tiai/view'
import { Button } from '@/components/ui/button'

export function OssView() {
  const go = useView((s) => s.go)
  const back = useView((s) => s.back)
  const [q, setQ] = useState('')
  const total = OSS_GROUPS.reduce((s, g) => s + g.repos.length, 0)

  const groups = useMemo(() => {
    const query = q.trim().toLowerCase()
    if (!query) return OSS_GROUPS
    return OSS_GROUPS.map((g) => ({
      ...g,
      repos: g.repos.filter(
        (r) =>
          r.name.toLowerCase().includes(query) ||
          r.desc.toLowerCase().includes(query) ||
          r.use.toLowerCase().includes(query) ||
          g.keywords.some((k) => k.includes(query)),
      ),
    })).filter((g) => g.repos.length > 0)
  }, [q])

  return (
    <div className="mx-auto w-full max-w-4xl px-4 pb-16">
      <button onClick={back} className="mb-3 flex items-center gap-1 text-sm font-semibold text-emerald-700 transition hover:text-emerald-900" aria-label="Về trang chủ">
        <ArrowLeft className="h-4 w-4" /> Trang chủ
      </button>
      <div className="mb-6 rounded-3xl bg-gradient-to-br from-emerald-600 via-teal-600 to-teal-600 p-6 text-white shadow-lg shadow-emerald-600/25">
        <p className="flex items-center gap-2 text-sm font-semibold text-emerald-100"><Library className="h-4 w-4" /> GIFHUB TỔNG HỢP</p>
        <h1 className="mt-1 text-2xl font-extrabold sm:text-3xl">Thư viện Nguồn mở AI</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-emerald-100">
          {total} repo tuyển chọn để làm video AI, dựng phim tự động, lipsync, điều hành công ty bằng AI Agent…
          Vexon AI cũng <b>đọc thư viện này</b> — chỉ cần hỏi &quot;dựng phim AI bằng gì?&quot; là bot tư vấn kèm link.
        </p>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Tìm repo, ví dụ: lipsync, upscale 4K, timeline, agent…"
          className="w-full rounded-2xl border border-stone-200 bg-white py-2.5 pl-9 pr-3 text-sm shadow-sm focus:border-emerald-400 focus:outline-none"
          aria-label="Tìm trong thư viện nguồn mở"
        />
      </div>

      <div className="space-y-8">
        {groups.map((g) => (
          <section key={g.key}>
            <h2 className="mb-3 flex items-center gap-2 text-base font-bold text-stone-800">
              <span className={`flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br ${g.tint} text-sm shadow`}><ToolIcon name={g.icon} className="h-4 w-4" /></span>
              {g.title}
              <span className="rounded-full bg-stone-100 px-2 py-0.5 text-[10px] font-bold text-stone-500">{g.repos.length}</span>
            </h2>
            <div className="grid gap-3 sm:grid-cols-2">
              {g.repos.map((r) => (
                <article key={r.url} className="flex flex-col rounded-2xl border border-stone-200 bg-white p-4 shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-300 hover:shadow-md">
                  <a href={r.url} target="_blank" rel="noreferrer" className="flex items-start justify-between gap-2" aria-label={`Mở GitHub ${r.name}`}>
                    <span className="text-sm font-bold text-emerald-900 underline-offset-2 hover:underline">{r.name}</span>
                    <ExternalLink className="h-3.5 w-3.5 shrink-0 text-stone-400" />
                  </a>
                  <p className="mt-1.5 flex-1 text-xs leading-relaxed text-stone-600">{r.desc}</p>
                  <p className="mt-2 rounded-lg bg-emerald-50 px-2.5 py-1.5 text-[11px] leading-relaxed text-emerald-700">
                    <b>Ứng dụng:</b> {r.use}
                  </p>
                </article>
              ))}
            </div>
          </section>
        ))}
        {groups.length === 0 && (
          <p className="rounded-2xl border border-dashed bg-white p-8 text-center text-sm text-stone-500">Không có repo nào khớp &quot;{q}&quot;.</p>
        )}
      </div>

      <div className="mt-10 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-center">
        <p className="text-sm font-bold text-emerald-900">Muốn triển khai repo nào?</p>
        <p className="mt-1 text-xs text-emerald-700">Hỏi Vexon AI — bot đã đọc toàn bộ thư viện này và sẽ tư vấn từng bước kèm link.</p>
        <Button className="mt-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500" onClick={() => window.open('/chat', '_blank')} aria-label="Mở Vexon AI">
          <Sparkles className="mr-1 h-4 w-4" /> Hỏi Vexon AI ngay
        </Button>
      </div>
    </div>
  )
}
