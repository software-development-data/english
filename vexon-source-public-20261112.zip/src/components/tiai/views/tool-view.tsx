'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Loader2 } from 'lucide-react'
import { getTool } from '@/lib/tiai/tools'
import { TaoAnh, AiEditTool, LocalImageTool } from '../tools/ai-image'
import { NenAnh, CatAnh } from '../tools/image-extra'
import { TachLoiNhac, CatNhac } from '../tools/audio-tools'
import { AnhSangPdf, GopPdf, TachPdf, XoayPdf, PdfSangAnh } from '../tools/pdf-tools'
import { TomTatPdf } from '../tools/pdf-ai'
import { TaoQr, Base64Tool } from '../tools/qr-base64'
import { InpaintLama, TachNenHd } from '../tools/inpaint'
import { VideoInpaint } from '../tools/video-inpaint'
import { NhanBanGiongNoi, GiongNoiThanhVanBan } from '../tools/voice-tools'
import { DichThuat, VietNoiDung, HoTroCode } from '../tools/text-ai'
import { PhanTichAnh } from '../tools/vision-tool'
import { TaoVideo } from '../tools/video-ai'
import { VideoEnhance, SceneDetect, SilenceCut, AiBroadcaster } from '../tools/video-studio'
import { TimAnhMau } from '../tools/image-search-tool'
import { TaoMatKhau, JsonFormat, BangMau, DemChu } from '../tools/dev-tools'
import { FileDrop, DownloadButton, ToolPage, RunButton, useAiRun } from '../shared'
import { fileToImage, makeCanvas, canvasToBlob, downloadBlob } from '@/lib/tiai/image'
import type { Tool } from '@/lib/tiai/tools'

function renderTool(tool: Tool) {
  switch (tool.slug) {
    case 'tao-anh':
      return <TaoAnh tool={tool} />
    case 'chinh-sua-anh':
      return (
        <AiEditTool
          tool={tool}
          placeholder="VD: đổi áo cưới sang màu đỏ, thêm nón lá, xóa người đứng sau…"
          examples={['Xóa người phía sau', 'Đổi nền sang bãi biển hoàng hôn', 'Đổi màu áo sang trắng', 'Thêm hiệu ứng tuyết rơi']}
        />
      )
    case 'khoi-phuc-mau':
      return (
        <AiEditTool
          tool={tool}
          fixedPrompt="Colorize this black and white photograph with natural, realistic colors. Preserve the original composition, faces, clothing texture and all details exactly as they are — only add believable natural color tones."
        />
      )
    case 'lam-net-anh':
      return <LocalImageTool tool={tool} mode="sharpen" />
    case 'tang-do-phan-giai':
      return <LocalImageTool tool={tool} mode="upscale" />
    case 'xoa-nen':
      return <LocalImageTool tool={tool} mode="removebg" />
    case 'lam-dep':
      return <LocalImageTool tool={tool} mode="beautify" />
    case 'tach-loi-nhac':
      return <TachLoiNhac tool={tool} />
    case 'nhan-ban-giong-noi':
      return <NhanBanGiongNoi tool={tool} />
    case 'giong-noi-thanh-van-ban':
      return <GiongNoiThanhVanBan tool={tool} />
    case 'tom-tat-pdf':
      return <TomTatPdf tool={tool} />
    case 'xoa-watermark-anh':
      return <InpaintLama tool={tool} />
    case 'tach-nen-hd':
      return <TachNenHd tool={tool} />
    case 'xoa-watermark-video':
      return <VideoInpaint tool={tool} />
    case 'dich-thuat':
      return <DichThuat tool={tool} />
    case 'viet-noi-dung':
      return <VietNoiDung tool={tool} />
    case 'phan-tich-anh':
      return <PhanTichAnh tool={tool} />
    case 'ho-tro-code':
      return <HoTroCode tool={tool} />
    case 'tao-video':
      return <TaoVideo tool={tool} />
    case 'lam-net-video':
      return <VideoEnhance tool={tool} />
    case 'cat-phan-canh':
      return <SceneDetect tool={tool} />
    case 'cat-khoang-lang':
      return <SilenceCut tool={tool} />
    case 'phat-thanh-vien':
      return <AiBroadcaster tool={tool} />
    case 'tim-anh-mau':
      return <TimAnhMau tool={tool} />
    case 'tao-mat-khau':
      return <TaoMatKhau tool={tool} />
    case 'json-format':
      return <JsonFormat tool={tool} />
    case 'bang-mau':
      return <BangMau tool={tool} />
    case 'dem-chu':
      return <DemChu tool={tool} />
    case 'nen-anh':
      return <NenAnh tool={tool} />
    case 'cat-anh':
      return <CatAnh tool={tool} />
    case 'doi-dinh-dang':
      return <DoiDinhDang tool={tool} />
    case 'anh-sang-pdf':
      return <AnhSangPdf tool={tool} />
    case 'gop-pdf':
      return <GopPdf tool={tool} />
    case 'tach-pdf':
      return <TachPdf tool={tool} />
    case 'xoay-pdf':
      return <XoayPdf tool={tool} />
    case 'pdf-sang-anh':
      return <PdfSangAnh tool={tool} />
    case 'cat-nhac':
      return <CatNhac tool={tool} />
    case 'tao-qr':
      return <TaoQr tool={tool} />
    case 'base64':
      return <Base64Tool tool={tool} />
    default:
      return (
        <div className="mx-auto max-w-3xl px-4 py-20 text-center text-emerald-700">
          Công cụ này đang được xây dựng — quay lại sau nhé!
        </div>
      )
  }
}

export function ToolView({ slug }: { slug: string }) {
  const tool = getTool(slug)
  if (!tool) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center text-emerald-700">
        Không tìm thấy công cụ.
      </div>
    )
  }
  return renderTool(tool)
}

// Đổi định dạng ảnh — nhiều ảnh một lượt (miễn phí)
function DoiDinhDang({ tool }: { tool: Tool }) {
  const [files, setFiles] = useState<File[]>([])
  const [format, setFormat] = useState('image/jpeg')
  const [busy, setBusy] = useState(false)
  const [results, setResults] = useState<{ name: string; url: string; blob: Blob }[]>([])
  const { run: paidRun } = useAiRun()

  const ext = format.includes('jpeg') ? 'jpg' : format.includes('webp') ? 'webp' : 'png'
  const run = () =>
    paidRun(
      tool,
      async () => {
        if (files.length === 0) throw new Error('Chưa chọn ảnh')
        setBusy(true)
        try {
          const out: { name: string; url: string; blob: Blob }[] = []
          for (const f of files) {
            const { img } = await fileToImage(f)
            const c = makeCanvas(img.naturalWidth, img.naturalHeight)
            c.getContext('2d')!.drawImage(img, 0, 0)
            const blob = await canvasToBlob(c, format, 0.92)
            out.push({ name: `${f.name.replace(/\.[^.]+$/, '')}.${ext}`, url: URL.createObjectURL(blob), blob })
          }
          setResults(out)
        } finally {
          setBusy(false)
        }
      },
      `Đã đổi định dạng ${files.length} ảnh`,
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <FileDrop
          accept="image/png,image/jpeg,image/webp"
          multiple
          onFiles={(fs) => { setFiles((p) => [...p, ...fs]); setResults([]) }}
          label="Thả các ảnh vào đây"
          hint="PNG ↔ JPG ↔ WEBP — đổi bao nhiêu ảnh cũng được"
        />
        {files.length > 0 && (
          <div className="space-y-3 rounded-2xl border border-stone-200 bg-card p-4">
            <div className="space-y-2">
              <Label>Chuyển sang định dạng</Label>
              <Select value={format} onValueChange={(v) => { setFormat(v); setResults([]) }}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="image/jpeg">JPG</SelectItem>
                  <SelectItem value="image/webp">WEBP</SelectItem>
                  <SelectItem value="image/png">PNG</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <p className="text-sm text-stone-600">{files.length} ảnh sẵn sàng</p>
            <RunButton loading={busy} onClick={run} disabled={files.length === 0} cost={tool.price}>
              Đổi định dạng
            </RunButton>
            {results.length > 0 && (
              <div className="space-y-2">
                {results.map((r, i) => (
                  <div key={i} className="flex items-center justify-between rounded-xl bg-black/5 px-3 py-2">
                    <span className="truncate text-sm text-emerald-900">{r.name} · {(r.blob.size / 1024).toFixed(1)} KB</span>
                    <Button size="sm" variant="outline" className="rounded-lg" onClick={() => downloadBlob(r.blob, r.name)}>
                      Tải
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </ToolPage>
  )
}
