'use client'

import { CheckCircle2, XCircle, History } from 'lucide-react'
import { useWallet } from '@/lib/tiai/wallet'
import { useView } from '@/lib/tiai/view'
import { Button } from '@/components/ui/button'

export function HistoryView() {
  const tasks = useWallet((s) => s.tasks)
  const go = useView((s) => s.go)
  return (
    <div className="mx-auto w-full max-w-2xl px-4 pb-16">
      <h1 className="mb-1 text-2xl font-extrabold text-emerald-950">Lịch sử tác vụ</h1>
      <p className="mb-6 text-sm text-stone-600">Mọi lần xử lý AI đều được ghi lại — công cụ miễn phí nên không mất gì cả.</p>
      {tasks.length === 0 ? (
        <div className="rounded-2xl border border-stone-200 bg-white p-10 text-center">
          <History className="mx-auto mb-3 h-10 w-10 text-stone-300" />
          <p className="text-sm text-stone-500">Chưa có tác vụ nào.</p>
          <Button onClick={() => go({ name: 'home' })} className="mt-4 rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-500">
            Khám phá công cụ
          </Button>
        </div>
      ) : (
        <ul className="space-y-2">
          {tasks.slice(0, 80).map((t) => (
            <li key={t.id} className="flex items-center justify-between rounded-xl border border-stone-200 bg-white px-4 py-3">
              <div className="flex items-center gap-3">
                {t.status === 'success' ? (
                  <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-500" />
                )}
                <div>
                  <p className="text-sm font-semibold text-emerald-950">{t.toolName}</p>
                  <p className="text-xs text-stone-500">
                    {new Date(t.at).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}
                    {' · '}{t.status === 'success' ? 'Thành công' : 'Thất bại — thử lại nhé'}
                  </p>
                </div>
              </div>
              {t.status === 'success' && <p className="text-sm font-bold text-emerald-600">Miễn phí</p>}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
