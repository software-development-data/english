'use client'

import { useMemo, useState } from 'react'
import { TOOLS, CATEGORY_LABELS, type ToolCategory } from '@/lib/tiai/tools'
import { useView } from '@/lib/tiai/view'
import { ToolCard } from './home-view'
import { Library, Sparkles, Palette, Image as ImageIcon, Search, Clapperboard, Music, FileText, PenLine, Wrench } from 'lucide-react'

/** Danh mục theo loại dữ liệu: Ảnh · Video · Âm thanh · PDF · Văn bản · Tiện ích */
const CATS: (ToolCategory | 'all')[] = [
  'all',
  'tao-hinh',
  'chinh-sua',
  'lam-net',
  'video',
  'am-thanh',
  'pdf',
  'van-ban',
  'tien-ich',
]

const CAT_ICONS: Record<ToolCategory | 'all', React.ReactNode> = {
  all: <Sparkles className="h-4 w-4 text-emerald-500" />,
  'tao-hinh': <Palette className="h-4 w-4 text-teal-500" />,
  'chinh-sua': <ImageIcon className="h-4 w-4 text-sky-500" />,
  'lam-net': <Search className="h-4 w-4 text-emerald-500" />,
  video: <Clapperboard className="h-4 w-4 text-rose-500" />,
  'am-thanh': <Music className="h-4 w-4 text-amber-500" />,
  pdf: <FileText className="h-4 w-4 text-red-500" />,
  'van-ban': <PenLine className="h-4 w-4 text-sky-500" />,
  'tien-ich': <Wrench className="h-4 w-4 text-stone-500" />,
}

export function ToolsView() {
  const go = useView((s) => s.go)
  const [cat, setCat] = useState<ToolCategory | 'all'>('all')
  // Công cụ ẩn (bot nội bộ của Vexon AI) không hiện trong lưới
  const visible = useMemo(() => TOOLS.filter((t) => !t.hidden), [])
  const list = visible.filter((t) => cat === 'all' || t.category === cat)
  const countOf = (c: ToolCategory | 'all') => (c === 'all' ? visible.length : visible.filter((t) => t.category === c).length)

  return (
    <div className="mx-auto w-full max-w-5xl px-4 pb-16">
      <h1 className="mb-1 text-2xl font-extrabold text-emerald-950">Tất cả công cụ</h1>
      <p className="mb-5 text-sm text-stone-600">
        Bộ sưu tập {visible.length} công cụ AI & tiện ích — mỗi ngày <b>2 lượt miễn phí</b>, sau đó tính tiền từ ví chung.
      </p>

      <button
        onClick={() => go({ name: 'oss' })}
        className="mb-5 flex w-full items-center gap-2.5 rounded-2xl border border-emerald-200 bg-emerald-50/70 px-4 py-3 text-left transition hover:border-emerald-400 hover:bg-emerald-50"
        aria-label="Mở thư viện Nguồn mở AI (gifhub tổng hợp)"
      >
        <Library className="h-5 w-5 shrink-0 text-emerald-600" />
        <span className="min-w-0 flex-1 text-xs font-semibold text-emerald-800">Thư viện Nguồn mở AI — sinh video, dựng phim, lipsync, AI Agent… Vexon AI tư vấn kèm link GitHub</span>
        <span className="shrink-0 rounded-full bg-emerald-600 px-2.5 py-1 text-[10px] font-bold text-white">Xem</span>
      </button>

      {/* Danh mục theo loại: ảnh · video · âm thanh · pdf · văn bản · tiện ích */}
      <div className="tiai-scroll mb-6 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Danh mục công cụ">
        {CATS.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            role="tab"
            aria-selected={cat === c}
            className={`flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm font-semibold transition ${
              cat === c
                ? 'border-emerald-600 bg-emerald-600 text-white shadow shadow-emerald-600/25'
                : 'border-stone-200 bg-white text-stone-600 hover:border-emerald-300 hover:text-emerald-700'
            }`}
          >
            <span aria-hidden>{CAT_ICONS[c]}</span>
            {c === 'all' ? 'Tất cả' : CATEGORY_LABELS[c]}
            <span className={`rounded-full px-1.5 text-[10px] font-bold ${cat === c ? 'bg-white/25 text-white' : 'bg-stone-100 text-stone-500'}`}>
              {countOf(c)}
            </span>
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <p className="rounded-2xl border border-stone-200 bg-white p-8 text-center text-sm text-stone-500">Chưa có công cụ nào trong mục này.</p>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {list.map((t) => (
            <ToolCard key={t.slug} tool={t} />
          ))}
        </div>
      )}
    </div>
  )
}
