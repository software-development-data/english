'use client'

import { toast } from 'sonner'
import { ArrowDownCircle, ArrowUpCircle, Coins, Info, ScanLine, Sparkles } from 'lucide-react'
import { useWallet } from '@/lib/tiai/wallet'
import { Button } from '@/components/ui/button'
import { BankTopUpButton } from '@/components/vexon/BankTopUp'
import { fmtUsdFromXu, fmtXuWithUsd } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'

export function WalletView({ username }: { username?: string }) {
  const { xu, freeLeft, txs, synced, topup, reset, hydrate } = useWallet()
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho ví tiền chung
  return (
    <div className="mx-auto w-full max-w-2xl px-4 pb-16">
      <h1 className="mb-1 text-2xl font-extrabold text-emerald-950">Ví tiền</h1>
      <p className="mb-6 text-sm text-stone-600">Một ví tiền USD duy nhất — Công cụ AI, Vexon AI và mạng xã hội Vexon <b>dùng chung</b> số dư, không có ví riêng.</p>

      <div className="tiai-hero-bg mb-6 rounded-3xl border border-amber-200 bg-white/60 p-8 text-center">
        <p className="text-sm font-semibold text-amber-700">SỐ DƯ KHẢ DỤNG</p>
        <p className="mt-2 flex items-center justify-center gap-2 text-5xl font-extrabold text-emerald-950">
          <Coins className="h-9 w-9 text-amber-500" />
          {fmtUsdFromXu(xu, rate)}
        </p>
        <p className="mt-1 text-sm font-bold text-amber-600">Tỷ giá thị trường hôm nay: {rate.toLocaleString('vi-VN')}đ/$</p>
        <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-stone-500">
          <Info className="h-3.5 w-3.5" /> {freeLeft > 0 ? `Còn ${freeLeft}/2 lượt miễn phí hôm nay — hết lượt mỗi lần chạy công cụ sẽ tính tiền vào ví` : 'Hết 2 lượt miễn phí hôm nay — mỗi lần chạy công cụ sẽ tính tiền vào ví'}
        </p>
        {!synced && (
          <p className="mt-2 rounded-lg bg-amber-50 px-3 py-1.5 text-xs font-semibold text-amber-700">
            Chưa đồng bộ ví chung — bấm “Làm mới” để tải số dư thật từ Vexon
          </p>
        )}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
          <BankTopUpButton
            username={username || 'vexon-user'}
            onSubmitted={() => {
              // Yêu cầu nạp CHỜ DUYỆT đã tạo — số dư chưa đổi, refresh để thấy dòng “Chờ duyệt”
              hydrate()
            }}
            className="h-10 gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-4 font-semibold text-white shadow-lg shadow-emerald-600/20 hover:from-emerald-500 hover:to-teal-500"
          />
          <Button
            variant="outline"
            className="h-10 gap-2 rounded-xl bg-white px-4 font-semibold text-emerald-800"
            onClick={() => { reset(); toast.info('Đã đồng bộ lại số dư thật từ server') }}
            aria-label="Làm mới số dư"
          >
            <Sparkles className="h-4 w-4" /> Làm mới
          </Button>
        </div>
      </div>

      <div className="mb-8 rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4 text-sm leading-relaxed text-emerald-900">
        <p className="font-bold">Nạp tiền bằng quét mã QR ngân hàng — chờ duyệt</p>
        <p className="mt-1 text-xs leading-relaxed text-stone-600">
          TECHCOMBANK · STK <b>2461388888</b> — chọn gói $0,50 → $20 hoặc nhập số USD tùy chọn, QR tự quy ra VND theo tỷ giá thị trường, bấm xác nhận là tạo yêu cầu nạp. Ban Giám đốc đối soát và duyệt thì số dư mới được cộng vào ví chung. Kiếm thêm miễn phí bằng cách tham gia mạng xã hội: đăng bài, bình luận, điểm danh, xem video!
        </p>
      </div>

      <div className="mb-4 flex items-center justify-between">
        <p className="font-bold text-emerald-950">Lịch sử ví</p>
        <Button variant="ghost" size="sm" className="text-xs text-emerald-700" onClick={() => hydrate()}>
          Đồng bộ lại
        </Button>
      </div>
      {txs.length === 0 ? (
        <p className="rounded-2xl border border-stone-200 bg-white p-6 text-center text-sm text-stone-500">
          Chưa có giao dịch nào — nạp tiền qua QR hoặc kiếm thêm bằng cách tham gia mạng xã hội nhé!
        </p>
      ) : (
        <ul className="space-y-2">
          {txs.slice(0, 50).map((t) => (
            <li key={t.id} className="flex items-center justify-between rounded-xl border border-stone-200 bg-white px-4 py-3">
              <div className="flex items-center gap-3">
                {t.kind === 'topup' ? (
                  <ArrowDownCircle className="h-5 w-5 text-emerald-600" />
                ) : (
                  <ArrowUpCircle className="h-5 w-5 text-amber-500" />
                )}
                <div>
                  <p className="text-sm font-semibold text-emerald-950">{t.name}</p>
                  <p className="text-xs text-stone-500">
                    {new Date(t.at).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}
                  </p>
                </div>
              </div>
              <p className={`text-sm font-bold ${t.kind === 'topup' ? 'text-emerald-600' : 'text-amber-600'}`}>
                {t.kind === 'topup' ? '+' : '−'}{fmtXuWithUsd(t.xu, rate)}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
