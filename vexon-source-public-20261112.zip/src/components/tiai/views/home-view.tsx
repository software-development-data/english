'use client'

import { useState } from 'react'
import { ArrowRight, BadgePercent, Library, ShieldCheck, Sparkles, Zap } from 'lucide-react'
import { TOOLS, priceLabel, type Tool, type ToolCategory } from '@/lib/tiai/tools'
import { useView } from '@/lib/tiai/view'
import { ToolIcon } from '../shared'

export function ToolCard({ tool }: { tool: Tool }) {
  const go = useView((s) => s.go)
  const isAi = tool.group === 'ai'
  return (
    <button
      onClick={() => go({ name: 'tool', slug: tool.slug })}
      className="group relative flex flex-col rounded-2xl border border-stone-200 bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-400/60 hover:shadow-lg hover:shadow-emerald-600/10"
    >
      <div className="mb-3 flex items-start justify-between">
        <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${isAi ? 'bg-gradient-to-br from-emerald-600 to-teal-600 shadow shadow-emerald-600/20' : 'border border-emerald-200 bg-emerald-50'}`}>
          <ToolIcon name={tool.icon} className={`h-5 w-5 ${isAi ? 'text-white' : 'text-emerald-600'}`} />
        </div>
        {tool.badge && (
          <span className="rounded-full bg-emerald-600/10 px-2 py-0.5 text-[10px] font-bold text-emerald-700">{tool.badge}</span>
        )}
      </div>
      <p className="font-semibold text-emerald-950">{tool.name}</p>
      <p className="mt-1 line-clamp-2 flex-1 text-xs leading-relaxed text-stone-600">{tool.desc}</p>
      <div className="mt-3 flex items-center justify-between">
        <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${isAi ? 'bg-amber-500/10 text-amber-700' : 'bg-emerald-600/10 text-emerald-700'}`}>
          {priceLabel(tool)}
        </span>
        <span className="flex items-center gap-1 text-xs font-semibold text-emerald-700 opacity-0 transition group-hover:opacity-100">
          Dùng ngay <ArrowRight className="h-3.5 w-3.5" />
        </span>
      </div>
    </button>
  )
}

// Một lưới duy nhất: AI + tiện ích chạy máy — lọc theo danh mục
const FILTERS: { key: 'all' | ToolCategory; label: string }[] = [
  { key: 'all', label: 'Tất cả' },
  { key: 'tao-hinh', label: 'Tạo hình ảnh' },
  { key: 'chinh-sua', label: 'Chỉnh sửa ảnh' },
  { key: 'lam-net', label: 'Làm nét ảnh' },
  { key: 'video', label: 'Video' },
  { key: 'am-thanh', label: 'Âm thanh & Giọng nói' },
  { key: 'pdf', label: 'PDF & Tệp' },
  { key: 'van-ban', label: 'Văn bản & AI' },
  { key: 'tien-ich', label: 'Tiện ích' },
]

const EFFECTS = [
  { img: '/effects/e1.png', label: 'Làm nét 4K' },
  { img: '/effects/e2.png', label: 'Xóa nền sản phẩm' },
  { img: '/effects/e3.png', label: 'Phục chế màu cũ' },
  { img: '/effects/e4.png', label: 'Poster bán hàng' },
  { img: '/effects/e5.png', label: 'Banner quán ăn' },
  { img: '/effects/e6.png', label: 'Tranh anime nét' },
]

export function HomeView() {
  const go = useView((s) => s.go)
  const [filter, setFilter] = useState<'all' | ToolCategory>('all')
  const allTools = TOOLS.filter((t) => !t.hidden)
  const aiCount = allTools.filter((t) => t.group === 'ai').length
  const list = allTools.filter((t) => filter === 'all' || t.category === filter)

  return (
    <div className="mx-auto w-full max-w-5xl px-4 pb-16">
      {/* HERO */}
      <section className="tiai-hero-bg -mx-4 mb-10 rounded-b-[2.5rem] border-b border-emerald-100 px-4 py-12 text-center sm:py-16">
        <p className="mb-3 inline-flex items-center gap-2 rounded-full border border-emerald-300 bg-emerald-50 px-4 py-1.5 text-xs font-bold tracking-wide text-emerald-700">
          <Sparkles className="h-4 w-4" /> CÔNG CỤ AI · 2 LƯỢT MIỄN PHÍ MỖI NGÀY
        </p>
        <h1 className="mx-auto max-w-2xl text-3xl font-extrabold leading-tight text-emerald-950 sm:text-5xl">
          Tất cả công cụ bạn cần — một ví tiền USD duy nhất.
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-stone-600 sm:text-base">
          Mỗi ngày nhận <b>2 lượt miễn phí</b> cho mỗi tài khoản hoặc thiết bị. Sau đó tính tiền vào ví —
          <b className="text-emerald-700"> kiếm thêm thoải mái bằng cách tham gia mạng xã hội Vexon</b> hoặc nạp nhanh qua QR ngân hàng.
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2 text-xs">
          <span className="rounded-full bg-white px-3 py-1.5 font-semibold text-emerald-800 shadow-sm"><b>{allTools.length}</b> công cụ</span>
          <span className="rounded-full bg-white px-3 py-1.5 font-semibold text-emerald-800 shadow-sm"><b>{aiCount}</b> công cụ AI</span>
          <span className="flex items-center gap-1 rounded-full bg-white px-3 py-1.5 font-semibold text-emerald-800 shadow-sm"><ShieldCheck className="h-3.5 w-3.5 text-emerald-600" /> Riêng tư</span>
          <span className="flex items-center gap-1 rounded-full bg-white px-3 py-1.5 font-semibold text-emerald-800 shadow-sm"><BadgePercent className="h-3.5 w-3.5 text-amber-500" /> Nạp QR ngân hàng</span>
        </div>
      </section>

      {/* TẤT CẢ CÔNG CỤ — một lưới duy nhất (AI + tiện ích chạy máy) */}
      <section className="mb-12">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-lg font-bold text-emerald-950 sm:text-xl">TẤT CẢ CÔNG CỤ</h2>
          <div className="tiai-scroll flex max-w-full gap-2 overflow-x-auto pb-1">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                  filter === f.key ? 'bg-emerald-600 text-white shadow' : 'border border-stone-300 bg-white text-stone-600 hover:border-emerald-400 hover:text-emerald-700'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {list.map((t) => (
            <ToolCard key={t.slug} tool={t} />
          ))}
        </div>
        <button
          onClick={() => go({ name: 'oss' })}
          className="mt-6 flex w-full items-center gap-3 rounded-2xl border border-emerald-200 bg-emerald-50/70 p-4 text-left transition hover:border-emerald-400 hover:bg-emerald-50"
          aria-label="Thư viện nguồn mở AI cho Vexon AI"
        >
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 shadow-lg shadow-emerald-600/25">
            <Library className="h-5 w-5 text-white" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-sm font-bold text-emerald-900">Thư viện Nguồn mở AI · gifhub tổng hợp</span>
            <span className="block text-xs leading-relaxed text-emerald-700">Sinh video, dựng phim AI, lipsync, Company OS, AI Agent… — các repo mã nguồn mở tốt nhất để Vexon AI tư vấn và bạn tự triển khai.</span>
          </span>
          <ArrowRight className="h-4 w-4 shrink-0 text-emerald-500" />
        </button>
        <p className="mt-4 flex items-center justify-center gap-2 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-center text-xs text-emerald-800">
          <Zap className="h-4 w-4 shrink-0" />
          Muốn có thêm tiền? Đăng bài, bình luận, điểm danh, xem video đều được thưởng vào ví USD — hoặc nạp qua QR ngân hàng trong Ví tiền!
        </p>
      </section>

      {/* HIỆU ỨNG MẪU */}
      <section>
        <div className="mb-4">
          <p className="text-xs font-bold tracking-widest text-emerald-600">CHỌN MẪU</p>
          <h2 className="text-lg font-bold text-emerald-950 sm:text-xl">Thả ảnh là xong</h2>
          <p className="text-sm text-stone-600">Hiệu ứng ảnh AI — không cần nghĩ câu lệnh, chọn mẫu bạn thích rồi bấm tạo.</p>
        </div>
        <div className="tiai-scroll flex gap-3 overflow-x-auto pb-2">
          {EFFECTS.map((e) => (
            <button
              key={e.label}
              onClick={() => go({ name: 'tool', slug: 'chinh-sua-anh' })}
              className="group relative h-40 w-32 shrink-0 overflow-hidden rounded-2xl border border-stone-200 shadow-sm sm:h-48 sm:w-40"
              style={{ backgroundImage: `linear-gradient(rgba(6,78,59,0.15), rgba(6,78,59,0.55)), url(${e.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }}
              aria-label={`Hiệu ứng ${e.label}`}
            >
              <span className="absolute bottom-2 left-2 right-2 truncate rounded-full bg-black/50 px-2 py-1 text-[11px] font-semibold text-white">{e.label}</span>
            </button>
          ))}
        </div>
      </section>
    </div>
  )
}
