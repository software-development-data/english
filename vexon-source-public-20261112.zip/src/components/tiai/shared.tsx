'use client'

import { useCallback, useRef, useState } from 'react'
import { toast } from 'sonner'
import {
  Wand2, Brush, Focus, Maximize2, Scissors, Sparkles, Palette, Mic, FileText,
  Package, Repeat2, Crop, Images, Merge, Split, RotateCw, FileImage, Music,
  QrCode, Binary, ArrowLeft, Coins, Loader2, Download, Upload, ShieldCheck, Zap,
  Film, Eraser, Layers, AudioLines, Captions, Languages, PenLine, Eye, Code2,
  Clapperboard, Search, KeyRound, Braces, Type,
  MonitorPlay, ScanLine, AudioWaveform, Megaphone, Smartphone, Building2,
  BotMessageSquare, Compass,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useWallet } from '@/lib/tiai/wallet'
import { useView } from '@/lib/tiai/view'
import type { Tool } from '@/lib/tiai/tools'
import { fmtXuWithUsd } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'

// ─── Icon registry ───────────────────────────────────────
const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  wand: Wand2, brush: Brush, focus: Focus, maximize: Maximize2, scissors: Scissors,
  sparkles: Sparkles, palette: Palette, mic: Mic, 'file-text': FileText,
  package: Package, repeat: Repeat2, crop: Crop, images: Images, merge: Merge,
  split: Split, rotate: RotateCw, 'file-image': FileImage, music: Music,
  qr: QrCode, binary: Binary, film: Film, eraser: Eraser, layers: Layers,
  'audio-lines': AudioLines, captions: Captions,
  languages: Languages, pen: PenLine, eye: Eye, code: Code2, clapper: Clapperboard,
  search: Search, key: KeyRound, braces: Braces, type: Type,
  'monitor-play': MonitorPlay, scan: ScanLine, waveform: AudioWaveform, megaphone: Megaphone,
  video: MonitorPlay, voice: Mic, clip: Film, cut: Scissors, mobile: Smartphone, org: Building2,
  bot: BotMessageSquare, image: FileImage, pdf: FileText, guide: Compass,
}

export function ToolIcon({ name, className = 'h-5 w-5' }: { name: string; className?: string }) {
  const C = ICONS[name] ?? Sparkles
  return <C className={className} />
}

// ─── FileDrop ────────────────────────────────────────────
export function FileDrop({
  accept, multiple = false, onFiles, label, hint,
}: {
  accept: string
  multiple?: boolean
  onFiles: (files: File[]) => void
  label: string
  hint?: string
}) {
  const [over, setOver] = useState(false)
  const ref = useRef<HTMLInputElement>(null)
  const pick = useCallback((fl: FileList | null) => {
    if (!fl || fl.length === 0) return
    onFiles(Array.from(fl))
  }, [onFiles])
  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={label}
      onClick={() => ref.current?.click()}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') ref.current?.click() }}
      onDragOver={(e) => { e.preventDefault(); setOver(true) }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); pick(e.dataTransfer.files) }}
      className={`flex min-h-[180px] cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed p-8 text-center transition-colors ${
        over ? 'border-emerald-500 bg-emerald-50' : 'border-stone-300 bg-emerald-50/40 hover:border-emerald-400 hover:bg-emerald-50'
      }`}
    >
      <input
        ref={ref} type="file" accept={accept} multiple={multiple} className="sr-only"
        aria-label="Chọn tệp từ máy"
        onChange={(e) => { pick(e.target.files); e.target.value = '' }}
      />
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-emerald-100 to-teal-100">
        <Upload className="h-6 w-6 text-emerald-600" />
      </div>
      <div>
        <p className="font-medium text-emerald-900">{label}</p>
        {hint && <p className="mt-1 text-sm text-stone-500">{hint}</p>}
      </div>
    </div>
  )
}

// ─── Run button ──────────────────────────────────────────
export function RunButton({
  loading, onClick, children, disabled, cost,
}: {
  loading: boolean
  onClick: () => void
  children: React.ReactNode
  disabled?: boolean
  cost?: number
}) {
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho giá công cụ
  return (
    <Button
      onClick={onClick}
      disabled={loading || disabled}
      className="h-12 w-full gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-base font-semibold text-white shadow-lg shadow-emerald-600/20 transition hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50"
    >
      {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Zap className="h-5 w-5" />}
      {loading ? 'Đang xử lý…' : children}
      {cost !== undefined && cost > 0 && !loading && (
        <span className="ml-1 rounded-full bg-black/10 px-2 py-0.5 text-xs font-bold">−{fmtXuWithUsd(cost, rate)}</span>
      )}
    </Button>
  )
}

export function DownloadButton({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <Button
      onClick={onClick}
      className="h-11 gap-2 rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-500"
    >
      <Download className="h-4 w-4" />
      {children}
    </Button>
  )
}

// ─── Before/After compare ────────────────────────────────
export function BeforeAfter({ before, after }: { before: string; after: string }) {
  const [pos, setPos] = useState(50)
  return (
    <div className="space-y-3">
      <div className="relative overflow-hidden rounded-2xl border border-stone-200 bg-stone-900">
        { }
        <img src={after} alt="Sau khi xử lý" className="block max-h-[440px] w-full object-contain" />
        <div className="absolute inset-0 overflow-hidden" style={{ width: `${pos}%` }}>
          { }
          <img
            src={before} alt="Trước khi xử lý"
            className="block h-full w-auto max-w-none object-contain"
            style={{ width: `${(100 / Math.max(pos, 1)) * 100}%`, maxWidth: 'none' }}
          />
        </div>
        <div className="absolute inset-y-0 w-0.5 bg-white/80" style={{ left: `${pos}%` }} />
        <span className="absolute left-3 top-3 rounded-full bg-stone-900/70 px-2 py-1 text-xs font-semibold text-white">Trước</span>
        <span className="absolute right-3 top-3 rounded-full bg-stone-900/70 px-2 py-1 text-xs font-semibold text-white">Sau</span>
      </div>
      <input
        type="range" min={0} max={100} value={pos}
        onChange={(e) => setPos(Number(e.target.value))}
        aria-label="Kéo để so sánh trước sau"
        className="w-full"
      />
    </div>
  )
}

// ─── Tool page shell ─────────────────────────────────────
export function ToolPage({ tool, children }: { tool: Tool; children: React.ReactNode }) {
  const back = useView((s) => s.back)
  const freeLeft = useWallet((s) => s.freeLeft)
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho giá công cụ
  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-16">
      <button
        onClick={back}
        className="mb-4 flex items-center gap-1.5 text-sm text-emerald-700 transition hover:text-emerald-900"
      >
        <ArrowLeft className="h-4 w-4" /> Quay lại
      </button>
      <div className="mb-6 flex items-start gap-4">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 shadow-lg shadow-emerald-600/20">
          <ToolIcon name={tool.icon} className="h-6 w-6 text-white" />
        </div>
        <div className="min-w-0">
          <h1 className="text-xl font-bold text-emerald-950 sm:text-2xl">{tool.name}</h1>
          <p className="mt-1 text-sm leading-relaxed text-stone-600">{tool.desc}</p>
        </div>
      </div>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <span className={`rounded-full px-3 py-1 text-xs font-bold ${tool.price > 0 ? 'bg-amber-500/10 text-amber-700' : 'bg-emerald-600/10 text-emerald-700'}`}>
          {tool.price > 0 ? `GIÁ ${fmtXuWithUsd(tool.price, rate)} · CHỈ TRỪ KHI THÀNH CÔNG` : 'MIỄN PHÍ'}
        </span>
        <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-bold text-emerald-700">
          CÒN {freeLeft}/2 LƯỢT MIỄN PHÍ HÔM NAY
        </span>
        <span className="flex items-center gap-1 rounded-full bg-stone-100 px-3 py-1 text-xs font-medium text-stone-600">
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" /> Xử lý riêng tư
        </span>
      </div>
      {children}
    </div>
  )
}

// ─── Chip số dư ví ─────────────────────────────────────
export function XuChip() {
  const xu = useWallet((s) => s.xu)
  const freeLeft = useWallet((s) => s.freeLeft)
  const go = useView((s) => s.go)
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho chip ví
  return (
    <button
      onClick={() => go({ name: 'wallet' })}
      className="flex h-9 items-center gap-1.5 whitespace-nowrap rounded-full border border-amber-300 bg-amber-50 px-3 text-sm font-bold text-amber-700 transition hover:bg-amber-100"
      aria-label="Ví tiền"
      title={freeLeft > 0 ? `Còn ${freeLeft}/2 lượt miễn phí hôm nay` : 'Hết 2 lượt miễn phí hôm nay — mỗi lần chạy tính tiền vào ví'}
    >
      <Coins className="h-4 w-4" />
      {fmtXuWithUsd(xu, rate)}
    </button>
  )
}

// ─── Image pick + preview ────────────────────────────────
export function ImagePick({
  url, onPick, onClear,
}: {
  url: string | null
  onPick: (f: File) => void
  onClear: () => void
}) {
  if (!url) {
    return (
      <FileDrop
        accept="image/png,image/jpeg,image/webp"
        onFiles={(fs) => onPick(fs[0])}
        label="Thả ảnh vào đây"
        hint="PNG · JPG · WEBP — ảnh xử lý ngay trên máy bạn"
      />
    )
  }
  return (
    <div className="relative overflow-hidden rounded-2xl border border-stone-200 bg-stone-100">
      <img src={url} alt="Ảnh đã chọn" className="mx-auto max-h-[360px] w-full object-contain" />
      <Button variant="secondary" size="sm" className="absolute right-3 top-3" onClick={onClear}>
        Đổi ảnh
      </Button>
    </div>
  )
}

export async function dataUrlToBlob(dataUrl: string): Promise<Blob> {
  const res = await fetch(dataUrl)
  return res.blob()
}

// ─── Hook: chạy tác vụ AI — giữ chỗ lượt (miễn phí hoặc trừ tiền ví) trước, hoàn lại khi lỗi ─────
export function useAiRun() {
  const { charge, refund, logFailed } = useWallet()
  const xu = useWallet((s) => s.xu)
  const freeLeft = useWallet((s) => s.freeLeft)
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho báo phí
  const run = useCallback(
    async (tool: Tool, action: () => Promise<void>, successNote?: string) => {
      const ok = charge(tool)
      if (!ok) {
        toast.error(`Cần ${fmtXuWithUsd(tool.price, rate)} để chạy ${tool.name}`, {
          description: 'Hết 2 lượt miễn phí hôm nay. Kiếm thêm: đăng bài, bình luận, điểm danh, xem video đều có thưởng — hoặc nạp qua QR ngân hàng trong Ví tiền.',
        })
        return
      }
      try {
        await action()
        toast.success(successNote || 'Thành công!')
      } catch (e) {
        refund(tool)
        logFailed(tool)
        toast.error(e instanceof Error ? e.message : 'Xử lý thất bại — thử lại nhé', {
          description: 'Đã hoàn lại tiền nếu lượt này bị trừ.',
        })
      }
    },
    [charge, refund, logFailed, rate]
  )
  return { run, xu, freeLeft }
}
