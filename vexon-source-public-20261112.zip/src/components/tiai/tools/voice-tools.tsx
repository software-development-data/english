'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Textarea } from '@/components/ui/textarea'
import {
  AudioWaveform, CircleStop, Copy, FileUp, Info, Mic, Trash2,
} from 'lucide-react'
import { toast } from 'sonner'
import { ToolPage, RunButton, useAiRun } from '../shared'
import type { Tool } from '@/lib/tiai/tools'

// ─── Hồ sơ giọng AI khả dụng (7 giọng studio) ────────────
const VOICE_PROFILES: { id: string; label: string; desc: string; hz: [number, number] }[] = [
  { id: 'jam', label: 'Jam', desc: 'Nam Anh · trầm lịch lãm', hz: [70, 130] },
  { id: 'douji', label: 'Đậu Ki', desc: 'Nam · tự nhiên mượt', hz: [110, 170] },
  { id: 'kazi', label: 'Kazi', desc: 'Chuẩn · rõ ràng dứt khoát', hz: [120, 185] },
  { id: 'xiaochen', label: 'Tiểu Trần', desc: 'Trầm ổn · chuyên nghiệp', hz: [160, 215] },
  { id: 'tongtong', label: 'Tổng Tổng', desc: 'Nữ ấm áp · thân thiện', hz: [190, 250] },
  { id: 'luodo', label: 'Lạc Đa', desc: 'Nữ · truyền cảm xúc', hz: [210, 275] },
  { id: 'chuichui', label: 'Chu Chuích', desc: 'Nữ trẻ · hoạt bát sáng', hz: [250, 340] },
]

/** Tự động chọn giọng gợi ý theo cao độ mẫu (Hz) */
function suggestVoices(pitch: number): string[] {
  return [...VOICE_PROFILES]
    .map((v) => {
      const mid = (v.hz[0] + v.hz[1]) / 2
      const half = (v.hz[1] - v.hz[0]) / 2
      const dist = Math.max(0, Math.abs(pitch - mid) - half)
      return { id: v.id, dist }
    })
    .sort((a, b) => a.dist - b.dist)
    .slice(0, 3)
    .map((v) => v.id)
}

// ─── Phân tích cao độ mẫu giọng (autocorrelation, chạy trên máy bạn) ──
async function analyzeVoice(file: Blob): Promise<{ duration: number; pitch: number } | null> {
  try {
    const ctx = new AudioContext()
    const buf = await ctx.decodeAudioData(await file.arrayBuffer())
    const ch = buf.getChannelData(0)
    const sr = buf.sampleRate
    const win = 4096
    const pitches: number[] = []
    for (let i = 0; i < 5; i++) {
      const start = Math.floor(Math.max(0, (ch.length - win) * (i / 4)))
      const seg = ch.slice(start, start + win)
      let rms = 0
      for (let j = 0; j < seg.length; j++) rms += seg[j] * seg[j]
      rms = Math.sqrt(rms / seg.length)
      if (rms < 0.008) continue // bỏ đoạn im lặng
      const p = autocorrelPitch(seg, sr)
      if (p) pitches.push(p)
    }
    await ctx.close()
    if (!pitches.length) return { duration: buf.duration, pitch: 0 }
    pitches.sort((a, b) => a - b)
    return { duration: buf.duration, pitch: Math.round(pitches[Math.floor(pitches.length / 2)]) }
  } catch {
    return null
  }
}

function autocorrelPitch(seg: Float32Array, sr: number): number | null {
  const minLag = Math.floor(sr / 400)
  const maxLag = Math.min(Math.floor(sr / 70), seg.length - 1)
  let energy = 0
  for (let i = 0; i < seg.length; i++) energy += seg[i] * seg[i]
  if (energy === 0) return null
  let bestLag = 0
  let bestCorr = 0
  for (let lag = minLag; lag <= maxLag; lag++) {
    let corr = 0
    for (let i = 0; i < seg.length - lag; i++) corr += seg[i] * seg[i + lag]
    if (corr > bestCorr) {
      bestCorr = corr
      bestLag = lag
    }
  }
  if (bestCorr / energy < 0.35) return null // tín nhiễu / không có cao độ rõ
  return sr / bestLag
}

function pitchLabel(pitch: number): string {
  if (!pitch) return 'Chưa xác định'
  if (pitch < 130) return `Nam trầm · ${pitch} Hz`
  if (pitch < 175) return `Nam trung · ${pitch} Hz`
  if (pitch < 220) return `Giọng trung · ${pitch} Hz`
  if (pitch < 270) return `Nữ trung · ${pitch} Hz`
  return `Nữ sáng · ${pitch} Hz`
}

// ─── Hook ghi âm micro (tối đa 15 giây) ──────────────────
function useRecorder(maxSeconds = 15) {
  const [recording, setRecording] = useState(false)
  const [seconds, setSeconds] = useState(0)
  const [blob, setBlob] = useState<Blob | null>(null)
  const [url, setUrl] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const mrRef = useRef<MediaRecorder | null>(null)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const stop = useCallback(() => {
    if (mrRef.current?.state === 'recording') mrRef.current.stop()
    setRecording(false)
    if (timerRef.current) clearInterval(timerRef.current)
  }, [])

  /** Đặt mẫu thủ công (tải tệp lên / xóa) — luôn đồng bộ blob + url xem trước */
  const setSample = useCallback((b: Blob | null) => {
    setBlob(b)
    setUrl((old) => {
      if (old) URL.revokeObjectURL(old)
      return b ? URL.createObjectURL(b) : null
    })
  }, [])

  const start = useCallback(async () => {
    setError(null)
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mr = new MediaRecorder(stream)
      const chunks: Blob[] = []
      mr.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data)
      }
      mr.onstop = () => {
        const b = new Blob(chunks, { type: mr.mimeType || 'audio/webm' })
        setBlob(b)
        setUrl(URL.createObjectURL(b))
        stream.getTracks().forEach((t) => t.stop())
      }
      mrRef.current = mr
      mr.start()
      setRecording(true)
      setSeconds(0)
      setBlob(null)
      setUrl(null)
      // Đếm giờ ngay trong callback của timer — tự dừng khi đủ thời lượng
      let elapsed = 0
      timerRef.current = setInterval(() => {
        elapsed++
        setSeconds(elapsed)
        if (elapsed >= maxSeconds) stop()
      }, 1000)
    } catch {
      setError('Không truy cập được micro — hãy cho phép quyền ghi âm trên trình duyệt hoặc dùng nút tải tệp lên.')
    }
  }, [maxSeconds, stop])

  useEffect(() => () => {
    if (timerRef.current) clearInterval(timerRef.current)
  }, [])

  return { recording, seconds, blob, url, error, start, stop, setSample }
}

function fmtSec(s: number) {
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

// ─── Khối chọn mẫu chung: ghi âm hoặc tải tệp lên ──────
function SamplePicker({
  rec, accept, onFile,
}: {
  rec: ReturnType<typeof useRecorder>
  accept: string
  onFile: (f: File) => void
}) {
  const fileRef = useRef<HTMLInputElement>(null)
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        {!rec.recording ? (
          <Button onClick={rec.start} className="gap-2 rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-500">
            <Mic className="h-4 w-4" /> Ghi âm mẫu giọng
          </Button>
        ) : (
          <Button onClick={rec.stop} variant="destructive" className="gap-2 rounded-xl font-semibold">
            <CircleStop className="h-4 w-4" /> Dừng ({fmtSec(rec.seconds)}/0:15)
          </Button>
        )}
        <Button onClick={() => fileRef.current?.click()} variant="outline" className="gap-2 rounded-xl">
          <FileUp className="h-4 w-4" /> Dùng tệp có sẵn
        </Button>
        {rec.blob && (
          <Button onClick={() => rec.setSample(null)} variant="ghost" size="sm" className="gap-1 text-stone-500">
            <Trash2 className="h-3.5 w-3.5" /> Xóa mẫu
          </Button>
        )}
        <input
          ref={fileRef} type="file" accept={accept} className="sr-only" aria-label="Chọn tệp âm thanh"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); e.target.value = '' }}
        />
      </div>
      {rec.recording && (
        <div className="flex items-center gap-1.5" aria-hidden>
          {[0, 1, 2, 3, 4, 5, 6].map((i) => (
            <span
              key={i}
              className="w-1.5 animate-pulse rounded-full bg-emerald-500"
              style={{ height: `${8 + ((i * 7) % 18)}px`, animationDelay: `${i * 90}ms` }}
            />
          ))}
          <span className="ml-2 text-xs font-semibold text-emerald-700">Đang ghi… {fmtSec(rec.seconds)}</span>
        </div>
      )}
      {rec.error && <p className="text-xs font-medium text-red-600">{rec.error}</p>}
      {rec.url && !rec.recording && (
        <audio src={rec.url} controls className="h-10 w-full max-w-md" aria-label="Nghe lại mẫu giọng" />
      )}
    </div>
  )
}

// ─── NHÂN BẢN GIỌNG NÓI ─────────────────────────────────
export function NhanBanGiongNoi({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const rec = useRecorder(15)
  const [analysis, setAnalysis] = useState<{ duration: number; pitch: number } | null>(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [voice, setVoice] = useState('tongtong')
  const [speed, setSpeed] = useState(1)
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)

  const suggested = analysis && analysis.pitch ? suggestVoices(analysis.pitch) : []

  // Có mẫu → phân tích cao độ ngay trên máy
  useEffect(() => {
    if (!rec.blob) {
      setAnalysis(null)
      return
    }
    let alive = true
    setAnalyzing(true)
    analyzeVoice(rec.blob).then((a) => {
      if (!alive) return
      setAnalysis(a)
      setAnalyzing(false)
      if (a && a.pitch) {
        const top = suggestVoices(a.pitch)[0]
        setVoice(top)
      }
    })
    return () => { alive = false }
  }, [rec.blob])

  const pickFile = (f: File) => {
    if (f.size > 10 * 1024 * 1024) {
      toast.error('Tệp quá lớn — tối đa 10MB')
      return
    }
    rec.setSample(f)
  }

  const generate = () =>
    run(
      tool,
      async () => {
        setLoading(true)
        try {
          const res = await fetch('/api/tiai/voice', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text, voice, speed }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'Tạo giọng nói thất bại')
          setResult(data.audio)
        } finally {
          setLoading(false)
        }
      },
      'Giọng đọc AI đã sẵn sàng để nghe & tải về'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        {/* 1 — Mẫu giọng */}
        <div className="space-y-3 rounded-2xl border border-stone-200 bg-white p-4 shadow-sm">
          <p className="flex items-center gap-2 text-sm font-bold text-emerald-900">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-xs text-white">1</span>
            Mẫu giọng của bạn (5–15 giây)
          </p>
          <SamplePicker rec={rec} accept="audio/*" onFile={pickFile} />
          {analyzing && <p className="text-xs font-medium text-emerald-700">Đang phân tích cao độ mẫu giọng…</p>}
          {analysis && !analyzing && (
            <div className="flex flex-wrap items-center gap-2 rounded-xl bg-emerald-50 px-3 py-2 text-xs text-emerald-800">
              <AudioWaveform className="h-4 w-4 shrink-0" />
              <b>{pitchLabel(analysis.pitch)}</b>
              <span>· mẫu {analysis.duration.toFixed(1)}s · đã chọn giọng khớp nhất bên dưới</span>
            </div>
          )}
          <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-stone-500">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            AI đo cao độ (Hz) của mẫu trên chính máy bạn để gợi ý giọng studio khớp nhất — mẫu giọng không được tải lên server.
          </p>
        </div>

        {/* 2 — Chọn giọng AI */}
        <div className="space-y-3 rounded-2xl border border-stone-200 bg-white p-4 shadow-sm">
          <p className="flex items-center gap-2 text-sm font-bold text-emerald-900">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-xs text-white">2</span>
            Chọn giọng AI khớp với mẫu
          </p>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {VOICE_PROFILES.map((v) => {
              const active = voice === v.id
              const hot = suggested.includes(v.id)
              return (
                <button
                  key={v.id}
                  onClick={() => setVoice(v.id)}
                  className={`relative rounded-xl border p-2.5 text-left transition ${
                    active ? 'border-emerald-500 bg-emerald-50 shadow-sm' : 'border-stone-200 hover:border-emerald-300 hover:bg-emerald-50/50'
                  }`}
                >
                  {hot && (
                    <span className="absolute -top-1.5 right-2 rounded-full bg-amber-400 px-1.5 py-0.5 text-[9px] font-bold text-amber-950">
                      KHỚP MẪU
                    </span>
                  )}
                  <p className="text-sm font-bold text-emerald-950">{v.label}</p>
                  <p className="text-[11px] text-stone-500">{v.desc}</p>
                </button>
              )
            })}
          </div>
        </div>

        {/* 3 — Nội dung & tốc độ */}
        <div className="space-y-3 rounded-2xl border border-stone-200 bg-white p-4 shadow-sm">
          <p className="flex items-center gap-2 text-sm font-bold text-emerald-900">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-xs text-white">3</span>
            Nội dung cần đọc
          </p>
          <div className="space-y-2">
            <Label htmlFor="voice-text">Văn bản (tiếng Việt hoặc đa ngôn ngữ)</Label>
            <Textarea
              id="voice-text"
              value={text}
              onChange={(e) => setText(e.target.value.slice(0, 1024))}
              rows={4}
              maxLength={1024}
              placeholder="VD: Xin chào, cửa hàng chúng tôi vừa khai trương với ưu đãi giảm 50% toàn bộ mặt hàng…"
            />
            <p className={`text-right text-[11px] ${text.length > 980 ? 'font-semibold text-amber-600' : 'text-stone-400'}`}>
              {text.length}/1024 ký tự
            </p>
          </div>
          <div className="space-y-2">
            <Label>Tốc độ đọc: <b className="text-emerald-700">{speed.toFixed(1)}×</b></Label>
            <Slider value={[speed]} min={0.5} max={2} step={0.1} onValueChange={([v]) => setSpeed(v)} aria-label="Tốc độ đọc" />
            <div className="flex gap-2">
              {[0.8, 1, 1.2, 1.5].map((s) => (
                <button
                  key={s}
                  onClick={() => setSpeed(s)}
                  className={`rounded-full border px-2.5 py-0.5 text-[11px] font-semibold transition ${
                    speed === s ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-stone-300 text-stone-500 hover:bg-stone-100'
                  }`}
                >
                  {s}×
                </button>
              ))}
            </div>
          </div>
        </div>

        <RunButton
          loading={loading}
          onClick={generate}
          disabled={text.trim().length < 2}
          cost={tool.price}
        >
          Tạo giọng nói từ văn bản
        </RunButton>
        <p className="text-center text-xs text-stone-500">Miễn phí 100% — tạo giọng đọc thoải mái không giới hạn.</p>

        {result && (
          <div className="space-y-3 rounded-2xl border border-stone-200 bg-white p-4 shadow-sm">
            <p className="text-sm font-bold text-emerald-900">Giọng đọc đã xong</p>
            <audio src={result} controls className="h-11 w-full" aria-label="Phát giọng đọc AI" />
            <div className="flex gap-2">
              <a
                href={result}
                download={`giong-ai-${voice}-${Date.now()}.wav`}
                className="flex h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-600 text-sm font-semibold text-white transition hover:bg-emerald-500"
              >
                Tải tệp WAV
              </a>
              <Button variant="outline" className="h-11 rounded-xl" onClick={generate}>
                Tạo lại lần nữa
              </Button>
            </div>
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ─── GIỌNG NÓI THÀNH VĂN BẢN ────────────────────────────
export function GiongNoiThanhVanBan({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const rec = useRecorder(60)
  const [loading, setLoading] = useState(false)
  const [text, setText] = useState('')

  const pickFile = (f: File) => {
    if (f.size > 10 * 1024 * 1024) {
      toast.error('Tệp quá lớn — tối đa 10MB')
      return
    }
    rec.setSample(f)
  }

  const blobToBase64 = (b: Blob) =>
    new Promise<string>((resolve, reject) => {
      const r = new FileReader()
      r.onload = () => {
        const s = String(r.result)
        resolve(s.slice(s.indexOf(',') + 1))
      }
      r.onerror = reject
      r.readAsDataURL(b)
    })

  const transcribe = () =>
    run(
      tool,
      async () => {
        const file = rec.blob
        if (!file) throw new Error('Chưa có tệp âm thanh')
        setLoading(true)
        try {
          const res = await fetch('/api/tiai/transcribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ audio: await blobToBase64(file) }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'Nhận diện thất bại')
          setText(data.text)
        } finally {
          setLoading(false)
        }
      },
      'Đã chép xong nội dung âm thanh'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <div className="space-y-3 rounded-2xl border border-stone-200 bg-white p-4 shadow-sm">
          <SamplePicker rec={rec} accept="audio/*" onFile={pickFile} />
          <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-stone-500">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            Hỗ trợ ghi âm tới 60 giây hoặc tệp MP3/WAV/M4A tối đa 10MB. Nói rõ ràng, tránh tiếng ồn xung quanh để kết quả chuẩn nhất.
          </p>
        </div>

        <RunButton loading={loading} onClick={transcribe} disabled={!rec.blob} cost={tool.price}>
          Chuyển thành văn bản
        </RunButton>

        {text && (
          <div className="space-y-3 rounded-2xl border border-stone-200 bg-white p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <p className="text-sm font-bold text-emerald-900">Kết quả</p>
              <Button
                variant="ghost"
                size="sm"
                className="gap-1 text-emerald-700"
                onClick={() => {
                  navigator.clipboard.writeText(text)
                  toast.success('Đã sao chép văn bản')
                }}
              >
                <Copy className="h-3.5 w-3.5" /> Sao chép
              </Button>
            </div>
            <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={6} aria-label="Văn bản nhận diện được" />
          </div>
        )}
      </div>
    </ToolPage>
  )
}
