'use client'

// ============ XÓA WATERMARK VIDEO (ProPainter-style) ============
// Quy trình lấy cảm hứng từ ProPainter (github.com/sczhou/ProPainter):
//  1) Trích khung hình theo fps        (frame extraction)
//  2) Vá vùng mask bằng môi trường xung quanh            (inpainting)
//  3) Truyền lan theo thời gian — trộn patch giữa các khung liền kề
//     (temporal propagation thay cho optical flow) → khử nháy
//  4) Dựng lại video WebM bằng MediaRecorder
// Chạy hoàn toàn trên máy người dùng — không tốn tiền GPU.
// Bản đầy đủ Optical Flow + Transformer có thể nối máy chủ GPU sau này.

import { useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Loader2, Undo2, Film, Info } from 'lucide-react'
import { FileDrop, ToolPage, RunButton, useAiRun } from '../shared'
import { downloadBlob } from '@/lib/tiai/image'
import type { Tool } from '@/lib/tiai/tools'

interface Rect { x: number; y: number; w: number; h: number }

const MAX_SIDE = 720 // hạ độ phân giải xử lý cho mượt máy thường

export function VideoInpaint({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [file, setFile] = useState<File | null>(null)
  const [url, setUrl] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [stage, setStage] = useState('')
  const [seconds, setSeconds] = useState('5')
  const [fps, setFps] = useState('12')
  const [keepAudio, setKeepAudio] = useState(true)
  const [rects, setRects] = useState<Rect[]>([])
  const [result, setResult] = useState<{ url: string; blob: Blob } | null>(null)
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const overlayRef = useRef<HTMLCanvasElement | null>(null)
  const drawing = useRef<{ x: number; y: number } | null>(null)
  const liveRect = useRef<Rect | null>(null)
  const rectsRef = useRef<Rect[]>([])
  rectsRef.current = rects

  const pick = (f?: File) => {
    if (!f) return
    if (f.size > 60_000_000) { alert('Video tối đa ~60MB — hãy cắt ngắn trước nhé'); return }
    setFile(f)
    setResult(null)
    setRects([])
    setUrl(URL.createObjectURL(f))
  }
  const clear = () => { setFile(null); setUrl(null); setResult(null); setRects([]) }

  // Vẽ lại overlay: các rect đã chốt + rect đang kéo
  const redraw = () => {
    const c = overlayRef.current
    const v = videoRef.current
    if (!c || !v) return
    if (c.width !== v.videoWidth && v.videoWidth) { c.width = v.videoWidth; c.height = v.videoHeight }
    const ctx = c.getContext('2d')!
    ctx.clearRect(0, 0, c.width, c.height)
    for (const r of [...rectsRef.current, ...(liveRect.current ? [liveRect.current] : [])]) {
      ctx.fillStyle = 'rgba(239,68,68,0.35)'
      ctx.fillRect(r.x, r.y, r.w, r.h)
      ctx.strokeStyle = 'rgba(239,68,68,0.95)'
      ctx.lineWidth = Math.max(2, c.width / 300)
      ctx.strokeRect(r.x, r.y, r.w, r.h)
    }
  }

  // Vẽ vùng watermark — native listener trực tiếp trên canvas,
  // toạ độ lấy tươi từ DOM mỗi sự kiện + chặn giá trị không hợp lệ
  useEffect(() => {
    const c = overlayRef.current
    if (!c) return
    const getXY = (e: PointerEvent) => {
      const r = c.getBoundingClientRect()
      if (!r.width || !r.height) return null
      const x = ((e.clientX - r.left) / r.width) * c.width
      const y = ((e.clientY - r.top) / r.height) * c.height
      if (!Number.isFinite(x) || !Number.isFinite(y)) return null
      return { x, y }
    }
    const onDown = (e: PointerEvent) => {
      const p = getXY(e)
      if (!p) return
      drawing.current = p
      liveRect.current = null
    }
    const onMove = (e: PointerEvent) => {
      if (!drawing.current) return
      const p = getXY(e)
      const d = drawing.current
      if (!p || !d) return
      liveRect.current = { x: Math.min(d.x, p.x), y: Math.min(d.y, p.y), w: Math.abs(p.x - d.x), h: Math.abs(p.y - d.y) }
      redraw()
    }
    const onUp = () => {
      const r = liveRect.current
      drawing.current = null
      liveRect.current = null
      if (r && r.w >= 8 && r.h >= 8) setRects((rs) => [...rs, r])
      else redraw()
    }
    c.addEventListener('pointerdown', onDown)
    c.addEventListener('pointermove', onMove)
    c.addEventListener('pointerup', onUp)
    c.addEventListener('pointerleave', onUp)
    c.addEventListener('pointercancel', onUp)
    return () => {
      c.removeEventListener('pointerdown', onDown)
      c.removeEventListener('pointermove', onMove)
      c.removeEventListener('pointerup', onUp)
      c.removeEventListener('pointerleave', onUp)
      c.removeEventListener('pointercancel', onUp)
    }
  }, [url])

  useEffect(() => { redraw() }, [rects, url])

  // ─── Pipeline xử lý ───────────────────────────────────────
  const seek = (v: HTMLVideoElement, t: number) =>
    new Promise<void>((res) => {
      const on = () => { v.removeEventListener('seeked', on); res() }
      v.addEventListener('seeked', on)
      v.currentTime = t
      setTimeout(on, 700) // an toàn với vài trình duyệt khó tính
    })

  const process = () =>
    run(
      tool,
      async () => {
        const v = videoRef.current
        const overlay = overlayRef.current
        if (!v || !overlay) throw new Error('Chưa có video')
        if (rects.filter((r) => r.w > 4 && r.h > 4).length === 0) throw new Error('Hãy quét ít nhất 1 vùng watermark trên video')
        setBusy(true)
        try {
          const fpsN = Number(fps), secN = Number(seconds)
          const dur = Math.min(v.duration || secN, secN)
          const total = Math.max(2, Math.min(240, Math.round(dur * fpsN)))
          // scale xử lý
          const vw = v.videoWidth || 640, vh = v.videoHeight || 360
          const scale = Math.min(1, MAX_SIDE / Math.max(vw, vh))
          const W = Math.round(vw * scale), H = Math.round(vh * scale)
          const sx = scale, sy = scale // rect → tọa độ xử lý

          // 1) Trích khung hình
          const frames: ImageData[] = []
          for (let i = 0; i < total; i++) {
            setStage(`Đang trích khung hình ${i + 1}/${total}…`)
            await seek(v, Math.min(v.duration - 0.01, i / fpsN))
            const c = document.createElement('canvas')
            c.width = W; c.height = H
            const ctx = c.getContext('2d')!
            ctx.drawImage(v, 0, 0, W, H)
            frames.push(ctx.getImageData(0, 0, W, H))
          }

          // 2+3) Vá mask + truyền lan thời gian (trộn patch khung kề → khử nháy)
          const masks = rects.filter((r) => r.w > 4).map((r) => ({ x: Math.round(r.x * sx), y: Math.round(r.y * sy), w: Math.round(r.w * sx), h: Math.round(r.h * sy) }))
          const outCanvases: HTMLCanvasElement[] = []
          let prevPatch: ImageData[] = []
          for (let i = 0; i < frames.length; i++) {
            if (i % 5 === 0) setStage(`Đang vá & truyền lan (optical-flow lite) ${i + 1}/${frames.length}…`)
            const f = frames[i]
            const d = f.data
            const curPatch: ImageData[] = []
            for (let m = 0; m < masks.length; m++) {
              const r = masks[m]
              const x0 = Math.max(0, r.x), y0 = Math.max(0, r.y)
              const x1 = Math.min(W - 1, r.x + r.w), y1 = Math.min(H - 1, r.y + r.h)
              const pw = x1 - x0 + 1, ph = y1 - y0 + 1
              const patch = new ImageData(pw, ph)
              // Vá: lấy từ dải pixel ngay trên & dưới vùng (mirror gần nhất)
              for (let yy = 0; yy < ph; yy++) {
                // offset mượt theo trục y — dải nguồn phản chiếu từ mép trên/dưới
                const srcYTop = y0 - 2 - (ph - 1 - yy)
                const srcYBot = y1 + 2 + yy
                const useTop = Math.abs(srcYTop - y0) <= Math.abs(srcYBot - y1) && srcYTop >= 0
                const sy2 = useTop ? srcYTop : Math.min(H - 1, srcYBot)
                for (let xx = 0; xx < pw; xx++) {
                  const sxx = Math.min(W - 1, x0 + xx)
                  const s = (sy2 * W + sxx) * 4
                  const tIdx = (yy * pw + xx) * 4
                  patch.data[tIdx] = d[s]
                  patch.data[tIdx + 1] = d[s + 1]
                  patch.data[tIdx + 2] = d[s + 2]
                  patch.data[tIdx + 3] = 255
                }
              }
              // Truyền lan thời gian: trộn patch khung trước (giảm nháy — thay optical flow)
              const pv = prevPatch[m]
              if (pv && pv.width === patch.width && pv.height === patch.height) {
                const A = 0.45
                for (let k = 0; k < patch.data.length; k += 4) {
                  patch.data[k] = patch.data[k] * (1 - A) + pv.data[k] * A
                  patch.data[k + 1] = patch.data[k + 1] * (1 - A) + pv.data[k + 1] * A
                  patch.data[k + 2] = patch.data[k + 2] * (1 - A) + pv.data[k + 2] * A
                }
              }
              curPatch.push(patch)
              // dán patch vào khung
              for (let yy = 0; yy < ph; yy++) {
                for (let xx = 0; xx < pw; xx++) {
                  const sIdx = (yy * pw + xx) * 4
                  const tIdx = ((y0 + yy) * W + (x0 + xx)) * 4
                  d[tIdx] = patch.data[sIdx]
                  d[tIdx + 1] = patch.data[sIdx + 1]
                  d[tIdx + 2] = patch.data[sIdx + 2]
                }
              }
            }
            prevPatch = curPatch
            const oc = document.createElement('canvas')
            oc.width = W; oc.height = H
            oc.getContext('2d')!.putImageData(f, 0, 0)
            outCanvases.push(oc)
          }

          // 4) Dựng video WebM (MediaRecorder + captureStream)
          setStage('Đang dựng video (MediaRecorder)…')
          const stream = outCanvases[0].captureStream(fpsN) as MediaStream
          let audioTrack: MediaStreamTrack | null = null
          if (keepAudio) {
            try {
              const withAudio = (v as HTMLVideoElement & { captureStream?: () => MediaStream }).captureStream?.()
              audioTrack = withAudio?.getAudioTracks?.()[0] || null
              if (audioTrack) stream.addTrack(audioTrack)
            } catch { /* không lấy được tiếng — vẫn xuất video câm */ }
          }
          const mime = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].find((m) => MediaRecorder.isTypeSupported(m)) || 'video/webm'
          const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 2_500_000 })
          const chunks: BlobPart[] = []
          rec.ondataavailable = (e) => e.data.size > 0 && chunks.push(e.data)
          const done = new Promise<Blob>((res) => { rec.onstop = () => res(new Blob(chunks, { type: 'video/webm' })) })
          rec.start()
          const drawCtx = outCanvases[0].getContext('2d')!
          const interval = 1000 / fpsN
          await new Promise<void>((res) => {
            let i = 0
            const timer = setInterval(() => {
              if (i >= outCanvases.length) { clearInterval(timer); res(); return }
              drawCtx.drawImage(outCanvases[i], 0, 0)
              i++
            }, interval)
          })
          await new Promise((r) => setTimeout(r, 350))
          rec.stop()
          const blob = await done
          if (blob.size < 1000) throw new Error('Trình duyệt không hỗ trợ ghi video (MediaRecorder)')
          setResult({ url: URL.createObjectURL(blob), blob })
        } finally {
          setBusy(false)
          setStage('')
        }
      },
      'Video đã được vá watermark — nháy gần như triệt tiêu'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        {!url ? (
          <FileDrop accept="video/mp4,video/webm,video/quicktime,video/*" onFiles={(fs) => pick(fs[0])} label="Thả video có watermark vào đây" hint="MP4 / WebM · xử lý ngay trên máy bạn — tối đa ~60MB" />
        ) : (
          <div className="flex items-center justify-between rounded-xl border bg-card p-3">
            <p className="flex items-center gap-2 truncate text-sm text-emerald-900"><Film className="h-4 w-4 shrink-0" /> {file?.name}</p>
            <button onClick={clear} className="text-xs text-stone-600 underline">Chọn video khác</button>
          </div>
        )}

        {url && (
          <div className="space-y-2">
            <Label>Quét vùng watermark (kéo chuột vẽ khung đỏ — được nhiều vùng)</Label>
            <div className="relative inline-block max-w-full overflow-hidden rounded-xl border">
              <video ref={videoRef} src={url} muted={false} playsInline controls className="max-h-[55vh] w-auto max-w-full" onLoadedMetadata={redraw} />
              <canvas
                ref={overlayRef}
                className="pointer-events-auto absolute inset-0 h-full w-full cursor-crosshair touch-none"
              />
            </div>
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <Button size="sm" variant="outline" onClick={() => { setRects([]); redraw() }}><Undo2 className="mr-1 h-3.5 w-3.5" /> Xoá vùng ({rects.filter((r) => r.w > 0).length})</Button>
              <span className="flex items-center gap-1 text-xs text-stone-500"><Info className="h-3.5 w-3.5" /> Vẽ khung bọc chặt logo/chữ đè — có thể vẽ nhiều vùng</span>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label>Xử lý bao lâu (tính từ đầu)</Label>
                <Select value={seconds} onValueChange={setSeconds}>
                  <SelectTrigger aria-label="Thời lượng xử lý"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="3">3 giây</SelectItem><SelectItem value="5">5 giây</SelectItem><SelectItem value="10">10 giây</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Số khung/giây</Label>
                <Select value={fps} onValueChange={setFps}>
                  <SelectTrigger aria-label="Số khung trên giây"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="10">10 fps (nhanh)</SelectItem><SelectItem value="12">12 fps (cân bằng)</SelectItem><SelectItem value="15">15 fps (mượt)</SelectItem></SelectContent>
                </Select>
              </div>
              <label className="flex cursor-pointer items-end gap-2 pb-2 text-sm">
                <Checkbox checked={keepAudio} onCheckedChange={(c) => setKeepAudio(Boolean(c))} /> Giữ âm thanh (thử nghiệm)
              </label>
            </div>
          </div>
        )}

        <RunButton loading={busy} onClick={process} disabled={!url} cost={tool.price}>
          <Film className="mr-1 h-4 w-4" /> Xóa watermark video
        </RunButton>
        {busy && stage && (
          <p className="flex items-center gap-2 text-sm text-emerald-700"><Loader2 className="h-4 w-4 animate-spin" /> {stage}</p>
        )}

        {result && (
          <div className="space-y-3 rounded-2xl border bg-card p-4">
            <p className="text-sm font-semibold text-emerald-900">Video sau khi vá watermark:</p>
            <video src={result.url} controls className="max-h-[55vh] w-full rounded-xl border" />
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => downloadBlob(result.blob, `video-da-xoa-watermark-${Date.now()}.webm`)}
                className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-500"
              >Tải video WebM ({(result.blob.size / 1024 / 1024).toFixed(1)} MB)</button>
              <span className="text-xs text-stone-500">Phiên bản đầy đủ với truyền lan quang học chạy trên máy chủ GPU khi triển khai.</span>
            </div>
          </div>
        )}
      </div>
    </ToolPage>
  )
}
