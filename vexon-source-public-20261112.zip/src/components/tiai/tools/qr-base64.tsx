'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ToolPage, DownloadButton, FileDrop, RunButton, useAiRun } from '../shared'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { downloadBlob, fileToDataUrl } from '@/lib/tiai/image'


async function renderQr(text: string): Promise<string> {
  const QR = (await import('qrcode')).default
  return QR.toDataURL(text, { width: 640, margin: 2, errorCorrectionLevel: 'M', color: { dark: '#12121f', light: '#ffffff' } })
}

function QrResult({ value, tool }: { value: string; tool: import('@/lib/tiai/tools').Tool }) {
  const [url, setUrl] = useState<string | null>(null)
  const [err, setErr] = useState('')
  const { run: paidRun } = useAiRun()
  useDeferredLoad(() => {
    if (!value.trim()) {
      setUrl(null)
      setErr('')
      return
    }
    renderQr(value)
      .then((u) => {
        setUrl(u)
        setErr('')
      })
      .catch(() => {
        setUrl(null)
        setErr('Nội dung quá dài để tạo mã QR')
      })
  }, [value])
  if (err) return <p className="text-sm text-red-400">{err}</p>
  if (!url) return null
  return (
    <div className="space-y-3 rounded-2xl border border-stone-200 bg-card p-4 text-center">
      <img src={url} alt="Mã QR" className="mx-auto w-56 rounded-xl" />
      <RunButton
        loading={false}
        onClick={() =>
          paidRun(tool, async () => downloadBlob(await (await fetch(url)).blob(), `ma-qr-${Date.now()}.png`), 'Đã tải mã QR')
        }
        cost={tool.price}
      >
        Tải mã QR (PNG)
      </RunButton>
    </div>
  )
}

// ─── VietQR EMV payload ─────────────────────────────────
const BANKS = [
  { bin: '970436', name: 'Vietcombank' },
  { bin: '970437', name: 'Techcombank' },
  { bin: '970422', name: 'MB Bank' },
  { bin: '970418', name: 'BIDV' },
  { bin: '970415', name: 'VietinBank' },
  { bin: '970416', name: 'ACB' },
  { bin: '970432', name: 'VPBank' },
  { bin: '970405', name: 'Agribank' },
  { bin: '970423', name: 'TPBank' },
  { bin: '970403', name: 'Sacombank' },
]

function tlv(id: string, value: string): string {
  return `${id}${value.length.toString().padStart(2, '0')}${value}`
}

function crc16(input: string): string {
  let crc = 0xffff
  for (let i = 0; i < input.length; i++) {
    crc ^= input.charCodeAt(i) << 8
    for (let j = 0; j < 8; j++) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0')
}

function buildVietQr(bin: string, account: string, amount: string, message: string): string {
  const merchant = tlv('00', 'A000000727') + tlv('01', bin) + tlv('02', account.replace(/\s/g, ''))
  let payload =
    tlv('00', '01') +
    tlv('01', amount && parseInt(amount) > 0 ? '12' : '11') +
    tlv('38', merchant) +
    tlv('53', '704')
  if (amount && parseInt(amount) > 0) payload += tlv('54', String(parseInt(amount)))
  payload += tlv('58', 'VN')
  if (message.trim()) payload += tlv('62', tlv('08', message.trim().slice(0, 25)))
  payload += '6304'
  return payload + crc16(payload)
}

// ─── Component chính ────────────────────────────────────
export function TaoQr({ tool }: { tool: import('@/lib/tiai/tools').Tool }) {
  const [text, setText] = useState('')
  const [url, setUrl] = useState('')
  const [ssid, setSsid] = useState('')
  const [wifiPass, setWifiPass] = useState('')
  const [enc, setEnc] = useState('WPA')
  const [bank, setBank] = useState(BANKS[0].bin)
  const [account, setAccount] = useState('')
  const [amount, setAmount] = useState('')
  const [message, setMessage] = useState('')

  const wifiPayload = `WIFI:T:${enc};S:${ssid};${wifiPass ? `P:${wifiPass};` : ''};`
  const vietPayload = account.trim() ? buildVietQr(bank, account, amount, message) : ''

  return (
    <ToolPage tool={tool}>
      <Tabs defaultValue="text" className="w-full">
        <TabsList className="mb-4 grid w-full grid-cols-4">
          <TabsTrigger value="text">Văn bản</TabsTrigger>
          <TabsTrigger value="link">Link</TabsTrigger>
          <TabsTrigger value="wifi">WiFi</TabsTrigger>
          <TabsTrigger value="vietqr">VietQR</TabsTrigger>
        </TabsList>
        <TabsContent value="text" className="space-y-4">
          <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={4} placeholder="Nhập nội dung bất kỳ…" />
          <QrResult value={text} tool={tool} />
        </TabsContent>
        <TabsContent value="link" className="space-y-4">
          <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://…" />
          <QrResult value={url} tool={tool} />
        </TabsContent>
        <TabsContent value="wifi" className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Tên WiFi (SSID)</Label>
              <Input value={ssid} onChange={(e) => setSsid(e.target.value)} placeholder="Nha Tro Phong 2" />
            </div>
            <div className="space-y-2">
              <Label>Mật khẩu</Label>
              <Input value={wifiPass} onChange={(e) => setWifiPass(e.target.value)} placeholder="Bỏ trống nếu mạng mở" />
            </div>
            <div className="space-y-2">
              <Label>Bảo mật</Label>
              <Select value={enc} onValueChange={setEnc}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="WPA">WPA / WPA2</SelectItem>
                  <SelectItem value="WEP">WEP</SelectItem>
                  <SelectItem value="nopass">Không mật khẩu</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <QrResult value={ssid ? wifiPayload : ''} tool={tool} />
        </TabsContent>
        <TabsContent value="vietqr" className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Ngân hàng</Label>
              <Select value={bank} onValueChange={setBank}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {BANKS.map((b) => (
                    <SelectItem key={b.bin} value={b.bin}>{b.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Số tài khoản</Label>
              <Input value={account} onChange={(e) => setAccount(e.target.value)} placeholder="0123456789" />
            </div>
            <div className="space-y-2">
              <Label>Số tiền (VND)</Label>
              <Input value={amount} onChange={(e) => setAmount(e.target.value.replace(/\D/g, ''))} placeholder="Bỏ trống = người quét tự nhập" />
            </div>
            <div className="space-y-2">
              <Label>Nội dung chuyển khoản</Label>
              <Input value={message} onChange={(e) => setMessage(e.target.value)} placeholder="VD: Thanh hoa don 12" />
            </div>
          </div>
          <QrResult value={vietPayload} tool={tool} />
          <p className="text-xs text-stone-500">Mã chuẩn VietQR EMVCo — dùng được với mọi app banking Việt Nam. Mã không hết hạn.</p>
        </TabsContent>
      </Tabs>
    </ToolPage>
  )
}

// ─── Base64 ──────────────────────────────────────────────
export function Base64Tool({ tool }: { tool: import('@/lib/tiai/tools').Tool }) {
  const [plain, setPlain] = useState('')
  const [encoded, setEncoded] = useState('')
  const [b64, setB64] = useState('')
  const [decoded, setDecoded] = useState('')
  const [fileB64, setFileB64] = useState('')
  const [fileName, setFileName] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const { run: paidRun } = useAiRun()

  const encodeText = () =>
    paidRun(
      tool,
      async () => {
        try {
          setEncoded(btoa(String.fromCharCode(...new TextEncoder().encode(plain))))
          setErr('')
        } catch {
          setErr('Nội dung quá dài')
          throw new Error('Nội dung quá dài')
        }
      },
      'Đã mã hóa sang Base64',
    )
  const decodeText = () =>
    paidRun(
      tool,
      async () => {
        try {
          const bytes = Uint8Array.from(atob(b64.trim()), (c) => c.charCodeAt(0))
          setDecoded(new TextDecoder().decode(bytes))
          setErr('')
        } catch {
          setErr('Chuỗi Base64 không hợp lệ')
          setDecoded('')
          throw new Error('Chuỗi Base64 không hợp lệ')
        }
      },
      'Đã giải mã thành văn bản',
    )

  const pick = (fs: File[]) => {
    const f = fs[0]
    if (!f) return
    setFile(f)
    setFileName(f.name)
    setFileB64('')
  }

  const encodeFile = () =>
    paidRun(
      tool,
      async () => {
        if (!file) throw new Error('Chưa chọn tệp')
        setBusy(true)
        try {
          setFileB64(await fileToDataUrl(file))
        } finally {
          setBusy(false)
        }
      },
      'Đã mã hóa tệp sang Base64',
    )

  const downloadDecodedFile = () => {
    try {
      const m = b64.trim().match(/^data:([^;]+);base64,(.*)$/s)
      const raw = m ? m[2] : b64.trim()
      const bytes = Uint8Array.from(atob(raw), (c) => c.charCodeAt(0))
      const blob = new Blob([bytes], { type: m?.[1] || 'application/octet-stream' })
      downloadBlob(blob, 'giai-ma-base64')
      setErr('')
    } catch {
      setErr('Chuỗi Base64 không hợp lệ')
    }
  }

  return (
    <ToolPage tool={tool}>
      <Tabs defaultValue="encode" className="w-full">
        <TabsList className="mb-4 grid w-full grid-cols-3">
          <TabsTrigger value="encode">Mã hóa văn bản</TabsTrigger>
          <TabsTrigger value="decode">Giải mã văn bản</TabsTrigger>
          <TabsTrigger value="file">Ảnh / tệp</TabsTrigger>
        </TabsList>
        <TabsContent value="encode" className="space-y-3">
          <Textarea value={plain} onChange={(e) => setPlain(e.target.value)} rows={4} placeholder="Nhập văn bản…" />
          <RunButton loading={false} onClick={encodeText} disabled={!plain.trim()} cost={tool.price}>Mã hóa → Base64</RunButton>
          {encoded && <Textarea readOnly value={encoded} rows={4} className="font-mono text-xs" />}
        </TabsContent>
        <TabsContent value="decode" className="space-y-3">
          <Textarea value={b64} onChange={(e) => setB64(e.target.value)} rows={4} placeholder="Dán chuỗi Base64…" className="font-mono text-xs" />
          <div className="flex gap-2">
            <RunButton loading={false} onClick={decodeText} disabled={!b64.trim()} cost={tool.price}>Giải mã → Văn bản</RunButton>
            <Button variant="outline" onClick={() => paidRun(tool, async () => downloadDecodedFile(), 'Đã tải tệp giải mã')} className="rounded-xl">Tải thành tệp</Button>
          </div>
          {decoded && <Textarea readOnly value={decoded} rows={4} />}
        </TabsContent>
        <TabsContent value="file" className="space-y-3">
          <FileDrop accept="image/*,.pdf,.zip,.doc,.docx" onFiles={pick} label={fileName || 'Chọn tệp để mã hóa'} hint="Ảnh, PDF, ZIP… bất kỳ định dạng nào" />
          {file && !fileB64 && <RunButton loading={busy} onClick={encodeFile} cost={tool.price}>Mã hóa tệp → Base64</RunButton>}
          {fileB64 && <Textarea readOnly value={fileB64} rows={6} className="font-mono text-[10px]" />}
        </TabsContent>
        {err && <p className="text-sm font-medium text-red-400">{err}</p>}
      </Tabs>
    </ToolPage>
  )
}
