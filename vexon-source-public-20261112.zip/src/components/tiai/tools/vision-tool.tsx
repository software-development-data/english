'use client'

// ============ PHÂN TÍCH ẢNH AI — nhìn ảnh trả lời (OCR, mô tả, nhận diện) ============

import { useState } from 'react'
import { Loader2, Copy, Check, Eye } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ToolPage, ImagePick, useAiRun } from '../shared'
import type { Tool } from '@/lib/tiai/tools'

const QUICK_QS = [
  'Ảnh này có gì? Mô tả chi tiết',
  'Trích xuất toàn bộ chữ trong ảnh',
  'Đọc bill/hóa đơn này: tổng tiền, ngày, các khoản',
  'Món ăn này là gì? Ước lượng calo',
  'Đánh giá bố cục ảnh này để bán hàng online',
]

export function PhanTichAnh({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [url, setUrl] = useState<string | null>(null)
  const [question, setQuestion] = useState('')
  const [loading, setLoading] = useState(false)
  const [output, setOutput] = useState('')
  const [copied, setCopied] = useState(false)

  const go = () =>
    run(
      tool,
      async () => {
        if (!url) throw new Error('Chưa chọn ảnh')
        setLoading(true)
        try {
          const res = await fetch('/api/tiai/vision', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ image: url, question: question.trim() || undefined }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'AI xử lý thất bại')
          setOutput(data.text)
        } finally {
          setLoading(false)
        }
      },
      question.trim() || 'Mô tả ảnh'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <ImagePick url={url} onPick={(f) => { setOutput(''); const r = new FileReader(); r.onload = () => setUrl(String(r.result)); r.readAsDataURL(f) }} onClear={() => { setUrl(null); setOutput('') }} />
        <div className="flex flex-wrap gap-1.5">
          {QUICK_QS.map((q) => (
            <button
              key={q}
              onClick={() => setQuestion(q)}
              className="rounded-full border border-stone-200 bg-white px-2.5 py-1 text-xs text-stone-600 transition hover:border-emerald-300 hover:bg-emerald-50"
            >
              {q}
            </button>
          ))}
        </div>
        <Input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Hỏi gì đó về bức ảnh (không bắt buộc — mặc định AI mô tả chi tiết)…"
          aria-label="Câu hỏi về bức ảnh"
        />
        <Button
          onClick={go}
          disabled={loading || !url}
          className="h-12 w-full gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-base font-semibold text-white shadow-lg shadow-emerald-600/20 transition hover:from-emerald-500 hover:to-teal-500"
        >
          {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Eye className="h-5 w-5" />}
          {loading ? 'AI đang nhìn ảnh…' : 'Phân tích ngay'}
        </Button>
        {output && (
          <div className="space-y-2 rounded-2xl border border-stone-200 bg-card p-4">
            <div className="flex items-center justify-between">
              <p className="font-semibold text-emerald-700">AI phân tích</p>
              <button
                onClick={async () => { await navigator.clipboard.writeText(output); setCopied(true); toast.success('Đã copy'); setTimeout(() => setCopied(false), 1500) }}
                className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-stone-500 transition hover:bg-stone-100"
                aria-label="Copy kết quả"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />} Copy
              </button>
            </div>
            <p className="whitespace-pre-wrap text-sm leading-relaxed text-emerald-950">{output}</p>
          </div>
        )}
      </div>
    </ToolPage>
  )
}
