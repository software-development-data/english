'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { ToolPage, RunButton, BeforeAfter, ImagePick, DownloadButton, useAiRun, dataUrlToBlob } from '../shared'
import { downloadBlob, fileToDataUrl, loadImage, makeCanvas, sharpenCanvas, upscaleCanvas, removeBackground, beautifyCanvas, canvasToBlob } from '@/lib/tiai/image'
import type { Tool } from '@/lib/tiai/tools'

// ─── TẠO ẢNH THEO YÊU CẦU (AI thật) ─────────────────────
const SIZES = [
  { value: '1024x1024', label: 'Vuông 1:1 — 1024px' },
  { value: '768x1344', label: 'Dọc 9:16 — story/reel' },
  { value: '1344x768', label: 'Ngang 16:9 — khung hình' },
  { value: '1440x720', label: 'Rộng 2:1 — banner' },
]
const EXAMPLES = [
  'Banner khai trương quán cà phê nền kem pastel, phong cách vintage ấm áp',
  'Ảnh sản phẩm son môi đỏ trên nền gương mờ sang trọng, ánh sáng studio',
  'Poster tiếng Việt "GIẢM 50%" cho tiệm giặt ủi, nền tím neon hiện đại',
  'Hình nền desktop thác nước giữa rừng sương mù, phong cách điện ảnh',
]

export function TaoAnh({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [prompt, setPrompt] = useState('')
  const [size, setSize] = useState('1024x1024')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)

  const generate = () =>
    run(
      tool,
      async () => {
        setLoading(true)
        try {
          const res = await fetch('/api/tiai/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt, size }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'Tạo ảnh thất bại')
          setResult(data.image)
        } finally {
          setLoading(false)
        }
      },
      'Ảnh AI đã sẵn sàng để tải về'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Mô tả ảnh bạn muốn (tiếng Việt)</Label>
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="VD: banner khai trương quán cà phê nền kem pastel, chữ phong cách vintage…"
            rows={4}
          />
          <div className="flex flex-wrap gap-2">
            {EXAMPLES.map((ex) => (
              <button
                key={ex}
                onClick={() => setPrompt(ex)}
                className="rounded-full border border-stone-300 bg-emerald-50 px-3 py-1 text-xs text-emerald-700 transition hover:bg-stone-200"
              >
                {ex.length > 46 ? ex.slice(0, 46) + '…' : ex}
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-2">
          <Label>Khung ảnh</Label>
          <Select value={size} onValueChange={setSize}>
            <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
            <SelectContent>
              {SIZES.map((s) => (
                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <RunButton loading={loading} onClick={generate} disabled={prompt.trim().length < 5} cost={tool.price}>
          Tạo ảnh ngay
        </RunButton>
        {result && (
          <div className="space-y-3 rounded-2xl border border-stone-200 bg-card p-4">
            <img src={result} alt="Ảnh AI tạo" className="mx-auto max-h-[460px] rounded-xl" />
            <div className="flex gap-2">
              <DownloadButton onClick={async () => downloadBlob(await dataUrlToBlob(result), `tiai-tao-anh-${Date.now()}.png`)}>
                Tải ảnh
              </DownloadButton>
              <Button variant="outline" className="h-11 flex-1 rounded-xl" onClick={generate}>
                Tạo lại lần nữa
              </Button>
            </div>
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ─── CHỈNH SỬA / PHỤC CHẾ MÀU (AI edit thật) ────────────
export function AiEditTool({ tool, fixedPrompt, placeholder = 'Mô tả muốn chỉnh sửa trên ảnh...', examples = [] }: { tool: Tool; fixedPrompt?: string; placeholder?: string; examples?: string[] }) {
  const { run } = useAiRun()
  const [file, setFile] = useState<File | null>(null)
  const [url, setUrl] = useState<string | null>(null)
  const [prompt, setPrompt] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)

  const pick = async (f: File) => {
    setFile(f)
    setResult(null)
    setUrl(await fileToDataUrl(f))
  }
  const clear = () => {
    setFile(null)
    setUrl(null)
    setResult(null)
  }

  const process = () =>
    run(
      tool,
      async () => {
        if (!url) throw new Error('Chưa có ảnh')
        setLoading(true)
        try {
          const res = await fetch('/api/tiai/edit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: fixedPrompt ?? prompt, image: url }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'Xử lý thất bại')
          setResult(data.image)
        } finally {
          setLoading(false)
        }
      },
      'AI đã xử lý xong — kéo thanh trượt để so sánh'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <ImagePick url={url} onPick={pick} onClear={clear} />
        {!fixedPrompt && (
          <div className="space-y-2">
            <Label>Bạn muốn sửa gì?</Label>
            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={placeholder}
              rows={3}
            />
            <div className="flex flex-wrap gap-2">
              {examples.map((ex) => (
                <button
                  key={ex}
                  onClick={() => setPrompt(ex)}
                  className="rounded-full border border-stone-300 bg-emerald-50 px-3 py-1 text-xs text-emerald-700 transition hover:bg-stone-200"
                >
                  {ex}
                </button>
              ))}
            </div>
          </div>
        )}
        <RunButton loading={loading} onClick={process} disabled={!url || (!fixedPrompt && prompt.trim().length < 4)} cost={tool.price}>
          {fixedPrompt ? 'Khôi phục màu ngay' : 'Chỉnh sửa ngay'}
        </RunButton>
        {result && url && (
          <div className="space-y-3">
            <BeforeAfter before={url} after={result} />
            <DownloadButton onClick={async () => downloadBlob(await dataUrlToBlob(result), `tiai-${tool.slug}-${Date.now()}.png`)}>
              Tải ảnh kết quả
            </DownloadButton>
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ─── Công cụ ảnh chạy local (làm nét / upscale / xóa nền / làm đẹp) ──
async function toWorkCanvas(file: File, maxSide: number): Promise<HTMLCanvasElement> {
  const url = await fileToDataUrl(file)
  const img = await loadImage(url)
  let w = img.naturalWidth
  let h = img.naturalHeight
  const scale = Math.min(1, maxSide / Math.max(w, h))
  w = Math.round(w * scale)
  h = Math.round(h * scale)
  const c = makeCanvas(w, h)
  c.getContext('2d')!.drawImage(img, 0, 0, w, h)
  return c
}

export function LocalImageTool({
  tool,
  mode,
}: {
  tool: Tool
  mode: 'sharpen' | 'upscale' | 'removebg' | 'beautify'
}) {
  const { run } = useAiRun()
  const [file, setFile] = useState<File | null>(null)
  const [url, setUrl] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [resultUrl, setResultUrl] = useState<string | null>(null)
  const [resultBlob, setResultBlob] = useState<Blob | null>(null)
  const [amount, setAmount] = useState(mode === 'removebg' ? 32 : mode === 'beautify' ? 50 : 60)
  const [factor, setFactor] = useState('2')

  const pick = async (f: File) => {
    setFile(f)
    setResultUrl(null)
    setResultBlob(null)
    setUrl(await fileToDataUrl(f))
  }
  const clear = () => {
    setFile(null)
    setUrl(null)
    setResultUrl(null)
    setResultBlob(null)
  }

  const process = () =>
    run(
      tool,
      async () => {
        if (!file) throw new Error('Chưa có ảnh')
        setLoading(true)
        try {
          let canvas: HTMLCanvasElement
          if (mode === 'sharpen') {
            canvas = await toWorkCanvas(file, 2000)
            canvas = sharpenCanvas(canvas, 0.4 + (amount / 100) * 1.1)
            const blob = await canvasToBlob(canvas, 'image/png')
            setResultBlob(blob)
            setResultUrl(URL.createObjectURL(blob))
          } else if (mode === 'upscale') {
            const f = parseInt(factor)
            const maxSrc = Math.floor(3200 / f)
            canvas = await toWorkCanvas(file, maxSrc)
            canvas = upscaleCanvas(canvas, f)
            const blob = await canvasToBlob(canvas, 'image/png')
            setResultBlob(blob)
            setResultUrl(URL.createObjectURL(blob))
          } else if (mode === 'removebg') {
            canvas = await toWorkCanvas(file, 1600)
            canvas = removeBackground(canvas, amount)
            const blob = await canvasToBlob(canvas, 'image/png')
            setResultBlob(blob)
            setResultUrl(URL.createObjectURL(blob))
          } else {
            canvas = await toWorkCanvas(file, 1800)
            canvas = beautifyCanvas(canvas, amount / 100)
            const blob = await canvasToBlob(canvas, 'image/png')
            setResultBlob(blob)
            setResultUrl(URL.createObjectURL(blob))
          }
        } finally {
          setLoading(false)
        }
      },
      mode === 'removebg' ? 'Xuất PNG nền trong suốt' : 'Kéo thanh trượt để so sánh trước/sau'
    )

  const isTrans = mode === 'removebg'
  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <ImagePick url={url} onPick={pick} onClear={clear} />
        {mode === 'sharpen' && (
          <div className="space-y-2">
            <Label>Cường độ làm nét: {amount}%</Label>
            <Slider value={[amount]} min={10} max={100} step={5} onValueChange={(v) => setAmount(v[0])} />
          </div>
        )}
        {mode === 'upscale' && (
          <div className="space-y-2">
            <Label>Hệ số phóng to</Label>
            <Select value={factor} onValueChange={setFactor}>
              <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="2">Phóng to ×2</SelectItem>
                <SelectItem value="4">Phóng to ×4</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-stone-500">Ảnh rất lớn sẽ được thu gọn về tối đa {Math.floor(3200 / parseInt(factor))}px trước khi phóng để chạy mượt trên máy bạn.</p>
          </div>
        )}
        {mode === 'removebg' && (
          <div className="space-y-2">
            <Label>Độ rộng vùng chọn nền: {amount}</Label>
            <Slider value={[amount]} min={8} max={90} step={2} onValueChange={(v) => setAmount(v[0])} />
            <p className="text-xs text-stone-500">Hoạt động tốt nhất với ảnh nền phẳng (sản phẩm, chân dung chụp studio). Tăng số nếu còn sót nền.</p>
          </div>
        )}
        {mode === 'beautify' && (
          <div className="space-y-2">
            <Label>Mức làm đẹp: {amount}%</Label>
            <Slider value={[amount]} min={15} max={90} step={5} onValueChange={(v) => setAmount(v[0])} />
          </div>
        )}
        <RunButton loading={loading} onClick={process} disabled={!file} cost={tool.price}>
          {mode === 'removebg' ? 'Xóa nền ngay' : mode === 'beautify' ? 'Làm đẹp ngay' : mode === 'upscale' ? 'Phóng to ảnh' : 'Làm nét ngay'}
        </RunButton>
        {resultUrl && url && (
          <div className="space-y-3">
            {isTrans ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="overflow-hidden rounded-2xl border border-stone-200">
                  <p className="bg-stone-900 px-3 py-1.5 text-xs font-semibold text-white">Gốc</p>
                  <img src={url} alt="Gốc" className="max-h-64 w-full bg-stone-900 object-contain" />
                </div>
                <div className="overflow-hidden rounded-2xl border border-emerald-500/30">
                  <p className="bg-stone-900 px-3 py-1.5 text-xs font-semibold text-white">Đã xóa nền</p>
                  <img src={resultUrl} alt="Đã xóa nền" className="tiai-checker max-h-64 w-full object-contain" />
                </div>
              </div>
            ) : (
              <BeforeAfter before={url} after={resultUrl} />
            )}
            {resultBlob && (
              <DownloadButton onClick={() => downloadBlob(resultBlob, `tiai-${tool.slug}-${Date.now()}.png`)}>
                Tải ảnh kết quả (PNG)
              </DownloadButton>
            )}
          </div>
        )}
      </div>
    </ToolPage>
  )
}
