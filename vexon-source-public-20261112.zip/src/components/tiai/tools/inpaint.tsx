'use client'

// ============ XÓA WATERMARK ẢNH (IOPaint / LaMa-style) ============
// Sơn mặt nạ lên vùng watermark/logo/vật thể → tiền-lấp đầy từ môi trường xung quanh
// (giống mask của LaMa) → AI dựng lại nền tự nhiên. Chỉ trừ Xu khi thành công.
// ============ TÁCH NỀN HD (BiRefNet-style) ============
// Bóc tách chủ thể biên nét độ phân giải cao → PNG nền trong suốt, tùy chọn phóng ×2.

import { useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Loader2, Eraser, Undo2, Layers, Scissors } from 'lucide-react'
import { FileDrop, BeforeAfter, DownloadButton, ImagePick, ToolPage, RunButton, useAiRun, dataUrlToBlob } from '../shared'
import { fileToDataUrl, downloadBlob, loadImage, makeCanvas, canvasToBlob, upscaleCanvas, removeBackground } from '@/lib/tiai/image'
import type { Tool } from '@/lib/tiai/tools'

// ─── Canvas có mặt nạ sơn tay ───────────────────────────
function MaskCanvas({ url, maskRef }: { url: string; maskRef: React.MutableRefObject<HTMLCanvasElement | null> }) {
  const wrapRef = useRef<HTMLDivElement>(null)
  const imgRef = useRef<HTMLImageElement | null>(null)
  const [brush, setBrush] = useState(28)
  const painting = useRef(false)
  const last = useRef<{ x: number; y: number } | null>(null)

  const setup = async (el: HTMLCanvasElement | null) => {
    if (!el || !url || imgRef.current?.src === url) return
    const img = await loadImage(url)
    imgRef.current = img
    const maxW = 640
    const scale = Math.min(1, maxW / img.naturalWidth)
    el.width = Math.round(img.naturalWidth * scale)
    el.height = Math.round(img.naturalHeight * scale)
    const ctx = el.getContext('2d')!
    ctx.clearRect(0, 0, el.width, el.height)
    ctx.drawImage(img, 0, 0, el.width, el.height)
    maskRef.current = el
  }

  const pos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const el = e.currentTarget
    const r = el.getBoundingClientRect()
    return { x: ((e.clientX - r.left) / r.width) * el.width, y: ((e.clientY - r.top) / r.height) * el.height }
  }

  const paint = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!painting.current) return
    const ctx = e.currentTarget.getContext('2d')!
    const { x, y } = pos(e)
    ctx.globalCompositeOperation = 'source-over'
    ctx.strokeStyle = 'rgba(239,68,68,0.55)'
    ctx.lineWidth = brush
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'
    ctx.beginPath()
    const p0 = last.current || { x, y }
    ctx.moveTo(p0.x, p0.y)
    ctx.lineTo(x, y)
    ctx.stroke()
    last.current = { x, y }
  }

  return (
    <div ref={wrapRef} className="space-y-2">
      <div className="relative inline-block max-w-full overflow-hidden rounded-xl border">
        <canvas
          ref={(el) => { void setup(el) }}
          className="max-h-[60vh] w-auto max-w-full cursor-crosshair touch-none"
          onPointerDown={(e) => { painting.current = true; last.current = null; paint(e) }}
          onPointerMove={paint}
          onPointerUp={() => { painting.current = false; last.current = null }}
          onPointerLeave={() => { painting.current = false; last.current = null }}
        />
      </div>
      <div className="flex flex-wrap items-center gap-3 text-sm">
        <Label className="flex items-center gap-2">
          Cọ <input type="range" min={8} max={80} value={brush} onChange={(e) => setBrush(Number(e.target.value))} className="w-32 accent-emerald-600" aria-label="Kích thước cọ" />
          {brush}px
        </Label>
        <Button
          size="sm" variant="outline"
          onClick={() => { const el = maskRef.current; if (el) el.getContext('2d')!.clearRect(0, 0, el.width, el.height) }}
        ><Undo2 className="mr-1 h-3.5 w-3.5" /> Xoá mặt nạ</Button>
        <span className="text-xs text-stone-500"> Sơn đỏ lên watermark/logo/vật thể cần xóa</span>
      </div>
    </div>
  )
}

// Tiền-lấp đầy vùng mặt nạ từ môi trường xung quanh (client-side, giống bước mask của LaMa)
function prefillMasked(imgEl: HTMLImageElement, maskEl: HTMLCanvasElement): string {
  const w = maskEl.width, h = maskEl.height
  const base = makeCanvas(w, h)
  const bctx = base.getContext('2d')!
  bctx.drawImage(imgEl, 0, 0, w, h)
  const src = bctx.getImageData(0, 0, w, h)
  const mctx = maskEl.getContext('2d')!
  const mdata = mctx.getImageData(0, 0, w, h).data
  const masked = new Uint8Array(w * h)
  for (let i = 0; i < w * h; i++) if (mdata[i * 4 + 3] > 40) masked[i] = 1
  // Lấp từ pixel lành bên trên, nếu không có thì bên trái/phải/dưới
  const at = (x: number, y: number) => src.data[(y * w + x) * 4]
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x
      if (!masked[i]) continue
      let found = false
      const tryDirs: [number, number][] = [[0, -1], [-1, 0], [1, 0], [0, 1], [-2, -2], [2, -2]]
      for (const [dx, dy] of tryDirs) {
        let px = x, py = y
        for (let step = 0; step < Math.max(w, h); step++) {
          px += dx; py += dy
          if (px < 0 || py < 0 || px >= w || py >= h) break
          if (!masked[py * w + px]) {
            const j = i * 4
            src.data[j] = at(px, py); src.data[j + 1] = at(px, py); src.data[j + 2] = at(px, py)
            found = true
            break
          }
        }
        if (found) break
      }
    }
  }
  bctx.putImageData(src, 0, 0)
  return base.toDataURL('image/jpeg', 0.9)
}

export function InpaintLama({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [url, setUrl] = useState<string | null>(null)
  const [imgEl, setImgEl] = useState<HTMLImageElement | null>(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)
  const maskRef = useRef<HTMLCanvasElement | null>(null)

  const pick = async (f: File) => {
    setResult(null)
    const dataUrl = await fileToDataUrl(f)
    setUrl(dataUrl)
    setImgEl(await loadImage(dataUrl))
  }
  const clear = () => { setUrl(null); setImgEl(null); setResult(null); maskRef.current = null }

  const process = () =>
    run(
      tool,
      async () => {
        if (!url || !imgEl || !maskRef.current) throw new Error('Chưa sơn vùng cần xóa')
        const hasMask = maskRef.current.getContext('2d')!.getImageData(0, 0, maskRef.current.width, maskRef.current.height).data.some((a, i) => i % 4 === 3 && a > 40)
        const prefilled = hasMask ? prefillMasked(imgEl, maskRef.current) : url
        setLoading(true)
        try {
          const res = await fetch('/api/tiai/edit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              prompt: hasMask
                ? 'Photo inpainting (LaMa-style): the smudged patch marks the area to remove. Reconstruct that region with a seamless, natural background continuing the surrounding texture, colors, lighting and grain. Completely remove any watermark, logo, text or object inside it. Keep everything outside the patch exactly unchanged.'
                : 'Remove any visible watermark, logo, overlay text and timestamps from this photo. Reconstruct the background behind them naturally and seamlessly. Keep everything else exactly unchanged.',
              image: prefilled,
            }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'Xử lý thất bại')
          setResult(data.image)
        } finally {
          setLoading(false)
        }
      },
      'AI đã dựng lại nền — kéo thanh trượt so sánh trước/sau'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        {!url ? (
          <FileDrop accept="image/*" onFiles={(fs) => fs[0] && pick(fs[0])} label="Thả ảnh có watermark vào đây" hint="Logo, chữ đè, tem mờ, dấu thời gian — sơn lên là AI xóa" />
        ) : (
          <ImagePick url={url} onPick={pick} onClear={clear} />
        )}
        {url && <MaskCanvas url={url} maskRef={maskRef} />}
        <RunButton loading={loading} onClick={process} disabled={!url} cost={tool.price}>
          <Eraser className="mr-1 h-4 w-4" /> Xóa watermark
        </RunButton>
        {result && url && (
          <div className="space-y-3">
            <BeforeAfter before={url} after={result} />
            <DownloadButton onClick={async () => downloadBlob(await dataUrlToBlob(result), `xoa-watermark-${Date.now()}.png`)}>Tải ảnh kết quả</DownloadButton>
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ═══════════ TÁCH NỀN HD (BiRefNet-style) ═══════════
export function TachNenHd({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [url, setUrl] = useState<string | null>(null)
  const [upscale, setUpscale] = useState(false)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ url: string; blob: Blob } | null>(null)

  const pick = async (f: File) => { setResult(null); setUrl(await fileToDataUrl(f)) }
  const clear = () => { setUrl(null); setResult(null) }

  const process = () =>
    run(
      tool,
      async () => {
        if (!url) throw new Error('Chưa có ảnh')
        setLoading(true)
        try {
          // Bước 1 — AI bóc tách chủ thể (BiRefNet-style) lên nền phẳng thuần
          const res = await fetch('/api/tiai/edit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              prompt: 'High-resolution dichotomous image segmentation (BiRefNet-style): cut out the main subject with razor-sharp edges and fine detail (hair, fur, glass edges included). Place the subject on a perfectly flat, pure white background (#FFFFFF) with no shadows, no gradients, no reflections. Keep the subject at its original size, pose, colors and details.',
              image: url,
            }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'Xử lý thất bại')

          // Bước 2 — client-side: khử nền trắng → PNG trong suốt (+ tuỳ chọn ×2)
          const img = await loadImage(data.image)
          let c = makeCanvas(img.naturalWidth, img.naturalHeight)
          c.getContext('2d')!.drawImage(img, 0, 0)
          c = removeBackground(c, 26)
          if (upscale) c = upscaleCanvas(c, 2)
          const blob = await canvasToBlob(c, 'image/png')
          setResult({ url: URL.createObjectURL(blob), blob })
        } finally {
          setLoading(false)
        }
      },
      'Tách nền xong — PNG nền trong suốt, viền chủ thể nét'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <ImagePick url={url} onPick={pick} onClear={clear} />
        {url && (
          <label className="flex w-fit cursor-pointer items-center gap-2 rounded-lg border p-2.5 text-sm">
            <Checkbox checked={upscale} onCheckedChange={(c) => setUpscale(Boolean(c))} />
            <Layers className="h-4 w-4 text-stone-600" /> Phóng to ×2 sau khi tách (ảnh HD hơn)
          </label>
        )}
        <RunButton loading={loading} onClick={process} disabled={!url} cost={tool.price}>
          <Scissors className="mr-1 h-4 w-4" /> Tách nền HD (BiRefNet)
        </RunButton>
        {result && (
          <div className="space-y-3">
            <div className="rounded-xl border p-3" style={{ backgroundImage: 'repeating-conic-gradient(#e5e7eb 0% 25%, white 0% 50%)', backgroundSize: '16px 16px' }}>
              <img src={result.url} alt="Chủ thể đã tách nền" className="mx-auto max-h-[55vh] w-auto rounded-lg" />
            </div>
            <DownloadButton onClick={() => downloadBlob(result.blob, `tach-nen-hd-${Date.now()}.png`)}>Tải PNG trong suốt</DownloadButton>
          </div>
        )}
      </div>
    </ToolPage>
  )
}
