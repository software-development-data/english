'use client'

// ============ VIDEO STUDIO — 4 công cụ dựng phim AI chạy trên máy người dùng ============
// Lấy cảm hứng từ các repo mã nguồn mở trong Thư viện Nguồn mở AI (gifhub):
//  • Làm nét video        → Real-ESRGAN  (xinntao/Real-ESRGAN)
//  • Tách cảnh phân cảnh  → PySceneDetect (Breakthrough/PySceneDetect)
//  • Cắt khoảng lặng      → auto-editor  (WyattBlue/auto-editor)
//  • Phát thanh viên AI   → SadTalker    (OpenTalker/SadTalker)
// Toàn bộ pipeline dùng Canvas + WebAudio + MediaRecorder — không cần máy chủ GPU.

import { useRef, useState } from 'react'
import { Loader2, Film, Info, Download, Sparkles, FileJson, FileSpreadsheet, Play } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Textarea } from '@/components/ui/textarea'
import { FileDrop, ToolPage, RunButton, useAiRun } from '../shared'
import { downloadBlob, fileToImage } from '@/lib/tiai/image'
import { useView } from '@/lib/tiai/view'
import type { Tool } from '@/lib/tiai/tools'

// ─── Helper chung ─────────────────────────────────────────
const MAX_SIDE = 720

const seekVideo = (v: HTMLVideoElement, t: number) =>
  new Promise<void>((res) => {
    const on = () => { v.removeEventListener('seeked', on); res() }
    v.addEventListener('seeked', on)
    v.currentTime = t
    setTimeout(on, 700)
  })

const pickMime = () =>
  ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].find((m) => MediaRecorder.isTypeSupported(m)) || 'video/webm'

/** Ghi canvas thành WebM — vẽ khung hình theo mốc thời gian thực (rAF), đồng bộ audio track nếu có */
async function recordCanvas(
  canvas: HTMLCanvasElement,
  opts: { fps: number; durationMs: number; audioTrack?: MediaStreamTrack | null; draw: (elapsedMs: number) => boolean },
): Promise<Blob> {
  const stream = canvas.captureStream(opts.fps) as MediaStream
  if (opts.audioTrack) stream.addTrack(opts.audioTrack)
  const mime = pickMime()
  const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 3_000_000 })
  const chunks: BlobPart[] = []
  rec.ondataavailable = (e) => e.data.size > 0 && chunks.push(e.data)
  const stopped = new Promise<Blob>((res) => { rec.onstop = () => res(new Blob(chunks, { type: 'video/webm' })) })
  rec.start(250)
  const t0 = performance.now()
  await new Promise<void>((resolve) => {
    const tick = () => {
      const el = performance.now() - t0
      const done = opts.draw(el)
      if (done || el >= opts.durationMs + 400) { resolve(); return }
      requestAnimationFrame(tick)
    }
    requestAnimationFrame(tick)
  })
  await new Promise((r) => setTimeout(r, 350))
  rec.stop()
  return stopped
}

const fmt = (s: number) => {
  const m = Math.floor(s / 60)
  const sec = s - m * 60
  return `${String(m).padStart(2, '0')}:${sec.toFixed(1).padStart(4, '0')}`
}

/** Ghi chú dẫn sang Thư viện Nguồn mở AI — nối công cụ ↔ repo gốc */
function OssNote() {
  const go = useView((s) => s.go)
  return (
    <button
      onClick={() => go({ name: 'oss' })}
      className="flex w-full items-center gap-2 rounded-xl border border-dashed border-stone-300 px-3 py-2.5 text-left text-xs text-stone-500 transition hover:border-emerald-400 hover:text-emerald-700"
    >
      <Sparkles className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
      Xem thêm các repo gốc (Real-ESRGAN, PySceneDetect, auto-editor, SadTalker…) trong Thư viện Nguồn mở AI →
    </button>
  )
}

// ═══════════ 1) LÀM NÉT VIDEO — phong cách Real-ESRGAN (unsharp mask từng khung) ═══════════
export function VideoEnhance({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [file, setFile] = useState<File | null>(null)
  const [url, setUrl] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [stage, setStage] = useState('')
  const [amount, setAmount] = useState('vua')
  const [scale, setScale] = useState('1')
  const [seconds, setSeconds] = useState('5')
  const [fps, setFps] = useState('12')
  const [keepAudio, setKeepAudio] = useState(true)
  const [result, setResult] = useState<{ url: string; blob: Blob } | null>(null)
  const videoRef = useRef<HTMLVideoElement | null>(null)

  const pick = (f?: File) => {
    if (!f) return
    if (f.size > 60_000_000) { alert('Video tối đa ~60MB — hãy cắt ngắn trước nhé'); return }
    setFile(f); setResult(null); setUrl(URL.createObjectURL(f))
  }
  const clear = () => { setFile(null); setUrl(null); setResult(null) }

  const process = () =>
    run(
      tool,
      async () => {
        const v = videoRef.current
        if (!v) throw new Error('Chưa có video')
        setBusy(true)
        try {
          const fpsN = Number(fps)
          const dur = Math.min(v.duration || Number(seconds), Number(seconds))
          const total = Math.max(2, Math.min(240, Math.round(dur * fpsN)))
          const vw = v.videoWidth || 640, vh = v.videoHeight || 360
          const capSide = scale === '2' ? 1280 : 720
          const s = Math.min(capSide / Math.max(vw, vh), scale === '2' ? 2 : 1)
          const W = Math.round(vw * s / 2) * 2, H = Math.round(vh * s / 2) * 2
          const gain = amount === 'nhe' ? 0.65 : amount === 'manh' ? 1.6 : 1.0
          const blurR = scale === '2' ? 1.2 : 0.9

          // Nền mờ (GPU filter) + hiệu Unsharp Mask: out = orig + gain·(orig − blur)
          const blurCv = document.createElement('canvas')
          blurCv.width = W; blurCv.height = H
          const bctx = blurCv.getContext('2d')!
          const outCv = document.createElement('canvas')
          outCv.width = W; outCv.height = H
          const octx = outCv.getContext('2d')!
          const frames: HTMLCanvasElement[] = []

          for (let i = 0; i < total; i++) {
            setStage(`Đang làm nét khung hình ${i + 1}/${total}…`)
            await seekVideo(v, Math.min(v.duration - 0.01, i / fpsN))
            octx.filter = 'none'
            octx.drawImage(v, 0, 0, W, H)
            const orig = octx.getImageData(0, 0, W, H)
            bctx.filter = `blur(${blurR}px)`
            bctx.drawImage(outCv, 0, 0)
            bctx.filter = 'none'
            const blur = bctx.getImageData(0, 0, W, H)
            const d = orig.data, b = blur.data
            for (let k = 0; k < d.length; k += 4) {
              d[k] = Math.max(0, Math.min(255, d[k] + gain * (d[k] - b[k])))
              d[k + 1] = Math.max(0, Math.min(255, d[k + 1] + gain * (d[k + 1] - b[k + 1])))
              d[k + 2] = Math.max(0, Math.min(255, d[k + 2] + gain * (d[k + 2] - b[k + 2])))
            }
            const fc = document.createElement('canvas')
            fc.width = W; fc.height = H
            fc.getContext('2d')!.putImageData(orig, 0, 0)
            frames.push(fc)
          }

          setStage('Đang dựng video đã làm nét…')
          let audioTrack: MediaStreamTrack | null = null
          if (keepAudio) {
            try {
              const withAudio = (v as HTMLVideoElement & { captureStream?: () => MediaStream }).captureStream?.()
              audioTrack = withAudio?.getAudioTracks?.()[0] || null
            } catch { /* không lấy được tiếng — xuất video và vẫn chạy */ }
          }
          const blob = await recordCanvas(outCv, {
            fps: fpsN,
            durationMs: (total / fpsN) * 1000,
            audioTrack,
            draw: (el) => {
              const i = Math.min(frames.length - 1, Math.floor((el / 1000) * fpsN))
              octx.drawImage(frames[i], 0, 0)
              return el >= (total / fpsN) * 1000
            },
          })
          if (blob.size < 300) throw new Error('Trình duyệt không hỗ trợ ghi video (MediaRecorder)')
          setResult({ url: URL.createObjectURL(blob), blob })
        } finally {
          setBusy(false)
          setStage('')
        }
      },
      'Video đã được làm nét từng khung hình'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        {!url ? (
          <FileDrop accept="video/mp4,video/webm,video/quicktime,video/*" onFiles={(fs) => pick(fs[0])} label="Thả video cần làm nét vào đây" hint="MP4 / WebM · xử lý ngay trên máy bạn — tối đa ~60MB" />
        ) : (
          <div className="flex items-center justify-between rounded-xl border bg-card p-3">
            <p className="flex items-center gap-2 truncate text-sm text-emerald-900"><Film className="h-4 w-4 shrink-0" /> {file?.name}</p>
            <button onClick={clear} className="text-xs text-stone-600 underline">Chọn video khác</button>
          </div>
        )}
        {url && (
          <div className="space-y-3">
            <video ref={videoRef} src={url} playsInline controls className="max-h-[50vh] w-full rounded-xl border" />
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Mức làm nét</Label>
                <Select value={amount} onValueChange={setAmount}>
                  <SelectTrigger aria-label="Mức làm nét"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="nhe">Nhẹ — giữ vẻ tự nhiên</SelectItem>
                    <SelectItem value="vua">Vừa (khuyên dùng)</SelectItem>
                    <SelectItem value="manh">Mạnh — video rất mờ</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Độ phân giải xuất</Label>
                <Select value={scale} onValueChange={setScale}>
                  <SelectTrigger aria-label="Độ phân giải xuất"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Giữ nguyên kích thước</SelectItem>
                    <SelectItem value="2">Phóng đại ×2 (nét hơn, chậm hơn)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Xử lý bao lâu (tính từ đầu)</Label>
                <Select value={seconds} onValueChange={setSeconds}>
                  <SelectTrigger aria-label="Thời lượng xử lý"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 giây</SelectItem>
                    <SelectItem value="10">10 giây</SelectItem>
                    <SelectItem value="20">20 giây</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Số khung/giây</Label>
                <Select value={fps} onValueChange={setFps}>
                  <SelectTrigger aria-label="Số khung trên giây"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10 fps (nhanh)</SelectItem>
                    <SelectItem value="12">12 fps (cân bằng)</SelectItem>
                    <SelectItem value="15">15 fps (mượt)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <label className="flex cursor-pointer items-center gap-2 text-sm">
              <Checkbox checked={keepAudio} onCheckedChange={(c) => setKeepAudio(Boolean(c))} /> Giữ âm thanh gốc (thử nghiệm)
            </label>
          </div>
        )}
        <RunButton loading={busy} onClick={process} disabled={!url} cost={tool.price}>
          <Film className="mr-1 h-4 w-4" /> Làm nét video
        </RunButton>
        {busy && stage && <p className="flex items-center gap-2 text-sm text-emerald-700"><Loader2 className="h-4 w-4 animate-spin" /> {stage}</p>}
        {result && (
          <div className="space-y-3 rounded-2xl border bg-card p-4">
            <p className="text-sm font-semibold text-emerald-900">Video sau khi làm nét:</p>
            <video src={result.url} controls className="max-h-[55vh] w-full rounded-xl border" />
            <button
              onClick={() => downloadBlob(result.blob, `video-lam-net-${Date.now()}.webm`)}
              className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-500"
            >
              <Download className="h-4 w-4" /> Tải video WebM ({(result.blob.size / 1024 / 1024).toFixed(1)} MB)
            </button>
          </div>
        )}
        <OssNote />
      </div>
    </ToolPage>
  )
}

// ═══════════ 2) TÁCH CẢNH THEO PHÂN CẢNH — phong cách PySceneDetect ═══════════
interface Scene { start: number; end: number; thumb: string }

export function SceneDetect({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [file, setFile] = useState<File | null>(null)
  const [url, setUrl] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [stage, setStage] = useState('')
  const [sensitivity, setSensitivity] = useState('vua')
  const [scanSec, setScanSec] = useState('30')
  const [scenes, setScenes] = useState<Scene[] | null>(null)
  const videoRef = useRef<HTMLVideoElement | null>(null)

  const pick = (f?: File) => {
    if (!f) return
    if (f.size > 80_000_000) { alert('Video tối đa ~80MB — hãy cắt ngắn trước nhé'); return }
    setFile(f); setScenes(null); setUrl(URL.createObjectURL(f))
  }
  const clear = () => { setFile(null); setUrl(null); setScenes(null) }

  const jump = (t: number) => {
    const v = videoRef.current
    if (!v) return
    v.currentTime = t + 0.05
    v.play().catch(() => {})
  }

  const analyze = () =>
    run(
      tool,
      async () => {
        const v = videoRef.current
        if (!v) throw new Error('Chưa có video')
        setBusy(true)
        try {
          const fpsN = 6 // tần suất phân tích
          const dur = Math.min(v.duration || Number(scanSec), Number(scanSec))
          const total = Math.max(4, Math.round(dur * fpsN))
          const aw = 160, ah = Math.max(90, Math.round((160 * (v.videoHeight || 90)) / (v.videoWidth || 160)))
          const c = document.createElement('canvas')
          c.width = aw; c.height = ah
          const ctx = c.getContext('2d', { willReadFrequently: true })!

          const thr = sensitivity === 'cao' ? 0.18 : sensitivity === 'thap' ? 0.42 : 0.28
          const hist = (d: Uint8ClampedArray) => {
            const h = new Float32Array(48)
            for (let i = 0; i < d.length; i += 4) {
              h[d[i] >> 4]++
              h[16 + (d[i + 1] >> 4)]++
              h[32 + (d[i + 2] >> 4)]++
            }
            return h
          }

          const cuts: number[] = [0]
          let prev: Float32Array | null = null
          for (let i = 0; i < total; i++) {
            if (i % 6 === 0) setStage(`Đang quét ${fmt(Math.min(dur, i / fpsN))} / ${fmt(dur)}…`)
            await seekVideo(v, Math.min(v.duration - 0.01, i / fpsN))
            ctx.drawImage(v, 0, 0, aw, ah)
            const d = ctx.getImageData(0, 0, aw, ah).data
            const h = hist(d)
            if (prev) {
              let diff = 0
              for (let k = 0; k < 48; k++) diff += Math.abs(h[k] - prev[k])
              diff = diff / (2 * aw * ah * 3)
              if (diff > thr) cuts.push(i / fpsN)
            }
            prev = h
          }

          // Ghép cảnh: cắt điểm + hợp cảnh quá ngắn (<0.7s)
          const bounds = [...new Set(cuts.map((t) => Math.round(t * 10) / 10))].sort((a, b) => a - b)
          const segs: { s: number; e: number }[] = []
          for (let i = 0; i < bounds.length; i++) {
            const s = bounds[i]
            const e = i + 1 < bounds.length ? bounds[i + 1] : dur
            if (e - s < 0.7 && segs.length > 0) segs[segs.length - 1].e = e
            else segs.push({ s, e })
          }
          if (segs.length === 0) segs.push({ s: 0, e: dur })

          // Ảnh đại diện từng cảnh
          const tc = document.createElement('canvas')
          tc.width = 120; tc.height = Math.round((120 * ah) / aw)
          const tctx = tc.getContext('2d')!
          const out: Scene[] = []
          for (let i = 0; i < segs.length; i++) {
            setStage(`Chụp ảnh cảnh ${i + 1}/${segs.length}…`)
            await seekVideo(v, segs[i].s + 0.08)
            tctx.drawImage(v, 0, 0, tc.width, tc.height)
            out.push({ start: segs[i].s, end: segs[i].e, thumb: tc.toDataURL('image/jpeg', 0.65) })
          }
          setScenes(out)
        } finally {
          setBusy(false)
          setStage('')
        }
      },
      `Đã tách xong phân cảnh — xem shot list bên dưới`
    )

  const exportCsv = () => {
    if (!scenes) return
    const rows = ['#', 'bat_dau', 'ket_thuc', 'do_dai_giay']
    scenes.forEach((s, i) => rows.push(`${i + 1},${fmt(s.start)},${fmt(s.end)},${(s.end - s.start).toFixed(1)}`))
    downloadBlob(new Blob([rows.join('\n')], { type: 'text/csv' }), `shot-list-${Date.now()}.csv`)
  }
  const exportJson = () => {
    if (!scenes) return
    const data = {
      video: file?.name,
      tool: 'Vexon — Tách cảnh theo phân cảnh (PySceneDetect-style)',
      shots: scenes.map((s, i) => ({ shot: i + 1, start: fmt(s.start), end: fmt(s.end), durationSec: Number((s.end - s.start).toFixed(1)) })),
    }
    downloadBlob(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }), `shot-list-${Date.now()}.json`)
  }

  const dur = scenes?.length ? scenes[scenes.length - 1].end : 1

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        {!url ? (
          <FileDrop accept="video/mp4,video/webm,video/quicktime,video/*" onFiles={(fs) => pick(fs[0])} label="Thả video cần tách cảnh vào đây" hint="MP4 / WebM · quét ngay trên máy bạn — tối đa ~80MB" />
        ) : (
          <div className="flex items-center justify-between rounded-xl border bg-card p-3">
            <p className="flex items-center gap-2 truncate text-sm text-emerald-900"><Film className="h-4 w-4 shrink-0" /> {file?.name}</p>
            <button onClick={clear} className="text-xs text-stone-600 underline">Chọn video khác</button>
          </div>
        )}
        {url && (
          <div className="space-y-3">
            <video ref={videoRef} src={url} playsInline controls className="max-h-[50vh] w-full rounded-xl border" />
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Độ nhạy phát hiện cắt cảnh</Label>
                <Select value={sensitivity} onValueChange={setSensitivity}>
                  <SelectTrigger aria-label="Độ nhạy"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="thap">Thấp — chỉ cảnh cắt lớn</SelectItem>
                    <SelectItem value="vua">Vừa (khuyên dùng)</SelectItem>
                    <SelectItem value="cao">Cao — bắt cả cú máy ngắn</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Quét bao lâu (tính từ đầu)</Label>
                <Select value={scanSec} onValueChange={setScanSec}>
                  <SelectTrigger aria-label="Thời lượng quét"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 giây</SelectItem>
                    <SelectItem value="30">30 giây</SelectItem>
                    <SelectItem value="60">60 giây</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )}
        <RunButton loading={busy} onClick={analyze} disabled={!url} cost={tool.price}>
          <Film className="mr-1 h-4 w-4" /> Quét & tách phân cảnh
        </RunButton>
        {busy && stage && <p className="flex items-center gap-2 text-sm text-emerald-700"><Loader2 className="h-4 w-4 animate-spin" /> {stage}</p>}

        {scenes && (
          <div className="space-y-4 rounded-2xl border bg-card p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm font-semibold text-emerald-900">Phát hiện {scenes.length} phân cảnh</p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={exportCsv}><FileSpreadsheet className="mr-1 h-3.5 w-3.5" /> CSV</Button>
                <Button size="sm" variant="outline" onClick={exportJson}><FileJson className="mr-1 h-3.5 w-3.5" /> JSON</Button>
              </div>
            </div>

            {/* Timeline — mỗi cảnh một màu xen kẽ */}
            <div className="relative h-7 w-full overflow-hidden rounded-lg bg-stone-100" aria-label="Timeline phân cảnh">
              {scenes.map((s, i) => (
                <button
                  key={i}
                  onClick={() => jump(s.start)}
                  title={`Cảnh ${i + 1}: ${fmt(s.start)}–${fmt(s.end)}`}
                  className={`absolute inset-y-0 ${i % 2 === 0 ? 'bg-emerald-500/70' : 'bg-teal-500/60'} border-r border-white transition hover:bg-emerald-400`}
                  style={{ left: `${(s.start / dur) * 100}%`, width: `${((s.end - s.start) / dur) * 100}%` }}
                />
              ))}
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              {scenes.map((s, i) => (
                <div key={i} className="flex items-center gap-3 rounded-xl border p-2">
                  <img src={s.thumb} alt={`Cảnh ${i + 1}`} className="h-14 w-24 shrink-0 rounded-lg border object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-emerald-900">Cảnh {i + 1}</p>
                    <p className="text-xs text-stone-500">{fmt(s.start)} → {fmt(s.end)} · {(s.end - s.start).toFixed(1)}s</p>
                  </div>
                  <button onClick={() => jump(s.start)} className="rounded-lg bg-emerald-50 p-2 text-emerald-700 transition hover:bg-emerald-100" title="Xem cảnh này" aria-label={`Xem cảnh ${i + 1}`}>
                    <Play className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
            <p className="flex items-center gap-1.5 text-xs text-stone-500"><Info className="h-3.5 w-3.5" /> Shot list CSV/JSON dùng làm nguyên liệu dựng phim hoặc dán vào pipeline auto-editor.</p>
          </div>
        )}
        <OssNote />
      </div>
    </ToolPage>
  )
}

// ═══════════ 3) CẮT KHOẢNG LẶNG — phong cách auto-editor (WebAudio + jump-cut) ═══════════
export function SilenceCut({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [file, setFile] = useState<File | null>(null)
  const [url, setUrl] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [stage, setStage] = useState('')
  const [db, setDb] = useState('-40')
  const [seconds, setSeconds] = useState('10')
  const [stats, setStats] = useState<{ cut: number; total: number } | null>(null)
  const [result, setResult] = useState<{ url: string; blob: Blob } | null>(null)
  const videoRef = useRef<HTMLVideoElement | null>(null)

  const pick = (f?: File) => {
    if (!f) return
    if (f.size > 60_000_000) { alert('Video tối đa ~60MB — hãy cắt ngắn trước nhé'); return }
    setFile(f); setResult(null); setStats(null); setUrl(URL.createObjectURL(f))
  }
  const clear = () => { setFile(null); setUrl(null); setResult(null); setStats(null) }

  const process = () =>
    run(
      tool,
      async () => {
        const v = videoRef.current
        if (!v) throw new Error('Chưa có video')
        setBusy(true)
        try {
          const maxSec = Math.min(Number(seconds), v.duration || Number(seconds))
          // 1) Phân tích âm lượng — tìm khoảng im lặng (WebAudio)
          setStage('Đang phân tích âm thanh…')
          const ac = new AudioContext()
          const buf = await ac.decodeAudioData(await file!.arrayBuffer())
          const sr = buf.sampleRate
          const ch = buf.getChannelData(0)
          const win = Math.round(sr * 0.05) // cửa sổ 50ms
          const thrAmp = Math.pow(10, Number(db) / 20)
          const nWin = Math.min(Math.floor(ch.length / win), Math.round(maxSec / 0.05))
          const loud = new Array<boolean>(nWin)
          for (let w = 0; w < nWin; w++) {
            let sum = 0
            for (let i = w * win; i < (w + 1) * win; i += 4) sum += ch[i] * ch[i]
            loud[w] = Math.sqrt(sum / (win / 4)) > thrAmp
          }
          // 2) Dựng danh sách đoạn giữ tiếng (chừa đệm 120ms, gộp đoạn quá ngắn)
          const pad = 0.12
          const segs: { s: number; e: number }[] = []
          for (let w = 0; w < nWin; w++) {
            if (!loud[w]) continue
            const s = Math.max(0, w * 0.05 - pad), e = Math.min(maxSec, (w + 1) * 0.05 + pad)
            if (segs.length > 0 && s - segs[segs.length - 1].e < 0.25) segs[segs.length - 1].e = e
            else segs.push({ s, e })
          }
          const totalKeep = segs.reduce((a, s) => a + (s.e - s.s), 0)
          if (segs.length === 0) throw new Error('Không tìm thấy đoạn có tiếng — thử ngưỡng im lặng cao hơn (−30dB)')
          const cutPct = Math.max(0, Math.round((1 - totalKeep / maxSec) * 100))
          setStage(`Bỏ được ${cutPct}% thời lượng — đang trích khung hình…`)

          // 3) Trích khung hình theo các đoạn giữ (12 fps)
          const fpsN = 12
          const vw = v.videoWidth || 640, vh = v.videoHeight || 360
          const sc = Math.min(1, MAX_SIDE / Math.max(vw, vh))
          const W = Math.round(vw * sc / 2) * 2, H = Math.round(vh * sc / 2) * 2
          const octx = document.createElement('canvas').getContext('2d')!
          const ocv = octx.canvas
          ocv.width = W; ocv.height = H
          const times: number[] = []
          for (const seg of segs) for (let t = seg.s; t < seg.e && times.length < 288; t += 1 / fpsN) times.push(t)
          const frames: HTMLCanvasElement[] = []
          for (let i = 0; i < times.length; i++) {
            if (i % 12 === 0) setStage(`Trích khung ${i + 1}/${times.length}…`)
            await seekVideo(v, Math.min(v.duration - 0.01, times[i]))
            octx.drawImage(v, 0, 0, W, H)
            const fc = document.createElement('canvas')
            fc.width = W; fc.height = H
            fc.getContext('2d')!.drawImage(ocv, 0, 0)
            frames.push(fc)
          }

          // 4) Âm thanh mới: ghép các đoạn giữ thành buffer liền mạch
          setStage('Ghép âm thanh liền mạch…')
          const newDur = times.length / fpsN
          const newBuf = ac.createBuffer(1, Math.ceil(newDur * sr), sr)
          const nd = newBuf.getChannelData(0)
          let wOff = 0
          for (const seg of segs) {
            const a = Math.floor(seg.s * sr), b = Math.min(ch.length, Math.floor(seg.e * sr))
            const n = Math.min(b - a, nd.length - wOff)
            if (n <= 0) break
            nd.set(ch.subarray(a, a + n), wOff)
            wOff += n
          }
          const dest = ac.createMediaStreamDestination()
          const src = ac.createBufferSource()
          src.buffer = newBuf
          src.connect(dest)

          // 5) Dựng video nhảy cắt + audio đồng bộ (audio start ngay tick đầu của vòng ghi)
          setStage('Đang dựng video đã cắt khoảng lặng…')
          let audioStarted = false
          const blob = await recordCanvas(ocv, {
            fps: fpsN,
            durationMs: newDur * 1000,
            audioTrack: dest.stream.getAudioTracks()[0] || null,
            draw: (el) => {
              if (!audioStarted) { try { src.start() } catch { /* đã phát */ } audioStarted = true }
              const i = Math.min(frames.length - 1, Math.floor((el / 1000) * fpsN))
              octx.drawImage(frames[i], 0, 0)
              return el >= newDur * 1000
            },
          })
          ac.close().catch(() => {})
          if (blob.size < 300) throw new Error('Trình duyệt không hỗ trợ ghi video (MediaRecorder)')
          setStats({ cut: cutPct, total: maxSec })
          setResult({ url: URL.createObjectURL(blob), blob })
        } finally {
          setBusy(false)
          setStage('')
        }
      },
      'Đã cắt sạch khoảng lặng — video gọn gàng hơn hẳn'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        {!url ? (
          <FileDrop accept="video/mp4,video/webm,video/quicktime,video/*" onFiles={(fs) => pick(fs[0])} label="Thả video nói/vlog/bài giảng vào đây" hint="MP4 / WebM · AI tự tìm & bỏ khoảng lặng — tối đa ~60MB" />
        ) : (
          <div className="flex items-center justify-between rounded-xl border bg-card p-3">
            <p className="flex items-center gap-2 truncate text-sm text-emerald-900"><Film className="h-4 w-4 shrink-0" /> {file?.name}</p>
            <button onClick={clear} className="text-xs text-stone-600 underline">Chọn video khác</button>
          </div>
        )}
        {url && (
          <div className="space-y-3">
            <video ref={videoRef} src={url} playsInline controls className="max-h-[50vh] w-full rounded-xl border" />
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Ngưỡng coi là im lặng</Label>
                <Select value={db} onValueChange={setDb}>
                  <SelectTrigger aria-label="Ngưỡng im lặng"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="-50">−50dB — chỉ im tuyệt đối</SelectItem>
                    <SelectItem value="-40">−40dB (khuyên dùng)</SelectItem>
                    <SelectItem value="-30">−30dB — cắt cả tiếng ồn nền</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Xử lý bao lâu (tính từ đầu)</Label>
                <Select value={seconds} onValueChange={setSeconds}>
                  <SelectTrigger aria-label="Thời lượng xử lý"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10 giây</SelectItem>
                    <SelectItem value="20">20 giây</SelectItem>
                    <SelectItem value="30">30 giây</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )}
        <RunButton loading={busy} onClick={process} disabled={!url} cost={tool.price}>
          <Film className="mr-1 h-4 w-4" /> Cắt khoảng lặng
        </RunButton>
        {busy && stage && <p className="flex items-center gap-2 text-sm text-emerald-700"><Loader2 className="h-4 w-4 animate-spin" /> {stage}</p>}
        {result && stats && (
          <div className="space-y-3 rounded-2xl border bg-card p-4">
            <p className="text-sm font-semibold text-emerald-900">
              Đã bỏ {stats.cut}% thời lượng im lặng ({stats.total}s → gọn hơn hẳn):
            </p>
            <video src={result.url} controls className="max-h-[55vh] w-full rounded-xl border" />
            <button
              onClick={() => downloadBlob(result.blob, `video-cat-lang-${Date.now()}.webm`)}
              className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-500"
            >
              <Download className="h-4 w-4" /> Tải video WebM ({(result.blob.size / 1024 / 1024).toFixed(1)} MB)
            </button>
          </div>
        )}
        <OssNote />
      </div>
    </ToolPage>
  )
}

// ═══════════ 4) PHÁT THANH VIÊN AI — SadTalker-style: ảnh + kịch bản → video phát thanh ═══════════
const VOICE_OPTIONS = [
  { v: 'tongtong', label: 'TongTong — ấm áp (khuyên dùng)' },
  { v: 'chuichui', label: 'ChuiChui — nhanh nhẹn' },
  { v: 'xiaochen', label: 'XiaoChen — dịu dàng' },
  { v: 'jam', label: 'Jam — trầm ấm' },
  { v: 'kazi', label: 'Kazi — trẻ trung' },
  { v: 'douji', label: 'Douji — mạnh mẽ' },
  { v: 'luodo', label: 'LuoDo — cân bằng' },
] as const

export function AiBroadcaster({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [imgUrl, setImgUrl] = useState<string | null>(null)
  const [imgFile, setImgFile] = useState<File | null>(null)
  const [script, setScript] = useState('')
  const [voice, setVoice] = useState('tongtong')
  const [speed, setSpeed] = useState('1')
  const [ratio, setRatio] = useState('9:16')
  const [busy, setBusy] = useState(false)
  const [stage, setStage] = useState('')
  const [result, setResult] = useState<{ url: string; blob: Blob } | null>(null)

  const pick = (f?: File) => {
    if (!f) return
    if (f.size > 8_000_000) { alert('Ảnh tối đa ~8MB'); return }
    setImgFile(f); setImgUrl(URL.createObjectURL(f)); setResult(null)
  }

  // Chia câu + dự kiến thời điểm từng câu (theo tỉ lệ ký tự)
  const splitSentences = (text: string) =>
    text.split(/(?<=[.!?…:;])\s+|\n+/).map((s) => s.trim()).filter(Boolean)

  const process = () =>
    run(
      tool,
      async () => {
        if (!imgUrl || !imgFile) throw new Error('Chưa chọn ảnh phát thanh viên')
        const text = script.trim()
        if (text.length < 10) throw new Error('Kịch bản quá ngắn — hãy viết ít nhất 10 ký tự')
        setBusy(true)
        try {
          // 1) Tạo giọng đọc AI
          setStage('Đang tạo giọng đọc AI…')
          const res = await fetch('/api/tiai/voice', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text, voice, speed: Number(speed) }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'Tạo giọng đọc thất bại')

          // 2) Giải mã âm thanh
          setStage('Đang xử lý âm thanh…')
          const ac = new AudioContext()
          const audioBuf = await ac.decodeAudioData(await (await fetch(data.audio as string)).arrayBuffer())
          const dur = audioBuf.duration
          if (dur > 150) { ac.close(); throw new Error('Kịch bản đọc quá dài (>150 giây) — hãy rút gọn') }

          // 3) Ảnh + khung vẽ theo tỷ lệ
          const { img } = await fileToImage(imgFile)
          const [W, H] = ratio === '1:1' ? [900, 900] : ratio === '16:9' ? [1280, 720] : [720, 1280]
          const cv = document.createElement('canvas')
          cv.width = W; cv.height = H
          const ctx = cv.getContext('2d')!

          const sents = splitSentences(text)
          const totalChars = sents.reduce((a, s) => a + s.length, 0) || 1
          let acc = 0
          const marks = sents.map((s) => { const t0 = (acc / totalChars) * dur; acc += s.length; return { t0, s } })

          const drawCover = (zoom: number) => {
            const iw = img.width, ih = img.height
            const base = Math.max(W / iw, H / ih)
            const s = base * zoom
            const dw = iw * s, dh = ih * s
            ctx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh)
          }
          const wrap = (t: string, maxW: number) => {
            const words = t.split(/\s+/)
            const lines: string[] = []
            let line = ''
            for (const w of words) {
              const test = line ? `${line} ${w}` : w
              if (ctx.measureText(test).width > maxW && line) { lines.push(line); line = w; if (lines.length === 2) break }
              else line = test
            }
            if (lines.length < 2 && line) lines.push(line)
            return lines
          }

          // 4) Phát audio → ghi canvas (audio start ngay tick đầu của vòng ghi)
          setStage('Đang quay video phát thanh…')
          const dest = ac.createMediaStreamDestination()
          const src = ac.createBufferSource()
          src.buffer = audioBuf
          src.connect(dest)
          let audioStarted = false
          const blob = await recordCanvas(cv, {
            fps: 25,
            durationMs: dur * 1000,
            audioTrack: dest.stream.getAudioTracks()[0] || null,
            draw: (el) => {
              if (!audioStarted) { try { src.start() } catch { /* đã phát */ } audioStarted = true }
              const t = el / 1000
              const p = Math.min(1, t / dur)
              drawCover(1 + 0.1 * p) // Ken Burns zoom chậm
              // gradient nền dưới cho phụ đề
              const g = ctx.createLinearGradient(0, H * 0.78, 0, H)
              g.addColorStop(0, 'rgba(0,0,0,0)')
              g.addColorStop(1, 'rgba(0,0,0,0.62)')
              ctx.fillStyle = g
              ctx.fillRect(0, H * 0.78, W, H * 0.22)
              // phụ đề câu hiện tại
              let cur = marks[0]?.s ?? ''
              for (const m of marks) if (t >= m.t0) cur = m.s
              if (cur) {
                const fs = Math.round(W * 0.052)
                ctx.font = `600 ${fs}px sans-serif`
                ctx.textAlign = 'center'
                const lines = wrap(cur, W * 0.86)
                lines.forEach((ln, i) => {
                  const y = H - 34 - (lines.length - 1 - i) * fs * 1.3
                  ctx.fillStyle = 'rgba(0,0,0,0.55)'
                  const wdt = ctx.measureText(ln).width
                  ctx.fillRect((W - wdt) / 2 - 14, y - fs, wdt + 28, fs * 1.45)
                  ctx.fillStyle = '#fff'
                  ctx.fillText(ln, W / 2, y)
                })
              }
              return el >= dur * 1000
            },
          })
          ac.close().catch(() => {})
          if (blob.size < 300) throw new Error('Trình duyệt không hỗ trợ ghi video (MediaRecorder)')
          setResult({ url: URL.createObjectURL(blob), blob })
        } finally {
          setBusy(false)
          setStage('')
        }
      },
      'Video phát thanh đã hoàn tất — giọng AI + phụ đề theo câu'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        {!imgUrl ? (
          <FileDrop accept="image/png,image/jpeg,image/webp" onFiles={(fs) => pick(fs[0])} label="Thả ảnh phát thanh viên vào đây" hint="Ảnh chân dung/sản phẩm — AI sẽ dựng video giọng đọc từ ảnh này" />
        ) : (
          <div className="relative overflow-hidden rounded-2xl border bg-stone-100">
            <img src={imgUrl} alt="Ảnh phát thanh viên" className="mx-auto max-h-[300px] w-full object-contain" />
            <Button variant="secondary" size="sm" className="absolute right-3 top-3" onClick={() => { setImgUrl(null); setImgFile(null) }}>Đổi ảnh</Button>
          </div>
        )}

        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label>Kịch bản giọng đọc</Label>
            <span className={`text-xs ${script.length > 1024 ? 'font-bold text-red-600' : 'text-stone-400'}`}>{script.length}/1024</span>
          </div>
          <Textarea
            value={script}
            onChange={(e) => setScript(e.target.value)}
            rows={4}
            placeholder="VD: Xin chào quý vị! Chào mừng đến với bản tin Vexon — mọi cập nhật mới nhất về sản phẩm sẽ có ngay sau đây…"
            aria-label="Kịch bản giọng đọc"
          />
        </div>

        <div className="grid gap-3 sm:grid-cols-3">
          <div className="space-y-1.5">
            <Label>Giọng đọc AI</Label>
            <Select value={voice} onValueChange={setVoice}>
              <SelectTrigger aria-label="Giọng đọc"><SelectValue /></SelectTrigger>
              <SelectContent>{VOICE_OPTIONS.map((o) => <SelectItem key={o.v} value={o.v}>{o.label}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Tốc độ đọc</Label>
            <Select value={speed} onValueChange={setSpeed}>
              <SelectTrigger aria-label="Tốc độ đọc"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0.9">Chậm hơn một nhịp</SelectItem>
                <SelectItem value="1">Chuẩn</SelectItem>
                <SelectItem value="1.2">Nhanh gọn</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Tỷ lệ khung hình</Label>
            <Select value={ratio} onValueChange={setRatio}>
              <SelectTrigger aria-label="Tỷ lệ khung hình"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="9:16">9:16 — TikTok/Reels</SelectItem>
                <SelectItem value="1:1">1:1 — Bài đăng</SelectItem>
                <SelectItem value="16:9">16:9 — YouTube</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <RunButton loading={busy} onClick={process} disabled={!imgUrl || script.trim().length < 10 || script.length > 1024} cost={tool.price}>
          <Film className="mr-1 h-4 w-4" /> Dựng video phát thanh
        </RunButton>
        {busy && stage && <p className="flex items-center gap-2 text-sm text-emerald-700"><Loader2 className="h-4 w-4 animate-spin" /> {stage}</p>}
        {result && (
          <div className="space-y-3 rounded-2xl border bg-card p-4">
            <p className="text-sm font-semibold text-emerald-900">Video phát thanh hoàn tất:</p>
            <video src={result.url} controls className="max-h-[60vh] w-full rounded-xl border" />
            <button
              onClick={() => downloadBlob(result.blob, `phat-thanh-vien-ai-${Date.now()}.webm`)}
              className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-500"
            >
              <Download className="h-4 w-4" /> Tải video WebM ({(result.blob.size / 1024 / 1024).toFixed(1)} MB)
            </button>
          </div>
        )}
        <OssNote />
      </div>
    </ToolPage>
  )
}
