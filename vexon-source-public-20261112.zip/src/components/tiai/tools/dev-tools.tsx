'use client'

// ============ TIỆN ÍCH NHANH (client-side, miễn phí): mật khẩu · JSON · màu · đếm chữ ============

import { useMemo, useState } from 'react'
import { toast } from 'sonner'
import { Copy, Check, KeyRound, RefreshCw, Braces, Palette, Type } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { ToolPage, RunButton, useAiRun } from '../shared'
import type { Tool } from '@/lib/tiai/tools'

function CopyBtn({ text, small = false }: { text: string; small?: boolean }) {
  const [copied, setCopied] = useState(false)
  return (
    <button
      onClick={async () => { await navigator.clipboard.writeText(text); setCopied(true); toast.success('Đã copy'); setTimeout(() => setCopied(false), 1500) }}
      className={`flex items-center gap-1 rounded-lg font-medium text-stone-500 transition hover:bg-stone-100 ${small ? 'px-1.5 py-0.5 text-[11px]' : 'px-2 py-1 text-xs'}`}
      aria-label="Copy"
    >
      {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />} Copy
    </button>
  )
}

// ───────────────────────── TẠO MẬT KHẨU ─────────────────────────
const SETS = { lower: 'abcdefghijkmnpqrstuvwxyz', upper: 'ABCDEFGHJKLMNPQRSTUVWXYZ', digits: '23456789', symbols: '!@#$%^&*()-_=+[]{};:,.?' }

function genPassword(len: number, opts: { upper: boolean; digits: boolean; symbols: boolean }): string {
  const pool = SETS.lower + (opts.upper ? SETS.upper : '') + (opts.digits ? SETS.digits : '') + (opts.symbols ? SETS.symbols : '')
  const arr = new Uint32Array(len)
  crypto.getRandomValues(arr)
  return Array.from(arr, (n) => pool[n % pool.length]).join('')
}

function strengthOf(len: number, opts: { upper: boolean; digits: boolean; symbols: boolean }): { label: string; pct: number; color: string } {
  let kinds = 1 + (opts.upper ? 1 : 0) + (opts.digits ? 1 : 0) + (opts.symbols ? 1 : 0)
  const score = len * kinds
  if (score >= 60) return { label: 'Cực mạnh', pct: 100, color: 'bg-emerald-600' }
  if (score >= 42) return { label: 'Mạnh', pct: 75, color: 'bg-emerald-500' }
  if (score >= 28) return { label: 'Khá', pct: 50, color: 'bg-amber-500' }
  return { label: 'Yếu', pct: 25, color: 'bg-red-500' }
}

export function TaoMatKhau({ tool }: { tool: Tool }) {
  const [len, setLen] = useState(16)
  const [upper, setUpper] = useState(true)
  const [digits, setDigits] = useState(true)
  const [symbols, setSymbols] = useState(true)
  const [seed, setSeed] = useState(0)
  const [unlocked, setUnlocked] = useState(false)
  const opts = useMemo(() => ({ upper, digits, symbols }), [upper, digits, symbols])
  const { run: paidRun } = useAiRun()

  // Mật khẩu sinh thuần khiết theo seed — đổi tùy chọn là tự cập nhật, không cần effect
  const { password, batch } = useMemo(() => ({
    password: genPassword(len, opts),
    batch: Array.from({ length: 5 }, () => genPassword(len, opts)),
  }), [len, opts, seed])

  // Sinh miễn phí — ghi lại lần dùng vào lịch sử
  const gen = () =>
    paidRun(tool, async () => { setSeed((s) => s + 1); setUnlocked(true) }, 'Mật khẩu mới đã sẵn sàng')

  const st = strengthOf(len, opts)
  return (
    <ToolPage tool={tool}>
      <div className="space-y-5">
        {!unlocked ? (
          <div className="space-y-4 rounded-2xl border border-dashed border-emerald-300 bg-emerald-50/50 p-8 text-center">
            <KeyRound className="mx-auto h-8 w-8 text-emerald-600" />
            <p className="mx-auto max-w-sm text-sm text-stone-600">Sinh mật khẩu ngẫu nhiên an toàn bằng crypto ngay trên máy bạn — kèm 5 gợi ý và đo độ mạnh.</p>
            <div className="mx-auto max-w-xs"><RunButton loading={false} onClick={gen} cost={tool.price}>Sinh mật khẩu</RunButton></div>
          </div>
        ) : (
        <div className="rounded-2xl border border-stone-200 bg-card p-4">
          <div className="flex items-center justify-between gap-2">
            <p className="select-all break-all font-mono text-lg font-bold text-emerald-950">{password}</p>
            <div className="flex shrink-0 items-center gap-1">
              <CopyBtn text={password} />
              <button onClick={gen} className="rounded-lg p-1.5 text-stone-500 transition hover:bg-stone-100" title="Sinh mật khẩu khác" aria-label="Sinh mật khẩu khác">
                <RefreshCw className="h-4 w-4" />
              </button>
            </div>
          </div>
          <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-stone-100">
            <div className={`h-full rounded-full transition-all ${st.color}`} style={{ width: `${st.pct}%` }} />
          </div>
          <p className="mt-1 text-xs font-medium text-stone-500">Độ mạnh: {st.label}</p>
        </div>
        )}

        <div className="space-y-4 rounded-2xl border border-stone-200 bg-card p-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Độ dài: <b>{len}</b> ký tự</Label>
            </div>
            <Slider value={[len]} min={8} max={64} step={1} onValueChange={(v) => setLen(v[0])} aria-label="Độ dài mật khẩu" />
          </div>
          <div className="grid gap-2 sm:grid-cols-3">
            <div className="flex items-center justify-between rounded-lg border p-2.5"><span className="text-sm">Chữ HOA</span><Switch checked={upper} onCheckedChange={setUpper} aria-label="Chữ hoa" /></div>
            <div className="flex items-center justify-between rounded-lg border p-2.5"><span className="text-sm">Chữ số</span><Switch checked={digits} onCheckedChange={setDigits} aria-label="Chữ số" /></div>
            <div className="flex items-center justify-between rounded-lg border p-2.5"><span className="text-sm">Ký tự đặc biệt</span><Switch checked={symbols} onCheckedChange={setSymbols} aria-label="Ký tự đặc biệt" /></div>
          </div>
        </div>

        {unlocked && batch.length > 0 && (
          <div className="rounded-2xl border border-stone-200 bg-card p-4">
            <p className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-emerald-800"><KeyRound className="h-4 w-4" /> 5 gợi ý khác</p>
            <ul className="space-y-1.5">
              {batch.map((p, i) => (
                <li key={i} className="flex items-center justify-between gap-2 rounded-lg bg-stone-50 px-3 py-1.5">
                  <code className="select-all truncate text-sm">{p}</code>
                  <CopyBtn text={p} small />
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ───────────────────────── JSON FORMAT ─────────────────────────
export function JsonFormat({ tool }: { tool: Tool }) {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [error, setError] = useState('')
  const { run: paidRun } = useAiRun()

  const runJson = (mode: 'format' | 'minify') =>
    paidRun(
      tool,
      async () => {
        try {
          const parsed = JSON.parse(input)
          setOutput(mode === 'format' ? JSON.stringify(parsed, null, 2) : JSON.stringify(parsed))
        } catch (e) {
          setError(e instanceof Error ? e.message : 'JSON không hợp lệ')
          throw new Error('JSON không hợp lệ')
        }
      },
      mode === 'format' ? 'Đã định dạng JSON' : 'Đã nén gọn JSON',
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-sm font-semibold text-emerald-900"><Braces className="h-4 w-4" /> JSON vào</p>
            <p className="text-xs text-stone-500">{input.length.toLocaleString('vi-VN')} ký tự</p>
          </div>
          <Textarea value={input} onChange={(e) => setInput(e.target.value)} rows={8} placeholder='{"hello": "Vexon", "tools": ["dịch", "viết", "code"]}' className="font-mono text-xs" aria-label="JSON đầu vào" />
        </div>
        <div className="flex gap-2">
          <RunButton loading={false} onClick={() => runJson('format')} disabled={!input.trim()} cost={tool.price}>
            <span className="whitespace-nowrap">Định dạng đẹp</span>
          </RunButton>
          <Button onClick={() => runJson('minify')} disabled={!input.trim()} variant="outline" className="flex-1 rounded-xl">Nén gọn</Button>
        </div>
        {error && <p className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-600">Lỗi: {error}</p>}
        {output && (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold text-emerald-700">JSON ra</p>
              <CopyBtn text={output} />
            </div>
            <Textarea readOnly value={output} rows={8} className="font-mono text-xs" aria-label="JSON đầu ra" />
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ───────────────────────── BẢNG MÀU ─────────────────────────
function hexToRgb(hex: string): [number, number, number] {
  const m = hex.replace('#', '')
  return [parseInt(m.slice(0, 2), 16), parseInt(m.slice(2, 4), 16), parseInt(m.slice(4, 6), 16)]
}
function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255; g /= 255; b /= 255
  const max = Math.max(r, g, b), min = Math.min(r, g, b)
  const l = (max + min) / 2
  if (max === min) return [0, 0, Math.round(l * 100)]
  const d = max - min
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
  let h = 0
  if (max === r) h = ((g - b) / d + (g < b ? 6 : 0))
  else if (max === g) h = (b - r) / d + 2
  else h = (r - g) / d + 4
  return [Math.round(h * 60), Math.round(s * 100), Math.round(l * 100)]
}
function harmonies(h: number, s: number, l: number): string[] {
  const mk = (hh: number, ss = s, ll = l) => `hsl(${(hh + 360) % 360} ${ss}% ${ll}%)`
  return [mk(h + 30), mk(h + 180), mk(h - 30), mk(h + 90), mk(h + 180, s, Math.max(20, l - 25))]
}

export function BangMau({ tool }: { tool: Tool }) {
  const [hex, setHex] = useState('#059669')
  const valid = /^#[0-9a-fA-F]{6}$/.test(hex)
  const [r, g, b] = useMemo(() => (valid ? hexToRgb(hex) : [0, 0, 0]), [valid, hex])
  const [h, s, l] = useMemo(() => (valid ? rgbToHsl(r, g, b) : [0, 0, 0]), [valid, r, g, b])
  const palette = useMemo(() => (valid ? harmonies(h, s, l) : []), [valid, h, s, l])
  const [unlocked, setUnlocked] = useState(false)
  const { run: paidRun } = useAiRun()

  const unlock = () =>
    paidRun(tool, async () => setUnlocked(true), 'Bảng màu hài hòa đã sẵn sàng')

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-stone-200 bg-card p-4">
          <input
            type="color"
            value={valid ? hex : '#059669'}
            onChange={(e) => setHex(e.target.value.toUpperCase())}
            className="h-20 w-20 cursor-pointer rounded-xl border"
            aria-label="Chọn màu"
          />
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <Input value={hex} onChange={(e) => setHex(e.target.value.toUpperCase())} className="w-32 font-mono" aria-label="Mã màu HEX" />
              <CopyBtn text={hex} />
            </div>
            <p className="font-mono text-sm text-stone-600">rgb({r}, {g}, {b})</p>
            <p className="font-mono text-sm text-stone-600">hsl({h}, {s}%, {l}%)</p>
            {!valid && <p className="text-xs text-red-500">Mã HEX cần 6 ký tự, VD: #059669</p>}
          </div>
        </div>
        {valid && (
          !unlocked ? (
            <div className="space-y-4 rounded-2xl border border-dashed border-emerald-300 bg-emerald-50/50 p-8 text-center">
              <Palette className="mx-auto h-8 w-8 text-emerald-600" />
              <p className="mx-auto max-w-sm text-sm text-stone-600">Gợi ý 5 màu hài hòa từ màu bạn chọn — phối đồ, làm banner, chọn tông sản phẩm.</p>
              <div className="mx-auto max-w-xs"><RunButton loading={false} onClick={unlock} cost={tool.price}>Tạo bảng màu hài hòa</RunButton></div>
            </div>
          ) : (
          <div className="rounded-2xl border border-stone-200 bg-card p-4">
            <p className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-emerald-800"><Palette className="h-4 w-4" /> Bảng màu hài hòa từ màu này</p>
            <div className="grid grid-cols-5 gap-2">
              <div className="space-y-1">
                <div className="h-14 rounded-lg border" style={{ backgroundColor: hex }} />
                <CopyBtn text={hex} small />
              </div>
              {palette.map((c, i) => (
                <div key={i} className="space-y-1">
                  <div className="h-14 rounded-lg border" style={{ backgroundColor: c }} />
                  <CopyBtn text={c} small />
                </div>
              ))}
            </div>
          </div>
          )
        )}
      </div>
    </ToolPage>
  )
}

// ───────────────────────── ĐẾM KÝ TỰ & TỪ ─────────────────────────
export function DemChu({ tool }: { tool: Tool }) {
  const [text, setText] = useState('')
  const [unlocked, setUnlocked] = useState(false)
  const { run: paidRun } = useAiRun()

  const count = () =>
    paidRun(tool, async () => setUnlocked(true), 'Đã đếm — số liệu cập nhật trực tiếp khi bạn gõ')

  const chars = text.length
  const noSpaces = text.replace(/\s/g, '').length
  const words = text.trim() ? text.trim().split(/\s+/).length : 0
  const lines = text ? text.split('\n').length : 0
  const paragraphs = text.trim() ? text.trim().split(/\n\s*\n/).length : 0
  const readMin = Math.max(1, Math.round(words / 200))

  const stats = [
    ['Ký tự', chars], ['Khôngspace', noSpaces], ['Từ', words], ['Dòng', lines], ['Đoạn', paragraphs], ['Phút đọc', readMin],
  ] as const

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        {unlocked ? (
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
            {stats.map(([label, v]) => (
              <div key={label} className="rounded-xl border border-stone-200 bg-card p-3 text-center">
                <p className="text-xl font-black text-emerald-800">{v.toLocaleString('vi-VN')}</p>
                <p className="text-[11px] text-stone-500">{label}</p>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4 rounded-2xl border border-dashed border-emerald-300 bg-emerald-50/50 p-8 text-center">
            <Type className="mx-auto h-8 w-8 text-emerald-600" />
            <p className="mx-auto max-w-sm text-sm text-stone-600">Đếm ký tự, từ, dòng và thời gian đọc — dùng trước khi đăng bài, soạn nội dung.</p>
            <div className="mx-auto max-w-xs"><RunButton loading={false} onClick={count} disabled={!text.trim()} cost={tool.price}>Đếm ngay</RunButton></div>
          </div>
        )}
        <div className="space-y-1.5">
          <p className="flex items-center gap-1.5 text-sm font-semibold text-emerald-900"><Type className="h-4 w-4" /> Dán nội dung cần đếm</p>
          <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={10} placeholder="Gõ hoặc dán văn bản — số liệu cập nhật ngay khi bạn gõ…" aria-label="Văn bản đếm" />
        </div>
      </div>
    </ToolPage>
  )
}
