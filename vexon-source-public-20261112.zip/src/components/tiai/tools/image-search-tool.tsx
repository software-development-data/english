'use client'

// ============ TÌM ẢNH THAM KHẢO — ảnh thật từ web kèm nguồn ============

import { useState } from 'react'
import { Loader2, Search, ExternalLink, ImageOff } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ToolPage, useAiRun } from '../shared'
import type { Tool } from '@/lib/tiai/tools'

interface ImgResult { url: string; caption: string; source: string; width: string; height: string }

export function TimAnhMau({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState<ImgResult[]>([])
  const [failed, setFailed] = useState<Record<string, boolean>>({})

  const go = () =>
    run(
      tool,
      async () => {
        if (query.trim().length < 2) throw new Error('Nhập từ khóa tìm kiếm')
        setLoading(true)
        try {
          const res = await fetch('/api/tiai/image-search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: query.trim() }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'Không tìm thấy ảnh')
          setResults(data.results)
        } finally {
          setLoading(false)
        }
      },
      query.trim()
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <div className="flex gap-2">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') go() }}
            placeholder="VD: nhà hàng quán cà phê đẹp, mẫu hộp giấy đóng gói…"
            aria-label="Từ khóa tìm ảnh"
          />
          <Button
            onClick={go}
            disabled={loading || query.trim().length < 2}
            className="h-10 shrink-0 gap-2 rounded-xl bg-emerald-600 px-5 font-semibold text-white hover:bg-emerald-500"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            Tìm
          </Button>
        </div>
        <p className="text-xs text-stone-500">Ảnh thật từ web, kèm nguồn — dùng để tham khảo ý tưởng, không nên dùng nguyên bản làm sản phẩm của bạn.</p>
        {results.length > 0 && (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {results.map((r, i) => (
              <a key={`${r.url}-${i}`} href={r.url} target="_blank" rel="noreferrer" className="group overflow-hidden rounded-xl border bg-white shadow-sm transition hover:shadow-md">
                <div className="aspect-square bg-stone-100">
                  {failed[r.url] ? (
                    <div className="flex h-full items-center justify-center"><ImageOff className="h-6 w-6 text-stone-300" /></div>
                  ) : (
                    <img
                      src={r.url}
                      alt={r.caption || 'Ảnh tham khảo'}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform group-hover:scale-[1.03]"
                      onError={() => setFailed((f) => ({ ...f, [r.url]: true }))}
                    />
                  )}
                </div>
                <div className="p-2">
                  <p className="line-clamp-2 text-[11px] leading-tight text-stone-600">{r.caption || 'Ảnh tham khảo'}</p>
                  <p className="mt-1 flex items-center gap-1 truncate text-[10px] text-emerald-700"><ExternalLink className="h-2.5 w-2.5" /> {r.source || 'Nguồn web'}</p>
                </div>
              </a>
            ))}
          </div>
        )}
      </div>
    </ToolPage>
  )
}
