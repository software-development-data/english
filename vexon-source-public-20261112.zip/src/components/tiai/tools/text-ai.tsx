'use client'

// ============ CÔNG CỤ VĂN BẢN AI: Dịch thuật · Viết nội dung · Trợ lý code ============
// Dùng chung endpoint /api/tiai/chat — chỉ trừ Xu khi thành công qua useAiRun

import { useState } from 'react'
import { toast } from 'sonner'
import { Loader2, Copy, Check, Languages, PenLine, Code2, SendHorizonal } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ToolPage, useAiRun } from '../shared'
import type { Tool } from '@/lib/tiai/tools'

const LANGS = ['Tiếng Anh', 'Tiếng Trung', 'Tiếng Nhật', 'Tiếng Hàn', 'Tiếng Pháp', 'Tiếng Đức', 'Tiếng Nga', 'Tiếng Tây Ban Nha', 'Tiếng Thái', 'Tiếng Việt']
const TONES = ['Giữ nguyên văn phong', 'Trang trọng', 'Thân thiện', 'Học thuật', 'Quảng cáo hấp dẫn']
const WRITE_TYPES = ['Caption mạng xã hội', 'Email chuyên nghiệp', 'Mô tả sản phẩm', 'Kịch bản video ngắn', 'Bài viết blog', 'Thông báo nội bộ']
const CODE_LANGS = ['TypeScript/JavaScript', 'Python', 'Java', 'PHP', 'Go', 'C#', 'SQL', 'Dart/Flutter']
const CODE_TASKS = ['Viết code mới', 'Giải thích code', 'Tìm lỗi & sửa', 'Viết unit test', 'Tối ưu hiệu năng', 'Chuyển đổi ngôn ngữ khác']

function OutputBox({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  return (
    <div className="space-y-2 rounded-2xl border border-stone-200 bg-card p-4">
      <div className="flex items-center justify-between">
        <p className="font-semibold text-emerald-700">Kết quả AI</p>
        <button
          onClick={async () => { await navigator.clipboard.writeText(text); setCopied(true); toast.success('Đã copy kết quả'); setTimeout(() => setCopied(false), 1500) }}
          className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-stone-500 transition hover:bg-stone-100"
          aria-label="Copy kết quả"
        >
          {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />} Copy
        </button>
      </div>
      <p className="whitespace-pre-wrap text-sm leading-relaxed text-emerald-950">{text}</p>
    </div>
  )
}

function TextAiTool({ tool, label, selectLabel, options, placeholder, buildPrompt, examples }: {
  tool: Tool
  label?: string
  selectLabel: string
  options: string[]
  placeholder: string
  buildPrompt: (input: string, option: string) => string
  examples?: string[]
}) {
  const { run } = useAiRun()
  const [input, setInput] = useState('')
  const [option, setOption] = useState(options[0])
  const [loading, setLoading] = useState(false)
  const [output, setOutput] = useState('')

  const go = () =>
    run(
      tool,
      async () => {
        if (input.trim().length < 2) throw new Error('Nhập nội dung trước đã!')
        setLoading(true)
        try {
          const res = await fetch('/api/tiai/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: buildPrompt(input.trim(), option) }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'AI xử lý thất bại')
          setOutput(data.text)
        } finally {
          setLoading(false)
        }
      },
      option
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <div className="space-y-1.5">
          <p className="text-sm font-semibold text-emerald-900">{selectLabel}</p>
          <Select value={option} onValueChange={setOption}>
            <SelectTrigger className="w-full sm:w-72" aria-label={selectLabel}>
              <SelectValue placeholder="Chọn..." />
            </SelectTrigger>
            <SelectContent>
              {options.map((o) => (
                <SelectItem key={o} value={o}>{o}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          rows={6}
          placeholder={placeholder}
          aria-label="Nội dung đầu vào"
        />
        {examples && (
          <div className="flex flex-wrap gap-1.5">
            {examples.map((ex) => (
              <button key={ex} onClick={() => setInput(ex)} className="rounded-full border border-stone-200 bg-white px-2.5 py-1 text-xs text-stone-600 transition hover:border-emerald-300 hover:bg-emerald-50">
                {ex}
              </button>
            ))}
          </div>
        )}
        <Button
          onClick={go}
          disabled={loading || input.trim().length < 2}
          className="h-12 w-full gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-base font-semibold text-white shadow-lg shadow-emerald-600/20 transition hover:from-emerald-500 hover:to-teal-500"
        >
          {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <SendHorizonal className="h-5 w-5" />}
          {loading ? 'Đang xử lý…' : 'Chạy ngay'}
        </Button>
        {output && <OutputBox text={output} />}
      </div>
    </ToolPage>
  )
}

export function DichThuat({ tool }: { tool: Tool }) {
  return (
    <TextAiTool
      tool={tool}
      selectLabel="Dịch sang ngôn ngữ nào?"
      options={LANGS}
      placeholder="Dán văn bản cần dịch (bất kỳ ngôn ngữ nào)…"
      examples={['Cảm ơn bạn đã đặt hàng, đơn sẽ được giao trong 2 ngày tới.', 'Vexon — một ứng dụng cho mọi nhu cầu.']}
      buildPrompt={(input, option) =>
        `Hãy dịch văn bản sau sang ${option}. Giữ nguyên ý nghĩa, văn phong và thuật ngữ chuyên ngành. Chỉ trả về bản dịch, không giải thích thêm:\n\n"""${input}"""`
      }
    />
  )
}
export function VietNoiDung({ tool }: { tool: Tool }) {
  return (
    <TextAiTool
      tool={tool}
      selectLabel="Bạn muốn viết gì?"
      options={WRITE_TYPES}
      placeholder="VD: viết caption giới thiệu áo thun local brand mới về, tone trẻ trung, có emoji…"
      examples={['Giới thiệu quán cà phê mới mở ở Đà Lạt', 'Email xin nghỉ phép 2 ngày', 'Mô tả tai nghe Bluetooth chống ồn']}
      buildPrompt={(input, option) =>
        `Hãy viết một ${option.toLowerCase()} bằng tiếng Việt dựa trên yêu cầu sau. Nội dung hấp dẫn, cấu trúc rõ ràng, phù hợp đăng ngay:\n\n"""${input}"""`
      }
    />
  )
}
export function HoTroCode({ tool }: { tool: Tool }) {
  return (
    <TextAiTool
      tool={tool}
      selectLabel="Nhiệm vụ lập trình"
      options={CODE_TASKS}
      placeholder="Dán code cần xử lý hoặc mô tả yêu cầu (nêu ngôn ngữ ở đầu nếu có)…"
      examples={['Viết hàm debounce trong TypeScript', 'Đoạn Python này bị lỗi gì?\nfor i in range(len(a))\n  print(a[i])']}
      buildPrompt={(input, option) =>
        `Bạn là lập trình viên senior. Nhiệm vụ: ${option}. Ngôn ngữ ưu tiên: JavaScript/TypeScript nếu không được nêu rõ. Trả lời bằng tiếng Việt, code trong khối \`\`\`:\n\n"""${input}"""`
      }
    />
  )
}
