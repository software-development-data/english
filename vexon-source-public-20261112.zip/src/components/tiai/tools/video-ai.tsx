'use client'

// ============ TẠO VIDEO AI — mô tả → video 5 giây (polling tiến độ) ============

import { useEffect, useRef, useState } from 'react'
import { Loader2, Clapperboard, Download, Film } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'sonner'
import { ToolPage, useAiRun } from '../shared'
import type { Tool } from '@/lib/tiai/tools'

export function TaoVideo({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [prompt, setPrompt] = useState('')
  const [quality, setQuality] = useState<'speed' | 'quality'>('speed')
  const [phase, setPhase] = useState<'idle' | 'submitting' | 'processing' | 'done'>('idle')
  const [progressNote, setProgressNote] = useState('')
  const [videoUrl, setVideoUrl] = useState<string | null>(null)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // Dọn polling khi rời trang
  useEffect(() => () => { if (timerRef.current) clearInterval(timerRef.current) }, [])

  const start = () =>
    run(
      tool,
      async () => {
        if (prompt.trim().length < 5) throw new Error('Mô tả video quá ngắn (tối thiểu 5 ký tự)')
        setPhase('submitting')
        setVideoUrl(null)
        try {
          const res = await fetch('/api/tiai/video', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: prompt.trim(), quality }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'Không tạo được video')
          const taskId: string = data.taskId
          setPhase('processing')
          setProgressNote('AI đang dựng khung hình… (thường mất 1–3 phút)')

          // Poll tiến độ mỗi 5s, tối đa ~6 phút
          await new Promise<void>((resolve, reject) => {
            let polls = 0
            timerRef.current = setInterval(async () => {
              polls++
              if (polls > 72) { clearInterval(timerRef.current!); reject(new Error('Hết thời gian chờ — thử lại với chế độ Nhanh nhé')); return }
              try {
                const st = await fetch(`/api/tiai/video?taskId=${encodeURIComponent(taskId)}`)
                const sd = await st.json()
                setProgressNote(`AI đang dựng khung hình… (${Math.min(polls, 72)}/72)`)
                if (sd.status === 'SUCCESS' && sd.videoUrl) {
                  clearInterval(timerRef.current!)
                  setVideoUrl(sd.videoUrl)
                  resolve()
                } else if (sd.status === 'FAIL') {
                  clearInterval(timerRef.current!)
                  reject(new Error('AI không dựng được video từ mô tả này — thử mô tả khác'))
                }
              } catch {
                /* bỏ qua lỗi poll lẻ, thử lần sau */
              }
            }, 5000)
          })
          setPhase('done')
        } finally {
          // giữ phase để hiện kết quả
        }
      },
      quality === 'quality' ? 'Video chất lượng cao' : 'Video nhanh'
    ).catch(() => setPhase('idle'))

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <Textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={4}
          placeholder="Mô tả video bạn muốn: VD: Một chiếc xe máy chạy trên đường đèo biển lúc bình minh, máy quay liếc ngang chậm…"
          aria-label="Mô tả video"
        />
        <div className="space-y-1.5">
          <p className="text-sm font-semibold text-emerald-900">Chế độ xử lý</p>
          <Select value={quality} onValueChange={(v) => setQuality(v as 'speed' | 'quality')}>
            <SelectTrigger className="w-full sm:w-72" aria-label="Chế độ xử lý video">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="speed">Nhanh (khuyên dùng)</SelectItem>
              <SelectItem value="quality">Chất lượng cao (chậm hơn, đẹp hơn)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button
          onClick={start}
          disabled={phase === 'submitting' || phase === 'processing' || prompt.trim().length < 5}
          className="h-12 w-full gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-base font-semibold text-white shadow-lg shadow-emerald-600/20 transition hover:from-emerald-500 hover:to-teal-500"
        >
          {phase === 'submitting' || phase === 'processing' ? <Loader2 className="h-5 w-5 animate-spin" /> : phase === 'done' ? <Film className="h-5 w-5" /> : <Clapperboard className="h-5 w-5" />}
          {phase === 'submitting' ? 'Đang gửi yêu cầu…' : phase === 'processing' ? 'Đang xử lý…' : 'Tạo video (Miễn phí)'}
        </Button>
        {phase === 'processing' && <p className="text-center text-sm text-emerald-700">{progressNote}</p>}
        {videoUrl && (
          <div className="space-y-2 rounded-2xl border border-stone-200 bg-card p-4">
            <p className="font-semibold text-emerald-700">Video hoàn tất — tải về dùng ngay, miễn phí!</p>
            <video src={videoUrl} controls className="w-full rounded-xl" aria-label="Video AI đã tạo" />
            <a
              href={videoUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex h-11 items-center gap-2 rounded-xl bg-emerald-600 px-4 font-semibold text-white transition hover:bg-emerald-500"
            >
              <Download className="h-4 w-4" /> Mở / tải video
            </a>
          </div>
        )}
      </div>
    </ToolPage>
  )
}
