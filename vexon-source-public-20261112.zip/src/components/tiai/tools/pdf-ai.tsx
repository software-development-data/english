'use client'

import { useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Loader2, SendHorizonal, FileText } from 'lucide-react'
import { ToolPage, FileDrop, useAiRun } from '../shared'
import { extractPdfText } from '@/lib/tiai/pdf'
import type { Tool } from '@/lib/tiai/tools'

interface Msg {
  role: 'user' | 'ai'
  text: string
}

export function TomTatPdf({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [file, setFile] = useState<File | null>(null)
  const [pages, setPages] = useState(0)
  const [loading, setLoading] = useState(false)
  const [progress, setProgress] = useState('')
  const [summary, setSummary] = useState('')
  const [question, setQuestion] = useState('')
  const [asking, setAsking] = useState(false)
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [err, setErr] = useState('')
  const textRef = useRef('')

  const pick = (fs: File[]) => {
    setFile(fs[0] ?? null)
    setSummary('')
    setMsgs([])
    setErr('')
  }

  const analyze = () =>
    run(
      tool,
      async () => {
        if (!file) throw new Error('Chưa chọn file PDF')
        setLoading(true)
        setErr('')
        try {
          const { pages: pageTexts, numPages } = await extractPdfText(file, (i, n) => setProgress(`Đang đọc trang ${i}/${n}…`))
          const text = pageTexts.join('\n\n').trim()
          if (text.length < 40) {
            throw new Error('PDF này không có lớp chữ (bản scan) — cần công cụ OCR, tạm thời chưa hỗ trợ')
          }
          textRef.current = text
          setPages(numPages)
          setProgress('AI đang tóm tắt…')
          const res = await fetch('/api/tiai/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              system: 'Bạn là trợ lý đọc tài liệu tiếng Việt. Tóm tắt ngắn gọn, chính xác, có cấu trúc bằng gạch đầu dòng.',
              prompt: `Tóm tắt tài liệu sau bằng tiếng Việt (tối đa 12 gạch đầu dòng, nêu ý chính và kết luận nếu có):\n\n"""${text.slice(0, 60000)}"""`,
            }),
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data.error || 'AI xử lý thất bại')
          setSummary(data.text)
          setMsgs([{ role: 'ai', text: 'Mình đã đọc xong tài liệu! Hỏi mình bất cứ điều gì về nội dung này nhé.' }])
          setProgress('')
        } finally {
          setLoading(false)
        }
      },
      `Đã phân tích ${pages || ''} trang tài liệu`
    ).then(() => setProgress(''))

  const ask = async () => {
    const q = question.trim()
    if (!q || !textRef.current || asking) return
    setQuestion('')
    setMsgs((m) => [...m, { role: 'user', text: q }])
    setAsking(true)
    try {
      const res = await fetch('/api/tiai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system: 'Bạn là trợ lý hỏi đáp tài liệu tiếng Việt. Trả lời NGẮN GỌN, dựa hoàn toàn vào nội dung tài liệu được cung cấp. Nếu tài liệu không có thông tin thì nói rõ.',
          prompt: `NỘI DUNG TÀI LIỆU:\n"""${textRef.current.slice(0, 60000)}"""\n\nCÂU HỎI: ${q}`,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'AI xử lý thất bại')
      setMsgs((m) => [...m, { role: 'ai', text: data.text }])
    } catch (e) {
      setMsgs((m) => [...m, { role: 'ai', text: `Có lỗi: ${e instanceof Error ? e.message : 'Lỗi không xác định'}` }])
    } finally {
      setAsking(false)
    }
  }

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <FileDrop
          accept="application/pdf"
          onFiles={pick}
          label={file ? (typeof file === 'string' ? file : file.name) : 'Thả file PDF vào đây'}
          hint="AI đọc trực tiếp, tóm tắt và trả lời câu hỏi — miễn phí, hỏi đáp thoải mái"
        />
        <button
          onClick={analyze}
          disabled={!file || loading}
          className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-base font-semibold text-white shadow-lg shadow-emerald-600/20 transition hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50"
        >
          {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <FileText className="h-5 w-5" />}
          {loading ? progress || 'Đang xử lý…' : 'Phân tích tài liệu (Miễn phí)'}
        </button>
        {err && <p className="text-sm font-medium text-red-400">{err}</p>}
        {summary && (
          <div className="space-y-4 rounded-2xl border border-stone-200 bg-card p-4">
            <div>
              <p className="mb-2 font-semibold text-emerald-700">Tóm tắt bởi AI</p>
              <p className="whitespace-pre-wrap text-sm leading-relaxed text-emerald-950">{summary}</p>
            </div>
            <div className="border-t border-stone-200 pt-3">
              <p className="mb-2 font-semibold text-emerald-700">Hỏi đáp về tài liệu</p>
              <div className="tiai-scroll mb-3 max-h-72 space-y-2 overflow-y-auto">
                {msgs.map((m, i) => (
                  <div key={i} className={`max-w-[85%] rounded-xl px-3 py-2 text-sm ${m.role === 'user' ? 'ml-auto bg-emerald-600 text-white' : 'bg-stone-100 text-emerald-950'}`}>
                    <p className="whitespace-pre-wrap">{m.text}</p>
                  </div>
                ))}
                {asking && <div className="rounded-xl bg-stone-100 px-3 py-2 text-sm text-emerald-700">AI đang soạn trả lời…</div>}
              </div>
              <div className="flex gap-2">
                <Input
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') ask() }}
                  placeholder="VD: Điều khoản quan trọng nhất là gì?"
                />
                <Button onClick={ask} disabled={asking || !textRef.current} className="gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500">
                  <SendHorizonal className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ToolPage>
  )
}
