'use client'

import { useRef, useState } from 'react'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { ToolPage, FileDrop, DownloadButton, BeforeAfter, ImagePick, RunButton, useAiRun } from '../shared'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { fileToDataUrl, loadImage, makeCanvas, canvasToBlob, cropCanvas, downloadBlob } from '@/lib/tiai/image'
import type { Tool } from '@/lib/tiai/tools'


// ─── NÉN ẢNH (miễn phí) ──────────────────────────────────
export function NenAnh({ tool }: { tool: Tool }) {
  const [file, setFile] = useState<File | null>(null)
  const [url, setUrl] = useState<string | null>(null)
  const [quality, setQuality] = useState(70)
  const [maxW, setMaxW] = useState('0')
  const [format, setFormat] = useState('image/jpeg')
  const [busy, setBusy] = useState(false)
  const [outUrl, setOutUrl] = useState<string | null>(null)
  const [outBlob, setOutBlob] = useState<Blob | null>(null)
  const [sizes, setSizes] = useState<{ before: number; after: number } | null>(null)
  const { run: paidRun } = useAiRun()

  const pick = async (f: File) => {
    if (!f) return
    setFile(f)
    setOutUrl(null)
    setSizes(null)
    setUrl(await fileToDataUrl(f))
  }
  const clear = () => {
    setFile(null)
    setUrl(null)
    setOutUrl(null)
    setSizes(null)
  }

  const run = () =>
    paidRun(
      tool,
      async () => {
        if (!file || !url) throw new Error('Chưa chọn ảnh')
        setBusy(true)
        try {
          const img = await loadImage(url)
          const scale = maxW === '0' ? 1 : Math.min(1, parseInt(maxW) / img.naturalWidth)
          const c = makeCanvas(Math.round(img.naturalWidth * scale), Math.round(img.naturalHeight * scale))
          c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height)
          const type = format === 'keep' ? (file.type === 'image/png' ? 'image/png' : 'image/jpeg') : format
          const blob = await canvasToBlob(c, type, quality / 100)
          setOutBlob(blob)
          setOutUrl(URL.createObjectURL(blob))
          setSizes({ before: file.size, after: blob.size })
        } finally {
          setBusy(false)
        }
      },
      'Ảnh đã nén xong — tải về bên dưới',
    )

  const fmtKB = (b: number) => (b > 1024 * 1024 ? `${(b / 1024 / 1024).toFixed(2)} MB` : `${(b / 1024).toFixed(1)} KB`)

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <ImagePick url={url} onPick={pick} onClear={clear} />
        {url && (
          <div className="space-y-4 rounded-2xl border border-stone-200 bg-card p-4">
            <div className="space-y-2">
              <Label>Chất lượng nén: {quality}%</Label>
              <Slider value={[quality]} min={10} max={95} step={5} onValueChange={(v) => setQuality(v[0])} />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Thu nhỏ về chiều ngang</Label>
                <Select value={maxW} onValueChange={setMaxW}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Giữ nguyên kích thước</SelectItem>
                    <SelectItem value="1920">≤ 1920px</SelectItem>
                    <SelectItem value="1280">≤ 1280px</SelectItem>
                    <SelectItem value="800">≤ 800px</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Định dạng xuất</Label>
                <Select value={format} onValueChange={setFormat}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="image/jpeg">JPG — nén tốt nhất</SelectItem>
                    <SelectItem value="image/webp">WEBP — hiện đại</SelectItem>
                    <SelectItem value="image/png">PNG — không mất dữ liệu</SelectItem>
                    <SelectItem value="keep">Giữ định dạng gốc</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <RunButton loading={busy} onClick={run} disabled={!file || !url} cost={tool.price}>
              {busy ? 'Đang nén…' : 'Nén ngay'}
            </RunButton>
            {outUrl && outBlob && sizes && (
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-2 rounded-xl bg-stone-100 p-3 text-center text-sm">
                  <div><p className="text-stone-600">Trước</p><p className="font-bold">{fmtKB(sizes.before)}</p></div>
                  <div><p className="text-stone-600">Sau</p><p className="font-bold text-emerald-600">{fmtKB(sizes.after)}</p></div>
                  <div><p className="text-stone-600">Tiết kiệm</p><p className="font-bold text-emerald-700">{Math.max(0, Math.round((1 - sizes.after / sizes.before) * 100))}%</p></div>
                </div>
                <BeforeAfter before={url} after={outUrl} />
                <DownloadButton onClick={() => downloadBlob(outBlob, `nen-anh-${Date.now()}.${outBlob.type.includes('webp') ? 'webp' : outBlob.type.includes('png') ? 'png' : 'jpg'}`)}>
                  Tải ảnh đã nén
                </DownloadButton>
              </div>
            )}
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ─── CẮT ẢNH (miễn phí) ─────────────────────────────────
const RATIOS = [
  { label: 'Ảnh thẻ 3×4', w: 3, h: 4 },
  { label: 'Vuông 1:1', w: 1, h: 1 },
  { label: '4:5 (Instagram)', w: 4, h: 5 },
  { label: '16:9 (YouTube)', w: 16, h: 9 },
  { label: '9:16 (TikTok)', w: 9, h: 16 },
]

export function CatAnh({ tool }: { tool: Tool }) {
  const [url, setUrl] = useState<string | null>(null)
  const [ratioIdx, setRatioIdx] = useState(0)
  const [zoom, setZoom] = useState(100)
  const [ox, setOx] = useState(0)
  const [oy, setOy] = useState(0)
  const [dims, setDims] = useState<{ w: number; h: number } | null>(null)
  const [saving, setSaving] = useState(false)
  const origRef = useRef<HTMLCanvasElement | null>(null)
  const previewRef = useRef<HTMLCanvasElement | null>(null)
  const { run: paidRun } = useAiRun()

  const pick = async (f: File) => {
    if (!f) return
    const u = await fileToDataUrl(f)
    const img = await loadImage(u)
    const c = makeCanvas(img.naturalWidth, img.naturalHeight)
    c.getContext('2d')!.drawImage(img, 0, 0)
    origRef.current = c
    setUrl(u)
  }

  useDeferredLoad(() => {
    const orig = origRef.current
    const preview = previewRef.current
    if (!orig || !preview) return
    const r = RATIOS[ratioIdx]
    const cropped = cropCanvas(orig, { ratioW: r.w, ratioH: r.h, zoom: zoom / 100, offsetX: ox / 100, offsetY: oy / 100 })
    const scale = Math.min(1, 420 / cropped.width)
    preview.width = Math.round(cropped.width * scale)
    preview.height = Math.round(cropped.height * scale)
    preview.getContext('2d')!.drawImage(cropped, 0, 0, preview.width, preview.height)
    setDims({ w: cropped.width, h: cropped.height })
  }, [url, ratioIdx, zoom, ox, oy])

  const download = () =>
    paidRun(
      tool,
      async () => {
        const orig = origRef.current
        if (!orig) throw new Error('Chưa chọn ảnh')
        setSaving(true)
        try {
          const r = RATIOS[ratioIdx]
          const cropped = cropCanvas(orig, { ratioW: r.w, ratioH: r.h, zoom: zoom / 100, offsetX: ox / 100, offsetY: oy / 100 })
          const b = await canvasToBlob(cropped, 'image/png')
          await downloadBlob(b, `cat-anh-${Date.now()}.png`)
        } finally {
          setSaving(false)
        }
      },
      'Đã tải ảnh đã cắt',
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        {!url ? (
          <FileDrop accept="image/png,image/jpeg,image/webp" onFiles={(files) => pick(files[0])} label="Thả ảnh vào đây" hint="Cắt theo tỉ lệ chuẩn mạng xã hội" />
        ) : (
          <div className="space-y-4">
            <div className="flex justify-center rounded-2xl border border-stone-200 bg-stone-900 p-4">
              <canvas ref={previewRef} className="max-h-[420px] rounded-lg" aria-label="Xem trước ảnh cắt" />
            </div>
            <div className="grid gap-4 rounded-2xl border border-stone-200 bg-card p-4 sm:grid-cols-2">
              <div className="space-y-2 sm:col-span-2">
                <Label>Tỉ lệ khung</Label>
                <div className="flex flex-wrap gap-2">
                  {RATIOS.map((r, i) => (
                    <button
                      key={r.label}
                      onClick={() => setRatioIdx(i)}
                      className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                        i === ratioIdx ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white' : 'border border-stone-300 bg-emerald-50 text-emerald-700 hover:bg-stone-200'
                      }`}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Zoom: {(zoom / 100).toFixed(2)}×</Label>
                <Slider value={[zoom]} min={100} max={300} step={5} onValueChange={(v) => setZoom(v[0])} />
              </div>
              <div className="space-y-2">
                <Label>Đẩy ngang: {ox}%</Label>
                <Slider value={[ox]} min={-100} max={100} step={5} onValueChange={(v) => setOx(v[0])} />
              </div>
              <div className="space-y-2">
                <Label>Đẩy dọc: {oy}%</Label>
                <Slider value={[oy]} min={-100} max={100} step={5} onValueChange={(v) => setOy(v[0])} />
              </div>
              {dims && (
                <div className="flex items-end text-sm text-stone-600">
                  Kích thước xuất: <b className="ml-1 text-emerald-900">{dims.w} × {dims.h}px</b>
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <RunButton loading={saving} onClick={download} cost={tool.price}>Tải ảnh đã cắt (PNG)</RunButton>
              <Button variant="outline" className="h-12 rounded-xl" onClick={() => { setUrl(null); origRef.current = null }}>Đổi ảnh khác</Button>
            </div>
          </div>
        )}
      </div>
    </ToolPage>
  )
}
