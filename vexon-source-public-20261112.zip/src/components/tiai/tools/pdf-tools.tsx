'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { X, Loader2 } from 'lucide-react'
import { ToolPage, FileDrop, RunButton, useAiRun, DownloadButton } from '../shared'
import { mergePdfs, splitPdf, rotatePdf, imagesToPdf, parseRanges, pageCount, renderPdfPages } from '@/lib/tiai/pdf'
import { canvasToBlob, downloadBlob } from '@/lib/tiai/image'
import type { Tool } from '@/lib/tiai/tools'

function ErrText({ msg }: { msg: string }) {
  return <p className="text-sm font-medium text-red-400">{msg}</p>
}

// ─── ẢNH SANG PDF ────────────────────────────────────────
export function AnhSangPdf({ tool }: { tool: Tool }) {
  const [files, setFiles] = useState<File[]>([])
  const [pageSize, setPageSize] = useState('a4')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [done, setDone] = useState(false)
  const { run: paidRun } = useAiRun()

  const run = () =>
    paidRun(
      tool,
      async () => {
        if (files.length === 0) throw new Error('Chưa chọn ảnh')
        setErr('')
        setDone(false)
        setBusy(true)
        try {
          const blob = await imagesToPdf(files, pageSize as 'fit' | 'a4' | 'letter')
          downloadBlob(blob, `anh-sang-pdf-${Date.now()}.pdf`)
          setDone(true)
        } catch (e) {
          setErr(e instanceof Error ? e.message : 'Lỗi tạo PDF')
          throw e
        } finally {
          setBusy(false)
        }
      },
      'Đã tạo PDF — kiểm tra thư mục tải về',
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <FileDrop
          accept="image/png,image/jpeg,image/webp"
          multiple
          onFiles={(fs) => { setFiles((p) => [...p, ...fs]); setDone(false) }}
          label="Thả các ảnh vào đây"
          hint="Chọn nhiều ảnh để ghép thành 1 file PDF"
        />
        {files.length > 0 && (
          <div className="space-y-2 rounded-2xl border border-stone-200 bg-card p-4">
            <p className="text-sm font-semibold text-emerald-700">{files.length} ảnh trong hàng đợi</p>
            <div className="tiai-scroll flex max-h-40 flex-wrap gap-2 overflow-y-auto">
              {files.map((f, i) => (
                <div key={i} className="relative">
                  { }
                  <img src={URL.createObjectURL(f)} alt={f.name} className="h-16 w-16 rounded-lg border border-stone-300 object-cover" />
                  <button
                    aria-label={`Xóa ảnh ${i + 1}`}
                    onClick={() => setFiles((p) => p.filter((_, j) => j !== i))}
                    className="absolute -right-1.5 -top-1.5 rounded-full bg-red-500 p-0.5 text-white"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
            <div className="space-y-2">
              <Label>Khổ giấy</Label>
              <Select value={pageSize} onValueChange={setPageSize}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="a4">A4 dọc</SelectItem>
                  <SelectItem value="letter">Letter dọc</SelectItem>
                  <SelectItem value="fit">Vừa khít kích thước ảnh</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <RunButton loading={busy} onClick={run} disabled={files.length === 0} cost={tool.price}>
              Tạo PDF
            </RunButton>
            {done && <p className="text-xs text-emerald-600/80">Đã tạo PDF — kiểm tra thư mục tải về.</p>}
            {err && <ErrText msg={err} />}
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ─── GỘP PDF ─────────────────────────────────────────────
export function GopPdf({ tool }: { tool: Tool }) {
  const [files, setFiles] = useState<File[]>([])
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [done, setDone] = useState(false)
  const { run: paidRun } = useAiRun()

  const run = () =>
    paidRun(
      tool,
      async () => {
        if (files.length < 2) throw new Error('Cần ít nhất 2 file PDF')
        setErr('')
        setDone(false)
        setBusy(true)
        try {
          const blob = await mergePdfs(files)
          downloadBlob(blob, `gop-pdf-${Date.now()}.pdf`)
          setDone(true)
        } catch (e) {
          setErr(e instanceof Error ? e.message : 'Lỗi gộp PDF — tệp có thể bị mã hóa')
          throw e
        } finally {
          setBusy(false)
        }
      },
      'Đã gộp xong — kiểm tra thư mục tải về',
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <FileDrop
          accept="application/pdf"
          multiple
          onFiles={(fs) => { setFiles((p) => [...p, ...fs]); setDone(false) }}
          label="Thả các file PDF vào đây"
          hint="Gộp theo thứ tự bạn chọn"
        />
        {files.length > 0 && (
          <div className="space-y-2 rounded-2xl border border-stone-200 bg-card p-4">
            <p className="text-sm font-semibold text-emerald-700">{files.length} file PDF</p>
            <ul className="tiai-scroll max-h-40 space-y-1 overflow-y-auto text-sm text-emerald-900/80">
              {files.map((f, i) => (
                <li key={i} className="flex items-center justify-between rounded-lg bg-stone-100 px-3 py-1.5">
                  <span className="truncate">{i + 1}. {f.name}</span>
                  <button aria-label={`Xóa ${f.name}`} onClick={() => setFiles((p) => p.filter((_, j) => j !== i))}>
                    <X className="h-4 w-4 text-red-400" />
                  </button>
                </li>
              ))}
            </ul>
            <RunButton loading={busy} onClick={run} disabled={files.length < 2} cost={tool.price}>
              Gộp ngay
            </RunButton>
            {done && <p className="text-xs text-emerald-600/80">Đã gộp xong — kiểm tra thư mục tải về.</p>}
            {err && <ErrText msg={err} />}
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ─── TÁCH PDF ────────────────────────────────────────────
export function TachPdf({ tool }: { tool: Tool }) {
  const [file, setFile] = useState<File | null>(null)
  const [total, setTotal] = useState(0)
  const [ranges, setRanges] = useState('')
  const [perFile, setPerFile] = useState(false)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const { run: paidRun } = useAiRun()

  const pick = async (fs: File[]) => {
    const f = fs[0]
    setFile(f)
    setErr('')
    if (f) {
      try {
        setTotal(await pageCount(f))
      } catch {
        setErr('Không đọc được file PDF')
      }
    }
  }

  const run = () =>
    paidRun(
      tool,
      async () => {
        if (!file) throw new Error('Chưa chọn file PDF')
        setErr('')
        const pages = parseRanges(ranges, total)
        if (pages.length === 0) throw new Error(`Nhập số trang hợp lệ trong khoảng 1–${total}`)
        setBusy(true)
        try {
          const blobs = await splitPdf(file, pages, perFile)
          if (blobs.length === 1) {
            downloadBlob(blobs[0], `tach-pdf-${Date.now()}.pdf`)
          } else {
            const JSZip = (await import('jszip')).default
            const zip = new JSZip()
            blobs.forEach((b, i) => zip.file(`trang-${pages[i] + 1}.pdf`, b))
            downloadBlob(await zip.generateAsync({ type: 'blob' }), `tach-pdf-${Date.now()}.zip`)
          }
        } catch (e) {
          setErr(e instanceof Error ? e.message : 'Lỗi tách PDF')
          throw e
        } finally {
          setBusy(false)
        }
      },
      'Đã tách xong — kiểm tra thư mục tải về',
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <FileDrop
          accept="application/pdf"
          onFiles={pick}
          label={file ? (typeof file === 'string' ? file : file.name) : 'Thả file PDF vào đây'}
          hint={total ? `Tài liệu có ${total} trang` : 'Chỉ tách trên máy bạn, không tải lên server'}
        />
        {file && total > 0 && (
          <div className="space-y-3 rounded-2xl border border-stone-200 bg-card p-4">
            <div className="space-y-2">
              <Label>Trang cần tách (VD: 1-3, 5, 8-10)</Label>
              <Input value={ranges} onChange={(e) => setRanges(e.target.value)} placeholder={`1-${total}`} />
            </div>
            <div className="flex items-center gap-2">
              <Checkbox id="perfile" checked={perFile} onCheckedChange={(v) => setPerFile(v === true)} />
              <Label htmlFor="perfile" className="cursor-pointer">Mỗi trang một file (nén ZIP)</Label>
            </div>
            <RunButton loading={busy} onClick={run} cost={tool.price}>
              Tách ngay
            </RunButton>
            {err && <ErrText msg={err} />}
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ─── XOAY PDF ────────────────────────────────────────────
export function XoayPdf({ tool }: { tool: Tool }) {
  const [file, setFile] = useState<File | null>(null)
  const [total, setTotal] = useState(0)
  const [ranges, setRanges] = useState('')
  const [angle, setAngle] = useState<'90' | '180' | '270'>('90')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const { run: paidRun } = useAiRun()

  const pick = async (fs: File[]) => {
    const f = fs[0]
    setFile(f)
    setErr('')
    if (f) {
      try {
        setTotal(await pageCount(f))
      } catch {
        setErr('Không đọc được file PDF')
      }
    }
  }

  const run = () =>
    paidRun(
      tool,
      async () => {
        if (!file) throw new Error('Chưa chọn file PDF')
        setErr('')
        setBusy(true)
        try {
          const pages = ranges.trim() ? parseRanges(ranges, total) : null
          const blob = await rotatePdf(file, parseInt(angle) as 90 | 180 | 270, pages && pages.length ? pages : null)
          downloadBlob(blob, `xoay-pdf-${Date.now()}.pdf`)
        } catch (e) {
          setErr(e instanceof Error ? e.message : 'Lỗi xoay PDF')
          throw e
        } finally {
          setBusy(false)
        }
      },
      'Đã xoay xong — kiểm tra thư mục tải về',
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <FileDrop
          accept="application/pdf"
          onFiles={pick}
          label={file ? (typeof file === 'string' ? file : file.name) : 'Thả file PDF vào đây'}
          hint={total ? `Tài liệu có ${total} trang — bỏ trống để xoay tất cả` : 'Xoay 90°, 180°, 270° ngay trên máy'}
        />
        {file && total > 0 && (
          <div className="space-y-3 rounded-2xl border border-stone-200 bg-card p-4">
            <div className="space-y-2">
              <Label>Góc xoay</Label>
              <Select value={angle} onValueChange={(v) => setAngle(v as '90' | '180' | '270')}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="90">Xoay phải 90°</SelectItem>
                  <SelectItem value="180">Xoay 180°</SelectItem>
                  <SelectItem value="270">Xoay trái 90°</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Trang cần xoay (bỏ trống = tất cả)</Label>
              <Input value={ranges} onChange={(e) => setRanges(e.target.value)} placeholder={`VD: 1-${total}`} />
            </div>
            <RunButton loading={busy} onClick={run} cost={tool.price}>
              Xoay & tải về
            </RunButton>
            {err && <ErrText msg={err} />}
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ─── PDF SANG ẢNH ────────────────────────────────────────
export function PdfSangAnh({ tool }: { tool: Tool }) {
  const [file, setFile] = useState<File | null>(null)
  const [busy, setBusy] = useState(false)
  const [progress, setProgress] = useState('')
  const [pages, setPages] = useState<{ url: string; index: number }[]>([])
  const [blobs, setBlobs] = useState<Blob[]>([])
  const [err, setErr] = useState('')
  const { run: paidRun } = useAiRun()

  const pick = (fs: File[]) => {
    setFile(fs[0] ?? null)
    setPages([])
    setBlobs([])
    setErr('')
  }

  const run = () =>
    paidRun(
      tool,
      async () => {
        if (!file) throw new Error('Chưa chọn file PDF')
        setErr('')
        setBusy(true)
        setPages([])
        try {
          const rendered = await renderPdfPages(file, 2, (i, n) => setProgress(`Đang đổi trang ${i}/${n}…`))
          const newPages: { url: string; index: number }[] = []
          const newBlobs: Blob[] = []
          for (const p of rendered) {
            const blob = await canvasToBlob(p.canvas, 'image/png')
            newBlobs.push(blob)
            newPages.push({ url: URL.createObjectURL(blob), index: p.pageIndex })
          }
          setBlobs(newBlobs)
          setPages(newPages)
          setProgress('')
        } catch (e) {
          setErr(e instanceof Error ? e.message : 'Lỗi đọc PDF')
          setProgress('')
          throw e
        } finally {
          setBusy(false)
        }
      },
      'Đã chuyển xong — tải ảnh bên dưới',
    )

  const downloadAll = async () => {
    if (blobs.length === 1) {
      downloadBlob(blobs[0], `pdf-trang-1-${Date.now()}.png`)
      return
    }
    const JSZip = (await import('jszip')).default
    const zip = new JSZip()
    blobs.forEach((b, i) => zip.file(`trang-${i + 1}.png`, b))
    downloadBlob(await zip.generateAsync({ type: 'blob' }), `pdf-sang-anh-${Date.now()}.zip`)
  }

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <FileDrop
          accept="application/pdf"
          onFiles={pick}
          label={file ? (typeof file === 'string' ? file : file.name) : 'Thả file PDF vào đây'}
          hint="Xuất từng trang thành ảnh PNG nét cao"
        />
        {file && (
          <div className="space-y-3 rounded-2xl border border-stone-200 bg-card p-4">
            <RunButton loading={busy} onClick={run} cost={tool.price}>
              Chuyển thành ảnh
            </RunButton>
            {progress && <p className="text-sm text-emerald-700">{progress}</p>}
            {err && <ErrText msg={err} />}
            {pages.length > 0 && (
              <>
                <div className="tiai-scroll grid max-h-96 grid-cols-2 gap-3 overflow-y-auto sm:grid-cols-3">
                  {pages.map((p) => (
                    <a key={p.index} href={p.url} download={`trang-${p.index}.png`} className="group relative block overflow-hidden rounded-lg border border-stone-300">
                      { }
                      <img src={p.url} alt={`Trang ${p.index}`} className="w-full object-contain transition group-hover:scale-[1.02]" />
                      <span className="absolute bottom-1 right-1 rounded bg-stone-900/70 px-1.5 py-0.5 text-xs text-white">Trang {p.index}</span>
                    </a>
                  ))}
                </div>
                <DownloadButton onClick={downloadAll}>
                  Tải {pages.length > 1 ? 'tất cả (ZIP)' : 'ảnh PNG'}
                </DownloadButton>
              </>
            )}
          </div>
        )}
      </div>
    </ToolPage>
  )
}
