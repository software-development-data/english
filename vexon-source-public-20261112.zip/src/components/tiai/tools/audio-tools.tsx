'use client'

import { useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Play, Pause, Music, Mic } from 'lucide-react'
import { ToolPage, RunButton, FileDrop, DownloadButton, useAiRun } from '../shared'
import { decodeAudioFile, computePeaks, encodeWav, changeSpeed, splitVocals, formatDur } from '@/lib/tiai/audio'
import { downloadBlob } from '@/lib/tiai/image'
import type { Tool } from '@/lib/tiai/tools'

// ─── Waveform canvas ─────────────────────────────────────
function Waveform({ peaks, startPct, endPct }: { peaks: number[]; startPct: number; endPct: number }) {
  const ref = useRef<HTMLCanvasElement>(null)
  const draw = (el: HTMLCanvasElement | null) => {
    if (!el || peaks.length === 0) return
    const w = el.width
    const h = el.height
    const ctx = el.getContext('2d')!
    ctx.clearRect(0, 0, w, h)
    ctx.fillStyle = '#1b1b2a'
    ctx.fillRect(0, 0, w, h)
    const bar = w / peaks.length
    for (let i = 0; i < peaks.length; i++) {
      const pct = (i / peaks.length) * 100
      const inRange = pct >= startPct && pct <= endPct
      ctx.fillStyle = inRange ? '#c026d3' : '#4c3a6e'
      const ph = Math.max(2, peaks[i] * (h - 8))
      ctx.fillRect(i * bar, (h - ph) / 2, Math.max(1, bar - 1), ph)
    }
  }
  return (
    <canvas
      ref={(el) => {
        ref.current = el
        draw(el)
      }}
      width={800}
      height={140}
      className="w-full rounded-xl border border-stone-200"
      aria-label="Dạng sóng âm thanh"
    />
  )
}

// ─── TÁCH LỜI & NHẠC (AI · miễn phí) ────────────────────
export function TachLoiNhac({ tool }: { tool: Tool }) {
  const { run } = useAiRun()
  const [fileName, setFileName] = useState('')
  const [loading, setLoading] = useState(false)
  const [vocalUrl, setVocalUrl] = useState<string | null>(null)
  const [instUrl, setInstUrl] = useState<string | null>(null)
  const [vocalBlob, setVocalBlob] = useState<Blob | null>(null)
  const [instBlob, setInstBlob] = useState<Blob | null>(null)
  const [duration, setDuration] = useState(0)
  const pickedRef = useRef<File | null>(null)

  const pick = (fs: File[]) => {
    setVocalUrl(null)
    setInstUrl(null)
    setFileName(fs[0]?.name ?? '')
    pickedRef.current = fs[0] ?? null
  }

  const process = () =>
    run(
      tool,
      async () => {
        const f = pickedRef.current
        if (!f) throw new Error('Chưa chọn bài hát')
        setLoading(true)
        try {
          const buf = await decodeAudioFile(f)
          const res = splitVocals(buf)
          const vb = URL.createObjectURL(res.vocal)
          const ib = URL.createObjectURL(res.instrumental)
          setVocalBlob(res.vocal)
          setInstBlob(res.instrumental)
          setVocalUrl(vb)
          setInstUrl(ib)
          setDuration(buf.duration)
        } finally {
          setLoading(false)
        }
      },
      'Đã tách xong Vocal và Beat ngay trên máy bạn'
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <FileDrop
          accept="audio/*,video/mp4"
          onFiles={pick}
          label={fileName || 'Thả bài hát vào đây'}
          hint="MP3 · WAV · M4A · OGG — xử lý ngay trên máy, không tải lên server"
        />
        <RunButton loading={loading} onClick={process} disabled={!pickedRef.current} cost={tool.price}>
          Tách lời & nhạc
        </RunButton>
        {vocalUrl && instUrl && (
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2 rounded-2xl border border-emerald-500/30 bg-card p-4">
              <p className="flex items-center gap-2 font-semibold text-emerald-700"><Mic className="h-4 w-4" /> Giọng hát (Vocal)</p>
              <audio controls src={vocalUrl} className="w-full" />
              <DownloadButton onClick={() => vocalBlob && downloadBlob(vocalBlob, `vocal-${Date.now()}.wav`)}>Tải Vocal WAV</DownloadButton>
            </div>
            <div className="space-y-2 rounded-2xl border border-stone-300 bg-card p-4">
              <p className="flex items-center gap-2 font-semibold text-emerald-700"><Music className="h-4 w-4" /> Nhạc nền (Beat)</p>
              <audio controls src={instUrl} className="w-full" />
              <DownloadButton onClick={() => instBlob && downloadBlob(instBlob, `beat-${Date.now()}.wav`)}>Tải Beat WAV</DownloadButton>
            </div>
            <p className="text-xs text-stone-500 sm:col-span-2">
              Thời lượng: {formatDur(duration)} · Dùng kỹ thuật triệt kê âm stereo (karaoke DSP) chạy 100% trên máy bạn — file không rời thiết bị.
            </p>
          </div>
        )}
      </div>
    </ToolPage>
  )
}

// ─── CẮT NHẠC (miễn phí khi xuất WAV) ─────────────
export function CatNhac({ tool }: { tool: Tool }) {
  const [fileName, setFileName] = useState('')
  const [buffer, setBuffer] = useState<AudioBuffer | null>(null)
  const [peaks, setPeaks] = useState<number[]>([])
  const [range, setRange] = useState<[number, number]>([0, 100])
  const [speed, setSpeed] = useState('1')
  const [playing, setPlaying] = useState(false)
  const [outBlob, setOutBlob] = useState<Blob | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const bufRef = useRef<AudioBuffer | null>(null)
  const { run: paidRun } = useAiRun()

  const pick = async (fs: File[]) => {
    const f = fs[0]
    if (!f) return
    try {
      const buf = await decodeAudioFile(f)
      bufRef.current = buf
      setBuffer(buf)
      setPeaks(computePeaks(buf, 600))
      setRange([0, 100])
      setOutBlob(null)
      setFileName(`${f.name} · ${formatDur(buf.duration)}`)
    } catch {
      setFileName('Không đọc được tệp âm thanh này')
    }
  }

  const [sPct, ePct] = range
  const dur = buffer?.duration ?? 0
  const s = (sPct / 100) * dur
  const e = (ePct / 100) * dur

  const preview = () => {
    if (!buffer) return
    audioRef.current?.pause()
    const wav = encodeWav(changeSpeed(buffer, parseFloat(speed)), s, e)
    const url = URL.createObjectURL(wav)
    const a = new Audio(url)
    audioRef.current = a
    a.onended = () => setPlaying(false)
    a.play()
    setPlaying(true)
  }

  const exportWav = () =>
    paidRun(
      tool,
      async () => {
        if (!buffer) throw new Error('Chưa chọn nhạc')
        const wav = encodeWav(changeSpeed(buffer, parseFloat(speed)), s, e)
        setOutBlob(wav)
        downloadBlob(wav, `cat-nhac-${Date.now()}.wav`)
      },
      'Đã xuất WAV — kiểm tra thư mục tải về',
    )

  return (
    <ToolPage tool={tool}>
      <div className="space-y-4">
        <FileDrop
          accept="audio/*"
          onFiles={pick}
          label={fileName || 'Thả nhạc vào đây'}
          hint="MP3 · WAV · M4A · OGG — cắt ghép ngay trên máy bạn"
        />
        {buffer && (
          <div className="space-y-4 rounded-2xl border border-stone-200 bg-card p-4">
            <Waveform peaks={peaks} startPct={sPct} endPct={ePct} />
            <div className="space-y-2">
              <Label>Đoạn giữ lại: {formatDur(s)} → {formatDur(e)}</Label>
              <div className="flex gap-3">
                <Slider
                  className="flex-1"
                  value={[sPct]} min={0} max={100} step={0.5}
                  onValueChange={(v) => setRange([Math.min(v[0], ePct - 1), ePct])}
                  aria-label="Bắt đầu"
                />
                <Slider
                  className="flex-1"
                  value={[ePct]} min={0} max={100} step={0.5}
                  onValueChange={(v) => setRange([sPct, Math.max(v[0], sPct + 1)])}
                  aria-label="Kết thúc"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Tốc độ phát: {speed}×</Label>
              <Select value={speed} onValueChange={setSpeed}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['0.5', '0.75', '1', '1.25', '1.5', '2'].map((v) => (
                    <SelectItem key={v} value={v}>{v}×</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" className="h-11 gap-2 rounded-xl" onClick={preview}>
                {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                Nghe thử đoạn đã chọn
              </Button>
              <RunButton loading={false} onClick={exportWav} cost={tool.price}>Xuất WAV ({formatDur((e - s) / parseFloat(speed))})</RunButton>
            </div>
            {outBlob && <p className="text-xs text-emerald-600/80">Đã xuất tệp — kiểm tra thư mục tải về.</p>}
          </div>
        )}
      </div>
    </ToolPage>
  )
}
