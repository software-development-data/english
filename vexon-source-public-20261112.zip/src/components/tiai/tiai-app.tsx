'use client'

import { useEffect, useState } from 'react'
import { Home, LayoutGrid, History, Coins, ChevronLeft, ArrowLeft } from 'lucide-react'
import { useView } from '@/lib/tiai/view'
import { useWallet } from '@/lib/tiai/wallet'
import { XuChip } from './shared'
import { HomeView } from './views/home-view'
import { ToolsView } from './views/tools-view'
import { WalletView } from './views/wallet-view'
import { HistoryView } from './views/history-view'
import { ToolView } from './views/tool-view'
import { OssView } from './views/oss-view'

/** Header riêng của trang Công cụ AI — trang độc lập, không trùng menu index */
function Header({ onExit }: { onExit?: () => void }) {
  const { view, go } = useView()
  const navBtn = (active: boolean) =>
    `flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-semibold transition ${
      active ? 'bg-emerald-600 text-white shadow' : 'text-stone-600 hover:bg-emerald-50 hover:text-emerald-800'
    }`
  return (
    <header className="sticky top-0 z-50 border-b border-stone-200 bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 w-full max-w-5xl items-center justify-between gap-2 px-4">
        <div className="flex items-center gap-1">
          {onExit && (
            <button
              onClick={onExit}
              className="rounded-lg p-2 text-stone-500 transition hover:bg-stone-100 hover:text-stone-800"
              title="Về Vexon"
              aria-label="Về Vexon"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
          )}
          <button onClick={() => go({ name: 'home' })} className="flex items-center gap-2" aria-label="Trang chủ CÔNG CỤ AI">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-600 to-teal-600 shadow-lg shadow-emerald-600/25">
              <img src="/vexon-logo.png" alt="Logo Công cụ AI" className="h-4.5 w-4.5" />
            </span>
            <span className="leading-tight">
              <span className="block text-sm font-extrabold tracking-wide whitespace-nowrap text-emerald-800 sm:text-base">
                CÔNG CỤ AI
              </span>
              <span className="hidden text-[10px] leading-tight text-stone-500 sm:block">
                Phân hệ công cụ của Vexon · Một ví tiền USD chung
              </span>
            </span>
          </button>
        </div>
        <nav className="flex items-center gap-0.5 sm:gap-1" aria-label="Điều hướng chính">
          <button onClick={() => go({ name: 'home' })} className={navBtn(view.name === 'home')} aria-label="Trang chủ">
            <Home className="h-4 w-4" />
            <span className="hidden sm:inline">Trang chủ</span>
          </button>
          <button onClick={() => go({ name: 'tools' })} className={navBtn(view.name === 'tools' || view.name === 'tool')} aria-label="Công cụ">
            <LayoutGrid className="h-4 w-4" />
            <span className="hidden sm:inline">Công cụ</span>
          </button>
          <button onClick={() => go({ name: 'history' })} className={navBtn(view.name === 'history')} aria-label="Lịch sử">
            <History className="h-4 w-4" />
            <span className="hidden sm:inline">Lịch sử</span>
          </button>
          <div className="ml-1"><XuChip /></div>
        </nav>
      </div>
    </header>
  )
}

/** Menu dưới kiểu ứng dụng — luôn hiện trên điện thoại (desktop đã có menu trên) */
function BottomNav() {
  const { view, go } = useView()
  const items = [
    { key: 'home', label: 'Trang chủ', icon: <Home className="h-5 w-5" /> },
    { key: 'tools', label: 'Công cụ', icon: <LayoutGrid className="h-5 w-5" /> },
    { key: 'wallet', label: 'Ví tiền', icon: <Coins className="h-5 w-5" /> },
    { key: 'history', label: 'Lịch sử', icon: <History className="h-5 w-5" /> },
  ] as const
  const active = view.name === 'tool' ? 'tools' : view.name
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-50 border-t border-stone-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden"
      aria-label="Menu dưới Công cụ AI"
    >
      <div className="mx-auto flex max-w-md items-stretch justify-around">
        {items.map((it) => (
          <button
            key={it.key}
            onClick={() => go({ name: it.key })}
            className={`flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] font-semibold transition-colors ${
              active === it.key ? 'text-emerald-600' : 'text-stone-400 hover:text-stone-600'
            }`}
            aria-label={it.label}
            aria-current={active === it.key ? 'page' : undefined}
          >
            {it.icon}
            {it.label}
          </button>
        ))}
      </div>
    </nav>
  )
}

/**
 * Trang Công cụ AI — chạy như một trang độc lập với menu riêng
 * (không hiển thị cùng menu index → không bị trùng lặp)
 */
export function TiaiApp({ onExit, meCoins }: { onExit?: () => void; meCoins?: number }) {
  const view = useView((s) => s.view)
  const back = useView((s) => s.back)
  const hydrate = useWallet((s) => s.hydrate)
  const [username, setUsername] = useState('vexon-user')

  // Hạt giống số dư thật từ Vexon shell — hiện đúng số ngay lập tức, không nhấp nháy 0
  useEffect(() => {
    if (typeof meCoins === 'number' && !useWallet.getState().synced) {
      useWallet.setState({ xu: meCoins })
    }
  }, [meCoins])

  // Ví tiền đồng bộ với nền tảng — nạp số dư thật từ server mỗi lần mở phân hệ
  useEffect(() => {
    const t = setTimeout(() => { hydrate() }, 0)
    return () => clearTimeout(t)
  }, [hydrate])

  // Lấy tên đăng nhập để ghi nội dung chuyển khoản NAPXU <username>
  useEffect(() => {
    fetch('/api/vx/auth')
      .then((r) => r.json())
      .then((d) => { if (d.user?.username) setUsername(d.user.username) })
      .catch(() => {})
  }, [])

  return (
    <div className="flex min-h-screen flex-1 flex-col bg-background text-foreground">
      <Header onExit={onExit} />
      {view.name === 'tool' && (
        <div className="mx-auto w-full max-w-5xl px-4 pt-4">
          <button
            onClick={back}
            className="flex items-center gap-1 text-sm text-emerald-700 transition hover:text-emerald-900"
          >
            <ChevronLeft className="h-4 w-4" /> Tất cả công cụ
          </button>
        </div>
      )}
      <main className="flex-1 pb-14 md:pb-0">
        {view.name === 'home' && <HomeView />}
        {view.name === 'tools' && <ToolsView />}
        {view.name === 'tool' && <ToolView slug={view.slug} />}
        {view.name === 'oss' && <OssView />}
        {view.name === 'wallet' && <WalletView username={username} />}
        {view.name === 'history' && <HistoryView />}
      </main>
      <BottomNav />
    </div>
  )
}
