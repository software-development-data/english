'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { fmtDate, fmtXuWithUsd } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'
import type { VxUserInfo } from '@/components/vexon/AuthView'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useToast } from '@/hooks/use-toast'
import { Heart, MessageCircle, Upload, Music2, Eye, Send, Loader2, UserPlus, ChevronUp, ChevronDown, PlayCircle } from 'lucide-react'

interface VxVideo {
  id: string
  user: { id: string; username: string; fullName: string; avatarColor: string }
  caption: string
  url: string
  views: number
  createdAt: string
  likeCount: number
  likedByMe: boolean
  commentCount: number
  comments: { id: string; content: string; createdAt: string; user: { fullName: string; avatarColor: string } }[]
  following: boolean
}

export default function VideoTikTokView({ me, onRefreshUser }: { me: VxUserInfo; onRefreshUser?: () => void }) {
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho thưởng xem video
  const [videos, setVideos] = useState<VxVideo[]>([])
  const [loading, setLoading] = useState(true)
  const [activeIdx, setActiveIdx] = useState(0)
  const [uploading, setUploading] = useState(false)
  const [openComments, setOpenComments] = useState<string | null>(null)
  const [commentText, setCommentText] = useState('')
  const containerRef = useRef<HTMLDivElement>(null)
  const slideRefs = useRef<(HTMLDivElement | null)[]>([])
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([])
  const fileRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const load = useCallback(() => {
    fetch('/api/vx/videos')
      .then((r) => r.json())
      .then((data) => Array.isArray(data) && setVideos(data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(load, [load])

  // IntersectionObserver: phát hiện slide đang chiếm màn hình
  useEffect(() => {
    if (videos.length === 0) return
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.6) {
            const idx = Number((entry.target as HTMLElement).dataset.index)
            if (!isNaN(idx)) setActiveIdx(idx)
          }
        }
      },
      { root: containerRef.current, threshold: [0.6] }
    )
    slideRefs.current.forEach((el) => el && observer.observe(el))
    return () => observer.disconnect()
  }, [videos])

  // Autoplay slide đang active, pause các slide khác + CÀY XU: xem video được +5 xu (1 lần/video/ngày)
  useEffect(() => {
    videoRefs.current.forEach((v, i) => {
      if (!v) return
      if (i === activeIdx) v.play().catch(() => {})
      else {
        v.pause()
        v.currentTime = 0
      }
    })
    const video = videos[activeIdx]
    if (video && video.user.id !== me.id) {
      fetch('/api/vx/wallet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'video_reward', videoId: video.id }),
      })
        .then((r) => r.json())
        .then((d) => {
          if (d.ok && d.earned) {
            toast({ title: `+${fmtXuWithUsd(d.earned, rate)} xem video`, description: `Số dư: ${fmtXuWithUsd(d.coins, rate)}` })
            onRefreshUser?.()
          }
        })
        .catch(() => {})
    }
  }, [activeIdx, videos, me.id, onRefreshUser])

  const like = async (id: string) => {
    const res = await fetch(`/api/vx/videos/${id}/like`, { method: 'POST' })
    const data = await res.json()
    if (!res.ok) return
    setVideos((vs) => vs.map((v) => (v.id === id ? { ...v, likedByMe: data.liked, likeCount: data.likeCount } : v)))
  }

  const follow = async (userId: string) => {
    const res = await fetch('/api/vx/friends', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'follow', userId }),
    })
    const data = await res.json()
    if (!res.ok) return
    setVideos((vs) => vs.map((v) => (v.user.id === userId ? { ...v, following: data.following } : v)))
    toast({ title: data.following ? 'Đã theo dõi kênh' : 'Đã bỏ theo dõi' })
  }

  const sendComment = async (videoId: string) => {
    if (!commentText.trim()) return
    const res = await fetch(`/api/vx/videos/${videoId}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: commentText.trim() }),
    })
    const data = await res.json()
    if (!res.ok) return
    setVideos((vs) =>
      vs.map((v) =>
        v.id === videoId
          ? {
              ...v,
              commentCount: data.commentCount,
              comments: [
                { id: data.id, content: data.content, createdAt: data.createdAt, user: { fullName: me.fullName, avatarColor: me.avatarColor } },
                ...v.comments,
              ],
            }
          : v
      )
    )
    setCommentText('')
  }

  const upload = async (file: File, caption: string) => {
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('caption', caption)
      const res = await fetch('/api/vx/videos', { method: 'POST', body: fd })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setVideos((vs) => [data, ...vs])
      toast({ title: 'Đăng video thành công!' })
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không đăng được video', variant: 'destructive' })
    } finally {
      setUploading(false)
    }
  }

  const scrollBy = (dir: 1 | -1) => {
    containerRef.current?.scrollBy({ top: dir * containerRef.current.clientHeight, behavior: 'smooth' })
  }

  if (loading) {
    return (
      <div className="mx-auto flex max-w-md items-center justify-center gap-2 py-32 text-muted-foreground">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span>Đang tải kênh video...</span>
      </div>
    )
  }

  return (
    <div className="relative mx-auto max-w-md">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-bold">
          <PlayCircle className="h-5 w-5 text-emerald-600" />
          Vexon Video
        </h2>
        <input
          ref={fileRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (!file) return
            const caption = prompt('Nhập mô tả video:', 'Video mới của tôi')
            if (caption === null) return
            upload(file, caption)
            e.target.value = ''
          }}
        />
        <Button size="sm" className="bg-rose-600 hover:bg-rose-700" disabled={uploading} onClick={() => fileRef.current?.click()}>
          {uploading ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Upload className="mr-1 h-4 w-4" />}
          Đăng video
        </Button>
      </div>

      {/* Feed dọc kiểu TikTok */}
      <div ref={containerRef} className="vx-no-scrollbar h-[70vh] snap-y snap-mandatory overflow-y-auto rounded-2xl bg-black">
        {videos.length === 0 ? (
          <div className="flex h-full items-center justify-center text-center text-sm text-stone-400">
            Chưa có video nào, hãy đăng video đầu tiên!
          </div>
        ) : (
          videos.map((v, i) => (
            <div
              key={v.id}
              ref={(el) => {
                slideRefs.current[i] = el
              }}
              data-index={i}
              className="relative h-[70vh] w-full snap-start snap-always overflow-hidden"
            >
              <video
                ref={(el) => {
                  videoRefs.current[i] = el
                }}
                src={v.url}
                className="h-full w-full object-cover"
                loop
                muted
                playsInline
                preload={Math.abs(i - activeIdx) <= 1 ? 'auto' : 'none'}
                onClick={(e) => {
                  const vid = e.currentTarget
                  if (vid.paused) vid.play().catch(() => {})
                  else vid.pause()
                }}
              />

              {/* Overlay */}
              <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent p-4 pb-5">
                <div className="pointer-events-auto">
                  <div className="flex items-end justify-between gap-3">
                    <div className="min-w-0 flex-1 text-white">
                      <div className="flex items-center gap-2">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-sm font-bold" style={{ backgroundColor: v.user.avatarColor }}>
                          {v.user.fullName[0]}
                        </div>
                        <div className="min-w-0">
                          <p className="truncate text-sm font-bold">@{v.user.username}</p>
                          <p className="flex items-center gap-1 text-xs text-stone-300">
                            <Eye className="h-3 w-3" /> {v.views.toLocaleString('vi-VN')} lượt xem, {fmtDate(v.createdAt)}
                          </p>
                        </div>
                        {v.user.id !== me.id && (
                          <Button
                            size="sm"
                            variant={v.following ? 'secondary' : 'default'}
                            className={`h-8 shrink-0 rounded-full px-3 text-xs ${v.following ? '' : 'bg-rose-600 hover:bg-rose-700'}`}
                            onClick={() => follow(v.user.id)}
                          >
                            {v.following ? 'Đang theo dõi' : <><UserPlus className="mr-1 h-3 w-3" />Theo dõi</>}
                          </Button>
                        )}
                      </div>
                      <p className="mt-2 line-clamp-2 text-sm">{v.caption}</p>
                    </div>

                    <div className="flex flex-col items-center gap-4 text-white">
                      <button className="flex flex-col items-center" onClick={() => like(v.id)} aria-label="Thích video">
                        <Heart className={`h-8 w-8 drop-shadow transition-transform active:scale-125 ${v.likedByMe ? 'fill-rose-500 text-rose-500' : ''}`} />
                        <span className="text-xs font-semibold">{v.likeCount}</span>
                      </button>
                      <button className="flex flex-col items-center" onClick={() => setOpenComments(openComments === v.id ? null : v.id)} aria-label="Bình luận">
                        <MessageCircle className="h-8 w-8 drop-shadow" />
                        <span className="text-xs font-semibold">{v.commentCount}</span>
                      </button>
                      <Music2 className="h-6 w-6 vx-spin-slow drop-shadow" />
                    </div>
                  </div>

                  {/* Bình luận */}
                  {openComments === v.id && (
                    <div className="pointer-events-auto mt-3 max-h-48 space-y-2 overflow-y-auto rounded-xl bg-black/75 p-3 backdrop-blur">
                      {v.comments.length === 0 ? (
                        <p className="py-2 text-center text-xs text-stone-400">Chưa có bình luận, hãy là người đầu tiên!</p>
                      ) : (
                        v.comments.map((c) => (
                          <div key={c.id} className="flex items-start gap-2">
                            <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[10px] font-bold text-white" style={{ backgroundColor: c.user.avatarColor }}>
                              {c.user.fullName[0]}
                            </div>
                            <div className="min-w-0">
                              <p className="text-xs font-semibold text-stone-300">{c.user.fullName}</p>
                              <p className="break-words text-sm text-white">{c.content}</p>
                            </div>
                          </div>
                        ))
                      )}
                      <div className="flex gap-2 pt-1">
                        <Input
                          value={commentText}
                          onChange={(e) => setCommentText(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && sendComment(v.id)}
                          placeholder="Thêm bình luận..."
                          className="h-9 border-stone-600 bg-stone-800/90 text-sm text-white"
                        />
                        <Button size="icon" className="h-9 w-9 shrink-0 bg-rose-600 hover:bg-rose-700" onClick={() => sendComment(v.id)} aria-label="Gửi bình luận">
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Nút cuộn */}
      <div className="absolute -right-14 top-1/2 hidden -translate-y-1/2 flex-col gap-2 sm:flex">
        <Button variant="outline" size="icon" className="h-10 w-10 rounded-full" onClick={() => scrollBy(-1)} aria-label="Video trước">
          <ChevronUp className="h-5 w-5" />
        </Button>
        <Button variant="outline" size="icon" className="h-10 w-10 rounded-full" onClick={() => scrollBy(1)} aria-label="Video sau">
          <ChevronDown className="h-5 w-5" />
        </Button>
      </div>

      <p className="mt-2 text-center text-xs text-muted-foreground">Cuộn dọc để xem video tiếp, Bấm vào video để tạm dừng</p>
    </div>
  )
}
