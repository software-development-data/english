'use client'

// ============ NÂNG CẤP TÀI KHOẢN DOANH NGHIỆP (dùng chung) ============
// Thẻ/bản banner hiện trạng tài khoản + hộp thoại nộp đơn nâng cấp:
//  • Hồ sơ (ProfileView): thẻ đầy đủ 4 trạng thái (doanh nghiệp / chờ duyệt / bị từ chối / cá nhân)
//  • Trang (Fanpage): banner gọn kêu gọi nâng cấp để mở Trang doanh nghiệp
// API: /api/vx/business-upgrade (nộp đơn trừ tiền ví → chờ Ban Giám đốc duyệt, từ chối hoàn 100%)

import { useEffect, useState } from 'react'
import type { VxUserInfo } from './AuthView'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { toast } from 'sonner'
import { ArrowRight, BadgeCheck, Building2, Hourglass, Loader2, Sparkles, XCircle } from 'lucide-react'
import { fmtUsdFromXu } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'

interface BizAppT {
  id?: string
  companyName?: string
  status?: string
  xuPaid?: number
  note?: string | null
  createdAt?: string
}

const BENEFITS = [
  'Trang doanh nghiệp (fanpage) chính thức: ảnh bìa, đại diện, danh mục, người theo dõi',
  'Hồ sơ năng lực công ty + portfolio + đánh giá uy tín',
  'Bot trả lời khách tự động theo kịch bản riêng',
  'Đăng tin tuyển dụng, rao vặt và tạo nhóm thành viên doanh nghiệp',
]

export default function BusinessUpgradeCard({ me, onRefreshUser, banner = false, onGoPages }: {
  me: VxUserInfo
  onRefreshUser?: () => void
  /** banner = phiên gọn đặt đầu trang Trang (Fanpage); mặc định = thẻ đầy đủ ở Hồ sơ */
  banner?: boolean
  /** gọi khi tài khoản đã là doanh nghiệp — chuyển tới Trang (Fanpage) */
  onGoPages?: () => void
}) {
  const [cost, setCost] = useState<number | null>(null)
  const [bizApp, setBizApp] = useState<BizAppT | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [companyName, setCompanyName] = useState('')
  const [taxId, setTaxId] = useState('')
  const [industry, setIndustry] = useState('')
  const [busy, setBusy] = useState(false)
  // Tỷ giá USD/VND thực tế (live) — quy phí nâng cấp ra USD cho dễ hiểu
  const rate = useUsdRate()

  useEffect(() => {
    fetch('/api/vx/business-upgrade')
      .then((r) => r.json())
      .then((d) => {
        if (d && typeof d.cost === 'number') setCost(d.cost)
        setBizApp(d.application ?? null)
      })
      .catch(() => {})
  }, [me.accountType])

  const submit = async () => {
    if (!companyName.trim()) { toast.error('Nhập tên công ty để nộp đơn'); return }
    setBusy(true)
    try {
      const res = await fetch('/api/vx/business-upgrade', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ companyName, taxId, industry }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không nộp được đơn')
      toast.success(d.message || 'Đã nộp đơn, chờ admin duyệt')
      setBizApp(d.application ?? null)
      setDialogOpen(false)
      setCompanyName(''); setTaxId(''); setIndustry('')
      onRefreshUser?.()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không nộp được đơn')
    } finally { setBusy(false) }
  }

  const isBusiness = me.accountType === 'business'
  const costText = cost != null ? fmtUsdFromXu(cost, rate) : '$1,95'

  // Hộp thoại nộp đơn — dùng chung cả 2 phiên hiển thị
  const dialog = (
    <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Building2 className="h-5 w-5 text-amber-600" /> Nâng cấp tài khoản doanh nghiệp</DialogTitle>
          <DialogDescription>Phí nộp đơn {costText} — từ chối hoàn 100% vào ví. Ban Giám đốc duyệt trong vòng vài giờ.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <ul className="space-y-1 rounded-lg border border-amber-200 bg-amber-50/70 p-3 text-xs text-amber-800">
            {BENEFITS.map((b) => (
              <li key={b} className="flex items-start gap-1.5"><Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" /> {b}</li>
            ))}
          </ul>
          <div className="space-y-1">
            <Label htmlFor="biz-name">Tên công ty *</Label>
            <Input id="biz-name" value={companyName} onChange={(e) => setCompanyName(e.target.value)} placeholder="Công ty TNHH ABC" aria-label="Tên công ty" />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label htmlFor="biz-tax">Mã số thuế</Label>
              <Input id="biz-tax" value={taxId} onChange={(e) => setTaxId(e.target.value)} placeholder="Tuỳ chọn" aria-label="Mã số thuế" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="biz-industry">Lĩnh vực</Label>
              <Input id="biz-industry" value={industry} onChange={(e) => setIndustry(e.target.value)} placeholder="VD: F&B, thời trang..." aria-label="Lĩnh vực" />
            </div>
          </div>
          <Button className="h-11 w-full gap-2 bg-amber-500 font-semibold hover:bg-amber-600" onClick={submit} disabled={busy || !companyName.trim()}>
            {busy ? <><Loader2 className="h-4 w-4 animate-spin" /> Đang nộp đơn...</> : <><Building2 className="h-4 w-4" /> Nộp đơn nâng cấp ({costText})</>}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )

  // ===== PHIÊN BANNER GỌN — đầu trang Trang (Fanpage) =====
  if (banner) {
    if (isBusiness) return null // đã doanh nghiệp: không cần banner
    return (
      <div className="flex flex-wrap items-center gap-3 rounded-xl border border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50 p-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow"><Building2 className="h-5 w-5" /></span>
        <div className="min-w-0 flex-1">
          <p className="flex flex-wrap items-center gap-1.5 text-sm font-bold text-amber-900">
            Trang doanh nghiệp (Fanpage)
            {bizApp?.status === 'pending' && <Badge className="bg-sky-100 text-sky-800 hover:bg-sky-100"><Hourglass className="mr-1 h-3 w-3" /> Đơn đang chờ duyệt</Badge>}
          </p>
          <p className="mt-0.5 text-xs text-amber-700/90">
            {bizApp?.status === 'pending'
              ? `Đơn "${bizApp.companyName}" đang chờ Ban Giám đốc duyệt — duyệt xong bạn có thể tạo Trang doanh nghiệp ngay.`
              : <>Nâng cấp tài khoản doanh nghiệp để mở Trang chính thức cho công ty — phí {costText}, từ chối hoàn 100%.</>}
          </p>
        </div>
        {bizApp?.status !== 'pending' && (
          <Button className="bg-amber-500 font-semibold hover:bg-amber-600" onClick={() => setDialogOpen(true)}>
            <Building2 className="mr-1 h-4 w-4" /> Nâng cấp doanh nghiệp
          </Button>
        )}
        {dialog}
      </div>
    )
  }

  // ===== THẺ ĐẦY ĐỦ — Hồ sơ =====
  return (
    <div className="overflow-hidden rounded-2xl border bg-white shadow-sm">
      <p className="border-b bg-stone-50 px-4 py-2.5 text-sm font-bold text-stone-700">Tài khoản của tôi</p>
      <div className="p-4">
        {isBusiness ? (
          <div className="flex flex-wrap items-center gap-3">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow"><Building2 className="h-5 w-5" /></span>
            <div className="min-w-0 flex-1">
              <p className="flex flex-wrap items-center gap-1.5 text-sm font-bold text-amber-800">
                <BadgeCheck className="h-4 w-4" /> Tài khoản DOANH NGHIỆP{me.companyName ? ` — ${me.companyName}` : ''}
              </p>
              <p className="mt-0.5 text-xs text-stone-500">Đã mở toàn bộ quyền lợi: Trang doanh nghiệp (fanpage), hồ sơ năng lực, bot trả lời khách, tin tuyển dụng &amp; rao vặt.</p>
            </div>
            {onGoPages && (
              <Button className="bg-emerald-600 font-semibold hover:bg-emerald-700" onClick={onGoPages}>
                Trang doanh nghiệp của tôi <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            )}
          </div>
        ) : bizApp?.status === 'pending' ? (
          <div className="flex flex-wrap items-center gap-3">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-sky-500 text-white shadow"><Hourglass className="h-5 w-5" /></span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold text-sky-800">Đơn nâng cấp "{bizApp.companyName}" đang CHỜ DUYỆT</p>
              <p className="mt-0.5 text-xs text-stone-500">
                Nộp lúc {bizApp.createdAt ? new Date(bizApp.createdAt).toLocaleString('vi-VN') : '—'} · đã trừ {bizApp.xuPaid != null ? fmtUsdFromXu(bizApp.xuPaid, rate) : costText}.
                Duyệt xong tài khoản tự chuyển thành doanh nghiệp; từ chối sẽ hoàn 100% vào ví.
              </p>
            </div>
          </div>
        ) : (
          <div className="flex flex-wrap items-center gap-3">
            {bizApp?.status === 'rejected' && (
              <p className="mb-1 flex w-full items-start gap-1.5 rounded border border-rose-200 bg-rose-50 p-2 text-xs text-rose-700">
                <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                Đơn "{bizApp.companyName}" bị từ chối{bizApp.note ? `: ${bizApp.note}` : ''}. Đã hoàn {bizApp.xuPaid != null ? fmtUsdFromXu(bizApp.xuPaid, rate) : ''} vào ví — bạn có thể nộp đơn lại.
              </p>
            )}
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow"><Building2 className="h-5 w-5" /></span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold text-stone-800">Nâng cấp lên tài khoản DOANH NGHIỆP</p>
              <p className="mt-0.5 text-xs text-stone-500">Mở Trang doanh nghiệp (fanpage) chính thức, hồ sơ năng lực, bot trả lời khách, tin tuyển dụng &amp; nhóm thành viên công ty.</p>
            </div>
            <Button className="bg-amber-500 font-semibold hover:bg-amber-600" onClick={() => setDialogOpen(true)}>
              <Building2 className="mr-1 h-4 w-4" /> Nâng cấp ngay
            </Button>
          </div>
        )}
      </div>
      {dialog}
    </div>
  )
}
