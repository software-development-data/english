'use client'

// ============ MASCOT AI 3D CHẠY QUANH WEB ============
// Robot chibi Vexon (ChibiBot dùng chung với Splash/404) trượt quanh màn hình theo lộ trình,
// có bóng đổ, nghiêng 3D theo hướng đi, bong bóng lời mời nhấp nháy — bấm vào là mở Trợ lý AI.
// Dùng CSS thuần (GPU transform), không thêm dependency, không đụng menu/nút của app.

import { useEffect, useState } from 'react'
import { ChibiBot } from './SplashScreen'

export default function AiMascot() {
  const [mounted, setMounted] = useState(false)

  // Xuất hiện sau khi app vào ổn định (tránh che splash + nhảy layout khi hydrate)
  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 2400)
    return () => clearTimeout(t)
  }, [])

  if (!mounted) return null

  const openAssistant = () => {
    window.dispatchEvent(new CustomEvent('vx-open-ai-assistant'))
  }

  return (
    <div className="vx-mascot-walk pointer-events-none fixed left-0 top-0 z-[45]" aria-hidden={false}>
      <div className="pointer-events-auto relative cursor-pointer select-none" onClick={openAssistant} role="button" tabIndex={0}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') openAssistant() }}
        aria-label="Mở Trợ lý AI Vexon"
        title="Mình là Vexon Bot — bấm để hỏi AI ngay!"
      >
        {/* Bong bóng lời mời — hiện nhấp nháy theo chu kỳ */}
        <span className="vx-mascot-bubble absolute -top-9 left-1/2 w-max -translate-x-1/2 rounded-xl rounded-br-none border border-emerald-200 bg-white px-2.5 py-1 text-[10px] font-bold text-emerald-700 shadow-md">
          Bấm mình để hỏi AI!
        </span>

        {/* Robot nghiêng 3D theo hướng di chuyển + nhịp nhảy nhẹ */}
        <div className="vx-mascot-tilt drop-shadow-[0_10px_14px_rgba(13,148,136,0.28)]">
          <ChibiBot className="h-14 w-14 sm:h-16 sm:w-16" waving />
        </div>

        {/* Bóng đổ dưới chân */}
        <span className="vx-mascot-shadow mx-auto block h-2 w-10 rounded-full bg-emerald-900/20" aria-hidden />
      </div>
    </div>
  )
}
