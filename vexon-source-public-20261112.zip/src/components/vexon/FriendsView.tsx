'use client'

import { useCallback, useState } from 'react'
import { fmtDate } from '@/lib/format'
import type { VxUserInfo } from '@/components/vexon/AuthView'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useToast } from '@/hooks/use-toast'
import { Users, UserPlus, Search, Clock3, Check, X, UserMinus, MessageCircle, Eye } from 'lucide-react'

interface VxUserLite {
  id: string
  username: string
  fullName: string
  role: string
  avatarColor: string
  bio?: string | null
}

interface FriendsData {
  friends: (VxUserLite & { friendshipId?: string })[]
  requestsReceived: { friendshipId: string; user: VxUserLite; createdAt: string }[]
  requestsSent: { friendshipId: string; user: VxUserLite; createdAt: string }[]
}

const ROLE_LABEL: Record<string, string> = { admin: 'Quản trị', manager: 'Quản lý', employee: 'Nhân viên' }

export default function FriendsView({ me, onMessage, onOpenProfile }: { me: VxUserInfo; onMessage: (userId: string) => void; onOpenProfile?: (userId: string) => void }) {
  const [data, setData] = useState<FriendsData>({ friends: [], requestsReceived: [], requestsSent: [] })
  const [allUsers, setAllUsers] = useState<VxUserLite[]>([])
  const [q, setQ] = useState('')
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  const load = useCallback(() => {
    Promise.all([
      fetch('/api/vx/friends').then((r) => r.json()),
      fetch('/api/vx/users').then((r) => r.json()),
    ])
      .then(([fr, us]) => {
        if (fr.friends !== undefined) setData(fr)
        if (Array.isArray(us)) setAllUsers(us)
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(load, [load])

  const act = async (action: string, payload: Record<string, string>, successMsg?: string) => {
    const res = await fetch('/api/vx/friends', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...payload }),
    })
    const d = await res.json()
    if (!res.ok) {
      toast({ title: 'Lỗi', description: d.error, variant: 'destructive' })
      return false
    }
    if (successMsg) toast({ title: successMsg })
    load()
    return true
  }

  const friendIds = new Set(data.friends.map((f) => f.id))
  const receivedIds = new Set(data.requestsReceived.map((r) => r.user.id))
  const sentIds = new Set(data.requestsSent.map((r) => r.user.id))
  const kw = q.trim().toLowerCase()
  const discover = allUsers.filter((u) => u.id !== me.id && !kw || (u.fullName.toLowerCase().includes(kw) || u.username.includes(kw)))

  return (
    <div className="mx-auto max-w-2xl">
      <h2 className="mb-4 flex items-center gap-2 font-bold">
        <Users className="h-5 w-5 text-emerald-600" />
        Bạn bè
      </h2>

      <Tabs defaultValue="friends">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="friends">Bạn bè ({data.friends.length})</TabsTrigger>
          <TabsTrigger value="requests">
            Lời mời {data.requestsReceived.length > 0 && <Badge className="ml-1 h-5 bg-rose-600 px-1.5 text-white hover:bg-rose-600">{data.requestsReceived.length}</Badge>}
          </TabsTrigger>
          <TabsTrigger value="discover">Tìm kiếm</TabsTrigger>
        </TabsList>

        {/* Danh sách bạn bè */}
        <TabsContent value="friends" className="mt-4 space-y-2">
          {loading ? (
            <p className="py-10 text-center text-sm text-muted-foreground">Đang tải...</p>
          ) : data.friends.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">Chưa có bạn bè, vào tab Tìm kiếm để thêm nhé!</p>
          ) : (
            data.friends.map((f) => (
              <div key={f.id} className="flex items-center gap-3 rounded-xl border p-3">
                {/* Bấm avatar/tên → xem trang cá nhân (kiểu TTO: nút Hồ sơ trên thẻ bạn bè) */}
                <button className="flex min-w-0 flex-1 items-center gap-3 text-left" onClick={() => onOpenProfile?.(f.id)} aria-label={`Xem trang cá nhân của ${f.fullName}`}>
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold text-white" style={{ backgroundColor: f.avatarColor }}>
                    {f.fullName[0]}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{f.fullName}</p>
                    <p className="truncate text-xs text-muted-foreground">@{f.username}, {ROLE_LABEL[f.role] || f.role}</p>
                  </div>
                </button>
                <Button size="sm" variant="outline" onClick={() => onMessage(f.id)}>
                  <MessageCircle className="mr-1 h-4 w-4" />
                  Nhắn tin
                </Button>
                {onOpenProfile && (
                  <Button size="sm" variant="outline" onClick={() => onOpenProfile(f.id)} aria-label={`Hồ sơ của ${f.fullName}`}>
                    <Eye className="mr-1 h-4 w-4" />
                    Hồ sơ
                  </Button>
                )}
                <Button size="sm" variant="outline" className="text-red-600 hover:bg-red-50" onClick={() => act('remove', { friendshipId: f.friendshipId || '' }, 'Đã hủy kết bạn')} aria-label={`Hủy kết bạn với ${f.fullName}`}>
                  <UserMinus className="h-4 w-4" />
                </Button>
              </div>
            ))
          )}
        </TabsContent>

        {/* Lời mời kết bạn */}
        <TabsContent value="requests" className="mt-4 space-y-4">
          <div>
            <p className="mb-2 flex items-center gap-1.5 text-sm font-semibold">
              <Clock3 className="h-4 w-4 text-amber-600" />
              Đã nhận ({data.requestsReceived.length})
            </p>
            {data.requestsReceived.length === 0 ? (
              <p className="rounded-xl border border-dashed p-4 text-center text-sm text-muted-foreground">Không có lời mời nào</p>
            ) : (
              <div className="space-y-2">
                {data.requestsReceived.map((r) => (
                  <div key={r.friendshipId} className="flex items-center gap-3 rounded-xl border p-3">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold text-white" style={{ backgroundColor: r.user.avatarColor }}>
                      {r.user.fullName[0]}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{r.user.fullName}</p>
                      <p className="text-xs text-muted-foreground">@{r.user.username}, {fmtDate(r.createdAt)}</p>
                    </div>
                    <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => act('accept', { friendshipId: r.friendshipId }, 'Đã chấp nhận kết bạn')}>
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" className="text-red-600" onClick={() => act('decline', { friendshipId: r.friendshipId })}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div>
            <p className="mb-2 text-sm font-semibold">Đã gửi ({data.requestsSent.length})</p>
            {data.requestsSent.length === 0 ? (
              <p className="rounded-xl border border-dashed p-4 text-center text-sm text-muted-foreground">Không có lời mời đang chờ</p>
            ) : (
              <div className="space-y-2">
                {data.requestsSent.map((r) => (
                  <div key={r.friendshipId} className="flex items-center gap-3 rounded-xl border p-3 opacity-75">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold text-white" style={{ backgroundColor: r.user.avatarColor }}>
                      {r.user.fullName[0]}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{r.user.fullName}</p>
                      <p className="text-xs text-muted-foreground">Đang chờ phản hồi...</p>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => act('remove', { friendshipId: r.friendshipId })}>
                      Huỷ
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Tìm kiếm người dùng */}
        <TabsContent value="discover" className="mt-4">
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm theo tên hoặc tên đăng nhập..." className="pl-9" />
          </div>
          <div className="space-y-2">
            {discover.length === 0 ? (
              <p className="py-10 text-center text-sm text-muted-foreground">Không tìm thấy ai</p>
            ) : (
              discover.map((u) => (
                <div key={u.id} className="flex items-center gap-3 rounded-xl border p-3">
                  <button className="flex min-w-0 flex-1 items-center gap-3 text-left" onClick={() => onOpenProfile?.(u.id)} aria-label={`Xem trang cá nhân của ${u.fullName}`}>
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold text-white" style={{ backgroundColor: u.avatarColor }}>
                      {u.fullName[0]}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{u.fullName}</p>
                      <p className="truncate text-xs text-muted-foreground">{u.bio || `@${u.username}, ${ROLE_LABEL[u.role] || u.role}`}</p>
                    </div>
                  </button>
                  {friendIds.has(u.id) ? (
                    <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">Bạn bè</Badge>
                  ) : receivedIds.has(u.id) ? (
                    <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => {
                      const req = data.requestsReceived.find((r) => r.user.id === u.id)
                      if (req) act('accept', { friendshipId: req.friendshipId }, 'Đã chấp nhận kết bạn')
                    }}>
                      Chấp nhận
                    </Button>
                  ) : sentIds.has(u.id) ? (
                    <Badge variant="secondary">Đã gửi lời mời</Badge>
                  ) : (
                    <Button size="sm" variant="outline" onClick={() => act('request', { userId: u.id }, 'Đã gửi lời mời kết bạn')}>
                      <UserPlus className="mr-1 h-4 w-4" />
                      Kết bạn
                    </Button>
                  )}
                </div>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
