'use client'

// ============ HỒ SƠ KIỂU FACEBOOK / ZALO ============
// Ảnh bìa + ảnh đại diện tự tải lên, lưới ảnh từ bài viết, danh sách bạn bè ·
// giới thiệu, chỉnh sửa nhanh — tất cả lưu qua /api/vx/profile

import { useCallback, useEffect, useRef, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { compressImage } from '@/lib/image-compress'
import { Avatar, timeAgo, GradMedia, isGradMedia } from './shared'
import type { VxUserInfo } from './AuthView'
import BusinessUpgradeCard from './BusinessUpgradeCard'
import { fmtUsdFromXu } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogClose, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Checkbox } from '@/components/ui/checkbox'
import { Skeleton } from '@/components/ui/skeleton'
import { Card, CardContent } from '@/components/ui/card'
import { toast } from 'sonner'
import { useToast } from '@/hooks/use-toast'
import { Coins, Loader2, Save, MapPin, FileText, Building2, Pencil, Camera, Images, Users as UsersIcon, Info, Heart, Video, Plus, ImagePlus, Trash2, PenLine, Layers, X, Paperclip, AtSign, Megaphone, ChevronDown, ChevronRight, Send, Briefcase, CalendarDays, Target, GraduationCap, Mail, Activity, Home as HomeIcon, Phone, SlidersHorizontal, MoreHorizontal, Newspaper, ThumbsUp, MessageCircle, Share2, BadgeCheck, Check, UserPlus, Ban, Archive, Repeat2, UserMinus, Ruler, Weight, Wine, UserRound, Globe2, UsersRound, Lock, Smile, IdCard, Landmark, Cigarette, PawPrint } from 'lucide-react'
import { POST_BACKGROUNDS, VISIBILITY_OPTIONS, visibilityOf } from './shared'
import { VN_PROVINCE_NAMES_34 } from '@/lib/vx-locations'
import { ShareSheet, PostCard, type PostT, type CommentT } from './FeedView'

interface ProfileData {
  profile: {
    id: string
    fullName: string
    username: string
    role: string
    department: string
    title: string
    avatarColor: string
    avatarImage?: string | null
    coverImage?: string | null
    bio: string | null
    hometown?: string | null
    education?: string | null
    birthday?: string | null
    phone?: string | null
    email?: string | null
    accountType: string
    companyName: string | null
    interests: string[]
    // Hồ sơ hẹn hò + xã giao (khôi phục đúng bản 09c): chiều cao/cân nặng/tình trạng/lối sống/thú cưng
    heightCm?: number | null
    weightKg?: number | null
    relationship?: string | null
    smoking?: string | null
    drinking?: string | null
    pets?: string | null
    gender?: string | null
    ethnicity?: string | null
    citizenId?: string | null
    taxCode?: string | null
    locationVisible?: boolean
    hiddenFields?: string[]
    online: boolean
    lastSeen?: string
    joinedAt: string
    locationName: string | null
    counts: { posts: number; videos: number; followers: number; following: number; attendanceDays: number }
    friendship?: string | null
    friendshipId?: string | null
    blocked?: boolean
    company?: { id: string; name: string; industry: string; ratingAvg: number; ratingCount: number; botEnabled: boolean } | null
    cv?: { headline: string | null; skills: string[] } | null
  }
  isMe: boolean
  photos?: string[]
  friends?: { id: string; fullName: string; avatarColor: string; avatarImage?: string | null; title?: string; friendshipId?: string | null }[]
}

// Nén ảnh → dùng chung từ @/lib/image-compress

interface AlbumMeta { id: string; name: string; count: number; cover: string | null; photos?: string[] }

// ─── Quyền xem từng mục hồ sơ kiểu Facebook: Công khai → Bạn bè → Chỉ mình tôi ───
const VIS_ORDER = ['public', 'friends', 'private'] as const
type VisValue = (typeof VIS_ORDER)[number]
const VIS_META: Record<VisValue, { label: string; icon: React.ReactNode; cls: string }> = {
  public: { label: 'Công khai', icon: <Globe2 className="h-3 w-3" />, cls: 'text-emerald-700 border-emerald-300 bg-emerald-50' },
  friends: { label: 'Bạn bè', icon: <UsersRound className="h-3 w-3" />, cls: 'text-sky-700 border-sky-300 bg-sky-50' },
  private: { label: 'Chỉ mình tôi', icon: <Lock className="h-3 w-3" />, cls: 'text-stone-600 border-stone-300 bg-stone-100' },
}
function VisCycle({ value, onChange, name }: { value: VisValue; onChange: (v: VisValue) => void; name: string }) {
  const meta = VIS_META[value]
  return (
    <button
      type="button"
      onClick={() => onChange(VIS_ORDER[(VIS_ORDER.indexOf(value) + 1) % VIS_ORDER.length])}
      className={`flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold transition ${meta.cls}`}
      title={`${name}: hiện ${meta.label} — bấm để đổi ai được xem mục này`}
      aria-label={`${name}: đang hiện ${meta.label}, bấm để đổi quyền xem`}
    >
      {meta.icon} {meta.label}
    </button>
  )
}
type InfoVisKey = 'birthday' | 'gender' | 'hometown' | 'education' | 'phone' | 'bio' | 'height' | 'weight' | 'relationship' | 'lifestyle' | 'interests' | 'job' | 'ethnicity' | 'citizenId' | 'taxCode'
const normVis = (v: unknown): VisValue => (v === 'friends' || v === 'private' ? v : 'public')

// Hành động bên cạnh MỖI dòng thông tin ở tab Giới thiệu (chỉ hiện cho chủ hồ sơ):
// nhãn quyền riêng tư bấm được (Công khai → Bạn bè → Chỉ mình tôi) + nút bút chì mở dialog sửa RIÊNG mục đó
function RowActions({ isMe, vis, name, onCycle, onEdit }: { isMe: boolean; vis?: VisValue; name: string; onCycle?: () => void; onEdit?: () => void }) {
  if (!isMe) return null
  return (
    <span className="ml-auto flex shrink-0 items-center gap-1">
      {vis && onCycle && <VisCycle value={vis} onChange={onCycle} name={name} />}
      {onEdit && (
        <button type="button" onClick={onEdit} className="rounded-md border border-stone-200 bg-white p-1.5 text-stone-500 transition hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-700" title={`Sửa ${name}`} aria-label={`Sửa ${name}`}>
          <Pencil className="h-3.5 w-3.5" />
        </button>
      )}
    </span>
  )
}

// ─── Sửa RIÊNG TỪNG MỤC (mỗi nút bút chì chỉ sửa đúng mục đó, không mở cả trang) ───
type EditKey = 'birthday' | 'hometown' | 'education' | 'phone' | 'bio' | 'gender' | 'interests' | 'height' | 'weight' | 'relationship' | 'smoking' | 'drinking' | 'pets' | 'ethnicity' | 'citizenId' | 'taxCode' | 'location' | 'job'
const EDIT_META: Record<EditKey, { label: string; visKey: string | null }> = {
  birthday: { label: 'Ngày sinh', visKey: 'birthday' },
  hometown: { label: 'Quê quán', visKey: 'hometown' },
  education: { label: 'Học vấn', visKey: 'education' },
  phone: { label: 'Số điện thoại', visKey: 'phone' },
  bio: { label: 'Bio cá nhân', visKey: 'bio' },
  gender: { label: 'Giới tính', visKey: 'gender' },
  interests: { label: 'Sở thích', visKey: 'interests' },
  height: { label: 'Chiều cao', visKey: 'height' },
  weight: { label: 'Cân nặng', visKey: 'weight' },
  relationship: { label: 'Tình trạng quan hệ', visKey: 'relationship' },
  smoking: { label: 'Thuốc lá', visKey: 'lifestyle' },
  drinking: { label: 'Rượu bia', visKey: 'lifestyle' },
  pets: { label: 'Thú cưng', visKey: 'lifestyle' },
  ethnicity: { label: 'Dân tộc', visKey: 'ethnicity' },
  citizenId: { label: 'Căn cước công dân', visKey: 'citizenId' },
  taxCode: { label: 'Mã số thuế', visKey: 'taxCode' },
  location: { label: 'Sống tại', visKey: null },
  job: { label: 'Chức danh', visKey: 'job' },
}
const GENDER_OPTIONS = ['Nam', 'Nữ', 'Khác']
const REL_OPTIONS = ['Độc thân', 'Hẹn hò', 'Có người yêu', 'Đã kết hôn']
const HABIT_OPTIONS = ['Không', 'Thỉnh thoảng', 'Thường xuyên', 'Đã bỏ']
const ETHNICITY_OPTIONS = ['Kinh', 'Tày', 'Thái', 'Mường', 'Khmer', 'Hoa', 'Nùng', "H'Mông", 'Dao', 'Gia Rai', 'Ê Đê', 'XĐăng', 'Cơ Tu', 'Khác']
// Nhãn tiếng Việt cho các mục bị ẩn do quyền riêng tư (hiển thị ở ghi chú cuối tab Giới thiệu)
const HIDDEN_LABELS: Record<string, string> = { gender: 'Giới tính', hometown: 'Quê quán', education: 'Học vấn', phone: 'Số điện thoại', bio: 'Bio', height: 'Chiều cao', weight: 'Cân nặng', relationship: 'Quan hệ', lifestyle: 'Lối sống', interests: 'Sở thích', ethnicity: 'Dân tộc', citizenId: 'CCCD', taxCode: 'Mã thuế', job: 'Chức vụ' }
// Ô chọn giá trị có sẵn (select) cho từng mục — chọn từ danh sách là chính, không gõ tay
function ValueSelect({ id, value, onChange, options, ariaLabel, placeholder }: { id?: string; value: string; onChange: (v: string) => void; options: string[]; ariaLabel: string; placeholder: string }) {
  const known = value === '' || options.includes(value)
  return (
    <select id={id} value={known ? value : '__keep__'} onChange={(e) => { if (e.target.value !== '__keep__') onChange(e.target.value) }} aria-label={ariaLabel}
      className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm">
      <option value="">{placeholder}</option>
      {!known && <option value="__keep__">{value} (giữ nguyên)</option>}
      {options.map((o) => <option key={o} value={o}>{o}</option>)}
    </select>
  )
}

export function UserProfileDialog({ userId, open, onClose, onMessage }: { userId: string | null; open: boolean; onClose: () => void; onMessage: (id: string) => void }) {
  const [data, setData] = useState<ProfileData | null>(null)
  const [busy, setBusy] = useState(false)

  useDeferredLoad(
    () => {
      if (open && userId) fetch(`/api/vx/users/${userId}`).then((r) => r.json()).then((d) => setData(d.profile ? d : null)).catch(() => {})
    },
    [open, userId]
  )

  // Kết bạn / chấp nhận lời mời (nút trên hộp thoại xem hồ sơ)
  const friendAction = async () => {
    if (!data?.profile) return
    const p = data.profile
    setBusy(true)
    try {
      if (p.friendship === 'request_received' && p.friendshipId) {
        const res = await fetch('/api/vx/friends', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'accept', friendshipId: p.friendshipId }) })
        if (res.ok) { toast(`Đã chấp nhận lời mời từ ${p.fullName}`); setData({ ...data, profile: { ...p, friendship: 'friends' } }) }
        else toast.error('Không chấp nhận được lời mời')
      } else if (!p.friendship) {
        const res = await fetch('/api/vx/friends', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'request', userId: p.id }) })
        if (res.ok) { toast(`Đã gửi lời mời kết bạn tới ${p.fullName}`); setData({ ...data, profile: { ...p, friendship: 'request_sent' } }) }
        else { const d = await res.json().catch(() => ({})); toast.error(d.error || 'Không gửi được lời mời') }
      }
    } finally {
      setBusy(false)
    }
  }

  // Chặn / bỏ chặn (kiểu Zalo): chặn xong 2 bên không thấy nhau, không nhắn tin được
  const blockAction = async () => {
    if (!data?.profile) return
    const p = data.profile
    if (!p.blocked && !window.confirm(`Chặn ${p.fullName}? Hai bên sẽ không thấy nhau trong tìm kiếm và không nhắn tin được cho nhau.`)) return
    setBusy(true)
    try {
      const res = await fetch('/api/vx/blocks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: p.id, action: p.blocked ? 'unblock' : 'block' }) })
      if (res.ok) {
        toast(p.blocked ? `Đã bỏ chặn ${p.fullName}` : `Đã chặn ${p.fullName}`)
        setData({ ...data, profile: { ...p, blocked: !p.blocked } })
      } else toast.error('Không thực hiện được')
    } finally {
      setBusy(false)
    }
  }

  // Hủy kết bạn (kiểu Facebook) — hoạt động thật nhờ friendshipId trả về từ API hồ sơ
  const unfriendAction = async () => {
    if (!data?.profile) return
    const p = data.profile
    if (!p.friendshipId) { toast.error('Không tìm thấy quan hệ bạn bè'); return }
    if (!window.confirm(`Hủy kết bạn với ${p.fullName}?`)) return
    setBusy(true)
    try {
      const res = await fetch('/api/vx/friends', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove', friendshipId: p.friendshipId }),
      })
      if (res.ok) {
        toast(`Đã hủy kết bạn với ${p.fullName}`)
        setData({ ...data, profile: { ...p, friendship: null, friendshipId: null } })
      } else toast.error('Không hủy được kết bạn')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      {/* Kiểu AJAX: bìa gradient tràn mép + skeleton shimmer khi tải + nội dung hiện mượt — cuộn được khi thu phóng; grid-cols-1 (minmax(0,1fr)) chặn grid blowout ngang */}
      <DialogContent className="grid-cols-1 gap-0 overflow-y-auto rounded-2xl p-0 sm:max-w-md" aria-describedby={undefined}>
        {data ? (
          <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
            {/* Bìa gradient kiểu hero trang chủ V2 + hoạ tiết vòng tròn & chấm bi */}
            <div className="relative h-24 shrink-0 bg-gradient-to-br from-emerald-700 via-teal-600 to-cyan-700">
              <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden rounded-t-2xl">
                <div className="absolute -right-10 -top-14 h-48 w-48 rounded-full border border-white/15" />
                <div className="absolute -right-4 -top-8 h-36 w-36 rounded-full border border-white/10" />
                <div className="absolute -left-10 -bottom-16 h-44 w-44 rounded-full bg-cyan-400/20 blur-2xl" />
                <div className="absolute inset-0 opacity-40" style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.18) 1px, transparent 1px)', backgroundSize: '14px 14px' }} />
              </div>
              <DialogClose className="absolute right-3 top-3 z-10 grid h-8 w-8 place-items-center rounded-full bg-black/25 text-white transition-colors hover:bg-black/40" aria-label="Đóng khung xem hồ sơ">
                <X className="h-4 w-4" />
              </DialogClose>
              <DialogTitle className="sr-only">Hồ sơ của {data.profile.fullName}</DialogTitle>
              <div className="absolute -bottom-9 left-5 z-10">
                <div className="rounded-full bg-white p-1 shadow-md">
                  <Avatar name={data.profile.fullName} color={data.profile.avatarColor} size={56} online={data.profile.online} img={data.profile.avatarImage} />
                </div>
              </div>
            </div>
            <div className="px-5 pb-5 pt-12">
              {/* Tên + chip trạng thái online kiểu Zalo */}
              <div className="flex flex-wrap items-center gap-2">
                <p className="text-lg font-bold leading-tight">{data.profile.fullName}</p>
                <span className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-semibold ${data.profile.online ? 'bg-emerald-50 text-emerald-700' : 'bg-stone-100 text-stone-500'}`}>
                  <span className={`h-1.5 w-1.5 rounded-full ${data.profile.online ? 'animate-pulse bg-emerald-500' : 'bg-stone-400'}`} />
                  {data.profile.online ? 'Đang online' : 'Không online'}
                </span>
              </div>
              <p className="mt-0.5 text-xs text-stone-500">@{data.profile.username}, {data.profile.title}</p>
              {data.profile.bio && <p className="mt-1.5 text-sm italic text-stone-600">{data.profile.bio}</p>}
              {/* Thông tin hồ sơ kiểu TTO: ngày sinh, vị trí, quê quán, chức vụ, giáo dục, SĐT, email, trạng thái — GIỮ NGUYÊN 100% các dòng */}
              <div className="mt-3 space-y-1.5 rounded-xl border bg-stone-50/60 p-3 text-sm">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-stone-400"><Info className="h-3.5 w-3.5 text-emerald-600" /> Thông tin hồ sơ</p>
                <InfoRow icon={<CalendarDays className="h-3.5 w-3.5 text-sky-600" />} label="Ngày sinh" value={data.profile.birthday ? new Date(data.profile.birthday).toLocaleDateString('vi-VN') : null} />
                {!data.profile.hiddenFields?.includes('gender') && <InfoRow icon={<UserRound className="h-3.5 w-3.5 text-sky-600" />} label="Giới tính" value={data.profile.gender} />}
                <InfoRow icon={<MapPin className="h-3.5 w-3.5 text-rose-500" />} label="Vị trí hiện tại" value={data.profile.locationName} />
                <InfoRow icon={<HomeIcon className="h-3.5 w-3.5 text-emerald-600" />} label="Quê quán" value={data.profile.hometown} />
                <InfoRow icon={<Briefcase className="h-3.5 w-3.5 text-amber-600" />} label="Chức vụ" value={`${data.profile.title}, ${data.profile.department}`} />
                <InfoRow icon={<GraduationCap className="h-3.5 w-3.5 text-emerald-600" />} label="Giáo dục" value={data.profile.education} />
                {/* Hồ sơ hẹn hò + xã giao (khôi phục đúng bản 09c) */}
                {!data.profile.hiddenFields?.includes('height') && <InfoRow icon={<Ruler className="h-3.5 w-3.5 text-teal-600" />} label="Chiều cao" value={data.profile.heightCm ? `${data.profile.heightCm} cm` : null} />}
                {!data.profile.hiddenFields?.includes('weight') && <InfoRow icon={<Weight className="h-3.5 w-3.5 text-teal-600" />} label="Cân nặng" value={data.profile.weightKg ? `${data.profile.weightKg} kg` : null} />}
                {!data.profile.hiddenFields?.includes('relationship') && <InfoRow icon={<Heart className="h-3.5 w-3.5 text-rose-500" />} label="Tình trạng quan hệ" value={data.profile.relationship} />}
                {!data.profile.hiddenFields?.includes('lifestyle') && <InfoRow icon={<Wine className="h-3.5 w-3.5 text-purple-600" />} label="Lối sống" value={[data.profile.smoking && `Thuốc lá: ${data.profile.smoking}`, data.profile.drinking && `Rượu bia: ${data.profile.drinking}`, data.profile.pets && `Thú cưng: ${data.profile.pets}`].filter(Boolean).join(', ') || null} />}
                <InfoRow icon={<Target className="h-3.5 w-3.5 text-teal-600" />} label="Sở thích" value={data.profile.interests?.length ? data.profile.interests.join(', ') : null} />
                <InfoRow icon={<Phone className="h-3.5 w-3.5 text-stone-500" />} label="Số điện thoại" value={data.profile.phone} />
                <InfoRow icon={<Mail className="h-3.5 w-3.5 text-sky-600" />} label="Email" value={data.profile.email} />
                <InfoRow icon={<Activity className="h-3.5 w-3.5 text-emerald-600" />} label="Trạng thái" value={data.profile.online ? 'Đang online' : 'Không online'} />
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {data.profile.accountType === 'business' && <Badge className="bg-amber-600 text-white hover:bg-amber-600"><Building2 className="mr-1 inline h-3 w-3" />Tài khoản doanh nghiệp</Badge>}
                {data.profile.companyName && <Badge variant="secondary">{data.profile.companyName}</Badge>}
                {data.profile.locationName && <Badge variant="secondary"><MapPin className="mr-1 inline h-3 w-3" />{data.profile.locationName}</Badge>}
                {data.profile.cv?.headline && <Badge className="bg-teal-100 text-teal-800 hover:bg-teal-100"><FileText className="mr-1 inline h-3 w-3" />{data.profile.cv.headline}</Badge>}
              </div>
              {data.photos && data.photos.length > 0 && (
                <div className="mt-3 grid grid-cols-4 gap-1">
                  {data.photos.slice(0, 8).map((src, i) => (
                    <img key={i} src={src} alt={`Ảnh ${i + 1}`} className="aspect-square w-full rounded-md object-cover" />
                  ))}
                </div>
              )}
              <div className="mt-3 grid grid-cols-5 gap-1 rounded-lg bg-stone-50 p-3 text-center text-xs">
                <div><p className="font-bold">{data.profile.counts.posts}</p><p className="text-stone-500">Bài viết</p></div>
                <div><p className="font-bold">{data.profile.counts.videos}</p><p className="text-stone-500">Video</p></div>
                <div><p className="font-bold">{data.profile.counts.followers}</p><p className="text-stone-500">Theo dõi</p></div>
                <div><p className="font-bold">{data.profile.counts.attendanceDays}</p><p className="text-stone-500">Ngày công</p></div>
                <div>{data.profile.company ? <><p className="font-bold">{data.profile.company.ratingAvg} điểm</p><p className="text-stone-500">Uy tín</p></> : <><p className="font-bold">-</p><p className="text-stone-500">Doanh nghiệp</p></>}</div>
              </div>
              {/* Hàng nút: Kết bạn (hoặc Chấp nhận) + Nhắn tin + Chặn (kiểu Zalo/Facebook) */}
              {!data.isMe && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {data.profile.blocked ? (
                    <Button variant="outline" className="flex-1 gap-1.5 border-rose-200 text-rose-600 hover:bg-rose-50" disabled={busy} onClick={blockAction}>
                      <Ban className="h-4 w-4" /> Bỏ chặn
                    </Button>
                  ) : (
                    data.profile.friendship !== 'friends' && (
                      <Button
                        variant="outline"
                        className="flex-1 gap-1.5 border-emerald-300 text-emerald-700 hover:bg-emerald-50"
                        disabled={busy || data.profile.friendship === 'request_sent'}
                        onClick={friendAction}
                      >
                        {data.profile.friendship === 'request_sent'
                          ? <><Check className="h-4 w-4" /> Đã gửi lời mời</>
                          : data.profile.friendship === 'request_received'
                            ? <><Check className="h-4 w-4" /> Chấp nhận lời mời</>
                            : <><UserPlus className="h-4 w-4" /> Kết bạn</>}
                      </Button>
                    )
                  )}
                  <Button
                    className="min-w-28 flex-1 gap-1.5 bg-emerald-600 hover:bg-emerald-700"
                    disabled={busy || Boolean(data.profile.blocked)}
                    onClick={() => { onMessage(data.profile.id); onClose() }}
                  >
                    <MessageCircle className="h-4 w-4" /> Nhắn tin
                  </Button>
                  {data.profile.friendship === 'friends' && (
                    <Button
                      variant="outline"
                      className="gap-1.5 border-rose-200 text-rose-600 hover:bg-rose-50"
                      disabled={busy}
                      onClick={unfriendAction}
                      aria-label={`Hủy kết bạn với ${data.profile.fullName}`}
                    >
                      <UserMinus className="h-4 w-4" /> Hủy kết bạn
                    </Button>
                  )}
                  {!data.profile.blocked && (
                    <Button variant="outline" className="gap-1.5 border-stone-200 text-stone-500 hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600" disabled={busy} onClick={blockAction} aria-label={`Chặn ${data.profile.fullName}`}>
                      <Ban className="h-4 w-4" /> Chặn
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Skeleton kiểu AJAX: phản chiếu đúng bố cục hộp thoại, shimmer mượt khi đang tải */
          <div>
            <div className="relative h-24 shrink-0 bg-gradient-to-br from-emerald-700 via-teal-600 to-cyan-700">
              <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden rounded-t-2xl">
                <div className="absolute -right-10 -top-14 h-48 w-48 rounded-full border border-white/15" />
                <div className="absolute inset-0 opacity-40" style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.18) 1px, transparent 1px)', backgroundSize: '14px 14px' }} />
              </div>
              <DialogClose className="absolute right-3 top-3 z-10 grid h-8 w-8 place-items-center rounded-full bg-black/25 text-white transition-colors hover:bg-black/40" aria-label="Đóng khung xem hồ sơ">
                <X className="h-4 w-4" />
              </DialogClose>
              <DialogTitle className="sr-only">Đang tải hồ sơ</DialogTitle>
              <div className="absolute -bottom-9 left-5 z-10">
                <div className="rounded-full bg-white p-1 shadow-md">
                  <div className="vx-skel-dark h-14 w-14 rounded-full" />
                </div>
              </div>
            </div>
            <div className="space-y-3 px-5 pb-5 pt-12">
              <div className="vx-skel h-5 w-44" />
              <div className="vx-skel h-3.5 w-60" />
              <div className="space-y-3 rounded-xl border p-3">
                <div className="vx-skel h-3 w-36" />
                {Array.from({ length: 7 }).map((_, i) => (
                  <div key={i} className="flex items-center gap-2.5">
                    <div className="vx-skel h-7 w-7 shrink-0 rounded-full" />
                    <div className="vx-skel h-3 w-24" />
                    <div className="vx-skel ml-auto h-3 w-32" />
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-5 gap-2 rounded-lg bg-stone-50 p-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex flex-col items-center gap-1.5">
                    <div className="vx-skel h-4 w-8" />
                    <div className="vx-skel h-2.5 w-12" />
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <div className="vx-skel h-9 flex-1" />
                <div className="vx-skel h-9 flex-1" />
                <div className="vx-skel h-9 w-16" />
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

type Tab = 'posts' | 'photos' | 'friends' | 'about'

// Hàng thông tin hồ sơ (dùng trong dialog + tab Thông tin) — kiểu TTO “Thông tin hồ sơ”
function InfoRow({ icon, label, value }: { icon: React.ReactNode; label: string; value?: string | null }) {
  return (
    <p className="flex items-center gap-2 text-sm">
      <span className="flex w-5 shrink-0 justify-center text-stone-400">{icon}</span>
      <span className="w-28 shrink-0 text-stone-500">{label}</span>
      <b className="min-w-0 flex-1 break-words text-stone-800">{value || 'Chưa cập nhật'}</b>
    </p>
  )
}

// Loài + giới tính cho TRANG THÚ CƯNG (fanpage riêng cho pet — mạng xã hội phụ)
const PET_SPECIES = ['Chó', 'Mèo', 'Chim', 'Cá', 'Bò sát', 'Hamster', 'Khác']
const PET_GENDERS = ['Đực', 'Cái']
interface PetPageLite { id: string; name: string; category: string; bio: string | null; avatar: string | null; cover: string | null; petSpecies: string | null; petBreed: string | null; petGender: string | null; petBirthday: string | null; followerCount: number; postCount: number }

export default function ProfileView({ me, onRefreshUser, onMessage, onGoPages, onOpenPages }: { me: VxUserInfo; onRefreshUser: () => void; onMessage: (id: string) => void; onGoPages?: (pageId: string) => void; onOpenPages?: () => void }) {
  // Tỷ giá USD/VND thực tế (live) — ô Ví tiền quy theo giá hiện nay
  const rate = useUsdRate()
  const [data, setData] = useState<ProfileData | null>(null)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [locVisible, setLocVisible] = useState(true)
  const [interests, setInterests] = useState('')
  const [tab, setTab] = useState<Tab>('posts')
  const avatarInputRef = useRef<HTMLInputElement>(null)
  const coverInputRef = useRef<HTMLInputElement>(null)
  const composerImgRef = useRef<HTMLInputElement>(null)
  const albImgRef = useRef<HTMLInputElement>(null)

  // ---- Đăng bài kiểu Facebook ngay trên hồ sơ ----
  const [composerOpen, setComposerOpen] = useState(false)
  const [postText, setPostText] = useState('')
  const [postBg, setPostBg] = useState<string | null>(null)
  const [postImgs, setPostImgs] = useState<string[]>([])
  const [postVideo, setPostVideo] = useState<string | null>(null)
  const [postFile, setPostFile] = useState<{ url: string | null; name: string } | null>(null)
  const [postLoc, setPostLoc] = useState('')
  const [showLoc, setShowLoc] = useState(false)
  const [postMentions, setPostMentions] = useState<{ id: string; fullName: string }[]>([])
  const [mentionOpen, setMentionOpen] = useState(false)
  const [users, setUsers] = useState<{ id: string; fullName: string; avatarColor: string; department?: string }[]>([])
  const [announce, setAnnounce] = useState(false)
  const [visibility, setVisibility] = useState<string>('public')
  const [visOpen, setVisOpen] = useState(false)
  const [posting, setPosting] = useState(false)

  // ---- Thông tin hồ sơ (kiểu TTO): sửa nhanh ngày sinh/quê quán/giáo dục/SĐT/bio + giới tính + hẹn hò: chiều cao/cân nặng/tình trạng/lối sống/sở thích ----
  const [infoOpen, setInfoOpen] = useState(false)
  // Quyền xem từng mục kiểu FB (Công khai / Bạn bè / Chỉ mình tôi) — bấm nhãn cạnh mỗi ô để đổi
  const [infoVis, setInfoVis] = useState<Record<InfoVisKey, VisValue>>({ birthday: 'public', gender: 'public', hometown: 'public', education: 'public', phone: 'public', bio: 'public', height: 'public', weight: 'public', relationship: 'public', lifestyle: 'public', interests: 'public', job: 'public', ethnicity: 'public', citizenId: 'public', taxCode: 'public' })
  const [infoForm, setInfoForm] = useState({ birthday: '', hometown: '', education: '', phone: '', bio: '', interests: '', gender: '', heightCm: '', weightKg: '', relationship: '', drinking: '', smoking: '', pets: '' })
  const [savingInfo, setSavingInfo] = useState(false)

  // Nạp form sửa giới thiệu từ dữ liệu profile hiện có (đúng dữ liệu cũ, không mất mục nào) + nạp quyền xem từng mục từ me.settings
  const openInfoDialog = (prof?: ProfileData['profile'] | null) => {
    const q = prof || data?.profile || null
    setInfoForm({
      birthday: q?.birthday ? String(q.birthday).slice(0, 10) : '',
      hometown: q?.hometown || '',
      education: q?.education || '',
      phone: q?.phone || '',
      bio: q?.bio || '',
      interests: (q?.interests || []).join(', '),
      gender: q?.gender || '',
      heightCm: q?.heightCm != null ? String(q.heightCm) : '',
      weightKg: q?.weightKg != null ? String(q.weightKg) : '',
      relationship: q?.relationship || '',
      drinking: q?.drinking || '',
      smoking: q?.smoking || '',
      pets: q?.pets || '',
    })
    const fv = (me.settings?.fieldVis || {}) as Partial<Record<Exclude<InfoVisKey, 'birthday'>, VisValue>>
    setInfoVis({
      birthday: normVis(me.settings?.birthdayVisibility),
      gender: normVis(fv.gender),
      hometown: normVis(fv.hometown),
      education: normVis(fv.education),
      phone: normVis(fv.phone),
      bio: normVis(fv.bio),
      height: normVis(fv.height),
      weight: normVis(fv.weight),
      relationship: normVis(fv.relationship),
      lifestyle: normVis(fv.lifestyle),
      interests: normVis(fv.interests),
      job: normVis(fv.job),
      ethnicity: normVis(fv.ethnicity),
      citizenId: normVis(fv.citizenId),
      taxCode: normVis(fv.taxCode),
    })
    setInfoOpen(true)
  }

  const saveInfo = async () => {
    setSavingInfo(true)
    try {
      const res = await fetch('/api/vx/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          birthday: infoForm.birthday || '', hometown: infoForm.hometown.trim(), education: infoForm.education.trim(), phone: infoForm.phone.trim(), bio: infoForm.bio.trim(),
          interests: infoForm.interests.split(',').map((s) => s.trim()).filter(Boolean),
          gender: infoForm.gender.trim() || null,
          heightCm: infoForm.heightCm === '' ? null : infoForm.heightCm,
          weightKg: infoForm.weightKg === '' ? null : infoForm.weightKg,
          relationship: infoForm.relationship.trim(), drinking: infoForm.drinking.trim(), smoking: infoForm.smoking.trim(), pets: infoForm.pets.trim(),
          // Quyền xem từng mục kiểu FB: năm sinh dùng birthdayVisibility, còn lại lưu trong settings.fieldVis
          settings: {
            birthdayVisibility: infoVis.birthday,
            fieldVis: { gender: infoVis.gender, hometown: infoVis.hometown, education: infoVis.education, phone: infoVis.phone, bio: infoVis.bio, height: infoVis.height, weight: infoVis.weight, relationship: infoVis.relationship, lifestyle: infoVis.lifestyle, interests: infoVis.interests },
          },
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không lưu được thông tin')
      toast.success('Đã cập nhật thông tin hồ sơ & quyền xem từng mục')
      setInfoOpen(false)
      onRefreshUser()
      load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không lưu được thông tin')
    } finally { setSavingInfo(false) }
  }

  // ---- Quyền xem từng mục ngay tại dòng (kiểu FB): bấm nhãn cycle Công khai → Bạn bè → Chỉ mình tôi, lưu tức thì ----
  const fvMe = (me.settings?.fieldVis || {}) as Record<string, string>
  const rowVis = (key: string): VisValue => (key === 'birthday' ? normVis(me.settings?.birthdayVisibility) : normVis(fvMe[key]))
  const cycleRowVis = async (key: string, label: string) => {
    const next = VIS_ORDER[(VIS_ORDER.indexOf(rowVis(key)) + 1) % VIS_ORDER.length]
    try {
      const res = await fetch('/api/vx/profile', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: key === 'birthday' ? { birthdayVisibility: next } : { fieldVis: { [key]: next } } }),
      })
      if (!res.ok) throw new Error()
      toast.success(`${label}: ${VIS_META[next].label}`)
      onRefreshUser()
      load()
    } catch {
      toast.error('Không lưu được quyền riêng tư')
    }
  }

  // ---- Dialog SỬA RIÊNG 1 MỤC: bấm bút chì cạnh dòng nào chỉ sửa đúng dòng đó (không mở cả trang) ----
  const [editKey, setEditKey] = useState<EditKey | null>(null)
  const [editVal, setEditVal] = useState('')
  const [editVis, setEditVis] = useState<VisValue>('public')
  const [editLocVisible, setEditLocVisible] = useState(true)
  const [savingField, setSavingField] = useState(false)
  const openEdit = (key: EditKey) => {
    const q = data?.profile
    const vals: Record<EditKey, string> = {
      birthday: q?.birthday ? String(q.birthday).slice(0, 10) : '',
      hometown: q?.hometown || '', education: q?.education || '', phone: q?.phone || '', bio: q?.bio || '',
      gender: q?.gender || '', interests: (q?.interests || []).join(', '),
      height: q?.heightCm != null ? String(q.heightCm) : '', weight: q?.weightKg != null ? String(q.weightKg) : '',
      relationship: q?.relationship || '', smoking: q?.smoking || '', drinking: q?.drinking || '', pets: q?.pets || '',
      ethnicity: q?.ethnicity || '', citizenId: q?.citizenId || '', taxCode: q?.taxCode || '', location: q?.locationName || '',
      job: q?.title || me.title || '',
    }
    setEditVal(vals[key])
    setEditLocVisible(data?.profile?.locationVisible !== false)
    const vk = EDIT_META[key].visKey
    setEditVis(vk ? rowVis(vk) : 'public')
    setEditKey(key)
  }
  const saveEdit = async () => {
    if (!editKey) return
    setSavingField(true)
    try {
      const body: Record<string, unknown> = {}
      const vk = EDIT_META[editKey].visKey
      if (editKey === 'location') {
        body.locationName = editVal.trim().slice(0, 120)
        body.locationVisible = editLocVisible
      } else if (editKey === 'job') {
        body.title = editVal.trim() || null
        body.settings = { fieldVis: { job: editVis } }
      } else if (editKey === 'birthday') {
        body.birthday = editVal
        body.settings = { birthdayVisibility: editVis }
      } else if (editKey === 'height' || editKey === 'weight') {
        body[editKey === 'height' ? 'heightCm' : 'weightKg'] = editVal === '' ? null : editVal
        body.settings = { fieldVis: { [vk as string]: editVis } }
      } else if (editKey === 'interests') {
        body.interests = editVal.split(',').map((s) => s.trim()).filter(Boolean)
        body.settings = { fieldVis: { interests: editVis } }
      } else if (['gender', 'ethnicity', 'relationship', 'smoking', 'drinking', 'pets'].includes(editKey)) {
        body[editKey] = editVal.trim() || null
        body.settings = { fieldVis: { [vk as string]: editVis } }
      } else {
        body[editKey] = editVal.trim()
        body.settings = { fieldVis: { [vk as string]: editVis } }
      }
      const res = await fetch('/api/vx/profile', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không lưu được')
      toast.success(`Đã cập nhật ${EDIT_META[editKey].label.toLowerCase()}`)
      setEditKey(null)
      onRefreshUser()
      load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không lưu được')
    } finally { setSavingField(false) }
  }

  // ---- Album ảnh kiểu Facebook ----
  const [albums, setAlbums] = useState<AlbumMeta[]>([])
  const [createAlbumOpen, setCreateAlbumOpen] = useState(false)
  const [albName, setAlbName] = useState('')
  const [albPhotos, setAlbPhotos] = useState<string[]>([])
  const [creatingAlbum, setCreatingAlbum] = useState(false)
  const [openAlbum, setOpenAlbum] = useState<AlbumMeta | null>(null)

  // ---- Bài viết trên hồ sơ — DÙNG CHUNG PostCard của Bảng tin để hiển thị đồng bộ 100% ----
  const [profilePosts, setProfilePosts] = useState<PostT[]>([])
  const loadProfilePosts = useCallback(() => {
    fetch(`/api/vx/posts?author=${me.id}`)
      .then((r) => r.json())
      .then((d) => Array.isArray(d) && setProfilePosts(d))
      .catch(() => {})
  }, [me.id])

  // ---- Trang thú cưng (fanpage riêng cho pet — bấm thẻ mở trang đầy đủ ở mục Trang) ----
  const [petPages, setPetPages] = useState<PetPageLite[]>([])
  const [petCreateOpen, setPetCreateOpen] = useState(false)
  const [petForm, setPetForm] = useState({ name: '', species: '', breed: '', gender: '', birthday: '', bio: '' })
  const [creatingPet, setCreatingPet] = useState(false)
  const loadPetPages = useCallback(() => {
    fetch('/api/vx/pages')
      .then((r) => r.json())
      .then((d) => { if (Array.isArray(d.mine)) setPetPages(d.mine.filter((p: PetPageLite) => p.category === 'Thú cưng')) })
      .catch(() => {})
  }, [])
  const createPetPage = async () => {
    if (!petForm.name.trim()) { toast.error('Nhập tên thú cưng'); return }
    setCreatingPet(true)
    try {
      const res = await fetch('/api/vx/pages', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: petForm.name.trim(), category: 'Thú cưng', bio: petForm.bio.trim() || null,
          petSpecies: petForm.species || null, petBreed: petForm.breed.trim() || null,
          petGender: petForm.gender || null, petBirthday: petForm.birthday || null,
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không tạo được trang thú cưng')
      toast.success(`Đã tạo trang thú cưng cho "${petForm.name.trim()}"`, { description: 'Trang hoạt động như fanpage riêng: đăng bài với tư cách pet, người khác theo dõi và thả tim' })
      setPetCreateOpen(false)
      setPetForm({ name: '', species: '', breed: '', gender: '', birthday: '', bio: '' })
      loadPetPages()
      if (onGoPages && d.id) onGoPages(d.id)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không tạo được trang thú cưng')
    } finally { setCreatingPet(false) }
  }

  const load = useCallback(() => {
    fetch(`/api/vx/users/${me.id}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.profile) {
          setData(d)
          setInterests((d.profile.interests || []).join(', '))
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [me.id])

  const loadAlbums = useCallback(() => {
    fetch('/api/vx/albums?full=1')
      .then((r) => r.json())
      .then((d) => Array.isArray(d) && setAlbums(d))
      .catch(() => {})
  }, [])

  useDeferredLoad(() => { load(); loadAlbums(); loadProfilePosts(); loadPetPages() }, [load, loadAlbums, loadProfilePosts, loadPetPages])

  const save = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setSaving(true)
    const fd = new FormData(e.currentTarget)
    const res = await fetch('/api/vx/profile', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fullName: fd.get('fullName'), username: fd.get('username'), bio: fd.get('bio'), title: fd.get('title'),
        interests: interests.split(',').map((s) => s.trim()).filter(Boolean),
        locationVisible: locVisible, locationName: fd.get('locationName'),
      }),
    })
    setSaving(false)
    if (res.ok) {
      toast.success('Đã cập nhật hồ sơ!')
      setEditing(false)
      onRefreshUser()
      load()
    } else {
      const d = await res.json().catch(() => ({}))
      toast.error(d.error || 'Không lưu được hồ sơ')
    }
  }

  // Tải ảnh bìa / ảnh đại diện (nén rồi PATCH)
  const uploadPhoto = async (file: File | undefined, kind: 'avatar' | 'cover') => {
    if (!file) return
    if (file.size > 6_000_000) { toast.error('Ảnh quá lớn (tối đa ~6MB trước khi nén)'); return }
    try {
      const dataUrl = await compressImage(file, kind === 'avatar' ? 512 : 1280)
      const res = await fetch('/api/vx/profile', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(kind === 'avatar' ? { avatarImage: dataUrl } : { coverImage: dataUrl }) })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success(kind === 'avatar' ? 'Đã đổi ảnh đại diện' : 'Đã đổi ảnh bìa')
      onRefreshUser()
      load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không tải được ảnh')
    }
  }

  const p = data?.profile
  const photos = data?.photos || []
  const friends = data?.friends || []
  const isMe = Boolean(data?.isMe)

  // ---- Xem hồ sơ bạn bè từ lưới Bạn bè (kiểu FB: bấm thẻ là mở trang cá nhân) ----
  const [viewUserId, setViewUserId] = useState<string | null>(null)

  const unfriend = async (f: { id: string; fullName: string; friendshipId?: string | null }) => {
    if (!f.friendshipId) { toast.error('Không tìm thấy quan hệ bạn bè'); return }
    if (!window.confirm(`Hủy kết bạn với ${f.fullName}?`)) return
    try {
      const res = await fetch('/api/vx/friends', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove', friendshipId: f.friendshipId }),
      })
      if (!res.ok) throw new Error()
      toast.success(`Đã hủy kết bạn với ${f.fullName}`)
      load()
    } catch {
      toast.error('Không hủy được kết bạn, thử lại nhé')
    }
  }

  // ---- Composer FB: ảnh/video/file + check-in + nhắc đồng nghiệp + chế độ hiển thị ----
  const readAsDataURL = (f: File) => new Promise<string>((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result))
    r.onerror = reject
    r.readAsDataURL(f)
  })

  const pickPostMedia = async (files: FileList | null) => {
    if (!files?.length) return
    for (const f of Array.from(files).slice(0, 6)) {
      if (f.size > 6_000_000) { toast.error(`${f.name} quá lớn (tối đa ~6MB trước khi nén)`); continue }
      try {
        if (f.type.startsWith('video/')) setPostVideo(await readAsDataURL(f))
        else {
          const url = await compressImage(f, 1280)
          setPostImgs((prev) => [...prev, url].slice(0, 6))
        }
      } catch { /* bỏ qua tệp lỗi */ }
    }
    setComposerOpen(true)
  }

  const pickPostFile = async (f: File | undefined) => {
    if (!f) return
    if (f.size > 1_500_000) { setPostFile({ url: null, name: f.name }); toast.error('File >1.5MB: chỉ đính kèm tên (bản demo)'); return }
    try { setPostFile({ url: await readAsDataURL(f), name: f.name }) } catch { /* bỏ qua */ }
  }

  useEffect(() => {
    if (mentionOpen && users.length === 0) {
      fetch('/api/vx/users').then((r) => r.json()).then((d) => Array.isArray(d) && setUsers(d)).catch(() => {})
    }
  }, [mentionOpen, users.length])

  const resetPost = () => {
    setPostText(''); setPostBg(null); setPostImgs([]); setPostVideo(null); setPostFile(null)
    setPostLoc(''); setShowLoc(false); setPostMentions([]); setAnnounce(false); setVisibility('public'); setVisOpen(false)
  }

  const submitPost = async () => {
    const hasMedia = postImgs.length > 0 || postVideo || postFile
    if (!postText.trim() && !hasMedia && !postBg) return
    setPosting(true)
    try {
      const res = await fetch('/api/vx/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: postText.trim(),
          background: postBg,
          images: postImgs,
          videoUrl: postVideo,
          fileUrl: postFile?.url || null,
          fileName: postFile?.name || null,
          location: postLoc.trim() || null,
          mentions: postMentions,
          isAnnouncement: announce,
          visibility,
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không đăng được bài')
      toast.success('Đã đăng bài lên Bảng tin', { description: d.reward > 0 ? `+${fmtUsdFromXu(d.reward, rate)} vào ví (thưởng đăng bài, tối đa 8 lần/ngày)` : 'Bài viết đã xuất hiện trên Bảng tin' })
      setComposerOpen(false)
      resetPost()
      onRefreshUser()
      load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không đăng được bài')
    } finally {
      setPosting(false)
    }
  }

  // ---- Album: tạo / xoá ----
  const pickAlbumPhotos = async (files: FileList | null) => {
    if (!files?.length) return
    const list = Array.from(files).slice(0, 30)
    const urls: string[] = []
    for (const f of list) {
      if (f.size > 6_000_000) { toast.error('Ảnh quá lớn (tối đa ~6MB trước khi nén)'); continue }
      try { urls.push(await compressImage(f, 1280)) } catch { /* bỏ qua */ }
    }
    setAlbPhotos((prev) => [...prev, ...urls].slice(0, 30))
  }

  const createAlbum = async () => {
    if (!albName.trim() || albPhotos.length === 0) { toast.error('Nhập tên album và thêm ít nhất 1 ảnh'); return }
    setCreatingAlbum(true)
    try {
      const res = await fetch('/api/vx/albums', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: albName.trim(), photos: albPhotos }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không tạo được album')
      toast.success('Đã tạo album', { description: albName.trim() })
      setCreateAlbumOpen(false)
      setAlbName('')
      setAlbPhotos([])
      loadAlbums()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không tạo được album')
    } finally {
      setCreatingAlbum(false)
    }
  }

  const deleteAlbum = async (a: AlbumMeta) => {
    try {
      const res = await fetch(`/api/vx/albums/${a.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Không xoá được album')
      toast.success(`Đã xoá album "${a.name}"`)
      setOpenAlbum(null)
      loadAlbums()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không xoá được album')
    }
  }

  return (
    <div className="space-y-5">
      {/* ---- Bìa kiểu Facebook ---- */}
      <div className="overflow-hidden rounded-2xl border bg-white shadow-sm">
        <div className="group relative h-36 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 sm:h-44">
          {p?.coverImage && (
            <img src={p.coverImage} alt="Ảnh bìa" className="h-full w-full object-cover" />
          )}
          <button onClick={() => coverInputRef.current?.click()}
            className="absolute bottom-2.5 right-2.5 flex items-center gap-1.5 rounded-full bg-black/45 px-3 py-1.5 text-xs font-medium text-white opacity-0 backdrop-blur transition-opacity group-hover:opacity-100"
            aria-label="Đổi ảnh bìa">
            <Camera className="h-3.5 w-3.5" /> Sửa ảnh bìa
          </button>
          <input ref={coverInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => uploadPhoto(e.target.files?.[0], 'cover')} />
        </div>

        <div className="px-5 pb-5">
          <div className="-mt-12 flex flex-wrap items-end justify-between gap-3">
            <div className="relative">
              <Avatar name={me.fullName} color={me.avatarColor} size={96} ring img={me.avatarImage} />
              <button onClick={() => avatarInputRef.current?.click()} title="Đổi ảnh đại diện"
                className="absolute -bottom-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full bg-emerald-600 text-white shadow hover:bg-emerald-700" aria-label="Đổi ảnh đại diện">
                <Camera className="h-4 w-4" />
              </button>
              <input ref={avatarInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => uploadPhoto(e.target.files?.[0], 'avatar')} />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setEditing(true)}><Pencil className="mr-1 h-4 w-4" />Chỉnh sửa</Button>
            </div>
          </div>

          <div className="mt-3">
            <h1 className="flex flex-wrap items-center gap-2 text-2xl font-black">
              {me.fullName}
              {me.accountType === 'business' && <Badge className="bg-amber-600 text-white hover:bg-amber-600"><Building2 className="mr-1 inline h-3.5 w-3.5" />Doanh nghiệp</Badge>}
            </h1>
            <p className="text-sm text-stone-500">@{me.username}, {p?.title || me.title}, {p?.companyName || me.companyName || p?.department || me.department}</p>
            {p?.bio && <p className="mt-2 text-sm text-stone-600">{p.bio}</p>}
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-5">
            <div className="rounded-lg bg-stone-50 p-3 text-center"><p className="text-lg font-black">{p?.counts.posts ?? '-'}</p><p className="text-xs text-stone-500">Bài viết</p></div>
            <div className="rounded-lg bg-stone-50 p-3 text-center"><p className="text-lg font-black">{p?.counts.videos ?? '-'}</p><p className="text-xs text-stone-500">Video</p></div>
            <div className="rounded-lg bg-stone-50 p-3 text-center"><p className="text-lg font-black">{p?.counts.followers ?? '-'}</p><p className="text-xs text-stone-500">Người theo dõi</p></div>
            <div className="rounded-lg bg-stone-50 p-3 text-center"><p className="text-lg font-black">{p?.counts.attendanceDays ?? '-'}</p><p className="text-xs text-stone-500">Ngày công</p></div>
            <div className="rounded-lg bg-amber-50 p-3 text-center"><p className="flex items-center justify-center gap-1 text-lg font-black text-amber-700"><Coins className="h-4 w-4" />{fmtUsdFromXu(me.coins ?? 0, rate)}</p><p className="text-xs text-amber-700">Ví tiền</p></div>
          </div>

          {/* Tài khoản doanh nghiệp: trạng thái + nộp đơn nâng cấp (dùng chung với Trang Fanpage) */}
          <BusinessUpgradeCard me={me} onRefreshUser={onRefreshUser} onGoPages={onOpenPages} />

          {/* Tabs kiểu Facebook: Bài viết, Ảnh, Bạn bè, Giới thiệu */}
          <div className="mt-4 flex gap-1 overflow-x-auto border-t pt-2">
            {([
              ['posts', 'Bài viết', <Newspaper key="p" className="h-4 w-4" />],
              ['photos', `Ảnh (${photos.length})`, <Images key="i" className="h-4 w-4" />],
              ['friends', `Bạn bè (${friends.length})`, <UsersIcon key="f" className="h-4 w-4" />],
              ['about', 'Giới thiệu', <Info key="a" className="h-4 w-4" />],
            ] as const).map(([k, label, icon]) => (
              <button key={k} onClick={() => setTab(k)}
                className={`flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${tab === k ? 'bg-emerald-600 text-white shadow' : 'text-stone-600 hover:bg-emerald-50 hover:text-emerald-800'}`}
                aria-current={tab === k ? 'page' : undefined}>
                {icon} {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ---- Nội dung tab ---- */}
      {loading ? (
        <div className="space-y-3">
          <Skeleton className="h-32 rounded-xl" />
          <Skeleton className="h-64 rounded-xl" />
        </div>
      ) : tab === 'posts' ? (
        /* TAB BÀI VIẾT — kiểu Facebook: cột trái (Giới thiệu gọn + Ảnh + Bạn bè) + cột phải (soạn bài + bài viết) */
        <div className="grid gap-4 lg:grid-cols-[290px_1fr]">
          <aside className="h-fit space-y-3">
            {/* Giới thiệu gọn — đúng kiểu FB: vài dòng icon, không dài dòng */}
            <div className="rounded-xl border bg-white p-4 shadow-sm">
              <p className="flex items-center gap-1.5 text-sm font-bold"><Info className="h-4 w-4 text-emerald-600" /> Giới thiệu</p>
              <div className="mt-2 space-y-1.5 text-[13px] text-stone-600">
                {p?.bio && <p className="whitespace-pre-wrap border-b pb-1.5 italic">{p.bio}</p>}
                <p className="flex items-center gap-1.5"><Building2 className="h-4 w-4 shrink-0 text-emerald-600" /> Làm việc tại <b>{p?.companyName || me.companyName || 'Vexon'}</b></p>
                <p className="flex items-center gap-1.5"><Briefcase className="h-4 w-4 shrink-0 text-amber-600" /> {p?.title || me.title}, {p?.department || me.department}</p>
                <p className="flex items-center gap-1.5"><MapPin className="h-4 w-4 shrink-0 text-rose-500" /> Sống tại <b>{p?.locationName || 'Chưa cập nhật'}</b></p>
                <p className="flex items-center gap-1.5"><HomeIcon className="h-4 w-4 shrink-0 text-emerald-600" /> Quê quán: <b>{p?.hometown || 'Chưa cập nhật'}</b></p>
                <p className="flex items-center gap-1.5"><CalendarDays className="h-4 w-4 shrink-0 text-sky-600" /> Tham gia {p ? new Date(p.joinedAt).toLocaleDateString('vi-VN') : '...'}</p>
              </div>
              <Button size="sm" variant="outline" className="mt-2.5 w-full" onClick={() => openInfoDialog(p)} aria-label="Chỉnh sửa giới thiệu">
                <Pencil className="mr-1 h-3.5 w-3.5" /> Chỉnh sửa giới thiệu
              </Button>
            </div>
            {/* Ảnh gọn */}
            <div className="rounded-xl border bg-white p-4 shadow-sm">
              <p className="flex items-center justify-between text-sm font-bold"><span className="flex items-center gap-1.5"><Images className="h-4 w-4 text-emerald-600" /> Ảnh</span><button className="text-xs font-medium text-emerald-700 hover:underline" onClick={() => setTab('photos')}>Xem tất cả</button></p>
              {photos.length ? (
                <div className="mt-2 grid grid-cols-3 gap-1">
                  {photos.slice(0, 9).map((src, i) => <img key={i} src={src} alt={`Ảnh ${i + 1}`} className="aspect-square w-full rounded-md object-cover" />)}
                </div>
              ) : <p className="mt-2 text-xs text-muted-foreground">Chưa có ảnh nào</p>}
            </div>
            {/* Bạn bè gọn */}
            <div className="rounded-xl border bg-white p-4 shadow-sm">
              <p className="flex items-center justify-between text-sm font-bold"><span className="flex items-center gap-1.5"><UsersIcon className="h-4 w-4 text-emerald-600" /> Bạn bè <span className="text-xs font-normal text-stone-400">({friends.length})</span></span><button className="text-xs font-medium text-emerald-700 hover:underline" onClick={() => setTab('friends')}>Xem tất cả</button></p>
              {friends.length ? (
                <div className="mt-2 grid grid-cols-3 gap-1.5">
                  {friends.slice(0, 9).map((f) => (
                    <button key={f.id} className="min-w-0 text-center" onClick={() => setViewUserId(f.id)} aria-label={`Xem trang cá nhân của ${f.fullName}`}>
                      <Avatar name={f.fullName} color={f.avatarColor} size={44} img={f.avatarImage} />
                      <p className="mt-0.5 truncate text-[10px] text-stone-600 hover:underline">{f.fullName.split(' ').slice(-1)[0]}</p>
                    </button>
                  ))}
                </div>
              ) : <p className="mt-2 text-xs text-muted-foreground">Chưa có bạn bè</p>}
            </div>
          </aside>

          <div className="space-y-4">
            {/* Composer đăng bài kiểu Facebook */}
            <div className="rounded-2xl border bg-white p-3 shadow-sm">
              <div className="flex items-center gap-3">
                <Avatar name={me.fullName} color={me.avatarColor} size={40} img={me.avatarImage} />
                <button
                  onClick={() => setComposerOpen(true)}
                  className="flex-1 rounded-full bg-stone-100 px-4 py-2.5 text-left text-sm text-stone-500 transition-colors hover:bg-stone-200"
                  aria-label="Mở khung soạn bài viết"
                >
                  {me.fullName} ơi, bạn đang nghĩ gì?
                </button>
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-2 border-t pt-2">
                <label className="flex cursor-pointer items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium text-stone-600 transition-colors hover:bg-emerald-50 hover:text-emerald-800">
                  <ImagePlus className="h-4 w-4 text-emerald-600" /> Ảnh
                  <input ref={composerImgRef} type="file" accept="image/*,video/*" multiple className="hidden" onChange={(e) => { pickPostMedia(e.target.files); e.target.value = '' }} />
                </label>
                <button
                  onClick={() => setComposerOpen(true)}
                  className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium text-stone-600 transition-colors hover:bg-emerald-50 hover:text-emerald-800"
                >
                  <PenLine className="h-4 w-4 text-sky-600" /> Viết bài
                </button>
                <span className="ml-auto hidden items-center gap-1 text-xs text-stone-400 sm:flex">Đăng bài có thưởng <Coins className="h-3.5 w-3.5 text-amber-500" /></span>
              </div>
            </div>

            {/* Bài viết của tôi — ĐỒNG BỘ 100% với Bảng tin: PostCard chung (cảm xúc, bình luận, chia sẻ, menu ⋯) */}
            {profilePosts.map((post) => (
              <PostCard
                key={post.id}
                me={me}
                post={post}
                onOpenProfile={(uid) => setViewUserId(uid)}
                onReacted={(id, d) => setProfilePosts((ps) => ps.map((pp) => (pp.id !== id ? pp : { ...pp, myReaction: d.myReaction, reactions: d.reactions })))}
                onEdited={(id, content, location) => setProfilePosts((ps) => ps.map((pp) => (pp.id !== id ? pp : { ...pp, content, location, editedAt: new Date().toISOString() })))}
                onDeleted={(id) => setProfilePosts((ps) => ps.filter((pp) => pp.id !== id))}
                onRemoved={(id) => setProfilePosts((ps) => ps.filter((pp) => pp.id !== id))}
                onReposted={() => loadProfilePosts()}
                onCommented={(postId, c) => setProfilePosts((ps) => ps.map((pp) => {
                  if (pp.id !== postId) return pp
                  const comments = c.parentId
                    ? pp.comments.map((root) => (root.id === c.parentId ? { ...root, replies: [...root.replies, c] } : root))
                    : [...pp.comments, c]
                  return { ...pp, comments, commentCount: pp.commentCount + 1 }
                }))}
                onCommentEdited={(postId, cid, content, at) => setProfilePosts((ps) => ps.map((pp) => (pp.id !== postId ? pp : {
                  ...pp,
                  comments: pp.comments.map((root) => (root.id === cid ? { ...root, content, editedAt: at } : { ...root, replies: root.replies.map((r) => (r.id === cid ? { ...r, content, editedAt: at } : r)) })),
                })))}
                onCommentDeleted={(postId, cid) => setProfilePosts((ps) => ps.map((pp) => {
                  if (pp.id !== postId) return pp
                  const strip = (cs: CommentT[]): CommentT[] => cs.filter((c) => c.id !== cid).map((c) => ({ ...c, replies: strip(c.replies) }))
                  const find = (cs: CommentT[]): CommentT | null => {
                    for (const c of cs) { if (c.id === cid) return c; const r = find(c.replies); if (r) return r }
                    return null
                  }
                  const target = find(pp.comments)
                  const removed = target ? 1 + target.replies.length : 1
                  return { ...pp, comments: strip(pp.comments), commentCount: Math.max(0, pp.commentCount - removed) }
                }))}
              />
            ))}
            {!loading && profilePosts.length === 0 && (
              <p className="rounded-xl border border-dashed bg-white p-10 text-center text-sm text-muted-foreground">Chưa có bài viết nào, viết bài đầu tiên của bạn!</p>
            )}
          </div>
        </div>
      ) : tab === 'photos' ? (
        /* TAB ẢNH — ảnh từ bài viết + album ảnh */
        <div className="space-y-3">
          {photos.length ? (
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
              {photos.map((src, i) => (
                <img key={i} src={src} alt={`Ảnh ${i + 1}`} className="aspect-square w-full rounded-lg border object-cover transition-transform hover:scale-[1.03]" />
              ))}
            </div>
          ) : (
            <p className="rounded-xl border border-dashed bg-white p-10 text-center text-sm text-muted-foreground">Chưa có ảnh nào, đăng bài kèm ảnh trong Bảng tin để tạo bộ sưu tập.</p>
          )}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            <button
              onClick={() => setCreateAlbumOpen(true)}
              className="flex aspect-square flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed bg-white text-stone-500 transition-colors hover:border-emerald-400 hover:text-emerald-700"
              aria-label="Tạo album mới"
            >
              <Plus className="h-7 w-7" />
              <span className="text-sm font-semibold">Tạo album</span>
            </button>
            {albums.map((a) => (
              <button
                key={a.id}
                onClick={() => setOpenAlbum(a)}
                className="group overflow-hidden rounded-2xl border bg-white text-left shadow-sm transition hover:shadow-md"
              >
                <div className="aspect-square bg-stone-100">
                  {a.cover ? (
                    <img src={a.cover} alt={a.name} className="h-full w-full object-cover transition-transform group-hover:scale-[1.03]" />
                  ) : (
                    <div className="flex h-full items-center justify-center"><Images className="h-8 w-8 text-stone-300" /></div>
                  )}
                </div>
                <div className="p-2.5">
                  <p className="truncate text-sm font-semibold">{a.name}</p>
                  <p className="text-xs text-stone-500">{a.count} ảnh</p>
                </div>
              </button>
            ))}
          </div>
          {albums.length === 0 && (
            <p className="rounded-xl border border-dashed bg-white p-6 text-center text-sm text-muted-foreground">
              Chưa có album nào, bấm <b>“Tạo album”</b> để gom những tấm ảnh ý nghĩa vào một bộ sưu tập nhé!
            </p>
          )}
        </div>
      ) : tab === 'friends' ? (
        /* TAB BẠN BẸ — kiểu Facebook: bấm thẻ mở trang cá nhân + Nhắn tin/Hủy kết bạn hoạt động thật */
        <div className="space-y-3">
          <div className="rounded-xl border bg-white p-4 shadow-sm">
            <div className="flex items-center justify-between gap-2">
              <p className="flex items-center gap-1.5 text-sm font-bold"><UsersIcon className="h-4 w-4 text-emerald-600" /> Bạn bè <span className="text-xs font-normal text-stone-400">· {friends.length} người</span></p>
              <Button size="sm" variant="outline" className="h-8" onClick={() => setTab('about')} aria-label="Xem thông tin hồ sơ ở tab Giới thiệu">
                <Info className="mr-1 h-3.5 w-3.5" /> Thông tin liên hệ
              </Button>
            </div>
            {friends.length ? (
              <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
                {friends.map((f) => (
                  <div key={f.id} className="flex flex-col items-center rounded-xl border bg-white p-3 text-center shadow-sm transition-colors hover:bg-emerald-50/50">
                    <button className="flex w-full flex-col items-center" onClick={() => setViewUserId(f.id)} aria-label={`Xem trang cá nhân của ${f.fullName}`}>
                      <Avatar name={f.fullName} color={f.avatarColor} size={64} img={f.avatarImage} />
                      <p className="mt-1.5 w-full truncate text-[13px] font-semibold text-stone-800 hover:underline" title={f.fullName}>{f.fullName}</p>
                    </button>
                    <div className="mt-2 flex w-full items-center justify-center gap-1.5">
                      <Button size="sm" variant="outline" className="h-7 gap-1 px-2 text-[11px]" onClick={() => onMessage(f.id)} aria-label={`Nhắn tin cho ${f.fullName}`}>
                        <MessageCircle className="h-3.5 w-3.5" /> Nhắn tin
                      </Button>
                      <Button size="sm" variant="outline" className="h-7 w-7 px-0 text-rose-600 hover:bg-rose-50" onClick={() => unfriend(f)} aria-label={`Hủy kết bạn với ${f.fullName}`} title="Hủy kết bạn">
                        <UserMinus className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-2 text-xs text-muted-foreground">Chưa có bạn bè, xem “Gợi ý kết bạn” ở Bảng tin nhé!</p>
            )}
          </div>
        </div>
      ) : (
        /* TAB GIỚI THIỆU — gọn gàng: 1 thẻ duy nhất, vài dòng icon ngắn (FB style) */
        <div className="mx-auto max-w-2xl space-y-3">
          <div className="rounded-xl border bg-white p-4 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="flex items-center gap-1.5 text-sm font-bold"><Info className="h-4 w-4 text-emerald-600" /> Giới thiệu</p>
              <div className="flex items-center gap-2">
                {isMe && <p className="flex items-center gap-1 text-[11px] text-stone-400"><Pencil className="h-3 w-3" /> bấm để sửa riêng từng dòng</p>}
                <Button size="sm" variant="outline" className="h-8" onClick={() => openInfoDialog(p)} aria-label="Chỉnh sửa giới thiệu">
                  <Pencil className="mr-1 h-3.5 w-3.5" /> Chỉnh sửa
                </Button>
              </div>
            </div>
            <div className="mt-3 space-y-2 text-sm text-stone-600">
              {/* Mỗi dòng có: nhãn quyền riêng tư bấm được (Công khai/Bạn bè/Chỉ mình tôi) + nút bút chì sửa — kiểu Facebook */}
              <div className="flex items-start gap-2 border-b pb-2"><p className="min-w-0 flex-1 whitespace-pre-wrap italic">{p?.bio || 'Chưa có dòng giới thiệu'}</p><RowActions isMe={isMe} vis={rowVis('bio')} name="Bio" onCycle={() => cycleRowVis('bio', 'Bio')} onEdit={() => openEdit('bio')} /></div>
              <p className="flex items-center gap-2"><UserRound className="h-4 w-4 shrink-0 text-sky-600" /> Giới tính: <b>{p?.gender || 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('gender')} name="Giới tính" onCycle={() => cycleRowVis('gender', 'Giới tính')} onEdit={() => openEdit('gender')} /></p>
              <p className="flex items-center gap-2"><CalendarDays className="h-4 w-4 shrink-0 text-sky-600" /> Ngày sinh: <b>{p?.birthday ? new Date(p.birthday).toLocaleDateString('vi-VN') : 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('birthday')} name="Ngày sinh" onCycle={() => cycleRowVis('birthday', 'Ngày sinh')} onEdit={() => openEdit('birthday')} /></p>
              <p className="flex items-center gap-2"><HomeIcon className="h-4 w-4 shrink-0 text-emerald-600" /> Quê quán: <b>{p?.hometown || 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('hometown')} name="Quê quán" onCycle={() => cycleRowVis('hometown', 'Quê quán')} onEdit={() => openEdit('hometown')} /></p>
              <p className="flex items-center gap-2"><MapPin className="h-4 w-4 shrink-0 text-rose-500" /> Sống tại: <b>{p?.locationName || 'Chưa cập nhật'}</b><RowActions isMe={isMe} name="Sống tại" onEdit={() => openEdit('location')} /></p>
              <p className="flex items-center gap-2"><GraduationCap className="h-4 w-4 shrink-0 text-sky-600" /> Học vấn: <b>{p?.education || 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('education')} name="Học vấn" onCycle={() => cycleRowVis('education', 'Học vấn')} onEdit={() => openEdit('education')} /></p>
              <p className="flex items-center gap-2"><Phone className="h-4 w-4 shrink-0 text-stone-500" /> Điện thoại: <b>{p?.phone || 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('phone')} name="Điện thoại" onCycle={() => cycleRowVis('phone', 'Điện thoại')} onEdit={() => openEdit('phone')} /></p>
              <p className="flex items-center gap-2"><Briefcase className="h-4 w-4 shrink-0 text-amber-600" /> Chức danh: <b>{p?.title || me.title}</b><RowActions isMe={isMe} vis={rowVis('job')} name="Chức danh" onCycle={() => cycleRowVis('job', 'Chức danh')} onEdit={() => openEdit('job')} /></p>
              <p className="flex items-center gap-2"><Target className="h-4 w-4 shrink-0 text-teal-600" /> Sở thích: <b>{p?.interests.length ? p.interests.join(', ') : 'chưa có'}</b><RowActions isMe={isMe} vis={rowVis('interests')} name="Sở thích" onCycle={() => cycleRowVis('interests', 'Sở thích')} onEdit={() => openEdit('interests')} /></p>
              {/* Các dòng chỉ hiển thị — do công ty quản lý */}
              <p className="flex items-center gap-2"><Mail className="h-4 w-4 shrink-0 text-sky-600" /> Email: <b>{p?.email || me.email}</b></p>
              <p className="flex items-center gap-2"><Building2 className="h-4 w-4 shrink-0 text-emerald-600" /> Làm việc tại <b>{p?.companyName || me.companyName || 'Vexon'}</b>, {p?.department || me.department}</p>
              {/* Hồ sơ chi tiết tích hợp từ Cài đặt: dân tộc / CCCD / mã số thuế — mỗi mục sửa riêng + quyền riêng tư riêng */}
              <p className="flex items-center gap-2"><Globe2 className="h-4 w-4 shrink-0 text-teal-600" /> Dân tộc: <b>{p?.ethnicity || 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('ethnicity')} name="Dân tộc" onCycle={() => cycleRowVis('ethnicity', 'Dân tộc')} onEdit={() => openEdit('ethnicity')} /></p>
              <p className="flex items-center gap-2"><IdCard className="h-4 w-4 shrink-0 text-rose-500" /> CCCD: <b>{p?.citizenId || 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('citizenId')} name="Căn cước công dân" onCycle={() => cycleRowVis('citizenId', 'Căn cước công dân')} onEdit={() => openEdit('citizenId')} /></p>
              <p className="flex items-center gap-2"><Landmark className="h-4 w-4 shrink-0 text-amber-600" /> Mã số thuế: <b>{p?.taxCode || 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('taxCode')} name="Mã số thuế" onCycle={() => cycleRowVis('taxCode', 'Mã số thuế')} onEdit={() => openEdit('taxCode')} /></p>
              {/* Hồ sơ hẹn hò + xã giao (khôi phục bản 09c): chiều cao/cân nặng/tình trạng/lối sống — mỗi mục sửa riêng */}
              <p className="flex items-center gap-2"><Ruler className="h-4 w-4 shrink-0 text-teal-600" /> Chiều cao: <b>{p?.heightCm != null ? `${p.heightCm} cm` : 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('height')} name="Chiều cao" onCycle={() => cycleRowVis('height', 'Chiều cao')} onEdit={() => openEdit('height')} /></p>
              <p className="flex items-center gap-2"><Weight className="h-4 w-4 shrink-0 text-teal-600" /> Cân nặng: <b>{p?.weightKg != null ? `${p.weightKg} kg` : 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('weight')} name="Cân nặng" onCycle={() => cycleRowVis('weight', 'Cân nặng')} onEdit={() => openEdit('weight')} /></p>
              <p className="flex items-center gap-2"><Heart className="h-4 w-4 shrink-0 text-rose-500" /> Tình trạng quan hệ: <b>{p?.relationship || 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('relationship')} name="Tình trạng quan hệ" onCycle={() => cycleRowVis('relationship', 'Tình trạng quan hệ')} onEdit={() => openEdit('relationship')} /></p>
              <p className="flex items-center gap-2"><Cigarette className="h-4 w-4 shrink-0 text-purple-600" /> Thuốc lá: <b>{p?.smoking || 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('lifestyle')} name="Thuốc lá" onCycle={() => cycleRowVis('lifestyle', 'Thuốc lá')} onEdit={() => openEdit('smoking')} /></p>
              <p className="flex items-center gap-2"><Wine className="h-4 w-4 shrink-0 text-purple-600" /> Rượu bia: <b>{p?.drinking || 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('lifestyle')} name="Rượu bia" onCycle={() => cycleRowVis('lifestyle', 'Rượu bia')} onEdit={() => openEdit('drinking')} /></p>
              <p className="flex items-center gap-2"><PawPrint className="h-4 w-4 shrink-0 text-amber-600" /> Thú cưng: <b>{p?.pets || 'Chưa cập nhật'}</b><RowActions isMe={isMe} vis={rowVis('lifestyle')} name="Thú cưng" onCycle={() => cycleRowVis('lifestyle', 'Thú cưng')} onEdit={() => openEdit('pets')} /></p>
              {p?.hiddenFields && p.hiddenFields.length > 0 && <p className="text-xs text-stone-400">Một số mục ({p.hiddenFields.map((k) => HIDDEN_LABELS[k] || k).join(', ')}) đang bị ẩn vì quyền riêng tư của chủ hồ sơ.</p>}
              <p className="flex items-center gap-2"><CalendarDays className="h-4 w-4 shrink-0 text-stone-400" /> Tham gia Vexon: <b>{p ? new Date(p.joinedAt).toLocaleDateString('vi-VN') : '...'}</b></p>
            </div>
            <p className="mt-2 text-[11px] text-muted-foreground">Email và nơi làm việc do công ty quản lý. Vị trí hiện tại cập nhật bằng định vị Radar.</p>
          </div>
          {p?.cv?.headline && (
            <div className="rounded-xl border bg-white p-4 shadow-sm">
              <p className="flex items-center gap-1.5 text-sm font-bold"><FileText className="h-4 w-4 text-sky-600" /> CV: {p.cv.headline}</p>
              {p.cv.skills.length > 0 && <div className="mt-2 flex flex-wrap gap-1">{p.cv.skills.map((s) => <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>)}</div>}
            </div>
          )}
          {/* TRANG THÚ CƯNG — fanpage riêng cho pet (mạng xã hội phụ trong công ty): bấm thẻ mở trang đầy đủ */}
          {isMe && (
            <div className="rounded-xl border border-amber-200 bg-white p-4 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="flex flex-wrap items-center gap-1.5 text-sm font-bold"><PawPrint className="h-4 w-4 text-amber-600" /> Trang thú cưng <span className="text-xs font-normal text-stone-400">· mạng xã hội riêng cho pet, kiểu fanpage</span></p>
                <Button size="sm" className="h-8 bg-amber-500 hover:bg-amber-600" onClick={() => setPetCreateOpen(true)} aria-label="Tạo trang thú cưng">
                  <Plus className="mr-1 h-3.5 w-3.5" /> Tạo trang thú cưng
                </Button>
              </div>
              {petPages.length ? (
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  {petPages.map((pg) => (
                    <button key={pg.id} onClick={() => onGoPages?.(pg.id)} className="flex items-center gap-3 rounded-xl border border-amber-200 bg-amber-50/50 p-3 text-left transition hover:border-amber-300 hover:bg-amber-50" aria-label={`Mở trang thú cưng ${pg.name}`}>
                      {pg.avatar
                        ? <img src={pg.avatar} alt={pg.name} className="h-12 w-12 shrink-0 rounded-xl border object-cover" />
                        : <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 text-white"><PawPrint className="h-6 w-6" /></span>}
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-bold text-stone-800">{pg.name}</span>
                        <span className="block truncate text-xs text-stone-500">{[pg.petSpecies, pg.petBreed].filter(Boolean).join(' · ') || 'Thú cưng'}{pg.petGender ? ` · ${pg.petGender}` : ''}</span>
                        <span className="block text-[11px] text-stone-400">{pg.postCount} bài · {pg.followerCount} người theo dõi</span>
                      </span>
                      <ChevronRight className="h-4 w-4 shrink-0 text-stone-400" />
                    </button>
                  ))}
                </div>
              ) : (
                <p className="mt-2 text-xs text-muted-foreground">Chưa có trang thú cưng nào — tạo trang cá nhân riêng kiểu fanpage cho boss nhà bạn: đăng bài với tư cách pet, người khác theo dõi và thả tim.</p>
              )}
            </div>
          )}
          <p className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
            <UsersIcon className="h-3.5 w-3.5" /> Danh sách bạn bè xem ở tab <button className="font-semibold text-emerald-700 hover:underline" onClick={() => setTab('friends')}>Bạn bè</button>
          </p>
        </div>
      )}

      {/* Dialog chỉnh sửa */}
      <Dialog open={editing} onOpenChange={setEditing}>
        <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
          <DialogHeader><DialogTitle>Chỉnh sửa hồ sơ</DialogTitle></DialogHeader>
          <form className="space-y-3" onSubmit={save}>
            <div className="space-y-1"><Label htmlFor="pf-name">Họ và tên</Label><Input id="pf-name" name="fullName" defaultValue={me.fullName} /></div>
            <div className="space-y-1">
              <Label htmlFor="pf-username">Tên người dùng (đổi được 1 lần duy nhất)</Label>
              <Input id="pf-username" name="username" defaultValue={me.username} disabled={(me.usernameChanges ?? 0) >= 1} />
              <p className="text-[11px] text-stone-500">
                {(me.usernameChanges ?? 0) >= 1
                  ? 'Bạn đã dùng lượt đổi tên người dùng duy nhất rồi.'
                  : 'Còn 1 lượt duy nhất — đổi xong sẽ không thể đổi lại. 3-20 ký tự (a-z, 0-9, _ .)'}
              </p>
            </div>
            <div className="space-y-1"><Label htmlFor="pf-title">Chức danh</Label><Input id="pf-title" name="title" defaultValue={p?.title || me.title || ''} /></div>
            <div className="space-y-1"><Label htmlFor="pf-bio">Giới thiệu bản thân</Label><Textarea id="pf-bio" name="bio" rows={3} defaultValue={p?.bio || me.bio || ''} /></div>
            <div className="space-y-1"><Label htmlFor="pf-interests">Sở thích (cách nhau bởi dấu phẩy)</Label><Input id="pf-interests" value={interests} onChange={(e) => setInterests(e.target.value)} placeholder="Golf, Cà phê, Đầu tư..." aria-label="Sở thích" /></div>
            <div className="space-y-1"><Label htmlFor="pf-loc">Tên vị trí (VD: Quận 1, TP.HCM)</Label><Input id="pf-loc" name="locationName" defaultValue={p?.locationName || ''} /></div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <p className="text-sm font-medium">Hiện vị trí trên Radar người gần</p>
              <Switch checked={locVisible} onCheckedChange={setLocVisible} aria-label="Hiện vị trí" />
            </div>
            <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={saving}>{saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Save className="mr-1 h-4 w-4" />}Lưu thay đổi</Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* ---- Dialog "Tạo bài viết" kiểu Facebook: chế độ hiển thị + nền màu + check-in + nhắc người khác ---- */}
      <Dialog open={composerOpen} onOpenChange={(o) => { setComposerOpen(o); if (!o) resetPost() }}>
        <DialogContent className="sm:max-w-lg" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle className="text-center">Tạo bài viết</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {/* Tác giả + chọn chế độ hiển thị (Công khai / Bạn bè / Riêng tư) */}
            <div className="flex items-center gap-2.5">
              <Avatar name={me.fullName} color={me.avatarColor} size={40} img={me.avatarImage} />
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">{me.fullName}</p>
                <Popover open={visOpen} onOpenChange={setVisOpen}>
                  <PopoverTrigger asChild>
                    <button
                      className="mt-0.5 flex items-center gap-1 rounded-full bg-stone-100 px-2 py-0.5 text-xs font-semibold text-stone-600 transition hover:bg-stone-200"
                      aria-label="Chọn chế độ hiển thị bài viết"
                    >
                      {visibilityOf(visibility).icon} {me.department || 'Vexon'}, {visibilityOf(visibility).label}
                      <ChevronDown className="h-3 w-3" />
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-72 p-2" align="start">
                    <p className="px-1 pb-1 text-xs font-semibold text-stone-500">Ai có thể thấy bài viết?</p>
                    {VISIBILITY_OPTIONS.map((v) => (
                      <button
                        key={v.key}
                        onClick={() => { setVisibility(v.key); setVisOpen(false) }}
                        className={`flex w-full items-start gap-2.5 rounded-lg p-2 text-left transition ${visibility === v.key ? 'bg-emerald-50' : 'hover:bg-stone-100'}`}
                        aria-label={`Chế độ ${v.label}`}
                      >
                        <span className="mt-0.5 text-lg leading-none">{v.icon}</span>
                        <span className="min-w-0 flex-1">
                          <span className="block text-sm font-semibold">{v.label}</span>
                          <span className="block text-xs text-stone-500">{v.desc}</span>
                        </span>
                        {visibility === v.key && <Check className="h-4 w-4 text-emerald-600" />}
                      </button>
                    ))}
                  </PopoverContent>
                </Popover>
              </div>
              {me.role === 'admin' && (
                <label className="ml-auto flex shrink-0 items-center gap-2 text-xs font-medium text-amber-700">
                  <Megaphone className="h-4 w-4" /> Thông báo BGĐ
                  <Switch checked={announce} onCheckedChange={setAnnounce} aria-label="Đăng làm thông báo Ban Giám đốc" />
                </label>
              )}
            </div>

            {/* Vùng soạn (có nền màu kiểu Facebook) */}
            <div className="rounded-lg" style={postBg ? { backgroundImage: postBg } : undefined}>
              <Textarea
                value={postText}
                onChange={(e) => setPostText(e.target.value)}
                rows={postBg ? 5 : 3}
                placeholder={`${me.fullName} ơi, bạn đang nghĩ gì?`}
                aria-label="Nội dung bài viết"
                className={`resize-none border-0 ${postBg ? 'bg-transparent text-center text-xl font-bold text-white placeholder:text-white/70 focus-visible:ring-0' : ''}`}
              />
              {postImgs.length > 0 && (
                <div className={`grid gap-1 p-2 ${postImgs.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
                  {postImgs.map((src, i) => (
                    <div key={i} className="relative">
                      <img src={src} alt={`Ảnh ${i + 1}`} className="h-32 w-full rounded-lg object-cover" />
                      <button
                        onClick={() => setPostImgs((arr) => arr.filter((_, j) => j !== i))}
                        className="absolute right-1 top-1 rounded-full bg-black/60 p-1 text-white"
                        aria-label={`Xoá ảnh ${i + 1}`}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              {postVideo && (
                <div className="relative p-2">
                  <video src={postVideo} controls className="max-h-56 w-full rounded-lg" aria-label="Video trong bài viết" />
                  <button onClick={() => setPostVideo(null)} className="absolute right-3 top-3 rounded-full bg-black/60 p-1 text-white" aria-label="Bỏ video"><X className="h-3 w-3" /></button>
                </div>
              )}
            </div>

            {/* Chọn nền màu (chỉ khi chưa có ảnh/video) */}
            {!(postImgs.length > 0 || postVideo) && (
              <div className="flex items-center gap-2">
                <PenLine className="h-4 w-4 shrink-0 text-stone-400" />
                <div className="flex flex-1 gap-1.5 overflow-x-auto">
                  <button onClick={() => setPostBg(null)} className={`h-7 w-7 shrink-0 rounded-md border text-[10px] ${postBg === null ? 'border-emerald-600' : 'border-stone-200'}`} aria-label="Không dùng nền">Aa</button>
                  {POST_BACKGROUNDS.map((g) => (
                    <button key={g} onClick={() => setPostBg(g)} aria-label="Chọn phông nền" className={`h-7 w-7 shrink-0 rounded-md border-2 ${postBg === g ? 'border-emerald-600' : 'border-transparent'}`} style={{ backgroundImage: g }} />
                  ))}
                </div>
              </div>
            )}

            {/* Chips nhắc người khác */}
            {postMentions.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {postMentions.map((m) => (
                  <span key={m.id} className="flex items-center gap-1 rounded-full bg-sky-100 px-2 py-0.5 text-xs font-medium text-sky-700">
                    @{m.fullName}
                    <button onClick={() => setPostMentions((ms) => ms.filter((x) => x.id !== m.id))} aria-label={`Bỏ nhắc ${m.fullName}`}><X className="h-3 w-3" /></button>
                  </span>
                ))}
              </div>
            )}
            {showLoc && (
              <Input value={postLoc} onChange={(e) => setPostLoc(e.target.value)} placeholder="Bạn đang ở đâu? (VD: Thôn Yên Hóa, Minh Hóa)" aria-label="Vị trí check-in" />
            )}
            {postFile && (
              <div className="flex items-center gap-2 rounded-lg border bg-stone-50 px-3 py-2 text-sm">
                <Paperclip className="h-4 w-4 text-stone-500" />
                <span className="flex-1 truncate">{postFile.name}</span>
                <button onClick={() => setPostFile(null)} aria-label="Bỏ file đính kèm"><X className="h-4 w-4" /></button>
              </div>
            )}

            {/* Thanh công cụ kiểu Facebook: Ảnh/Video, File, Check-in, Nhắc + nút Đăng bài xanh */}
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border bg-stone-50 p-2">
              <div className="flex flex-wrap items-center gap-1">
                <label className="flex cursor-pointer items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-emerald-700 transition hover:bg-emerald-50" aria-label="Gắn ảnh hoặc video">
                  <ImagePlus className="h-4 w-4" /> Ảnh/Video
                  <input type="file" accept="image/*,video/*" multiple className="hidden" onChange={(e) => { pickPostMedia(e.target.files); e.target.value = '' }} />
                </label>
                <label className="flex cursor-pointer items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-sky-700 transition hover:bg-sky-50" aria-label="Gắn file tài liệu">
                  <Paperclip className="h-4 w-4" /> File
                  <input type="file" className="hidden" onChange={(e) => { pickPostFile(e.target.files?.[0]); e.target.value = '' }} />
                </label>
                <button className="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-rose-600 transition hover:bg-rose-50" onClick={() => setShowLoc((v) => !v)} aria-label="Check-in vị trí">
                  <MapPin className="h-4 w-4" /> Check-in
                </button>
                <Popover open={mentionOpen} onOpenChange={setMentionOpen}>
                  <PopoverTrigger asChild>
                    <button className="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-sky-600 transition hover:bg-sky-50" aria-label="Nhắc người khác trong bài viết">
                      <AtSign className="h-4 w-4" /> Nhắc người khác
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-64 p-2" align="start">
                    <p className="mb-1.5 px-1 text-xs font-semibold text-stone-500">Chọn người muốn nhắc</p>
                    <div className="max-h-56 overflow-y-auto">
                      {users.map((u) => (
                        <label key={u.id} className="flex cursor-pointer items-center gap-2 rounded-md p-1.5 hover:bg-stone-100">
                          <Checkbox checked={postMentions.some((m) => m.id === u.id)} onCheckedChange={(c) => setPostMentions((ms) => (c ? [...ms, { id: u.id, fullName: u.fullName }] : ms.filter((m) => m.id !== u.id)))} />
                          <Avatar name={u.fullName} color={u.avatarColor} size={26} />
                          <div className="min-w-0"><p className="truncate text-xs font-medium">{u.fullName}</p><p className="truncate text-[10px] text-stone-500">{u.department}</p></div>
                        </label>
                      ))}
                      {users.length === 0 && <p className="py-4 text-center text-xs text-stone-400">Đang tải...</p>}
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
              <Button
                className="bg-emerald-600 hover:bg-emerald-700"
                disabled={posting || (!postText.trim() && postImgs.length === 0 && !postVideo && !postFile && !postBg)}
                onClick={submitPost}
                aria-label="Đăng bài viết"
              >
                {posting ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Send className="mr-1 h-4 w-4" />}
                Đăng bài
              </Button>
            </div>
            <p className="text-center text-[11px] text-stone-400">Đăng lên Bảng tin Vexon, Chế độ: {visibilityOf(visibility).label} {visibilityOf(visibility).icon}</p>
          </div>
        </DialogContent>
      </Dialog>

      {/* ---- Dialog tạo album ---- */}
      <Dialog open={createAlbumOpen} onOpenChange={setCreateAlbumOpen}>
        <DialogContent className="sm:max-w-lg" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Images className="h-4 w-4 text-emerald-600" /> Tạo album ảnh</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label htmlFor="alb-name">Tên album</Label>
              <Input id="alb-name" value={albName} onChange={(e) => setAlbName(e.target.value)} placeholder="VD: Chuyến du lịch Đà Lạt" />
            </div>
            <div className="flex items-center justify-between rounded-lg border bg-stone-50 px-3 py-2">
              <span className="text-xs text-stone-500">{albPhotos.length > 0 ? `${albPhotos.length} ảnh đã chọn` : 'Chưa có ảnh nào (tối đa 30)'}</span>
              <label className="flex cursor-pointer items-center gap-1.5 rounded-lg border bg-white px-3 py-1.5 text-sm font-medium transition-colors hover:bg-emerald-50">
                <ImagePlus className="h-4 w-4 text-emerald-600" /> Chọn ảnh
                <input ref={albImgRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => { pickAlbumPhotos(e.target.files); e.target.value = '' }} />
              </label>
            </div>
            {albPhotos.length > 0 && (
              <div className="grid grid-cols-4 gap-2">
                {albPhotos.map((src, i) => (
                  <div key={i} className="relative">
                    <img src={src} alt={`Ảnh ${i + 1}`} className="aspect-square w-full rounded-lg border object-cover" />
                    <button
                      onClick={() => setAlbPhotos((arr) => arr.filter((_, j) => j !== i))}
                      className="absolute right-1 top-1 rounded-full bg-black/60 p-1 text-white"
                      aria-label={`Bỏ ảnh ${i + 1}`}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <Button
              className="w-full bg-emerald-600 hover:bg-emerald-700"
              disabled={creatingAlbum || !albName.trim() || albPhotos.length === 0}
              onClick={createAlbum}
            >
              {creatingAlbum ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Plus className="mr-1 h-4 w-4" />}
              Tạo album
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ---- Dialog xem album ---- */}
      <Dialog open={Boolean(openAlbum)} onOpenChange={(o) => !o && setOpenAlbum(null)}>
        <DialogContent className="sm:max-w-2xl" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-2"><Images className="h-4 w-4 text-emerald-600" /> {openAlbum?.name} <span className="text-xs font-normal text-stone-500">({openAlbum?.count} ảnh)</span></span>
              {openAlbum && (
                <button
                  onClick={() => deleteAlbum(openAlbum)}
                  className="flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium text-red-500 transition-colors hover:bg-red-50"
                  aria-label="Xoá album"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Xoá album
                </button>
              )}
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-3 gap-2">
            {(openAlbum?.photos || []).map((src, i) => (
              <img key={i} src={src} alt={`${openAlbum?.name}, ảnh ${i + 1}`} className="aspect-square w-full rounded-lg border object-cover" />
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* ---- Dialog chỉnh sửa thông tin hồ sơ (kiểu TTO: sửa ngay từng mục) ---- */}
      <Dialog open={infoOpen} onOpenChange={setInfoOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><SlidersHorizontal className="h-4.5 w-4.5 text-emerald-600" /> Chỉnh sửa thông tin hồ sơ</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2"><Label htmlFor="if-birth">Ngày sinh</Label><VisCycle value={infoVis.birthday} onChange={(v) => setInfoVis((f) => ({ ...f, birthday: v }))} name="Ngày sinh" /></div>
              <Input id="if-birth" type="date" value={infoForm.birthday} onChange={(e) => setInfoForm((f) => ({ ...f, birthday: e.target.value }))} aria-label="Ngày sinh" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2"><Label htmlFor="if-hometown">Quê quán</Label><VisCycle value={infoVis.hometown} onChange={(v) => setInfoVis((f) => ({ ...f, hometown: v }))} name="Quê quán" /></div>
              <Input id="if-hometown" list="province-options" value={infoForm.hometown} onChange={(e) => setInfoForm((f) => ({ ...f, hometown: e.target.value }))} placeholder="Sổ 34 tỉnh thành sau sáp nhập" aria-label="Quê quán" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2"><Label htmlFor="if-edu">Giáo dục</Label><VisCycle value={infoVis.education} onChange={(v) => setInfoVis((f) => ({ ...f, education: v }))} name="Giáo dục" /></div>
              <Input id="if-edu" value={infoForm.education} onChange={(e) => setInfoForm((f) => ({ ...f, education: e.target.value }))} placeholder="VD: Đại học Bách Khoa Hà Nội" aria-label="Giáo dục" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2"><Label htmlFor="if-phone">Số điện thoại</Label><VisCycle value={infoVis.phone} onChange={(v) => setInfoVis((f) => ({ ...f, phone: v }))} name="Số điện thoại" /></div>
              <Input id="if-phone" value={infoForm.phone} onChange={(e) => setInfoForm((f) => ({ ...f, phone: e.target.value }))} placeholder="VD: 09xx xxx xxx" inputMode="tel" aria-label="Số điện thoại" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2"><Label htmlFor="if-bio">Bio cá nhân</Label><VisCycle value={infoVis.bio} onChange={(v) => setInfoVis((f) => ({ ...f, bio: v }))} name="Bio" /></div>
              <Textarea id="if-bio" value={infoForm.bio} onChange={(e) => setInfoForm((f) => ({ ...f, bio: e.target.value }))} rows={3} maxLength={300} placeholder="Giới thiệu ngắn về bản thân..." aria-label="Bio cá nhân" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2"><Label htmlFor="if-interests">Sở thích</Label><VisCycle value={infoVis.interests} onChange={(v) => setInfoVis((f) => ({ ...f, interests: v }))} name="Sở thích" /></div>
              <Input id="if-interests" value={infoForm.interests} onChange={(e) => setInfoForm((f) => ({ ...f, interests: e.target.value }))} placeholder="Cách nhau bằng dấu phẩy: Du lịch, Ẩm thực, Thể thao..." aria-label="Sở thích" />
            </div>
            {/* Giới tính (Nam | Nữ | Khác) — chọn từ danh sách hoặc nhập */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2"><Label htmlFor="if-gender">Giới tính</Label><VisCycle value={infoVis.gender} onChange={(v) => setInfoVis((f) => ({ ...f, gender: v }))} name="Giới tính" /></div>
              <Input id="if-gender" list="gender-options" value={infoForm.gender} onChange={(e) => setInfoForm((f) => ({ ...f, gender: e.target.value }))} placeholder="Chọn hoặc nhập" aria-label="Giới tính" />
            </div>
            {/* Hồ sơ hẹn hò + xã giao (khôi phục đúng bản 09c) */}
            <p className="flex items-center gap-1.5 pt-1 text-[11px] font-bold uppercase tracking-wide text-rose-500"><Heart className="h-3.5 w-3.5" /> Hẹn hò &amp; xã giao</p>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2"><Label htmlFor="if-height">Chiều cao (cm)</Label><VisCycle value={infoVis.height} onChange={(v) => setInfoVis((f) => ({ ...f, height: v }))} name="Chiều cao" /></div>
                <Input id="if-height" type="number" min={80} max={250} value={infoForm.heightCm} onChange={(e) => setInfoForm((f) => ({ ...f, heightCm: e.target.value }))} placeholder="VD: 170" aria-label="Chiều cao cm" />
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2"><Label htmlFor="if-weight">Cân nặng (kg)</Label><VisCycle value={infoVis.weight} onChange={(v) => setInfoVis((f) => ({ ...f, weight: v }))} name="Cân nặng" /></div>
                <Input id="if-weight" type="number" min={20} max={400} value={infoForm.weightKg} onChange={(e) => setInfoForm((f) => ({ ...f, weightKg: e.target.value }))} placeholder="VD: 62" aria-label="Cân nặng kg" />
              </div>
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2"><Label htmlFor="if-rel">Tình trạng quan hệ</Label><VisCycle value={infoVis.relationship} onChange={(v) => setInfoVis((f) => ({ ...f, relationship: v }))} name="Tình trạng quan hệ" /></div>
              <Input id="if-rel" list="rel-options" value={infoForm.relationship} onChange={(e) => setInfoForm((f) => ({ ...f, relationship: e.target.value }))} placeholder="Chọn hoặc nhập" aria-label="Tình trạng quan hệ" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2"><Label htmlFor="if-smoke">Thuốc lá</Label><VisCycle value={infoVis.lifestyle} onChange={(v) => setInfoVis((f) => ({ ...f, lifestyle: v }))} name="Thuốc lá" /></div>
                <Input id="if-smoke" list="smoke-options" value={infoForm.smoking} onChange={(e) => setInfoForm((f) => ({ ...f, smoking: e.target.value }))} placeholder="Chọn hoặc nhập" aria-label="Thuốc lá" />
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2"><Label htmlFor="if-drink">Rượu bia</Label><VisCycle value={infoVis.lifestyle} onChange={(v) => setInfoVis((f) => ({ ...f, lifestyle: v }))} name="Rượu bia" /></div>
                <Input id="if-drink" list="drink-options" value={infoForm.drinking} onChange={(e) => setInfoForm((f) => ({ ...f, drinking: e.target.value }))} placeholder="Chọn hoặc nhập" aria-label="Rượu bia" />
              </div>
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2"><Label htmlFor="if-pets">Thú cưng</Label><VisCycle value={infoVis.lifestyle} onChange={(v) => setInfoVis((f) => ({ ...f, lifestyle: v }))} name="Thú cưng" /></div>
              <Input id="if-pets" value={infoForm.pets} onChange={(e) => setInfoForm((f) => ({ ...f, pets: e.target.value }))} placeholder="VD: Mèo Tam Thể, Chó Alaska" aria-label="Thú cưng" />
            </div>
            <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground"><Lock className="h-3 w-3 shrink-0" /> Bấm nhãn Công khai / Bạn bè / Chỉ mình tôi cạnh mỗi mục để chọn ai được xem — giống quyền riêng tư Facebook.</p>
            <datalist id="gender-options"><option value="Nam" /><option value="Nữ" /><option value="Khác" /></datalist>
            <datalist id="province-options">{VN_PROVINCE_NAMES_34.map((pv) => <option key={pv} value={pv} />)}</datalist>
            <datalist id="rel-options"><option value="Độc thân" /><option value="Hẹn hò" /><option value="Có người yêu" /><option value="Đã kết hôn" /></datalist>
            <datalist id="smoke-options"><option value="Không" /><option value="Thỉnh thoảng" /><option value="Thường xuyên" /><option value="Đã bỏ" /></datalist>
            <datalist id="drink-options"><option value="Không" /><option value="Thỉnh thoảng" /><option value="Thường xuyên" /><option value="Đã bỏ" /></datalist>
            <p className="text-[11px] text-muted-foreground">Vị trí hiện tại tự cập nhật bằng định vị Radar, chỉnh tại tab Giới thiệu. Email và chức vụ do công ty quản lý.</p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setInfoOpen(false)}>Huỷ</Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={saveInfo} disabled={savingInfo} aria-label="Lưu thông tin hồ sơ">
                {savingInfo ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Save className="mr-1 h-4 w-4" />} Lưu
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ---- Dialog SỬA RIÊNG 1 MỤC — bấm bút chì cạnh dòng nào chỉ sửa đúng mục đó + chọn quyền riêng tư, không mở cả trang ---- */}
      <Dialog open={editKey !== null} onOpenChange={(o) => { if (!o) setEditKey(null) }}>
        <DialogContent className="sm:max-w-sm" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Pencil className="h-4 w-4 text-emerald-600" /> Sửa {editKey ? EDIT_META[editKey].label : ''}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {editKey === 'birthday' && (
              <Input type="date" value={editVal} onChange={(e) => setEditVal(e.target.value)} aria-label="Ngày sinh" />
            )}
            {editKey === 'hometown' && (
              <>
                <select value={VN_PROVINCE_NAMES_34.includes(editVal) ? editVal : (editVal === '' ? '' : '__other__')} onChange={(e) => setEditVal(e.target.value === '__other__' ? (editVal && !VN_PROVINCE_NAMES_34.includes(editVal) ? editVal : '') : e.target.value)} aria-label="Chọn tỉnh thành quê quán"
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm">
                  <option value="">— Chọn tỉnh/thành —</option>
                  {VN_PROVINCE_NAMES_34.map((pv) => <option key={pv} value={pv}>{pv}</option>)}
                  <option value="__other__">Khác / ở nước ngoài...</option>
                </select>
                {!VN_PROVINCE_NAMES_34.includes(editVal) && (
                  <Input value={editVal} onChange={(e) => setEditVal(e.target.value)} placeholder="VD: Quảng Trị, Paris (Pháp)..." aria-label="Quê quán khác" />
                )}
              </>
            )}
            {editKey === 'education' && (
              <Input value={editVal} onChange={(e) => setEditVal(e.target.value)} placeholder="VD: Đại học Bách Khoa Hà Nội" aria-label="Học vấn" />
            )}
            {editKey === 'phone' && (
              <Input value={editVal} onChange={(e) => setEditVal(e.target.value)} placeholder="VD: 09xx xxx xxx" inputMode="tel" aria-label="Số điện thoại" />
            )}
            {editKey === 'bio' && (
              <Textarea value={editVal} onChange={(e) => setEditVal(e.target.value)} rows={3} maxLength={300} placeholder="Giới thiệu ngắn về bản thân..." aria-label="Bio cá nhân" />
            )}
            {editKey === 'interests' && (
              <Input value={editVal} onChange={(e) => setEditVal(e.target.value)} placeholder="Cách nhau dấu phẩy: Du lịch, Ẩm thực..." aria-label="Sở thích" />
            )}
            {(editKey === 'height' || editKey === 'weight') && (
              <Input type="number" min={editKey === 'height' ? 80 : 20} max={editKey === 'height' ? 250 : 400} value={editVal} onChange={(e) => setEditVal(e.target.value)} placeholder={editKey === 'height' ? 'VD: 170 (cm)' : 'VD: 62 (kg)'} aria-label={EDIT_META[editKey].label} />
            )}
            {editKey === 'gender' && <ValueSelect value={editVal} onChange={setEditVal} options={GENDER_OPTIONS} ariaLabel="Giới tính" placeholder="— Chọn giới tính —" />}
            {editKey === 'relationship' && <ValueSelect value={editVal} onChange={setEditVal} options={REL_OPTIONS} ariaLabel="Tình trạng quan hệ" placeholder="— Chọn tình trạng —" />}
            {editKey === 'smoking' && <ValueSelect value={editVal} onChange={setEditVal} options={HABIT_OPTIONS} ariaLabel="Thuốc lá" placeholder="— Chọn —" />}
            {editKey === 'drinking' && <ValueSelect value={editVal} onChange={setEditVal} options={HABIT_OPTIONS} ariaLabel="Rượu bia" placeholder="— Chọn —" />}
            {editKey === 'ethnicity' && <ValueSelect value={editVal} onChange={setEditVal} options={ETHNICITY_OPTIONS} ariaLabel="Dân tộc" placeholder="— Chọn dân tộc —" />}
            {editKey === 'citizenId' && (
              <Input value={editVal} onChange={(e) => setEditVal(e.target.value.replace(/[^0-9]/g, '').slice(0, 12))} placeholder="12 chữ số" inputMode="numeric" aria-label="Căn cước công dân" />
            )}
            {editKey === 'taxCode' && (
              <Input value={editVal} onChange={(e) => setEditVal(e.target.value.replace(/[^0-9]/g, '').slice(0, 20))} placeholder="MST cá nhân" inputMode="numeric" aria-label="Mã số thuế" />
            )}
            {editKey === 'pets' && (
              <Input value={editVal} onChange={(e) => setEditVal(e.target.value)} placeholder="VD: Mèo Tam Thể, Chó Alaska" aria-label="Thú cưng" />
            )}
            {editKey === 'job' && (
              <Input value={editVal} onChange={(e) => setEditVal(e.target.value)} placeholder="VD: Tổng Giám đốc" aria-label="Chức danh" />
            )}
            {editKey === 'location' && (
              <>
                <Input value={editVal} onChange={(e) => setEditVal(e.target.value)} placeholder="VD: Quận 1, TP.HCM" aria-label="Sống tại" />
                <div className="flex items-center justify-between rounded-lg border bg-stone-50 px-3 py-2">
                  <span className="text-sm">Hiện vị trí trên Radar người gần</span>
                  <Switch checked={editLocVisible} onCheckedChange={setEditLocVisible} aria-label="Hiện vị trí" />
                </div>
              </>
            )}
            {editKey && EDIT_META[editKey].visKey && (
              <div className="flex items-center justify-between rounded-lg border bg-stone-50 px-3 py-2">
                <span className="text-sm font-medium">Ai được xem mục này?</span>
                <VisCycle value={editVis} onChange={setEditVis} name={EDIT_META[editKey].label} />
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setEditKey(null)}>Huỷ</Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={saveEdit} disabled={savingField} aria-label="Lưu mục này">
                {savingField ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Save className="mr-1 h-4 w-4" />} Lưu mục này
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ---- Dialog TẠO TRANG THÚ CƯNG — fanpage riêng cho pet, mạng xã hội phụ trong Vexon ---- */}
      <Dialog open={petCreateOpen} onOpenChange={setPetCreateOpen}>
        <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><PawPrint className="h-4 w-4 text-amber-600" /> Tạo trang thú cưng</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label htmlFor="pet-name">Tên thú cưng</Label>
              <Input id="pet-name" value={petForm.name} onChange={(e) => setPetForm((f) => ({ ...f, name: e.target.value }))} placeholder="VD: Milu" aria-label="Tên thú cưng" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label htmlFor="pet-species">Loài</Label>
                <select id="pet-species" value={petForm.species} onChange={(e) => setPetForm((f) => ({ ...f, species: e.target.value }))}
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm" aria-label="Loài thú cưng">
                  <option value="">— Chọn loài —</option>
                  {PET_SPECIES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <Label htmlFor="pet-breed">Giống</Label>
                <Input id="pet-breed" value={petForm.breed} onChange={(e) => setPetForm((f) => ({ ...f, breed: e.target.value }))} placeholder="VD: Alaska, Tam Thể" aria-label="Giống thú cưng" />
              </div>
              <div className="space-y-1">
                <Label htmlFor="pet-gender">Giới tính</Label>
                <select id="pet-gender" value={petForm.gender} onChange={(e) => setPetForm((f) => ({ ...f, gender: e.target.value }))}
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm" aria-label="Giới tính thú cưng">
                  <option value="">— Chọn —</option>
                  {PET_GENDERS.map((g) => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <Label htmlFor="pet-birthday">Sinh nhật</Label>
                <Input id="pet-birthday" type="date" value={petForm.birthday} onChange={(e) => setPetForm((f) => ({ ...f, birthday: e.target.value }))} aria-label="Sinh nhật thú cưng" />
              </div>
            </div>
            <div className="space-y-1">
              <Label htmlFor="pet-bio">Giới thiệu</Label>
              <Textarea id="pet-bio" value={petForm.bio} onChange={(e) => setPetForm((f) => ({ ...f, bio: e.target.value }))} rows={2} maxLength={300} placeholder="Ví dụ: Tôi là Milu, chuyên phá nhà và nịnh chủ..." aria-label="Giới thiệu thú cưng" />
            </div>
            <p className="text-[11px] text-muted-foreground">Trang thú cưng hoạt động như một trang cá nhân riêng kiểu fanpage: đăng bài với tư cách pet, người khác theo dõi và thả tim — mạng xã hội phụ trong Vexon (công ty vẫn là chính).</p>
            <Button className="w-full bg-amber-500 hover:bg-amber-600" onClick={createPetPage} disabled={creatingPet || !petForm.name.trim()} aria-label="Tạo trang thú cưng">
              {creatingPet ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <PawPrint className="mr-1 h-4 w-4" />} Tạo trang thú cưng
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog xem trang cá nhân của bạn bè — bấm thẻ bạn bè ở tab Bạn bè/sidebar là mở */}
      <UserProfileDialog userId={viewUserId} open={viewUserId !== null} onClose={() => setViewUserId(null)} onMessage={onMessage} />
    </div>
  )
}
