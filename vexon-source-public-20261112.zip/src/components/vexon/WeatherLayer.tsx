'use client'

// ============ LỚP HIỆU ỨNG THỜI TIẾT & 4 MÙA (nhẹ nhàng, mượt) ============
// Cánh hoa anh đào (Xuân), đom đóm (Hạ), lá vàng (Thu), tuyết êm đềm (Đông),
// mưa nhiều tầng sâu và sao đêm lấp lánh — toàn bộ particle chạy bằng CSS
// animation trên GPU (không canvas, không vòng lặp JS) nên rất nhẹ, không che nội dung.
// Chế độ Tự động: mùa theo tháng + thời tiết thật (Open-Meteo) tại vị trí GPS của bạn.

import { useEffect, useMemo, useState } from 'react'
import { useVxTheme, seasonOfMonth, type ThemeEffect } from '@/lib/vx-theme'

type Resolved = 'spring' | 'summer' | 'autumn' | 'winter' | 'rain' | 'night'

// Xét weathercode Open-Meteo → hiệu ứng phù hợp (mưa dầm/rào/giông, tuyết)
function fxFromWeatherCode(code: number): 'rain' | 'winter' | null {
  if ([95, 96, 99].includes(code)) return 'rain'
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return 'rain'
  if ([71, 73, 75, 77, 85, 86].includes(code)) return 'winter'
  return null
}

// Cache kết quả thời tiết 10 phút — tránh gọi API liên tục mỗi lần đổi tab
let wxCache: { at: number; fx: 'rain' | 'winter' | null } | null = null

function rand(min: number, max: number) {
  return min + Math.random() * (max - min)
}

export default function WeatherLayer() {
  const { effect, effectsOn, geo } = useVxTheme()
  const [resolved, setResolved] = useState<Resolved | ''>('')

  // Quyết định hiệu ứng cuối: auto = thời tiết thật (GPS) > sao đêm > mùa theo tháng
  useEffect(() => {
    let alive = true
    if (!effectsOn || effect === 'off') { setResolved(''); return }
    if (effect !== 'auto') { setResolved(effect as Resolved); return }
    const hour = new Date().getHours()
    const nightNow = hour >= 19 || hour < 5
    const fallback = () => (nightNow ? 'night' : seasonOfMonth())
    if (geo) {
      if (wxCache && Date.now() - wxCache.at < 10 * 60_000) {
        setResolved(wxCache.fx ?? fallback())
        return
      }
      fetch(`https://api.open-meteo.com/v1/forecast?latitude=${geo.lat.toFixed(3)}&longitude=${geo.lon.toFixed(3)}&current_weather=true`)
        .then((r) => r.json())
        .then((d) => {
          if (!alive) return
          const wx = fxFromWeatherCode(Number(d?.current_weather?.weathercode ?? -1))
          wxCache = { at: Date.now(), fx: wx }
          setResolved(wx ?? fallback())
        })
        .catch(() => { if (alive) setResolved(fallback()) })
    } else {
      setResolved(fallback())
    }
    return () => { alive = false }
  }, [effect, effectsOn, geo])

  if (!effectsOn || effect === 'off' || !resolved) return null

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-30 overflow-hidden" data-weather-fx={resolved}>
      {resolved === 'spring' && <Petals />}
      {resolved === 'summer' && <Fireflies />}
      {resolved === 'autumn' && <Leaves />}
      {resolved === 'winter' && <Snow />}
      {resolved === 'rain' && <Rain />}
      {resolved === 'night' && <Stars />}
    </div>
  )
}

/* ---------- XUÂN: hoa anh đào rơi nhẹ nhàng ---------- */
function Petals() {
  const items = useMemo(
    () =>
      Array.from({ length: 14 }, (_, i) => ({
        left: rand(0, 100),
        size: rand(9, 17),
        dur: rand(10, 18),
        delay: -rand(0, 18),
        sway: rand(18, 44),
        swayDur: rand(2.4, 4.2),
        op: rand(0.5, 0.8),
        spinDur: rand(5, 9),
        color: ['#fbcfe8', '#f9a8d4', '#ffe4e6'][i % 3],
      })),
    [],
  )
  return (
    <>
      {items.map((p, i) => (
        <span key={i} className="absolute -top-8 will-change-transform" style={{ left: `${p.left}%`, animation: `vx-fx-fall ${p.dur}s linear ${p.delay}s infinite` }}>
          <span className="block will-change-transform" style={{ ['--sway' as string]: `${p.sway}px`, animation: `vx-fx-sway ${p.swayDur}s ease-in-out infinite alternate` }}>
            <span
              className="block will-change-transform"
              style={{
                width: p.size,
                height: p.size,
                opacity: p.op,
                background: `linear-gradient(135deg, ${p.color}, #fff)`,
                borderRadius: '90% 0 90% 0',
                animation: `vx-fx-spin ${p.spinDur}s linear infinite`,
              }}
            />
          </span>
        </span>
      ))}
    </>
  )
}

/* ---------- HẠ: đom đóm phát sáng lung linh ---------- */
function Fireflies() {
  const items = useMemo(
    () =>
      Array.from({ length: 14 }, () => ({
        top: rand(8, 88),
        left: rand(2, 96),
        size: rand(5, 9),
        driftDur: rand(14, 26),
        delay: -rand(0, 20),
        pulseDur: rand(2.2, 4),
        pulseDelay: -rand(0, 4),
      })),
    [],
  )
  return (
    <>
      {items.map((p, i) => (
        <span key={i} className="absolute will-change-transform" style={{ top: `${p.top}%`, left: `${p.left}%`, animation: `vx-fx-drift ${p.driftDur}s ease-in-out ${p.delay}s infinite` }}>
          <span
            className="block rounded-full will-change-transform"
            style={{
              width: p.size,
              height: p.size,
              background: 'radial-gradient(circle, #fefce8 0%, #fde047 45%, rgba(163,230,53,0.25) 80%, transparent 100%)',
              boxShadow: '0 0 14px 3px rgba(253, 224, 71, 0.5)',
              animation: `vx-fx-pulse ${p.pulseDur}s ease-in-out ${p.pulseDelay}s infinite`,
            }}
          />
        </span>
      ))}
    </>
  )
}

/* ---------- THU: lá vàng bay trong gió ---------- */
function Leaves() {
  const items = useMemo(
    () =>
      Array.from({ length: 12 }, (_, i) => ({
        left: rand(0, 100),
        w: rand(12, 20),
        h: rand(8, 14),
        dur: rand(11, 20),
        delay: -rand(0, 20),
        sway: rand(24, 56),
        swayDur: rand(2.6, 4.6),
        op: rand(0.45, 0.75),
        spinDur: rand(6, 11),
        color: ['#f59e0b', '#fb923c', '#eab308', '#d97706'][i % 4],
      })),
    [],
  )
  return (
    <>
      {items.map((p, i) => (
        <span key={i} className="absolute -top-8 will-change-transform" style={{ left: `${p.left}%`, animation: `vx-fx-fall ${p.dur}s linear ${p.delay}s infinite` }}>
          <span className="block will-change-transform" style={{ ['--sway' as string]: `${p.sway}px`, animation: `vx-fx-sway ${p.swayDur}s ease-in-out infinite alternate` }}>
            <span
              className="block will-change-transform"
              style={{
                width: p.w,
                height: p.h,
                opacity: p.op,
                background: `linear-gradient(120deg, ${p.color}, #fde68a)`,
                borderRadius: '0 70% 0 70%',
                animation: `vx-fx-spin ${p.spinDur}s linear infinite`,
              }}
            />
          </span>
        </span>
      ))}
    </>
  )
}

/* ---------- ĐÔNG: tuyết rơi êm đềm ---------- */
function Snow() {
  const items = useMemo(
    () =>
      Array.from({ length: 22 }, () => ({
        left: rand(0, 100),
        size: rand(4, 9),
        dur: rand(14, 28),
        delay: -rand(0, 28),
        sway: rand(12, 34),
        swayDur: rand(2.8, 5),
        op: rand(0.4, 0.85),
      })),
    [],
  )
  return (
    <>
      {items.map((p, i) => (
        <span key={i} className="absolute -top-6 will-change-transform" style={{ left: `${p.left}%`, animation: `vx-fx-fall ${p.dur}s linear ${p.delay}s infinite` }}>
          <span className="block will-change-transform" style={{ ['--sway' as string]: `${p.sway}px`, animation: `vx-fx-sway ${p.swayDur}s ease-in-out infinite alternate` }}>
            <span
              className="block rounded-full bg-white will-change-transform"
              style={{ width: p.size, height: p.size, opacity: p.op, filter: 'blur(0.4px)', boxShadow: '0 0 6px rgba(255,255,255,0.6)' }}
            />
          </span>
        </span>
      ))}
    </>
  )
}

/* ---------- MƯA: mưa nhiều tầng sâu (gần/trung/xa), xiên nhẹ ---------- */
function Rain() {
  const layers = useMemo(() => {
    const drop = (n: number, o: number, sMin: number, sMax: number, w: number, hMin: number, hMax: number) =>
      Array.from({ length: n }, () => ({
        left: rand(-2, 102),
        h: rand(hMin, hMax),
        dur: rand(sMin, sMax),
        delay: -rand(0, sMax),
        op: rand(o * 0.6, o),
        w,
      }))
    return [
      // Tầng xa: mảnh, chậm, mờ
      ...drop(14, 0.3, 1.5, 2.1, 1, 10, 15),
      // Tầng giữa
      ...drop(12, 0.45, 1.0, 1.5, 1.5, 14, 20),
      // Tầng gần: đậm, nhanh, rõ
      ...drop(8, 0.55, 0.65, 1.0, 2, 18, 26),
    ]
  }, [])
  return (
    <div className="absolute -inset-[10%]" style={{ transform: 'rotate(-7deg)' }}>
      {layers.map((p, i) => (
        <span
          key={i}
          className="absolute top-0 will-change-transform"
          style={{
            left: `${p.left}%`,
            width: p.w,
            height: p.h,
            opacity: p.op,
            background: 'linear-gradient(to bottom, transparent, #cbd5e1 55%, #f1f5f9)',
            borderRadius: 999,
            animation: `vx-fx-rainfall ${p.dur}s linear ${p.delay}s infinite`,
          }}
        />
      ))}
    </div>
  )
}

/* ---------- ĐÊM: sao lấp lánh + sao băng thoáng qua ---------- */
function Stars() {
  const stars = useMemo(
    () =>
      Array.from({ length: 26 }, () => ({
        top: rand(2, 62),
        left: rand(1, 98),
        size: rand(1.5, 3.2),
        dur: rand(2.4, 5.5),
        delay: -rand(0, 6),
      })),
    [],
  )
  const shooting = useMemo(
    () => ({ top: rand(6, 26), left: rand(52, 88), w: rand(70, 110), dur: rand(8, 12), delay: rand(1.5, 4) }),
    [],
  )
  return (
    <>
      {stars.map((s, i) => (
        <span
          key={i}
          className="absolute block rounded-full bg-white"
          style={{
            top: `${s.top}%`,
            left: `${s.left}%`,
            width: s.size,
            height: s.size,
            boxShadow: '0 0 5px rgba(255,255,255,0.85)',
            animation: `vx-fx-twinkle ${s.dur}s ease-in-out ${s.delay}s infinite`,
          }}
        />
      ))}
      {/* Sao băng: vệt sáng dài thoảng qua mỗi chục giây */}
      <span
        className="absolute block rounded-full"
        style={{
          top: `${shooting.top}%`,
          left: `${shooting.left}%`,
          width: shooting.w,
          height: 2,
          background: 'linear-gradient(to left, #fff, rgba(255,255,255,0.65) 40%, transparent)',
          animation: `vx-fx-shoot ${shooting.dur}s linear ${shooting.delay}s infinite`,
        }}
      />
    </>
  )
}
