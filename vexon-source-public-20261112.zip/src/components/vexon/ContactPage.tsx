'use client'

// ============ TRANG LIÊN HỆ RIÊNG — SOLOWORKS BY VEXON ============
// Trang độc lập tách khỏi footer: nền tối sang trọng, mỗi kênh một thẻ riêng.
// Mở từ footer (mọi phân hệ), menu "Cá nhân → Liên hệ" — nút ← quay về Vexon.

import { useState } from 'react'
import {
  ArrowLeft, Check, Copy, ExternalLink, Mail, MapPin, MessageCircle,
  Music2, Navigation, Phone, Youtube,
} from 'lucide-react'
import { CONTACT } from './ContactInfo'

/** Cấu hình từng kênh — một thẻ một kênh, kèm hành động thật (gọi / mailto / mở link) */
const CHANNELS: {
  key: string
  name: string
  value: string
  desc: string
  icon: React.ReactNode
  badgeClass: string
  glowClass: string
  actions: { label: string; href?: string; copy?: string; primary?: boolean }[]
}[] = [
  {
    key: 'zalo',
    name: 'Zalo',
    value: CONTACT.zaloPhone,
    desc: 'Gọi điện & nhắn tin trực tiếp, phản hồi nhanh nhất',
    icon: <MessageCircle className="h-6 w-6 text-white" />,
    badgeClass: 'bg-gradient-to-br from-sky-500 to-blue-600',
    glowClass: 'group-hover:shadow-[0_0_36px_-8px_rgba(14,165,233,0.55)]',
    actions: [
      { label: 'Gọi ngay', href: CONTACT.zaloTel, primary: true },
      { label: 'Nhắn Zalo', href: CONTACT.zaloMe },
      { label: 'copy', copy: CONTACT.zaloPhone },
    ],
  },
  {
    key: 'email',
    name: 'Email',
    value: CONTACT.email,
    desc: 'Gửi thư về văn phòng SoloWorks by Vexon',
    icon: <Mail className="h-6 w-6 text-white" />,
    badgeClass: 'bg-gradient-to-br from-amber-500 to-orange-600',
    glowClass: 'group-hover:shadow-[0_0_36px_-8px_rgba(245,158,11,0.55)]',
    actions: [
      { label: 'Soạn thư', href: `mailto:${CONTACT.email}`, primary: true },
      { label: 'copy', copy: CONTACT.email },
    ],
  },
  {
    key: 'tiktok',
    name: 'TikTok',
    value: 'SoloWorks by Vexon',
    desc: 'Video ngắn, sản phẩm & dự án trong từng khung hình',
    icon: <Music2 className="h-6 w-6 text-white" />,
    badgeClass: 'bg-gradient-to-br from-stone-700 to-stone-900',
    glowClass: 'group-hover:shadow-[0_0_36px_-8px_rgba(236,72,153,0.5)]',
    actions: [
      { label: 'Xem kênh', href: CONTACT.tiktokUrl, primary: true },
    ],
  },
  {
    key: 'youtube',
    name: 'YouTube',
    value: 'SoloWorks by Vexon',
    desc: 'Video dài, hướng dẫn & giới thiệu hệ thống',
    icon: <Youtube className="h-6 w-6 text-white" />,
    badgeClass: 'bg-gradient-to-br from-red-500 to-rose-600',
    glowClass: 'group-hover:shadow-[0_0_36px_-8px_rgba(244,63,94,0.5)]',
    actions: [
      { label: 'Xem kênh', href: CONTACT.youtubeUrl, primary: true },
    ],
  },
]

export default function ContactPage({ onExit }: { onExit?: () => void }) {
  const [copied, setCopied] = useState<string | null>(null)

  const copy = (key: string, text: string) => {
    try {
      navigator.clipboard?.writeText(text)
      setCopied(key)
      setTimeout(() => setCopied(null), 1600)
    } catch {}
  }

  return (
    <div className="flex min-h-screen flex-col bg-stone-950 text-stone-100">
      {/* Thanh đầu trang — nút về Vexon + nhận diện thương hiệu */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-stone-950/85 backdrop-blur-md">
        <div className="mx-auto flex h-14 w-full max-w-4xl items-center justify-between gap-2 px-4">
          <div className="flex items-center gap-2">
            {onExit && (
              <button
                onClick={onExit}
                className="rounded-lg p-2 text-stone-400 transition hover:bg-white/10 hover:text-white"
                title="Về Vexon"
                aria-label="Về Vexon"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
            )}
            <span className="text-sm font-black tracking-[0.35em] text-emerald-400">VEXON</span>
          </div>
          <span className="truncate text-xs font-medium text-stone-400">{CONTACT.brand}</span>
        </div>
      </header>

      {/* Hero — chữ VEXON phát sáng trên nền tối */}
      <section className="relative overflow-hidden">
        <div aria-hidden className="pointer-events-none absolute -top-28 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-500/25 blur-3xl" />
        <div aria-hidden className="pointer-events-none absolute -right-20 top-24 h-56 w-56 rounded-full bg-teal-400/15 blur-3xl" />
        <div aria-hidden className="pointer-events-none absolute -left-20 top-36 h-56 w-56 rounded-full bg-sky-500/15 blur-3xl" />

        <div className="relative mx-auto max-w-4xl px-4 pb-12 pt-14 text-center sm:pt-20">
          <span className="inline-flex items-center gap-2 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.25em] text-emerald-300">
            Liên hệ
          </span>
          <h1 className="mt-5 bg-gradient-to-r from-emerald-300 via-teal-200 to-sky-300 bg-clip-text text-5xl font-black leading-none tracking-tight text-transparent sm:text-7xl">
            VEXON
          </h1>
          <p className="mx-auto mt-4 max-w-md text-sm leading-relaxed text-stone-400 sm:text-base">
            Mạng xã hội, Cửa hàng, Công cụ AI, nối liền mọi phân hệ.
            Chạm một kênh bất kỳ bên dưới, đội ngũ <b className="text-stone-200">{CONTACT.brand}</b> luôn sẵn sàng nghe bạn.
          </p>
        </div>
      </section>

      {/* Các kênh liên hệ — mỗi kênh một thẻ kính riêng */}
      <section className="relative mx-auto w-full max-w-4xl flex-1 px-4">
        <div className="grid gap-4 sm:grid-cols-2">
          {CHANNELS.map((c) => (
            <div
              key={c.key}
              className={`group relative flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition-all duration-200 hover:-translate-y-1 hover:border-white/20 hover:bg-white/[0.07] ${c.glowClass}`}
            >
              <div className="flex items-center gap-3">
                <span className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl shadow-lg ${c.badgeClass}`}>
                  {c.icon}
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-bold text-stone-200">{c.name}</p>
                  <p className="truncate text-lg font-black tracking-wide text-white">{c.value}</p>
                </div>
              </div>
              <p className="mt-3 flex-1 text-xs leading-relaxed text-stone-400">{c.desc}</p>
              <div className="mt-4 flex flex-wrap items-center gap-2">
                {c.actions.map((a) =>
                  a.copy ? (
                    <button
                      key={`${c.key}-${a.label}`}
                      onClick={() => copy(c.key, a.copy!)}
                      className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-stone-300 transition hover:bg-white/10 hover:text-white"
                      aria-label={`Sao chép ${a.copy}`}
                    >
                      {copied === c.key ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                      {copied === c.key ? 'Đã sao chép' : 'Sao chép'}
                    </button>
                  ) : (
                    <a
                      key={`${c.key}-${a.label}`}
                      href={a.href}
                      target={a.href?.startsWith('http') ? '_blank' : undefined}
                      rel="noreferrer"
                      className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-bold transition ${
                        a.primary
                          ? 'bg-emerald-500 text-stone-950 hover:bg-emerald-400'
                          : 'border border-white/10 bg-white/5 text-stone-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      {a.label}
                      {a.href?.startsWith('http') && <ExternalLink className="h-3 w-3" />}
                    </a>
                  ),
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Địa chỉ trụ sở — thẻ rộng riêng, mở chỉ đường thật */}
        <a
          href={CONTACT.mapUrl}
          target="_blank"
          rel="noreferrer"
          className="group mt-4 flex flex-col gap-4 rounded-2xl border border-white/10 bg-gradient-to-br from-emerald-500/10 via-white/[0.04] to-sky-500/10 p-5 transition-all duration-200 hover:border-emerald-400/40 sm:flex-row sm:items-center sm:justify-between"
          aria-label="Mở chỉ đường tới địa chỉ SoloWorks by Vexon"
        >
          <div className="flex items-start gap-3">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-red-600 shadow-lg">
              <MapPin className="h-6 w-6 text-white" />
            </span>
            <div>
              <p className="text-sm font-bold text-stone-200">Địa chỉ trụ sở</p>
              <p className="mt-0.5 text-base font-black text-white">{CONTACT.address}</p>
              <p className="mt-1 text-xs text-stone-400">Ghé thăm văn phòng, hẹn trước qua Zalo để được đón tận nơi.</p>
            </div>
          </div>
          <span className="flex shrink-0 items-center gap-2 self-start rounded-lg bg-emerald-500 px-4 py-2 text-xs font-bold text-stone-950 transition group-hover:bg-emerald-400 sm:self-center">
            <Navigation className="h-3.5 w-3.5" />
            Mở chỉ đường
          </span>
        </a>
      </section>

      {/* Chân trang */}
      <footer className="mt-12 border-t border-white/10 py-6 text-center text-xs text-stone-500">
        <p className="font-semibold text-stone-400">© 2026 Vexon, {CONTACT.brand}</p>
        <p className="mt-1">Mạng xã hội + Điểm danh nhân viên, Nâng cấp từ PHP lên Next.js</p>
      </footer>
    </div>
  )
}
