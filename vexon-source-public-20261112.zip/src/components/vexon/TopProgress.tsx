'use client'

// ============ HỆ THỐNG LOADING TOÀN CỤC ============
// Thanh tiến trình trên cùng: tự bắt mọi fetch() tới /api/* (trừ polling nền)
// + hook usePageLoading cho view dùng riêng.

import { useEffect, useRef, useState } from 'react'

const START_EVT = 'vx-load-start'
const DONE_EVT = 'vx-load-done'
const SKIP = ['/api/vx/notifications', '/api/vx/socket', '/api/vx/auth']

/** Cài đặt interception — gọi 1 lần khi app mount. */
let installed = false
export function installLoadTracker() {
  if (installed || typeof window === 'undefined') return
  installed = true
  const original = window.fetch.bind(window)
  window.fetch = async (...args: Parameters<typeof fetch>) => {
    const url = typeof args[0] === 'string' ? args[0] : args[0] instanceof URL ? args[0].pathname : (args[0] as Request).url
    const tracked = typeof url === 'string' && url.includes('/api/') && !SKIP.some((s) => url.includes(s))
    if (tracked) window.dispatchEvent(new Event(START_EVT))
    try {
      return await original(...args)
    } finally {
      if (tracked) setTimeout(() => window.dispatchEvent(new Event(DONE_EVT)), 150)
    }
  }
}

export default function TopProgress() {
  const [pct, setPct] = useState(0)
  const [visible, setVisible] = useState(false)
  const pending = useRef(0)
  const doneTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const tickTimer = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    installLoadTracker()
    const stopTick = () => {
      if (tickTimer.current) { clearInterval(tickTimer.current); tickTimer.current = null }
    }
    const start = () => {
      pending.current += 1
      if (doneTimer.current) { clearTimeout(doneTimer.current); doneTimer.current = null }
      setVisible(true)
      if (!tickTimer.current) {
        setPct((p) => (p < 15 ? 15 : p))
        tickTimer.current = setInterval(() => setPct((p) => Math.min(90, p + Math.max(0.6, (90 - p) * 0.08))), 180)
      }
    }
    const done = () => {
      pending.current = Math.max(0, pending.current - 1)
      if (pending.current === 0) {
        stopTick()
        setPct(100)
        doneTimer.current = setTimeout(() => { setVisible(false); setPct(0) }, 350)
      }
    }
    window.addEventListener(START_EVT, start)
    window.addEventListener(DONE_EVT, done)
    return () => {
      window.removeEventListener(START_EVT, start)
      window.removeEventListener(DONE_EVT, done)
      stopTick()
      if (doneTimer.current) clearTimeout(doneTimer.current)
    }
  }, [])

  if (!visible && pct === 0) return null
  return (
    <div className="fixed inset-x-0 top-0 z-[70] h-0.5" aria-hidden>
      <div
        className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 transition-[width] duration-200 ease-out"
        style={{ width: `${pct}%`, opacity: visible ? 1 : 0 }}
      />
    </div>
  )
}
