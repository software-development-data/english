'use client'

// ─── CÀI ĐẶT TIN NHẮN KIỂU fMESS ────────────────────────────────
// fMess (messenger desktop): Theme (Zalo/WhatsApp/Teams), Text size, Notification
// sounds, Do Not Disturb, "Show sender and message", "Block Typing in Chat",
// "Allow calls". Tất cả lưu máy (localStorage) như fMess lưu preferences.

import { useCallback, useState } from 'react'

export type ChatTheme = 'vexon' | 'zalo' | 'whatsapp' | 'teams'
export type ChatFontScale = 'small' | 'medium' | 'large'

export interface ChatPrefs {
  theme: ChatTheme
  fontScale: ChatFontScale
  soundOn: boolean
  dnd: boolean
  showPreview: boolean
  hideTyping: boolean
  allowCalls: boolean
}

export const DEFAULT_PREFS: ChatPrefs = {
  theme: 'vexon',
  fontScale: 'medium',
  soundOn: true,
  dnd: false,
  showPreview: true,
  hideTyping: false,
  allowCalls: true,
}

const KEY = 'vx-chat-prefs'

/** 4 theme chat — đúng tinh thần fMess: Messenger gốc · Zalo · WhatsApp · Teams */
export const CHAT_THEMES: { key: ChatTheme; name: string; desc: string; mine: string; mineSoft: string; accent: string; accentBg: string; accentSoftBg: string; dot: string }[] = [
  {
    key: 'vexon', name: 'Vexon gốc', desc: 'Bong bóng emerald mặc định của Vexon',
    mine: 'bg-emerald-600', mineSoft: 'bg-emerald-100', accent: 'text-emerald-600', accentBg: 'bg-emerald-600 hover:bg-emerald-700', accentSoftBg: 'bg-emerald-50', dot: 'bg-emerald-500',
  },
  {
    key: 'zalo', name: 'Zalo', desc: 'Bong bóng xanh dương kiểu Zalo PC',
    mine: 'bg-sky-600', mineSoft: 'bg-sky-100', accent: 'text-sky-600', accentBg: 'bg-sky-600 hover:bg-sky-700', accentSoftBg: 'bg-sky-50', dot: 'bg-sky-500',
  },
  {
    key: 'whatsapp', name: 'WhatsApp', desc: 'Xanh lá cổ điển kiểu WhatsApp Web',
    mine: 'bg-[#008069]', mineSoft: 'bg-[#d9fdd3]', accent: 'text-[#008069]', accentBg: 'bg-[#008069] hover:bg-[#016c59]', accentSoftBg: 'bg-[#d9fdd3]', dot: 'bg-[#25d366]',
  },
  {
    key: 'teams', name: 'Teams', desc: 'Tím công sở kiểu Microsoft Teams',
    mine: 'bg-[#5b5fc7]', mineSoft: 'bg-indigo-100', accent: 'text-[#5b5fc7]', accentBg: 'bg-[#5b5fc7] hover:bg-[#4a52c0]', accentSoftBg: 'bg-indigo-50', dot: 'bg-indigo-500',
  },
]

export function themeOf(t: ChatTheme) {
  return CHAT_THEMES.find((x) => x.key === t) || CHAT_THEMES[0]
}

export const FONT_SCALES: { key: ChatFontScale; label: string; px: number }[] = [
  { key: 'small', label: 'Nhỏ', px: 13 },
  { key: 'medium', label: 'Vừa', px: 14 },
  { key: 'large', label: 'Lớn', px: 16 },
]

export function useChatPrefs(): [ChatPrefs, (p: Partial<ChatPrefs>) => void] {
  // Đọc localStorage ngay từ initializer (cùng pattern mutedIds của MessagesView) — không dùng effect
  const [prefs, setPrefs] = useState<ChatPrefs>(() => {
    if (typeof window === 'undefined') return DEFAULT_PREFS
    try {
      const raw = localStorage.getItem(KEY)
      return raw ? { ...DEFAULT_PREFS, ...JSON.parse(raw) } : DEFAULT_PREFS
    } catch {
      return DEFAULT_PREFS
    }
  })

  const update = useCallback((p: Partial<ChatPrefs>) => {
    setPrefs((old) => {
      const next = { ...old, ...p }
      try { localStorage.setItem(KEY, JSON.stringify(next)) } catch { /* bỏ qua */ }
      return next
    })
  }, [])

  return [prefs, update]
}

/** Chuông "ting" WebAudio khi có tin mới — không cần file âm thanh */
let _ctx: AudioContext | null = null
export function playPing() {
  if (typeof window === 'undefined') return
  try {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
    if (!AC) return
    _ctx ||= new AC()
    if (_ctx.state === 'suspended') void _ctx.resume()
    const t = _ctx.currentTime
    const o = _ctx.createOscillator()
    const g = _ctx.createGain()
    o.connect(g); g.connect(_ctx.destination)
    o.type = 'sine'
    o.frequency.setValueAtTime(880, t)
    o.frequency.setValueAtTime(659, t + 0.11)
    g.gain.setValueAtTime(0.0001, t)
    g.gain.exponentialRampToValueAtTime(0.14, t + 0.02)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.38)
    o.start(t); o.stop(t + 0.42)
  } catch { /* bỏ qua */ }
}

/** Link sạch kiểu fMess: gỡ tham số theo dõi (fbclid, utm*, gclid...) khỏi URL */
const TRACK_PARAMS = ['fbclid', 'gclid', 'msclkid', 'messenger_dest', '__mref', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'ref_src', 'ref_url']
export function cleanUrl(u: string): string {
  try {
    const x = new URL(u)
    for (const k of TRACK_PARAMS) x.searchParams.delete(k)
    return x.toString()
  } catch { return u }
}
