'use client'

import { useCallback, useState } from 'react'
import type QRCode from 'qrcode'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import type { VxUserInfo } from './AuthView'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { useToast } from '@/hooks/use-toast'
import { fmtXuWithUsd } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'
import {
  Wand2, ImagePlus, Image as ImageIcon, Loader2, Download, Coins, History,
  Scissors, FileImage, QrCode, Frame, Binary, Minimize2, RefreshCw, ShieldCheck, X,
} from 'lucide-react'

interface ToolJob {
  id: string
  kind: string
  prompt: string
  size: string
  cost: number
  status: string
  resultUrl: string | null
  error: string | null
  createdAt: string
}

const SIZES = [
  { value: '1024x1024', label: 'Vuông 1:1 (1024)' },
  { value: '768x1344', label: 'Dọc 9:16 (768×1344)' },
  { value: '1344x768', label: 'Ngang 16:9 (1344×768)' },
  { value: '1440x720', label: 'Banner rộng (1440×720)' },
]

const readFileAsDataURL = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result))
    r.onerror = reject
    r.readAsDataURL(file)
  })

function download(dataUrl: string, name: string) {
  const a = document.createElement('a')
  a.href = dataUrl
  a.download = name
  a.click()
}

// Canvas ảnh đại diện cho các công cụ miễn phí
function useImgCanvas() {
  const load = (src: string): Promise<HTMLImageElement> =>
    new Promise((resolve, reject) => {
      const img = new Image()
      img.onload = () => resolve(img)
      img.onerror = reject
      img.src = src
    })
  return { load }
}

export default function ToolsView({ me, onRefreshUser }: { me: VxUserInfo; onRefreshUser?: () => void }) {
  const [tab, setTab] = useState<'ai' | 'free'>('ai')
  return (
    <div className="space-y-5">
      <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-sky-600 via-teal-600 to-teal-600 p-5 text-white shadow-lg">
        <h1 className="flex items-center gap-2 text-xl font-black"><Wand2 className="h-6 w-6" /> Tiệm Ảnh AI, Công cụ cho bức ảnh</h1>
        <p className="mt-1 text-sm text-sky-100">
          Công cụ AI trả bằng <b>tiền ví USD</b> (dùng chung Ví tiền, <b>chỉ trừ khi thành công</b>), Công cụ miễn phí chạy ngay trên máy bạn, không tốn tiền
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        <button onClick={() => setTab('ai')} className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold ${tab === 'ai' ? 'bg-sky-600 text-white shadow' : 'bg-white text-stone-600 hover:bg-sky-50'}`}>
          <Wand2 className="h-4 w-4" /> Công cụ AI (trả tiền ví)
        </button>
        <button onClick={() => setTab('free')} className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold ${tab === 'free' ? 'bg-sky-600 text-white shadow' : 'bg-white text-stone-600 hover:bg-sky-50'}`}>
          <ShieldCheck className="h-4 w-4" /> Miễn phí, chạy trên máy bạn
        </button>
      </div>
      {tab === 'ai' ? <AiTools me={me} onRefreshUser={onRefreshUser} /> : <FreeTools />}
    </div>
  )
}

// ==================== CÔNG CỤ AI (trả tiền ví) ====================
function AiTools({ me, onRefreshUser }: { me: VxUserInfo; onRefreshUser?: () => void }) {
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho Công cụ AI
  const [mode, setMode] = useState<'generate' | 'edit'>('generate')
  const [prompt, setPrompt] = useState('')
  const [size, setSize] = useState('1024x1024')
  const [editImg, setEditImg] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState<string | null>(null)
  const [coins, setCoins] = useState(me.coins ?? 0)
  const [jobs, setJobs] = useState<ToolJob[]>([])
  const { toast } = useToast()

  const loadHistory = useCallback(() => {
    fetch('/api/vx/tools').then((r) => r.json()).then((d) => {
      if (Array.isArray(d.jobs)) setJobs(d.jobs)
      if (typeof d.coins === 'number') setCoins(d.coins)
    }).catch(() => {})
  }, [])

  useDeferredLoad(() => loadHistory(), [loadHistory])

  const run = async () => {
    if (!prompt.trim()) {
      toast({ title: 'Thiếu mô tả', description: 'Mô tả bằng tiếng Việt bạn muốn tạo hoặc sửa gì', variant: 'destructive' })
      return
    }
    if (mode === 'edit' && !editImg) {
      toast({ title: 'Chưa thả ảnh', description: 'Chọn ảnh cần chỉnh sửa', variant: 'destructive' })
      return
    }
    setBusy(true)
    setResult(null)
    try {
      const res = await fetch('/api/vx/tools', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind: mode, prompt, size, image: mode === 'edit' ? editImg : undefined }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      setResult(d.resultUrl)
      setCoins(d.coins)
      onRefreshUser?.()
      toast({ title: mode === 'generate' ? 'Đã tạo ảnh!' : 'Đã sửa ảnh!', description: `Trừ ${fmtXuWithUsd(d.spent, rate)}, còn ${fmtXuWithUsd(d.coins, rate)}` })
      loadHistory()
    } catch (e) {
      toast({ title: 'Chưa thành công', description: e instanceof Error ? e.message : 'Lỗi', variant: 'destructive' })
      loadHistory()
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-5">
      {/* Bảng điều khiển */}
      <div className="space-y-4 rounded-xl border bg-white p-4 shadow-sm lg:col-span-2">
        <div className="flex items-center justify-between">
          <p className="font-bold">Chọn phép màu</p>
          <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100"><Coins className="mr-1 inline h-3.5 w-3.5" />{fmtXuWithUsd(coins, rate)}</Badge>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button onClick={() => setMode('generate')} className={`rounded-lg border-2 p-3 text-left text-sm transition-colors ${mode === 'generate' ? 'border-sky-500 bg-sky-50' : 'border-stone-200 hover:bg-stone-50'}`} aria-pressed={mode === 'generate'}>
            <ImagePlus className="mb-1 h-5 w-5 text-sky-600" />
            <b>Tạo ảnh mới</b><br /><span className="text-[11px] text-stone-500">{fmtXuWithUsd(5, rate)}, từ mô tả</span>
          </button>
          <button onClick={() => setMode('edit')} className={`rounded-lg border-2 p-3 text-left text-sm transition-colors ${mode === 'edit' ? 'border-sky-500 bg-sky-50' : 'border-stone-200 hover:bg-stone-50'}`} aria-pressed={mode === 'edit'}>
            <Wand2 className="mb-1 h-5 w-5 text-teal-600" />
            <b>Sửa ảnh của bạn</b><br /><span className="text-[11px] text-stone-500">{fmtXuWithUsd(9, rate)}, sửa đúng chỗ</span>
          </button>
        </div>

        {mode === 'edit' && (
          <div className="space-y-1.5">
            <Label>Ảnh cần sửa</Label>
            {editImg ? (
              <div className="relative">
                <img src={editImg} alt="Ảnh đính kèm" className="max-h-48 w-full rounded-lg border object-contain" />
                <button className="absolute right-1 top-1 rounded-full bg-white/90 p-1 shadow" onClick={() => setEditImg(null)} aria-label="Bỏ ảnh">
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <label className="flex cursor-pointer flex-col items-center gap-1 rounded-xl border-2 border-dashed p-6 text-sm text-stone-500 hover:border-sky-400 hover:bg-sky-50/50">
                <ImageIcon className="h-6 w-6" />
                Bấm để chọn ảnh (tối đa ~2.5MB)
                <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                  const f = e.target.files?.[0]
                  if (f) setEditImg(await readFileAsDataURL(f))
                }} />
              </label>
            )}
          </div>
        )}

        <div className="space-y-1.5">
          <Label>Mô tả bằng tiếng Việt *</Label>
          <Textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={4} aria-label="Mô tả yêu cầu AI"
            placeholder={mode === 'generate'
              ? 'VD: banner quảng cáo quán cà phê, nền be, có chữ "Sáng xem sao", phong cách tối giản'
              : 'VD: đổi nền thành bãi biển hoàng hôn, giữ nguyên người và ánh sáng'} />
        </div>
        <div className="space-y-1.5">
          <Label>Kích thước ảnh</Label>
          <Select value={size} onValueChange={setSize}>
            <SelectTrigger aria-label="Kích thước ảnh"><SelectValue /></SelectTrigger>
            <SelectContent>{SIZES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <Button className="w-full bg-sky-600 hover:bg-sky-700" onClick={run} disabled={busy}>
          {busy ? <><Loader2 className="mr-1 h-4 w-4 animate-spin" /> AI đang vẽ...</> : <><Wand2 className="mr-1 h-4 w-4" />{mode === 'generate' ? `Tạo ảnh, ${fmtXuWithUsd(5, rate)}` : `Sửa ảnh, ${fmtXuWithUsd(9, rate)}`}</>}
        </Button>
        <p className="flex items-center gap-1 text-[11px] text-stone-500"><ShieldCheck className="h-3.5 w-3.5 text-emerald-600" /> Chỉ trừ tiền khi xử lý thành công, thất bại không mất gì.</p>
      </div>

      {/* Kết quả + lịch sử */}
      <div className="space-y-4 lg:col-span-3">
        <div className="flex min-h-72 flex-col items-center justify-center rounded-xl border bg-white p-4 shadow-sm">
          {busy && <div className="flex flex-col items-center gap-2 py-16 text-sm text-stone-500"><Loader2 className="h-8 w-8 animate-spin text-sky-500" /> AI đang xử lý, khoảng 10-40 giây...</div>}
          {!busy && !result && <div className="py-16 text-center text-sm text-stone-400">Kết quả sẽ hiện ở đây</div>}
          {!busy && result && (
            <>
              <img src={result} alt="Kết quả AI" className="max-h-[60vh] rounded-lg border" />
              <Button variant="outline" className="mt-3" onClick={() => download(result, `vexon-ai-${Date.now()}.png`)}>
                <Download className="mr-1 h-4 w-4" /> Tải ảnh về máy
              </Button>
            </>
          )}
        </div>
        <div className="rounded-xl border bg-white p-4 shadow-sm">
          <p className="mb-2 flex items-center gap-1.5 text-sm font-bold"><History className="h-4 w-4 text-stone-400" /> Lịch sử của bạn</p>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
            {jobs.filter((j) => j.resultUrl).map((j) => (
              <img key={j.id} src={j.resultUrl as string} alt={j.prompt} title={`${j.kind === 'generate' ? 'Tạo' : 'Sửa'}: ${j.prompt}`} className="aspect-square w-full cursor-pointer rounded-lg border object-cover hover:opacity-80" onClick={() => setResult(j.resultUrl)} />
            ))}
            {jobs.length === 0 && <p className="col-span-full py-4 text-center text-xs text-stone-400">Chưa có ảnh nào, thử ngay!</p>}
          </div>
        </div>
      </div>
    </div>
  )
}

// ==================== CÔNG CỤ MIỄN PHÍ (client-side) ====================
function FreeTools() {
  const [tool, setTool] = useState<'compress' | 'convert' | 'crop' | 'qr' | 'thumb' | 'base64'>('compress')
  const TOOLS = [
    { key: 'compress', label: 'Nén ảnh', icon: <Minimize2 className="h-4 w-4" />, desc: 'Giảm dung lượng JPG/PNG' },
    { key: 'convert', label: 'Đổi định dạng', icon: <RefreshCw className="h-4 w-4" />, desc: 'PNG, JPG, WEBP' },
    { key: 'crop', label: 'Cắt ảnh', icon: <Scissors className="h-4 w-4" />, desc: 'Thẻ 3×4, Facebook, TikTok' },
    { key: 'qr', label: 'Tạo mã QR', icon: <QrCode className="h-4 w-4" />, desc: 'WiFi, link, danh thiếp' },
    { key: 'thumb', label: 'Tạo thumbnail', icon: <Frame className="h-4 w-4" />, desc: 'Ảnh bìa chữ, 6 bố cục' },
    { key: 'base64', label: 'Base64', icon: <Binary className="h-4 w-4" />, desc: 'Mã hóa ảnh & văn bản' },
  ] as const

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-xs text-emerald-900">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
        Không cần đăng nhập, Không tốn tiền, Không giới hạn, ảnh xử lý ngay trên máy bạn, không tải lên máy chủ.
      </div>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {TOOLS.map((t) => (
          <button key={t.key} onClick={() => setTool(t.key)} className={`rounded-xl border-2 p-3 text-left transition-colors ${tool === t.key ? 'border-emerald-500 bg-emerald-50' : 'border-stone-200 bg-white hover:bg-stone-50'}`} aria-pressed={tool === t.key}>
            <span className="flex items-center gap-1.5 text-sm font-bold">{t.icon} {t.label}</span>
            <span className="text-[11px] text-stone-500">{t.desc}</span>
          </button>
        ))}
      </div>
      <div className="rounded-xl border bg-white p-4 shadow-sm">
        {tool === 'compress' && <CompressTool />}
        {tool === 'convert' && <ConvertTool />}
        {tool === 'crop' && <CropTool />}
        {tool === 'qr' && <QrTool />}
        {tool === 'thumb' && <ThumbTool />}
        {tool === 'base64' && <Base64Tool />}
      </div>
    </div>
  )
}

const FilePicker = ({ onData, accept = 'image/*', label }: { onData: (d: string, f: File) => void; accept?: string; label: string }) => (
  <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed p-4 text-sm text-stone-500 hover:border-emerald-400 hover:bg-emerald-50/50">
    <FileImage className="h-5 w-5" /> {label}
    <input type="file" accept={accept} className="hidden" onChange={async (e) => {
      const f = e.target.files?.[0]
      if (f) onData(await readFileAsDataURL(f), f)
    }} />
  </label>
)

function CompressTool() {
  const [src, setSrc] = useState<string | null>(null)
  const [out, setOut] = useState<string | null>(null)
  const [quality, setQuality] = useState(70)
  const [sizes, setSizes] = useState<{ before: string; after: string } | null>(null)
  const { load } = useImgCanvas()

  const compress = async (q: number) => {
    if (!src) return
    const img = await load(src)
    const c = document.createElement('canvas')
    c.width = img.naturalWidth
    c.height = img.naturalHeight
    c.getContext('2d')!.drawImage(img, 0, 0)
    const dataUrl = c.toDataURL('image/jpeg', q / 100)
    setOut(dataUrl)
    const before = Math.round((src.length * 3) / 4)
    const after = Math.round((dataUrl.length * 3) / 4)
    setSizes({ before: `${(before / 1024).toFixed(0)} KB`, after: `${(after / 1024).toFixed(0)} KB (−${Math.max(0, Math.round((1 - after / before) * 100))}%)` })
  }

  return (
    <div className="space-y-3">
      <p className="font-bold">Nén ảnh, giảm dung lượng, so sánh trước sau</p>
      <FilePicker onData={(d) => { setSrc(d); setOut(null); setSizes(null) }} label="Chọn ảnh cần nén" />
      {src && (
        <>
          <div className="flex items-center gap-3">
            <Label className="shrink-0 text-sm">Chất lượng: {quality}%</Label>
            <Slider value={[quality]} min={20} max={95} step={5} onValueChange={(v) => setQuality(v[0])} aria-label="Chất lượng nén" />
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => compress(quality)}>Nén ngay</Button>
          </div>
          {out && sizes && (
            <div className="grid gap-3 sm:grid-cols-2">
              <div><p className="text-xs font-semibold text-stone-500">Gốc, {sizes.before}</p><img src={src} alt="Gốc" className="max-h-56 w-full rounded-lg border object-contain" /></div>
              <div><p className="text-xs font-semibold text-emerald-700">Đã nén, {sizes.after}</p><img src={out} alt="Đã nén" className="max-h-56 w-full rounded-lg border object-contain" /></div>
              <Button variant="outline" className="sm:col-span-2" onClick={() => download(out, `nen-anh-${Date.now()}.jpg`)}><Download className="mr-1 h-4 w-4" /> Tải ảnh đã nén</Button>
            </div>
          )}
        </>
      )}
    </div>
  )
}

function ConvertTool() {
  const [src, setSrc] = useState<string | null>(null)
  const [out, setOut] = useState<string | null>(null)
  const [fmt, setFmt] = useState<'png' | 'jpeg' | 'webp'>('png')
  const { load } = useImgCanvas()
  const convert = async () => {
    if (!src) return
    const img = await load(src)
    const c = document.createElement('canvas')
    c.width = img.naturalWidth
    c.height = img.naturalHeight
    const ctx = c.getContext('2d')!
    if (fmt === 'jpeg') {
      ctx.fillStyle = '#fff'
      ctx.fillRect(0, 0, c.width, c.height)
    }
    ctx.drawImage(img, 0, 0)
    setOut(c.toDataURL(`image/${fmt}`, 0.92))
  }
  return (
    <div className="space-y-3">
      <p className="font-bold">Đổi định dạng ảnh, PNG, JPG, WEBP</p>
      <FilePicker onData={(d) => { setSrc(d); setOut(null) }} label="Chọn ảnh cần đổi định dạng" />
      {src && (
        <div className="flex flex-wrap items-center gap-3">
          <Select value={fmt} onValueChange={(v) => setFmt(v as 'png' | 'jpeg' | 'webp')}>
            <SelectTrigger className="w-40" aria-label="Định dạng đích"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="png">PNG</SelectItem><SelectItem value="jpeg">JPG</SelectItem><SelectItem value="webp">WEBP</SelectItem></SelectContent>
          </Select>
          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={convert}>Chuyển đổi</Button>
          {out && <Button size="sm" variant="outline" onClick={() => download(out, `doi-dinh-dang-${Date.now()}.${fmt === 'jpeg' ? 'jpg' : fmt}`)}><Download className="mr-1 h-4 w-4" /> Tải về</Button>}
        </div>
      )}
      {out && <img src={out} alt="Kết quả" className="max-h-56 rounded-lg border object-contain" />}
    </div>
  )
}

const CROP_PRESETS = [
  { key: '1:1', label: 'Vuông 1:1', ratio: 1 },
  { key: '3:4', label: 'Ảnh thẻ 3×4', ratio: 3 / 4 },
  { key: '4:5', label: 'Facebook 4:5', ratio: 4 / 5 },
  { key: '9:16', label: 'TikTok 9:16', ratio: 9 / 16 },
  { key: '16:9', label: 'YouTube 16:9', ratio: 16 / 9 },
]

function CropTool() {
  const [src, setSrc] = useState<string | null>(null)
  const [out, setOut] = useState<string | null>(null)
  const { load } = useImgCanvas()
  const crop = async (ratio: number) => {
    if (!src) return
    const img = await load(src)
    const W = img.naturalWidth
    const H = img.naturalHeight
    let cw = W
    let ch = W / ratio
    if (ch > H) {
      ch = H
      cw = H * ratio
    }
    const c = document.createElement('canvas')
    c.width = Math.round(cw)
    c.height = Math.round(ch)
    c.getContext('2d')!.drawImage(img, (W - cw) / 2, (H - ch) / 2, cw, ch, 0, 0, c.width, c.height)
    setOut(c.toDataURL('image/jpeg', 0.92))
  }
  return (
    <div className="space-y-3">
      <p className="font-bold">Cắt ảnh theo tỉ lệ, crop giữa ảnh</p>
      <FilePicker onData={(d) => { setSrc(d); setOut(null) }} label="Chọn ảnh cần cắt" />
      {src && (
        <div className="flex flex-wrap gap-2">
          {CROP_PRESETS.map((p) => (
            <Button key={p.key} size="sm" variant="outline" onClick={() => crop(p.ratio)}>{p.label}</Button>
          ))}
        </div>
      )}
      {out && (
        <div className="space-y-2">
          <img src={out} alt="Đã cắt" className="max-h-72 rounded-lg border object-contain" />
          <Button variant="outline" size="sm" onClick={() => download(out, `cat-anh-${Date.now()}.jpg`)}><Download className="mr-1 h-4 w-4" /> Tải về</Button>
        </div>
      )}
    </div>
  )
}

function QrTool() {
  const [text, setText] = useState('')
  const [qr, setQr] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const gen = async () => {
    if (!text.trim()) return
    setBusy(true)
    try {
      const QR = (await import('qrcode')) as typeof QRCode
      setQr(await QR.toDataURL(text, { width: 512, margin: 2, errorCorrectionLevel: 'M' }))
    } finally {
      setBusy(false)
    }
  }
  return (
    <div className="space-y-3">
      <p className="font-bold">Tạo mã QR, link, WiFi, số điện thoại, danh thiếp (mã không hết hạn)</p>
      <div className="flex flex-wrap gap-2">
        <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Dán link hoặc nội dung, VD: https://vexon.vn" className="min-w-64 flex-1" aria-label="Nội dung QR" />
        <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={gen} disabled={busy || !text.trim()}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Tạo QR'}</Button>
      </div>
      {qr && (
        <div className="flex items-center gap-4">
          <img src={qr} alt="Mã QR" className="h-40 w-40 rounded-lg border" />
          <Button variant="outline" onClick={() => download(qr, `qr-${Date.now()}.png`)}><Download className="mr-1 h-4 w-4" /> Tải QR</Button>
        </div>
      )}
    </div>
  )
}

const THUMB_STYLES = [
  'linear-gradient(135deg,#f43f5e,#f97316)', 'linear-gradient(135deg,#8b5cf6,#ec4899)', 'linear-gradient(135deg,#0ea5e9,#22d3ee)',
  'linear-gradient(135deg,#10b981,#84cc16)', 'linear-gradient(135deg,#0f172a,#334155)', 'linear-gradient(135deg,#f59e0b,#ef4444)',
]

function ThumbTool() {
  const [title, setTitle] = useState('VEXON')
  const [sub, setSub] = useState('Siêu nền tảng MXH & Doanh nghiệp')
  const [styleIdx, setStyleIdx] = useState(2)
  const [out, setOut] = useState<string | null>(null)
  const gen = () => {
    const c = document.createElement('canvas')
    c.width = 1280
    c.height = 720
    const ctx = c.getContext('2d')!
    ctx.fillStyle = THUMB_STYLES[styleIdx]
    ctx.fillRect(0, 0, 1280, 720)
    ctx.font = '900 96px sans-serif'
    ctx.fillStyle = '#ffffff'
    ctx.textAlign = 'center'
    ctx.shadowColor = 'rgba(0,0,0,.4)'
    ctx.shadowBlur = 18
    ctx.fillText(title.slice(0, 18).toUpperCase() || 'THUMBNAIL', 640, 350)
    ctx.font = '600 40px sans-serif'
    ctx.fillText(sub.slice(0, 44), 640, 440)
    ctx.shadowBlur = 0
    ctx.font = '500 24px sans-serif'
    ctx.fillStyle = 'rgba(255,255,255,.85)'
    ctx.fillText('VEXON, TIỆM ẢNH AI', 640, 680)
    setOut(c.toDataURL('image/png'))
  }
  return (
    <div className="space-y-3">
      <p className="font-bold">Tạo thumbnail, ảnh bìa chữ to, 6 bố cục màu</p>
      <div className="grid gap-2 sm:grid-cols-2">
        <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Chữ lớn" aria-label="Chữ lớn" />
        <Input value={sub} onChange={(e) => setSub(e.target.value)} placeholder="Chú thích nhỏ" aria-label="Chú thích" />
      </div>
      <div className="flex flex-wrap gap-2">
        {THUMB_STYLES.map((s, i) => (
          <button key={i} onClick={() => setStyleIdx(i)} aria-label={`Màu ${i + 1}`} className={`h-9 w-14 rounded-lg border-2 ${styleIdx === i ? 'border-stone-800' : 'border-transparent'}`} style={{ backgroundImage: s }} />
        ))}
        <Button size="sm" className="ml-auto bg-emerald-600 hover:bg-emerald-700" onClick={gen}>Tạo thumbnail</Button>
        {out && <Button size="sm" variant="outline" onClick={() => download(out, `thumbnail-${Date.now()}.png`)}><Download className="mr-1 h-4 w-4" /> Tải</Button>}
      </div>
      {out && <img src={out} alt="Thumbnail" className="w-full max-w-xl rounded-lg border" />}
    </div>
  )
}

function Base64Tool() {
  const [plain, setPlain] = useState('')
  const [b64, setB64] = useState('')
  const [err, setErr] = useState('')
  return (
    <div className="space-y-3">
      <p className="font-bold">Mã hóa & giải mã Base64, văn bản hai chiều</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label>Văn bản gốc</Label>
          <Textarea rows={5} value={plain} onChange={(e) => setPlain(e.target.value)} aria-label="Văn bản gốc" />
          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => { try { setB64(btoa(unescape(encodeURIComponent(plain)))); setErr('') } catch { setErr('Không mã hóa được') } }}>Mã hóa Base64</Button>
        </div>
        <div className="space-y-1.5">
          <Label>Base64</Label>
          <Textarea rows={5} value={b64} onChange={(e) => setB64(e.target.value)} aria-label="Base64" />
          <Button size="sm" variant="outline" onClick={() => { try { setPlain(decodeURIComponent(escape(atob(b64.trim())))); setErr('') } catch { setErr('Base64 không hợp lệ') } }}>Giải mã Base64</Button>
        </div>
      </div>
      {err && <p className="text-sm text-rose-600">{err}</p>}
      <FilePicker onData={(d) => setB64(d.split(',')[1] || '')} label="...hoặc chọn ảnh/tệp để lấy Base64" />
    </div>
  )
}
