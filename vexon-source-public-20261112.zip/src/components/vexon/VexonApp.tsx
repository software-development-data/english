'use client'

import { useCallback, useEffect, useState } from 'react'
import AuthView, { VxUserInfo } from '@/components/vexon/AuthView'
import FeedView from '@/components/vexon/FeedView'
import VideoTikTokView from '@/components/vexon/VideoTikTokView'
import LiveView from '@/components/vexon/LiveView'
import MessagesView from '@/components/vexon/MessagesView'
import FriendsView from '@/components/vexon/FriendsView'
import AttendanceView from '@/components/vexon/AttendanceView'
import AnalysisView from '@/components/vexon/AnalysisView'
import NearbyView from '@/components/vexon/NearbyView'
import JobsView from '@/components/vexon/JobsView'
import CompaniesView from '@/components/vexon/CompaniesView'
import WalletView from '@/components/vexon/WalletView'
import OpsView from '@/components/vexon/OpsView'
import GroupsView from '@/components/vexon/GroupsView'
import PagesView from '@/components/vexon/PagesView'
import PetsView from '@/components/vexon/PetsView'
import SettingsView from '@/components/vexon/SettingsView'
import WeatherLayer from '@/components/vexon/WeatherLayer'
import TopProgress from '@/components/vexon/TopProgress'
import CallLayer from '@/components/vexon/CallLayer'
import AiAssistant from '@/components/vexon/AiAssistant'
import SplashScreen from '@/components/vexon/SplashScreen'
import AiMascot from '@/components/vexon/AiMascot'
import { VxThemeProvider, useVxTheme } from '@/lib/vx-theme'
import ProfileView, { UserProfileDialog } from '@/components/vexon/ProfileView'
import HomeView from '@/components/vexon/HomeView'
import { TiaiApp } from '@/components/tiai/tiai-app'
import FloatingChatHeads from '@/components/vexon/FloatingChatHeads'
import VietBizApp from '@/components/store/VietBizApp'
import ContactPage from '@/components/vexon/ContactPage'
import { disconnectSocket } from '@/lib/vx-socket'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { fmtUsdFromXu } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'
import { type VxView, VX_VIEWS } from '@/lib/vx-views'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import {
  Newspaper, PlayCircle, Radio, MessagesSquare, Users, CalendarCheck, FileSearch,
  Video, ShoppingBag, Bell, LogOut, UserCircle, MapPin, Briefcase, Building2, Coins, Wand2,
  LayoutGrid, Home as HomeIcon, KanbanSquare, UsersRound, Settings, Moon, Sun, Phone, BotMessageSquare,
  Globe, Heart, MessageCircle, Flag, PawPrint, Wallet, ArrowLeftRight,
  Languages,
} from 'lucide-react'

type View = VxView

/** Phát số dư ví tiền CHUNG mới nhất cho mọi phân hệ (Công cụ AI, Vexon AI, Ví tiền mạng xã hội) */
function broadcastCoins(coins?: number) {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('vx-coins-changed', { detail: { coins: coins ?? 0 } }))
  }
}

// Nav chính — đúng thứ tự user yêu cầu: Trang chủ → Tin nhắn → Bảng tin → Hồ sơ (+ nút Menu)
const NAV: { key: View; label: string; icon: React.ReactNode }[] = [
  { key: 'home', label: 'Trang chủ', icon: <HomeIcon className="h-4 w-4" /> },
  { key: 'messages', label: 'Tin nhắn', icon: <MessagesSquare className="h-4 w-4" /> },
  { key: 'feed', label: 'Bảng tin', icon: <Newspaper className="h-4 w-4" /> },
  { key: 'profile', label: 'Hồ sơ', icon: <UserCircle className="h-4 w-4" /> },
]

// Menu dưới (mobile) — 5 mục: Trang chủ, Tin nhắn, Bảng tin, Hồ sơ, Menu
const BOTTOM_PRIMARY: { key: View; label: string; icon: React.ReactNode }[] = [
  { key: 'home', label: 'Trang chủ', icon: <HomeIcon className="h-5 w-5" /> },
  { key: 'messages', label: 'Tin nhắn', icon: <MessagesSquare className="h-5 w-5" /> },
  { key: 'feed', label: 'Bảng tin', icon: <Newspaper className="h-5 w-5" /> },
  { key: 'profile', label: 'Hồ sơ', icon: <UserCircle className="h-5 w-5" /> },
]

// Toàn bộ tính năng gói thành nhóm — bấm Menu/Thêm là hiện ra lựa chọn
const MENU_CATEGORIES: { title: string; icon: React.ReactNode; items: { key: View; label: string; icon: React.ReactNode }[] }[] = [
  {
    title: 'Mạng xã hội & Giải trí',
    icon: <Globe className="h-3.5 w-3.5 text-sky-500" />,
    items: [
      // Bảng tin đã có ở nav chính/menu dưới nên bỏ khỏi đây để menu gọn (không trùng lặp)
      { key: 'video', label: 'Video', icon: <PlayCircle className="h-4.5 w-4.5" /> },
      { key: 'live', label: 'Livestream', icon: <Radio className="h-4.5 w-4.5" /> },
      { key: 'groups', label: 'Nhóm', icon: <UsersRound className="h-4.5 w-4.5" /> },
      { key: 'pages', label: 'Trang (Fanpage)', icon: <Flag className="h-4.5 w-4.5" /> },
      { key: 'pets', label: 'Thú cưng', icon: <PawPrint className="h-4.5 w-4.5" /> },
      { key: 'friends', label: 'Bạn bè', icon: <Users className="h-4.5 w-4.5" /> },
      { key: 'nearby', label: 'Người gần', icon: <MapPin className="h-4.5 w-4.5" /> },
    ],
  },
  {
    title: 'Công việc & Doanh nghiệp',
    icon: <Briefcase className="h-3.5 w-3.5 text-amber-600" />,
    items: [
      { key: 'attendance', label: 'Điểm danh', icon: <CalendarCheck className="h-4.5 w-4.5" /> },
      { key: 'ops', label: 'Quản trị 360', icon: <KanbanSquare className="h-4.5 w-4.5" /> },
      { key: 'analysis', label: 'Phân tích', icon: <FileSearch className="h-4.5 w-4.5" /> },
      { key: 'jobs', label: 'Việc làm', icon: <Briefcase className="h-4.5 w-4.5" /> },
      { key: 'companies', label: 'Doanh nghiệp', icon: <Building2 className="h-4.5 w-4.5" /> },
    ],
  },
  {
    title: 'Tiện ích & Mua sắm',
    icon: <Wand2 className="h-3.5 w-3.5 text-teal-600" />,
    items: [
      { key: 'aichat', label: 'Chatbot AI', icon: <BotMessageSquare className="h-4.5 w-4.5" /> },
      { key: 'tools', label: 'Công cụ AI', icon: <Wand2 className="h-4.5 w-4.5" /> },
      { key: 'shop', label: 'Cửa hàng', icon: <ShoppingBag className="h-4.5 w-4.5" /> },
      { key: 'wallet', label: 'Ví tiền', icon: <Wallet className="h-4.5 w-4.5" /> },
    ],
  },
  {
    title: 'Cá nhân',
    icon: <Settings className="h-3.5 w-3.5 text-stone-500" />,
    items: [
      // Hồ sơ đã có ở nav chính — chỉ giữ Cài đặt + Liên hệ ở đây
      { key: 'settings', label: 'Cài đặt', icon: <Settings className="h-4.5 w-4.5" /> },
      { key: 'contact', label: 'Liên hệ', icon: <Phone className="h-4.5 w-4.5" /> },
    ],
  },
]

/** Nội dung menu đầy đủ — dùng chung cho nút Menu (header) và nút Thêm (menu bottom) */
function FullMenu({ current, onGo }: { current: View; onGo: (v: View) => void }) {
  const go = (v: View) => {
    // Chatbot AI là trang riêng có link riêng: /chat
    if (v === 'aichat') { window.location.assign('/chat'); return }
    onGo(v)
  }
  return (
    <div className="space-y-4">
      {MENU_CATEGORIES.map((cat) => (
        <div key={cat.title}>
          <p className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-stone-400">{cat.icon}{cat.title}</p>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
            {cat.items.map((m) => (
              <button
                key={`${m.key}-${m.label}`}
                onClick={() => go(m.key)}
                className={`flex flex-col items-center gap-1.5 rounded-xl border p-3 text-xs font-medium transition-colors ${
                  current === m.key ? 'border-emerald-300 bg-emerald-50 text-emerald-800' : 'border-stone-200 bg-white text-stone-600 hover:bg-emerald-50'
                }`}
              >
                {m.icon}
                {m.label}
              </button>
            ))}
          </div>
        </div>
      ))}
      <section>
        <p className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-stone-400">
          <Languages className="h-3.5 w-3.5 text-sky-600" /> Học tập
        </p>
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          <a
            href="https://english.soloworks.pro"
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center gap-1.5 rounded-xl border border-stone-200 bg-white p-3 text-xs font-medium text-stone-600 transition-colors hover:border-sky-200 hover:bg-sky-50 hover:text-sky-800"
          >
            <Languages className="h-4.5 w-4.5" />
            English Quest
          </a>
        </div>
      </section>
    </div>
  )
}

interface Notification {
  id: string
  type: string
  content: string
  read: boolean
  createdAt: string
}

export default function VexonApp({ initialView }: { initialView?: VxView }) {
  return (
    <VxThemeProvider>
      <VexonShell initialView={initialView} />
    </VxThemeProvider>
  )
}

function VexonShell({ initialView }: { initialView?: VxView }) {
  const [user, setUser] = useState<VxUserInfo | null>(null)
  const [booting, setBooting] = useState(true)
  // Splash logo + thanh loading: hiển thị tối thiểu 1.4s cho mượt rồi mới fade vào app
  const [splashMin, setSplashMin] = useState(false)
  // Deep-link ?view=… — mở thẳng phân hệ được chỉ định (mặc định: Trang chủ)
  const [view, setView] = useState<View>(() => (initialView && VX_VIEWS.includes(initialView) ? initialView : 'home'))
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [showNoti, setShowNoti] = useState(false)
  const [messageTo, setMessageTo] = useState<string | null>(null)
  const [profileUserId, setProfileUserId] = useState<string | null>(null)
  const [showProfile, setShowProfile] = useState(false)
  // Trang thú cưng: mở trang Fanpage cụ thể từ Hồ sơ (bấm thẻ pet ở tab Giới thiệu)
  const [pagesFocusId, setPagesFocusId] = useState<string | null>(null)
  const openPetPage = useCallback((pageId: string) => { setPagesFocusId(pageId); setView('pages') }, [])
  const [showMore, setShowMore] = useState(false)
  const [showMenu, setShowMenu] = useState(false)
  const theme = useVxTheme()
  // Tỷ giá USD/VND thực tế (live, cache 6h) — chip ví tiền ở header quy theo giá hiện nay
  const rate = useUsdRate()

  // Sự kiện toàn cục: mở hộp thoại xem hồ sơ từ bất kỳ đâu (Trang chủ bấm thẻ người, tìm kiếm gần đây...)
  useEffect(() => {
    const handler = (e: Event) => {
      const id = (e as CustomEvent).detail?.userId
      if (id) { setProfileUserId(id); setShowProfile(true) }
    }
    window.addEventListener('vx-open-profile', handler)
    return () => window.removeEventListener('vx-open-profile', handler)
  }, [])

  // Khởi động: kiểm tra phiên đăng nhập + đồng bộ cài đặt giao diện từ user
  useDeferredLoad(() => {
    fetch('/api/vx/auth')
      .then((r) => r.json())
      .then((d) => {
        const u: VxUserInfo | null = d.user || null
        setUser(u)
        if (u) broadcastCoins(u.coins)
        if (u?.settings) theme.set({ mode: u.settings.theme || 'day', effect: u.settings.effect || 'auto', effectsOn: u.settings.effectsOn !== false, notifSound: u.settings.notifSound !== false })
      })
      .catch(() => {})
      .finally(() => setBooting(false))
  }, [])

  // Thông báo (polling 12s)
  const loadNoti = useCallback(() => {
    fetch('/api/vx/notifications')
      .then((r) => r.json())
      .then((d) => Array.isArray(d.notifications) && setNotifications(d.notifications))
      .catch(() => {})
  }, [])

  useEffect(() => {
    if (!user) return
    loadNoti()
    const t = setInterval(loadNoti, 12000)
    return () => clearInterval(t)
  }, [user, loadNoti])

  const logout = async () => {
    await fetch('/api/vx/auth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'logout' }),
    })
    disconnectSocket()
    setUser(null)
    window.dispatchEvent(new Event('vx-coins-changed')) // ví về chế độ khách ở mọi phân hệ
  }

  const unread = notifications.filter((n) => !n.read).length

  // Splash hiển thị tối thiểu 1.4s
  useEffect(() => {
    const t = setTimeout(() => setSplashMin(true), 1400)
    return () => clearTimeout(t)
  }, [])

  // Trang riêng biệt (Cửa hàng / Công cụ AI / Liên hệ): có menu riêng → ẩn toàn bộ menu index tránh chồng chéo
  const isFullApp = view === 'shop' || view === 'tools' || view === 'contact'

  const markAllRead = async () => {
    await fetch('/api/vx/notifications', { method: 'PATCH' })
    setNotifications((ns) => ns.map((n) => ({ ...n, read: true })))
  }

  const openMessageWith = (userId: string) => {
    setMessageTo(userId)
    setView('messages')
  }

  const refreshUser = useCallback(() => {
    fetch('/api/vx/auth')
      .then((r) => r.json())
      .then((d) => {
        if (d.user) {
          setUser(d.user)
          broadcastCoins(d.user.coins)
        }
      })
      .catch(() => {})
  }, [])

  // Công cụ AI dùng giao diện sáng thống nhất với index — không cần class dark

  // Công cụ AI tính Xu (2 lượt miễn phí/ngày) — chạy xong vẫn báo header cập nhật số dư ví chung
  useEffect(() => {
    if (!user) return
    const onCoins = () => refreshUser()
    window.addEventListener('vx-coins-changed', onCoins)
    return () => window.removeEventListener('vx-coins-changed', onCoins)
  }, [user, refreshUser])

  // Chatbox Vexon Bot trong Tin nhắn: đảm bảo hội thoại bot + tin chào mừng tồn tại (1 lần mỗi phiên)
  useEffect(() => {
    if (!user?.id) return
    const t = setTimeout(() => {
      fetch('/api/vx/bot', { method: 'POST' }).catch(() => {})
    }, 2500)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id])

  if (booting || !splashMin) return <SplashScreen />

  if (!user) return <AuthView onAuthed={(u) => { setUser(u); broadcastCoins(u?.coins) }} />

  return (
    <div className="flex min-h-screen flex-col bg-stone-100">
      {/* Header index — ẩn khi đang ở trang riêng (Cửa hàng / Công cụ AI) để không bị 2 menu chồng nhau */}
      {!isFullApp && (
      <header className="sticky top-0 z-40 border-b bg-white shadow-sm">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-3 py-2.5 sm:px-6">
          {/* Đã bỏ chữ brand "Vexon" trên header theo yêu cầu (dư thừa — splash + logo đã có) */}

          {/* Nav chính */}
          <nav className="flex min-w-0 flex-1 items-center justify-start gap-0.5 overflow-x-auto sm:gap-1" aria-label="Điều hướng chính">
            {NAV.map((n) => (
              <button
                key={n.key}
                onClick={() => setView(n.key)}
                title={n.label}
                className={`flex shrink-0 items-center gap-1.5 rounded-lg px-2 py-2 text-sm font-medium transition-colors sm:px-2.5 ${
                  view === n.key ? 'bg-emerald-600 text-white shadow' : 'text-stone-600 hover:bg-emerald-50 hover:text-emerald-800'
                }`}
                aria-current={view === n.key ? 'page' : undefined}
              >
                {n.icon}
                <span className="hidden xl:inline">{n.label}</span>
              </button>
            ))}
          </nav>

          {/* Nút Menu — bấm vào hiện toàn bộ lựa chọn phân nhóm (desktop + mobile) */}
          <Sheet open={showMenu} onOpenChange={setShowMenu}>
            <SheetTrigger asChild>
              <button
                className="flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-2 text-sm font-medium text-stone-600 transition-colors hover:bg-emerald-50 hover:text-emerald-800"
                aria-label="Mở menu tất cả tính năng"
              >
                <LayoutGrid className="h-4.5 w-4.5" />
                <span className="hidden sm:inline">Menu</span>
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-md">
              <SheetTitle className="sr-only">Tất cả tính năng</SheetTitle>
              <p className="mb-4 mt-2 text-base font-bold">Tất cả tính năng Vexon</p>
              <FullMenu current={view} onGo={(v) => { setView(v); setShowMenu(false) }} />
            </SheetContent>
          </Sheet>

          <div className="flex items-center gap-1.5">
            {/* Chế độ ngày/đêm nhanh (desktop — mobile chỉnh trong Cài đặt) */}
            <button
              onClick={() => theme.set({ mode: theme.mode === 'day' ? 'night' : 'day' })}
              className="hidden rounded-lg p-2 text-stone-600 transition-colors hover:bg-emerald-50 hover:text-emerald-800 sm:block"
              title={theme.mode === 'day' ? 'Chuyển sang chế độ đêm' : 'Chuyển sang chế độ ngày'}
              aria-label={theme.mode === 'day' ? 'Bật chế độ đêm' : 'Bật chế độ ngày'}
            >
              {theme.mode === 'day' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5 text-amber-400" />}
            </button>

            {/* Cài đặt */}
            <button
              onClick={() => setView('settings')}
              className={`rounded-lg p-2 transition-colors ${view === 'settings' ? 'bg-emerald-600 text-white' : 'text-stone-600 hover:bg-emerald-50 hover:text-emerald-800'}`}
              title="Cài đặt"
              aria-label="Cài đặt"
            >
              <Settings className="h-5 w-5" />
            </button>

            {/* Ví tiền (USD theo tỷ giá thật) — thẻ Vexon Pay quản lý ở trang Ví tiền */}
            <button
              onClick={() => setView('wallet')}
              className="flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-sm font-bold text-emerald-700 transition-colors hover:bg-emerald-100"
              title={`Ví tiền (USD) & thẻ Vexon Pay — tỷ giá 1$ = ${rate.toLocaleString('vi-VN')}đ`}
              aria-label={`Ví tiền: ${fmtUsdFromXu(user.coins ?? 0, rate)}`}
            >
              <Wallet className="h-4 w-4" />
              {fmtUsdFromXu(user.coins ?? 0, rate)}
            </button>

            {/* Chuông thông báo */}
            <div className="relative">
              <button
                className="relative rounded-lg p-2 text-stone-600 hover:bg-stone-100"
                onClick={() => {
                  setShowNoti(!showNoti)
                  if (!showNoti && unread > 0) markAllRead()
                }}
                aria-label={`Thông báo (${unread} chưa đọc)`}
              >
                <Bell className="h-5 w-5" />
                {unread > 0 && (
                  <Badge className="absolute -right-0.5 -top-0.5 h-4 min-w-4 rounded-full bg-rose-600 p-0 text-[9px] text-white hover:bg-rose-600">
                    {unread}
                  </Badge>
                )}
              </button>
              {showNoti && (
                <div className="absolute right-0 top-11 z-50 w-80 overflow-hidden rounded-xl border bg-white shadow-xl">
                  <p className="border-b bg-muted/50 px-4 py-2 text-xs font-semibold">Thông báo</p>
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <p className="py-8 text-center text-xs text-muted-foreground">Chưa có thông báo nào</p>
                    ) : (
                      notifications.map((n) => (
                        <div key={n.id} className={`border-b px-4 py-2.5 text-sm last:border-0 ${!n.read ? 'bg-emerald-50/60' : ''}`}>
                          <p className="flex items-start gap-2">
                            {n.type === 'friend_request' && <Users className="mt-0.5 h-4 w-4 shrink-0 text-cyan-600" />}
                            {n.type === 'like' && <Heart className="mt-0.5 h-4 w-4 shrink-0 fill-rose-500 text-rose-500" />}
                            {n.type === 'comment' && <MessageCircle className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />}
                            {n.type === 'live' && <Radio className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" />}
                            {n.type === 'ping' && <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-sky-600" />}
                            {n.type === 'gift' && <Coins className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />}
                            {n.type === 'job_apply' && <Briefcase className="mt-0.5 h-4 w-4 shrink-0 text-teal-600" />}
                            {n.type === 'job_status' && <CalendarCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />}
                            {n.type === 'ops' && <KanbanSquare className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />}
                            {n.type === 'coins' && <Coins className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />}
                            {n.type === 'transfer' && <ArrowLeftRight className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />}
                            <span>{n.content}</span>
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Hồ sơ của tôi */}
            <button
              className="flex items-center gap-2 rounded-lg p-1.5 hover:bg-stone-100"
              onClick={() => setView('profile')}
              title="Hồ sơ của tôi"
              aria-label="Hồ sơ cá nhân"
            >
              <div className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold text-white" style={{ backgroundColor: user.avatarColor }}>
                {user.fullName[0]}
              </div>
              <span className="hidden max-w-28 truncate text-sm font-medium md:block">{user.fullName}</span>
            </button>
            <button className="rounded-lg p-2 text-stone-400 hover:bg-stone-100 hover:text-stone-700" onClick={logout} title="Đăng xuất" aria-label="Đăng xuất">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </header>
      )}

      {/* Hiệu ứng thời tiết Pixe lFx + thanh loading toàn cục */}
      <WeatherLayer />
      <TopProgress />
      {/* Cuộc gọi WebRTC + họp nhóm kiểu Zoom (toàn cục, nghe chuông từ mọi tab) */}
      <CallLayer me={user} />

      {isFullApp ? (
        /* Trang riêng biệt — phân hệ tự dùng menu riêng của nó (header + điều hướng + footer) */
        view === 'shop' ? (
          <VietBizApp onExit={() => setView('feed')} onOpenContact={() => setView('contact')} />
        ) : view === 'tools' ? (
          <TiaiApp meCoins={user.coins} onExit={() => setView('home')} />
        ) : (
          <ContactPage onExit={() => setView('home')} />
        )
      ) : (
        <>
      {/* Nội dung index */}
      <main className="mx-auto w-full max-w-6xl flex-1 px-3 pb-24 pt-5 sm:px-6 lg:pb-5">
        {/* Trang chủ = Tìm kiếm gần đây (Heesay-style); Bảng tin là tab riêng */}
        {view === 'home' && <HomeView me={user} onGo={setView} onMessage={openMessageWith} />}
        {view === 'feed' && <FeedView me={user} onOpenProfile={(id) => { setProfileUserId(id); setShowProfile(true) }} />}
        {view === 'video' && <VideoTikTokView me={user} onRefreshUser={refreshUser} />}
        {view === 'live' && <LiveView me={user} onRefreshUser={refreshUser} />}
        {view === 'messages' && <MessagesView me={user} openWithUser={messageTo} onConsumedOpenWith={() => setMessageTo(null)} onOpenProfile={(id) => { setProfileUserId(id); setShowProfile(true) }} />}
        {view === 'friends' && <FriendsView me={user} onMessage={openMessageWith} onOpenProfile={(id) => { setProfileUserId(id); setShowProfile(true) }} />}
        {view === 'nearby' && <NearbyView me={user} onMessage={openMessageWith} />}
        {view === 'jobs' && <JobsView me={user} onMessage={openMessageWith} />}
        {view === 'companies' && <CompaniesView me={user} onMessage={openMessageWith} />}
        {view === 'wallet' && <WalletView me={user} onRefreshUser={refreshUser} />}
        {view === 'profile' && <ProfileView me={user} onRefreshUser={refreshUser} onMessage={openMessageWith} onGoPages={openPetPage} onOpenPages={() => setView('pages')} />}
        {view === 'attendance' && <AttendanceView me={user} />}
        {view === 'ops' && <OpsView me={user} onRefreshUser={refreshUser} />}
        {view === 'groups' && <GroupsView me={user} onRefreshUser={refreshUser} />}
        {view === 'pages' && <PagesView me={user} focusPageId={pagesFocusId} onConsumedFocus={() => setPagesFocusId(null)} />}
        {view === 'pets' && <PetsView me={user} onOpenProfile={(id) => { setProfileUserId(id); setShowProfile(true) }} />}
        {view === 'settings' && <SettingsView me={user} onRefreshUser={refreshUser} />}
        {view === 'analysis' && <AnalysisView me={user} />}
      </main>

      {/* Menu bottom — tính năng nhiều nên gói lại cho gọn (mobile/tablet) */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t bg-white/95 shadow-[0_-4px_16px_rgba(0,0,0,0.06)] backdrop-blur lg:hidden">
        <nav className="mx-auto flex max-w-6xl items-stretch justify-around px-1 py-1" aria-label="Menu dưới màn hình">
          {BOTTOM_PRIMARY.map((n) => (
            <button
              key={n.key}
              onClick={() => setView(n.key)}
              className={`flex min-w-16 flex-col items-center gap-0.5 rounded-lg px-2 py-1.5 text-[10px] font-medium transition-colors ${
                view === n.key ? 'text-emerald-700' : 'text-stone-500 hover:text-emerald-700'
              }`}
              aria-current={view === n.key ? 'page' : undefined}
            >
              {n.icon}
              {n.label}
            </button>
          ))}
          <Sheet open={showMore} onOpenChange={setShowMore}>
            <SheetTrigger asChild>
              <button className="flex min-w-16 flex-col items-center gap-0.5 rounded-lg px-2 py-1.5 text-[10px] font-medium text-stone-500 transition-colors hover:text-emerald-700">
                <LayoutGrid className="h-5 w-5" />
                Thêm
              </button>
            </SheetTrigger>
            <SheetContent side="bottom" className="rounded-t-2xl px-4 pb-6">
              <SheetTitle className="sr-only">Tất cả phân hệ</SheetTitle>
              <p className="mb-3 text-center text-sm font-bold">Tất cả tính năng Vexon</p>
              <div className="max-h-[70vh] overflow-y-auto">
                <FullMenu current={view} onGo={(v) => { setView(v); setShowMore(false) }} />
              </div>
            </SheetContent>
          </Sheet>
        </nav>
      </div>

      {/* Chat nổi góc màn hình — vừa làm việc vừa nhắn tin */}
      <FloatingChatHeads me={user} />

      {/* Trợ lý AI nổi — tích hợp AI toàn cục */}
      <AiAssistant me={user} />

      {/* Mascot AI 3D chạy quanh web — bấm là mở Trợ lý AI */}
      <AiMascot />
        </>
      )}

      {/* Hồ sơ công khai */}
      <UserProfileDialog userId={profileUserId} open={showProfile} onClose={() => setShowProfile(false)} onMessage={openMessageWith} />
    </div>
  )
}
