'use client'

// ============ VEXON AI — TRỢ LÝ SIÊU ĐA NĂNG (nâng cấp) ============
// • Hội thoại nhiều lượt, lưu lịch sử nhiều cuộc trò chuyện (localStorage)
// • 4 chế độ: Chat, Nhìn ảnh trả lời, Vẽ ảnh, Tìm kiếm web (kèm nguồn)
// • Đọc to câu trả lời (TTS), Gợi ý nhanh, Miễn phí

import { useCallback, useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Sparkles, X, Send, Loader2, ImagePlus, ImageIcon, Globe, Volume2, Square,
  History, Plus, Trash2, ChevronLeft, Download, PenLine, FileText, Lightbulb, Link2, TriangleAlert,
} from 'lucide-react'

interface AMsg { role: 'user' | 'ai'; text: string; image?: string; sources?: { url: string; name: string }[]; audio?: string }
interface AConv { id: string; title: string; msgs: AMsg[]; at: number }

const STORE_KEY = 'vexon-ai-convs-v1'
const QUICK = [
  { icon: <PenLine className="h-3 w-3" />, label: 'Viết caption bán hàng', q: 'Viết giúp mình 3 caption giới thiệu sản phẩm áo thun local brand, tone trẻ trung, có emoji' },
  { icon: <Globe className="h-3 w-3" />, label: 'Dịch sang tiếng Anh', q: 'Dịch sang tiếng Anh: "Cảm ơn bạn đã tin tưởng Vexon, đơn hàng sẽ giao trong 24 giờ."' },
  { icon: <FileText className="h-3 w-3" />, label: 'Tóm tắt nội quy', q: 'Tóm tắt giúp mình cách kiếm và dùng tiền ví trong Vexon' },
  { icon: <Lightbulb className="h-3 w-3" />, label: 'Hỏi ý tưởng', q: 'Gợi ý 5 ý tưởng bài đăng tăng tương tác cho fanpage cửa hàng đồ ăn' },
]

function loadConvs(): AConv[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = localStorage.getItem(STORE_KEY)
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr.slice(0, 30) : []
  } catch {
    return []
  }
}

export default function AiAssistant({ me }: { me: { fullName: string } }) {
  const [open, setOpen] = useState(false)
  const [convs, setConvs] = useState<AConv[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const [mode, setMode] = useState<'chat' | 'image'>('chat')
  const [webOn, setWebOn] = useState(false)
  const [attach, setAttach] = useState<string | null>(null)
  const [showHistory, setShowHistory] = useState(false)
  const [speakingId, setSpeakingId] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  // Nạp lịch sử sau khi mount (tránh lệch hydration)
  useEffect(() => {
    const list = loadConvs()
    setConvs(list)
    if (list.length > 0) setActiveId(list[0].id)
  }, [])

  // Mascot AI chạy quanh web bấm vào → mở ngay hộp trợ lý AI này
  useEffect(() => {
    const handler = () => setOpen(true)
    window.addEventListener('vx-open-ai-assistant', handler)
    return () => window.removeEventListener('vx-open-ai-assistant', handler)
  }, [])

  const active = convs.find((c) => c.id === activeId) || null
  const msgs = active?.msgs || []

  const saveConvs = useCallback((next: AConv[]) => {
    setConvs(next)
    try { localStorage.setItem(STORE_KEY, JSON.stringify(next.slice(0, 30))) } catch { /* đầy bộ nhớ, bỏ qua */ }
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [msgs.length, busy])

  const newConv = () => {
    setActiveId(null)
    setShowHistory(false)
    setAttach(null)
    setWebOn(false)
    setMode('chat')
  }

  const removeConv = (id: string) => {
    const next = convs.filter((c) => c.id !== id)
    saveConvs(next)
    if (activeId === id) setActiveId(next[0]?.id || null)
  }

  const pickAttach = (f: File | undefined) => {
    if (!f) return
    if (!f.type.startsWith('image/')) { return }
    if (f.size > 3_500_000) return
    const r = new FileReader()
    r.onload = () => setAttach(String(r.result))
    r.readAsDataURL(f)
  }

  const stopAudio = () => {
    audioRef.current?.pause()
    audioRef.current = null
    setSpeakingId(null)
  }

  const speak = async (idx: number) => {
    const m = msgs[idx]
    if (!m || m.role !== 'ai') return
    if (speakingId === String(idx)) { stopAudio(); return }
    stopAudio()
    setSpeakingId(String(idx))
    try {
      const src = m.audio || await (async () => {
        const res = await fetch('/api/tiai/voice', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: m.text.slice(0, 1000), voice: 'tongtong', speed: 1 }),
        })
        const d = await res.json()
        if (!res.ok || !d.audio) throw new Error('no audio')
        // Lưu vào hội thoại để phát lại không tốn lần gọi mới
        setConvs((cs) => {
          const next = cs.map((c) => (c.id === activeId ? { ...c, msgs: c.msgs.map((mm, i) => (i === idx ? { ...mm, audio: d.audio } : mm)) } : c))
          try { localStorage.setItem(STORE_KEY, JSON.stringify(next.slice(0, 30))) } catch { /* bỏ qua */ }
          return next
        })
        return d.audio as string
      })()
      const audio = new Audio(src)
      audioRef.current = audio
      audio.onended = () => setSpeakingId(null)
      await audio.play()
    } catch {
      setSpeakingId(null)
    }
  }

  const send = async (quickQ?: string) => {
    const q = (quickQ ?? text).trim()
    if ((!q && !attach) || busy) return
    stopAudio()

    const userMsg: AMsg = { role: 'user', text: q || 'Nhìn ảnh này giúp mình', image: attach || undefined }
    const nextMsgs: AMsg[] = [...msgs, userMsg]
    const convId = activeId || `c${Date.now()}`
    const nextConvs: AConv[] = [
      { id: convId, title: (q || 'Ảnh gửi AI').slice(0, 40), msgs: nextMsgs, at: Date.now() },
      ...convs.filter((c) => c.id !== convId),
    ]
    saveConvs(nextConvs)
    setActiveId(convId)
    setText('')
    const sentImage = attach
    setAttach(null)
    setBusy(true)

    try {
      let aiMsg: AMsg
      if (mode === 'image') {
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'image', prompt: q }) })
        const d = await res.json()
        aiMsg = res.ok
          ? { role: 'ai', text: `Ảnh minh họa cho "${q}", bấm giữ để tải về:`, image: d.image }
          : { role: 'ai', text: `Không tạo được ảnh: ${d.error || ''}`.trim() }
      } else if (sentImage) {
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'vision', text: q, image: sentImage }) })
        const d = await res.json()
        aiMsg = res.ok ? { role: 'ai', text: d.text } : { role: 'ai', text: `Không đọc được ảnh: ${d.error || ''}`.trim() }
      } else if (webOn) {
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'search', query: q }) })
        const d = await res.json()
        aiMsg = res.ok ? { role: 'ai', text: d.text, sources: d.sources || [] } : { role: 'ai', text: `Không tìm được: ${d.error || ''}`.trim() }
      } else {
        const history = nextMsgs.slice(-10).map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', content: m.text }))
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'chat', messages: history }) })
        const d = await res.json()
        aiMsg = res.ok ? { role: 'ai', text: d.text } : { role: 'ai', text: `AI đang bận: ${d.error || ''}`.trim() }
      }
      saveConvs(nextConvs.map((c) => (c.id === convId ? { ...c, msgs: [...c.msgs, aiMsg], at: Date.now() } : c)))
    } catch {
      saveConvs(nextConvs.map((c) => (c.id === convId ? { ...c, msgs: [...c.msgs, { role: 'ai', text: 'Không kết nối được máy chủ AI, thử lại giúp mình nhé.' }] } : c)))
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      {/* Nút nổi */}
      <button
        onClick={() => setOpen((o) => !o)}
        title="Vexon AI, trợ lý đa năng"
        aria-label="Mở trợ lý AI"
        className="fixed bottom-20 right-4 z-50 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-600/30 transition-transform hover:scale-105 lg:bottom-6"
      >
        {open ? <X className="h-5 w-5" /> : <Sparkles className="h-5 w-5" />}
      </button>

      {/* Khung chat */}
      {open && (
        <div className="fixed bottom-36 right-4 z-50 flex h-[min(72vh,600px)] w-[min(94vw,420px)] flex-col overflow-hidden rounded-2xl border bg-white shadow-2xl lg:bottom-24">
          {/* Header */}
          <div className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 px-3 py-2.5 text-white">
            <button onClick={() => setShowHistory((h) => !h)} className="rounded-lg p-1 transition hover:bg-white/20" title="Lịch sử trò chuyện" aria-label="Lịch sử trò chuyện">
              <History className="h-4 w-4" />
            </button>
            <Sparkles className="h-4 w-4" />
            <p className="flex-1 text-sm font-bold">Vexon AI</p>
            <a href="/chat" className="rounded-lg p-1 transition hover:bg-white/20" title="Mở trang Chatbot AI riêng (/chat)" aria-label="Mở trang Chatbot AI riêng">
              <Sparkles className="h-4 w-4" />
            </a>
            <button onClick={newConv} className="rounded-lg p-1 transition hover:bg-white/20" title="Cuộc trò chuyện mới" aria-label="Cuộc trò chuyện mới">
              <Plus className="h-4 w-4" />
            </button>
            <button onClick={() => setOpen(false)} aria-label="Đóng trợ lý AI" className="rounded-lg p-1 transition hover:bg-white/20">
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Lịch sử hội thoại (overlay) */}
          {showHistory && (
            <div className="absolute inset-x-0 top-12 bottom-0 z-10 flex flex-col border-t bg-white">
              <div className="flex items-center gap-2 border-b px-3 py-2">
                <button onClick={() => setShowHistory(false)} className="rounded-lg p-1 text-stone-500 hover:bg-stone-100" aria-label="Đóng lịch sử"><ChevronLeft className="h-4 w-4" /></button>
                <p className="flex-1 text-sm font-bold">Lịch sử trò chuyện</p>
                <button onClick={newConv} className="rounded-lg bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 hover:bg-emerald-100">+ Mới</button>
              </div>
              <div className="flex-1 overflow-y-auto p-2">
                {convs.length === 0 ? (
                  <p className="py-10 text-center text-xs text-stone-400">Chưa có cuộc trò chuyện nào</p>
                ) : (
                  convs.map((c) => (
                    <div key={c.id} className={`group flex items-center gap-2 rounded-lg px-2.5 py-2 transition ${activeId === c.id ? 'bg-emerald-50' : 'hover:bg-stone-50'}`}>
                      <button onClick={() => { setActiveId(c.id); setShowHistory(false) }} className="min-w-0 flex-1 text-left">
                        <p className="truncate text-sm font-medium">{c.title || 'Cuộc trò chuyện'}</p>
                        <p className="text-[10px] text-stone-400">{c.msgs.length} tin, {new Date(c.at).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}</p>
                      </button>
                      <button onClick={() => removeConv(c.id)} className="rounded-lg p-1.5 text-stone-300 transition hover:bg-red-50 hover:text-red-500 group-hover:text-stone-400" aria-label={`Xóa ${c.title}`}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Tin nhắn */}
          <div className="flex-1 space-y-2.5 overflow-y-auto bg-stone-50 p-3">
            {msgs.length === 0 && (
              <div className="rounded-xl border border-emerald-100 bg-white p-3 text-sm text-stone-600">
                <p className="font-semibold text-emerald-700">Xin chào {me.fullName}!</p>
                <p className="mt-1 text-xs leading-relaxed">Mình là <b>Vexon AI</b>, chat mọi chủ đề, nhìn ảnh trả lời, vẽ ảnh minh họa, tìm tin tức web và đọc to câu trả lời. Chọn gợi ý nhanh bên dưới hoặc gõ câu hỏi nhé!</p>
              </div>
            )}
            {msgs.map((m, i) => (
              <div key={i} className={`max-w-[88%] rounded-xl px-3 py-2 text-sm ${m.role === 'user' ? 'ml-auto bg-emerald-600 text-white' : 'border bg-white text-stone-700'}`}>
                {m.image && (
                  <div className="mb-2">
                    <img src={m.image} alt="Ảnh trong hội thoại" className="max-h-48 rounded-lg" />
                    {m.role === 'ai' && (
                      <a href={m.image} download={`vexon-ai-${i}.png`} className="mt-1.5 inline-flex items-center gap-1 rounded-lg bg-emerald-50 px-2 py-1 text-[11px] font-semibold text-emerald-700 hover:bg-emerald-100">
                        <Download className="h-3 w-3" /> Tải ảnh
                      </a>
                    )}
                  </div>
                )}
                <p className="whitespace-pre-wrap">{m.text}</p>
                {m.sources && m.sources.length > 0 && (
                  <div className="mt-1.5 space-y-0.5 border-t border-stone-100 pt-1.5">
                    {m.sources.slice(0, 4).map((s, j) => (
                      <a key={j} href={s.url} target="_blank" rel="noreferrer" className="block truncate text-[11px] text-emerald-600 hover:underline"><Link2 className="mr-0.5 inline h-3 w-3" /> {s.name}</a>
                    ))}
                  </div>
                )}
                {m.role === 'ai' && m.text && (
                  <button onClick={() => speak(i)} className="mt-1.5 flex items-center gap-1 rounded-lg px-1.5 py-0.5 text-[11px] font-medium text-emerald-600 transition hover:bg-emerald-50" aria-label="Đọc to câu trả lời">
                    {speakingId === String(i) ? <Square className="h-3 w-3" /> : <Volume2 className="h-3 w-3" />} {speakingId === String(i) ? 'Dừng đọc' : 'Đọc to'}
                  </button>
                )}
              </div>
            ))}
            {busy && (
              <div className="flex w-24 items-center justify-center gap-1.5 rounded-xl border bg-white py-2 text-xs text-emerald-600">
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> AI đang soạn...
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Ảnh đính kèm */}
          {attach && (
            <div className="flex items-center gap-2 border-t bg-emerald-50/60 px-3 py-1.5">
              <img src={attach} alt="Ảnh đính kèm" className="h-10 w-10 rounded-lg object-cover" />
              <p className="flex-1 truncate text-xs text-emerald-700">Đã gắn ảnh, AI sẽ nhìn ảnh và trả lời</p>
              <button onClick={() => setAttach(null)} className="rounded-lg p-1 text-emerald-500 hover:bg-emerald-100" aria-label="Bỏ ảnh"><X className="h-3.5 w-3.5" /></button>
            </div>
          )}

          {/* Gợi ý nhanh */}
          <div className="flex gap-1 overflow-x-auto border-t bg-white px-2.5 py-1.5">
            {QUICK.map((q) => (
              <button key={q.label} onClick={() => { setMode('chat'); send(q.q) }} disabled={busy}
                className="shrink-0 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[11px] text-emerald-700 hover:bg-emerald-100">
                {q.icon} {q.label}
              </button>
            ))}
          </div>

          {/* Thanh công cụ chế độ */}
          <div className="flex items-center gap-1 border-t bg-white px-2.5 py-1.5">
            <button onClick={() => fileRef.current?.click()} className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-[11px] font-medium text-stone-600 transition hover:bg-emerald-50 hover:text-emerald-700" title="Gửi ảnh cho AI nhìn và trả lời">
              <ImagePlus className="h-4 w-4" /> Ảnh
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { pickAttach(e.target.files?.[0]); e.target.value = '' }} />
            </button>
            <button onClick={() => setMode(mode === 'image' ? 'chat' : 'image')} className={`flex items-center gap-1 rounded-lg px-2 py-1.5 text-[11px] font-medium transition ${mode === 'image' ? 'bg-emerald-600 text-white' : 'text-stone-600 hover:bg-emerald-50 hover:text-emerald-700'}`} title="Chế độ vẽ ảnh từ mô tả">
              <ImageIcon className="h-4 w-4" /> Vẽ ảnh
            </button>
            <button onClick={() => setWebOn(!webOn)} className={`flex items-center gap-1 rounded-lg px-2 py-1.5 text-[11px] font-medium transition ${webOn ? 'bg-sky-600 text-white' : 'text-stone-600 hover:bg-sky-50 hover:text-sky-700'}`} title="Tìm thông tin trên web">
              <Globe className="h-4 w-4" /> Web {webOn ? 'BẬT' : ''}
            </button>
          </div>

          {/* Nhập */}
          <form className="flex items-center gap-2 border-t bg-white p-2.5" onSubmit={(e) => { e.preventDefault(); send() }}>
            <Input value={text} onChange={(e) => setText(e.target.value)} placeholder={mode === 'image' ? 'Mô tả ảnh muốn vẽ...' : webOn ? 'Tìm gì trên web...' : 'Hỏi Vexon AI...'} aria-label="Nhập câu hỏi cho AI" className="h-9" />
            <Button type="submit" size="sm" className="h-9 bg-emerald-600 hover:bg-emerald-700" disabled={busy || (!text.trim() && !attach)} aria-label="Gửi câu hỏi">
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      )}
    </>
  )
}
