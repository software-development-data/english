'use client'

// ============ VEXON AI — TRANG CHATBOT RIÊNG (/chat) ============
// • Link riêng biệt: mở trực tiếp /chat không cần vào app
// • Tổng hợp mọi công cụ: chat đa chủ đề · nhìn ảnh trả lời · vẽ ảnh · tìm kiếm web + tổng hợp dữ liệu
// • Chế độ TỰ ĐỘNG: chỉ cần nhập câu lệnh — hệ thống tự nhận diện và xử lý
// • Một ví tiền USD chung cho cả mạng lưới Vexon (hiển thị cùng số dư với mạng xã hội & Công cụ AI)

import { useCallback, useEffect, useRef, useState } from 'react'
import { fmtXuWithUsd } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import {
  Sparkles, X, Send, Loader2, ImagePlus, ImageIcon, Globe, Volume2, Square,
  History, Plus, Trash2, Menu, Coins, Wand2, ArrowLeft, Zap, Search, Eye,
} from 'lucide-react'

interface AMsg { role: 'user' | 'ai'; text: string; image?: string; sources?: { url: string; name: string }[]; audio?: string }
interface AConv { id: string; title: string; msgs: AMsg[]; at: number }

const STORE_KEY = 'vexon-chatbot-convs-v1'

/** Bộ công cụ AI mà chatbot này tổng hợp — bấm là tự điền câu lệnh mẫu */
const CAPABILITIES = [
  { icon: '🎨', label: 'Vẽ ảnh AI', prompt: 'Vẽ ảnh: hoàng hôn trên biển có thuyền buồn, phong cách watercolor' },
  { icon: '🔍', label: 'Tìm kiếm & tổng hợp', prompt: 'Tìm kiếm: giá vàng hôm nay và nhận định thị trường' },
  { icon: '🖼️', label: 'Nhìn ảnh trả lời', prompt: '', hint: 'Bấm 📷 gắn ảnh rồi hỏi' },
  { icon: '✍️', label: 'Viết bài, caption', prompt: 'Viết giúp mình bài đăng giới thiệu quán cà phê mới mở, tone gần gũi, có emoji' },
  { icon: '🌍', label: 'Dịch thuật', prompt: 'Dịch sang tiếng Anh: "Cảm ơn bạn đã tin tưởng Vexon — đơn hàng sẽ giao trong 24 giờ."' },
  { icon: '📊', label: 'Phân tích & tóm tắt', prompt: 'Tóm tắt giúp mình các cách kiếm tiền vào ví trong Vexon theo gạch đầu dòng' },
  { icon: '💡', label: 'Tư vấn ý tưởng', prompt: 'Gợi ý 5 ý tưởng nội dung TikTok cho cửa hàng quần áo local brand' },
  { icon: '🧰', label: 'Mẹo dùng Vexon', prompt: 'Hướng dẫn mình cách dùng Công cụ AI và Nhóm trong Vexon' },
]

/** Nhận diện chế độ TỰ ĐỘNG từ câu lệnh */
function detectAuto(text: string, hasImage: boolean): 'vision' | 'image' | 'search' | 'chat' {
  const t = text.trim().toLowerCase()
  if (hasImage) return 'vision'
  if (/^(vẽ|ve\b|tạo ảnh|viet hoa|draw|generate image|make an image)/i.test(t) || /^vẽ ảnh/i.test(t)) return 'image'
  if (/(^tìm kiếm|^tim kiem|^tìm |^search |tin tức|tin tuc|giá .* hôm nay|thời tiết|tuổi|kết quả|xem ngay|kiểm tra giá)/i.test(t)) return 'search'
  return 'chat'
}

const AUTO_BADGE: Record<string, { icon: React.ReactNode; label: string; cls: string }> = {
  chat: { icon: <Sparkles className="h-3 w-3" />, label: 'Hội thoại', cls: 'bg-violet-100 text-violet-700' },
  image: { icon: <ImageIcon className="h-3 w-3" />, label: 'Vẽ ảnh', cls: 'bg-fuchsia-100 text-fuchsia-700' },
  search: { icon: <Search className="h-3 w-3" />, label: 'Tìm web', cls: 'bg-sky-100 text-sky-700' },
  vision: { icon: <Eye className="h-3 w-3" />, label: 'Nhìn ảnh', cls: 'bg-emerald-100 text-emerald-700' },
}

function loadConvs(): AConv[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = localStorage.getItem(STORE_KEY)
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr.slice(0, 40) : []
  } catch {
    return []
  }
}

export default function ChatBotPage() {
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho Chatbot AI
  const [me, setMe] = useState<{ fullName: string; coins: number } | null>(null)
  const [convs, setConvs] = useState<AConv[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const [mode, setMode] = useState<'auto' | 'chat' | 'image'>('auto')
  const [attach, setAttach] = useState<string | null>(null)
  const [webOn, setWebOn] = useState(false)
  const [showSidebar, setShowSidebar] = useState(false)
  const [speakingId, setSpeakingId] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  // Đăng nhập (nếu có) → chào tên + hiện ví tiền USD CHUNG của cả mạng lưới
  useEffect(() => {
    fetch('/api/vx/auth')
      .then((r) => r.json())
      .then((d) => d.user && setMe({ fullName: d.user.fullName, coins: d.user.coins ?? 0 }))
      .catch(() => {})
  }, [])

  useEffect(() => {
    const list = loadConvs()
    setConvs(list)
    if (list.length > 0) setActiveId(list[0].id)
  }, [])

  const active = convs.find((c) => c.id === activeId) || null
  const msgs = active?.msgs || []

  const saveConvs = useCallback((next: AConv[]) => {
    setConvs(next)
    try { localStorage.setItem(STORE_KEY, JSON.stringify(next.slice(0, 40))) } catch { /* đầy bộ nhớ — bỏ qua */ }
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [msgs.length, busy])

  const newConv = () => {
    setActiveId(null)
    setAttach(null)
    setWebOn(false)
    setMode('auto')
    setShowSidebar(false)
  }

  const removeConv = (id: string) => {
    const next = convs.filter((c) => c.id !== id)
    saveConvs(next)
    if (activeId === id) setActiveId(next[0]?.id || null)
  }

  const pickAttach = (f: File | undefined) => {
    if (!f) return
    if (!f.type.startsWith('image/')) return
    if (f.size > 3_500_000) return
    const r = new FileReader()
    r.onload = () => setAttach(String(r.result))
    r.readAsDataURL(f)
  }

  const stopAudio = () => {
    audioRef.current?.pause()
    audioRef.current = null
    setSpeakingId(null)
  }

  const speak = async (idx: number) => {
    const m = msgs[idx]
    if (!m || m.role !== 'ai') return
    if (speakingId === String(idx)) { stopAudio(); return }
    stopAudio()
    setSpeakingId(String(idx))
    try {
      const src = m.audio || await (async () => {
        const res = await fetch('/api/tiai/voice', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: m.text.slice(0, 1000), voice: 'tongtong', speed: 1 }),
        })
        const d = await res.json()
        if (!res.ok || !d.audio) throw new Error('no audio')
        return d.audio as string
      })()
      const audio = new Audio(src)
      audioRef.current = audio
      audio.onended = () => setSpeakingId(null)
      await audio.play()
    } catch {
      setSpeakingId(null)
    }
  }

  const send = async (quickQ?: string) => {
    const q = (quickQ ?? text).trim()
    if ((!q && !attach) || busy) return
    stopAudio()

    // Chế độ: tự động nhận diện hoặc dùng chế độ chọn sẵn
    const kind = mode === 'auto' ? detectAuto(q, Boolean(attach)) : attach ? 'vision' : mode === 'image' ? 'image' : webOn ? 'search' : 'chat'

    const userMsg: AMsg = { role: 'user', text: q || 'Nhìn ảnh này giúp mình 📷', image: attach || undefined }
    const nextMsgs: AMsg[] = [...msgs, userMsg]
    const convId = activeId || `c${Date.now()}`
    const nextConvs: AConv[] = [
      { id: convId, title: (q || 'Ảnh gửi AI').slice(0, 40), msgs: nextMsgs, at: Date.now() },
      ...convs.filter((c) => c.id !== convId),
    ]
    saveConvs(nextConvs)
    setActiveId(convId)
    setText('')
    const sentImage = attach
    setAttach(null)
    setBusy(true)

    try {
      let aiMsg: AMsg
      if (kind === 'image') {
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'image', prompt: q }) })
        const d = await res.json()
        aiMsg = res.ok
          ? { role: 'ai', text: `🖼️ Ảnh minh họa cho "${q}" — bấm giữ để tải về:`, image: d.image }
          : { role: 'ai', text: `⚠️ ${d.error || 'Không tạo được ảnh'}` }
      } else if (kind === 'vision' && sentImage) {
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'vision', text: q, image: sentImage }) })
        const d = await res.json()
        aiMsg = res.ok ? { role: 'ai', text: d.text } : { role: 'ai', text: `⚠️ ${d.error || 'Không đọc được ảnh'}` }
      } else if (kind === 'search') {
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'search', query: q }) })
        const d = await res.json()
        aiMsg = res.ok ? { role: 'ai', text: d.text, sources: d.sources || [] } : { role: 'ai', text: `⚠️ ${d.error || 'Không tìm được'}` }
      } else {
        const history = nextMsgs.slice(-10).map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', content: m.text }))
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'chat', messages: history }) })
        const d = await res.json()
        aiMsg = res.ok ? { role: 'ai', text: d.text } : { role: 'ai', text: `⚠️ ${d.error || 'AI đang bận'}` }
      }
      saveConvs(nextConvs.map((c) => (c.id === convId ? { ...c, msgs: [...c.msgs, aiMsg], at: Date.now() } : c)))
    } catch {
      saveConvs(nextConvs.map((c) => (c.id === convId ? { ...c, msgs: [...c.msgs, { role: 'ai' as const, text: '⚠️ Không kết nối được máy chủ AI, thử lại giúp mình nhé.' }] } : c)))
    } finally {
      setBusy(false)
    }
  }

  // Xem trước chế độ tự động đang nhận diện
  const previewKind = mode === 'auto' ? detectAuto(text, Boolean(attach)) : null

  const sidebar = (
    <div className="flex h-full w-72 flex-col border-r border-violet-100 bg-white">
      <div className="flex items-center justify-between border-b border-violet-100 p-3">
        <p className="flex items-center gap-1.5 text-sm font-bold text-violet-800"><History className="h-4 w-4" /> Lịch sử chat</p>
        <button onClick={newConv} className="rounded-lg bg-violet-50 px-2.5 py-1 text-xs font-semibold text-violet-700 hover:bg-violet-100" aria-label="Cuộc trò chuyện mới">+ Mới</button>
      </div>
      <div className="flex-1 overflow-y-auto p-2">
        {convs.length === 0 ? (
          <p className="py-10 text-center text-xs text-stone-400">Chưa có cuộc trò chuyện nào</p>
        ) : (
          convs.map((c) => (
            <div key={c.id} className={`group flex items-center gap-2 rounded-lg px-2.5 py-2 transition ${activeId === c.id ? 'bg-violet-50' : 'hover:bg-stone-50'}`}>
              <button onClick={() => { setActiveId(c.id); setShowSidebar(false) }} className="min-w-0 flex-1 text-left">
                <p className="truncate text-sm font-medium">{c.title || 'Cuộc trò chuyện'}</p>
                <p className="text-[10px] text-stone-400">{c.msgs.length} tin · {new Date(c.at).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}</p>
              </button>
              <button onClick={() => removeConv(c.id)} className="rounded-lg p-1.5 text-stone-300 transition hover:bg-red-50 hover:text-red-500 group-hover:text-stone-400" aria-label={`Xóa ${c.title}`}>
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))
        )}
      </div>
      <div className="border-t border-violet-100 p-3 text-[11px] leading-relaxed text-stone-500">
        <p className="font-semibold text-violet-700">Vexon AI tổng hợp mọi công cụ</p>
        <p>Chat · Vẽ ảnh · Nhìn ảnh · Tìm web · Đọc to — tất cả miễn phí.</p>
      </div>
    </div>
  )

  return (
    <div className="flex h-screen flex-col bg-stone-50">
      {/* Header riêng của trang chatbot */}
      <header className="sticky top-0 z-40 border-b border-violet-100 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-14 w-full max-w-6xl items-center justify-between gap-2 px-3 sm:px-5">
          <div className="flex items-center gap-2">
            <a href="/" className="rounded-lg p-2 text-stone-500 transition hover:bg-stone-100 hover:text-stone-800" title="Về Vexon" aria-label="Về Vexon">
              <ArrowLeft className="h-5 w-5" />
            </a>
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-600 shadow-lg shadow-violet-600/25">
              <Sparkles className="h-5 w-5 text-white" />
            </span>
            <span className="leading-tight">
              <span className="block text-sm font-extrabold tracking-wide text-violet-900 sm:text-base">VEXON AI · CHATBOT</span>
              <span className="hidden text-[10px] leading-tight text-stone-500 sm:block">Tổng hợp mọi công cụ — chỉ cần nhập câu lệnh, tự động xử lý</span>
            </span>
          </div>
          <div className="flex items-center gap-2">
            {/* Một ví tiền USD CHUNG cả mạng lưới — số dư giống hệt mạng xã hội & Công cụ AI */}
            <span
              className="flex h-9 items-center gap-1.5 whitespace-nowrap rounded-full border border-amber-300 bg-amber-50 px-3 text-sm font-bold text-amber-700"
              title="Một ví tiền USD duy nhất cho cả mạng lưới Vexon"
              aria-label={`Ví tiền chung: ${fmtXuWithUsd(me?.coins ?? 0, rate)}`}
            >
              <Coins className="h-4 w-4" />
              {fmtXuWithUsd(me?.coins ?? 0, rate)}
            </span>
            <button onClick={() => setShowSidebar((s) => !s)} className="rounded-lg p-2 text-stone-600 hover:bg-violet-50 lg:hidden" aria-label="Lịch sử trò chuyện">
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex w-full max-w-6xl flex-1 overflow-hidden">
        {/* Sidebar lịch sử — desktop */}
        <aside className="hidden lg:block">{sidebar}</aside>
        {/* Sidebar lịch sử — mobile drawer */}
        {showSidebar && (
          <div className="fixed inset-0 z-50 flex lg:hidden">
            <div className="flex-1 bg-black/40" onClick={() => setShowSidebar(false)} aria-hidden />
            <div className="h-full">{sidebar}</div>
          </div>
        )}

        {/* Khung chat chính */}
        <main className="flex min-w-0 flex-1 flex-col">
          {/* Tin nhắn */}
          <div className="flex-1 space-y-3 overflow-y-auto p-3 sm:p-5">
            {msgs.length === 0 && (
              <div className="mx-auto max-w-2xl space-y-4">
                <div className="rounded-2xl border border-violet-100 bg-white p-5 shadow-sm">
                  <p className="flex items-center gap-2 text-lg font-bold text-violet-800"><Sparkles className="h-5 w-5" /> Xin chào {me?.fullName || 'bạn'}! 👋</p>
                  <p className="mt-1.5 text-sm leading-relaxed text-stone-600">
                    Mình là <b>Vexon AI</b> — chatbot tổng hợp mọi công cụ của mạng lưới Vexon. Chỉ cần nhập câu lệnh, mình <b>tự động xử lý</b>:
                    hội thoại mọi chủ đề, <b>vẽ ảnh</b>, <b>nhìn ảnh trả lời</b>, <b>tìm kiếm &amp; tổng hợp dữ liệu web</b>, viết bài, dịch thuật, phân tích — và <b>đọc to</b> câu trả lời. Hoàn toàn miễn phí!
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {CAPABILITIES.map((c) => (
                    <button
                      key={c.label}
                      onClick={() => { if (c.prompt) send(c.prompt) }}
                      className="flex flex-col items-start gap-1 rounded-xl border border-violet-100 bg-white p-3 text-left transition hover:border-violet-300 hover:shadow-sm"
                    >
                      <span className="text-xl">{c.icon}</span>
                      <span className="text-xs font-bold text-stone-700">{c.label}</span>
                      <span className="text-[10px] leading-snug text-stone-400">{c.hint || c.prompt.slice(0, 46) + '…'}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            {msgs.map((m, i) => (
              <div key={i} className={`mx-auto max-w-3xl ${m.role === 'user' ? 'flex justify-end' : ''}`}>
                <div className={`max-w-[88%] rounded-2xl px-4 py-2.5 text-sm shadow-sm ${m.role === 'user' ? 'bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white' : 'border bg-white text-stone-700'}`}>
                  {m.image && (
                    <div className="mb-2">
                      <img src={m.image} alt="Ảnh trong hội thoại" className="max-h-56 rounded-xl" />
                      {m.role === 'ai' && (
                        <a href={m.image} download={`vexon-ai-${i}.png`} className="mt-1.5 inline-flex items-center gap-1 rounded-lg bg-violet-50 px-2 py-1 text-[11px] font-semibold text-violet-700 hover:bg-violet-100">
                          ⬇ Tải ảnh
                        </a>
                      )}
                    </div>
                  )}
                  <p className="whitespace-pre-wrap">{m.text}</p>
                  {m.sources && m.sources.length > 0 && (
                    <div className="mt-2 space-y-0.5 border-t border-stone-100 pt-2">
                      <p className="text-[10px] font-bold uppercase tracking-wide text-stone-400">Nguồn tổng hợp</p>
                      {m.sources.slice(0, 6).map((s, j) => (
                        <a key={j} href={s.url} target="_blank" rel="noreferrer" className="block truncate text-[11px] text-violet-600 hover:underline">🔗 {s.name}</a>
                      ))}
                    </div>
                  )}
                  {m.role === 'ai' && m.text && (
                    <button onClick={() => speak(i)} className="mt-1.5 flex items-center gap-1 rounded-lg px-1.5 py-0.5 text-[11px] font-medium text-violet-600 transition hover:bg-violet-50" aria-label="Đọc to câu trả lời">
                      {speakingId === String(i) ? <Square className="h-3 w-3" /> : <Volume2 className="h-3 w-3" />} {speakingId === String(i) ? 'Dừng đọc' : 'Đọc to'}
                    </button>
                  )}
                </div>
              </div>
            ))}
            {busy && (
              <div className="mx-auto flex w-fit items-center gap-1.5 rounded-full border bg-white px-3 py-1.5 text-xs text-violet-600 shadow-sm">
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> Vexon AI đang tổng hợp & xử lý…
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Ảnh đính kèm */}
          {attach && (
            <div className="mx-auto flex w-full max-w-3xl items-center gap-2 px-3 pb-1">
              <div className="flex flex-1 items-center gap-2 rounded-xl border border-violet-200 bg-violet-50/70 px-3 py-1.5">
                <img src={attach} alt="Ảnh đính kèm" className="h-10 w-10 rounded-lg object-cover" />
                <p className="flex-1 truncate text-xs text-violet-700">Đã gắn ảnh — AI sẽ nhìn ảnh và trả lời</p>
                <button onClick={() => setAttach(null)} className="rounded-lg p-1 text-violet-500 hover:bg-violet-100" aria-label="Bỏ ảnh"><X className="h-3.5 w-3.5" /></button>
              </div>
            </div>
          )}

          {/* Thanh chế độ */}
          <div className="mx-auto w-full max-w-3xl px-3">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5">
              <button
                onClick={() => { setMode('auto'); setWebOn(false) }}
                className={`flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${mode === 'auto' ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow' : 'border bg-white text-stone-600 hover:bg-violet-50'}`}
                title="Tự động nhận diện câu lệnh: chat · vẽ ảnh · tìm web · nhìn ảnh"
                aria-label="Chế độ tự động"
              >
                <Zap className="h-3.5 w-3.5" /> Tự động {previewKind ? `→ ${AUTO_BADGE[previewKind].label}` : ''}
              </button>
              <button
                onClick={() => { setMode('chat'); setWebOn(false) }}
                className={`flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${mode === 'chat' && !webOn ? 'bg-violet-600 text-white' : 'border bg-white text-stone-600 hover:bg-violet-50'}`}
                aria-label="Chế độ hội thoại"
              >
                <Sparkles className="h-3.5 w-3.5" /> Chat
              </button>
              <button
                onClick={() => { setMode('image'); setWebOn(false) }}
                className={`flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${mode === 'image' ? 'bg-fuchsia-600 text-white' : 'border bg-white text-stone-600 hover:bg-fuchsia-50'}`}
                aria-label="Chế độ vẽ ảnh"
              >
                <ImageIcon className="h-3.5 w-3.5" /> Vẽ ảnh
              </button>
              <button
                onClick={() => { setMode('chat'); setWebOn(!webOn) }}
                className={`flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${webOn ? 'bg-sky-600 text-white' : 'border bg-white text-stone-600 hover:bg-sky-50'}`}
                title="Tìm thông tin thực trên web rồi tổng hợp trả lời"
                aria-label="Bật tìm kiếm web"
              >
                <Globe className="h-3.5 w-3.5" /> Web {webOn ? 'BẬT' : ''}
              </button>
              <button
                onClick={() => fileRef.current?.click()}
                className="flex shrink-0 items-center gap-1 rounded-full border bg-white px-3 py-1.5 text-[11px] font-bold text-stone-600 transition hover:bg-emerald-50 hover:text-emerald-700"
                title="Gửi ảnh cho AI nhìn và trả lời"
                aria-label="Gắn ảnh cho AI nhìn"
              >
                <ImagePlus className="h-3.5 w-3.5" /> Gắn ảnh
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { pickAttach(e.target.files?.[0]); e.target.value = '' }} />
              </button>
              <a href="/" className="ml-auto flex shrink-0 items-center gap-1 rounded-full border bg-white px-3 py-1.5 text-[11px] font-bold text-stone-500 transition hover:bg-stone-100" title="Mở Công cụ AI đầy đủ trong Vexon">
                <Wand2 className="h-3.5 w-3.5" /> Công cụ AI
              </a>
            </div>
          </div>

          {/* Ô nhập câu lệnh */}
          <form className="mx-auto w-full max-w-3xl p-3 pt-1" onSubmit={(e) => { e.preventDefault(); send() }}>
            <div className="flex items-center gap-2 rounded-2xl border border-violet-200 bg-white p-2 shadow-sm focus-within:border-violet-400">
              <Input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder={mode === 'image' ? 'Mô tả ảnh muốn vẽ…' : 'Nhập câu lệnh — Vexon AI tự động xử lý…'}
                aria-label="Nhập câu lệnh cho Vexon AI"
                className="h-10 border-0 bg-transparent text-sm focus-visible:ring-0"
              />
              <Button type="submit" size="icon" className="h-10 w-10 shrink-0 rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500" disabled={busy || (!text.trim() && !attach)} aria-label="Gửi câu lệnh">
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <p className="mt-1.5 text-center text-[10px] text-stone-400">Vexon AI · Chatbot tổng hợp công cụ của mạng lưới Vexon — miễn phí, một ví tiền USD chung</p>
          </form>
        </main>
      </div>
    </div>
  )
}
