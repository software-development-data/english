'use client'

// ============ FANPAGE (TRANG) KIỂU FACEBOOK ============
// Trang khác trang cá nhân: danh mục, người theo dõi, ảnh bìa/đại diện,
// đăng bài với tư cách Trang. API: /api/vx/pages

import { useCallback, useEffect, useRef, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { compressImage } from '@/lib/image-compress'
import type { VxUserInfo } from './AuthView'
import { Avatar, timeAgo, RichContent } from './shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import BusinessUpgradeCard from './BusinessUpgradeCard'
import {
  Flag, Plus, Globe, ArrowLeft, Loader2, Users2, Camera, ImagePlus, Search, Heart, MessageCircle,
  ThumbsUp, Share2, Trash2, Pencil, BadgeCheck, Store, Megaphone, X, PawPrint } from 'lucide-react'

interface PageT {
  id: string; name: string; category: string; bio: string | null
  avatar: string | null; cover: string | null; verified: boolean
  owner: { id: string; fullName: string; avatarColor: string }
  petSpecies?: string | null; petBreed?: string | null; petGender?: string | null; petBirthday?: string | null
  followerCount: number; postCount: number
  isOwner: boolean; isFollowing: boolean; createdAt: string
}
interface PageDetailT extends PageT {
  petSpecies?: string | null; petBreed?: string | null; petGender?: string | null; petBirthday?: string | null
  posts: {
    id: string; content: string; images: string[]; createdAt: string
    reactions: Record<string, number>; commentCount: number
    comments: { id: string; content: string; user: { fullName: string; avatarColor: string }; createdAt: string }[]
  }[]
}

const CATEGORIES = [
  'Doanh nghiệp địa phương', 'Cửa hàng bán lẻ', 'Ẩm thực & Nhà hàng',
  'Thương hiệu thời trang', 'Công nghệ & Điện tử', 'Mỹ phẩm & Làm đẹp',
  'Dịch vụ & Sửa chữa', 'Giáo dục & Đào tạo', 'Nông sản & đặc sản', 'Người sáng tạo nội dung',
  'Thú cưng',
]
const PET_SPECIES = ['Chó', 'Mèo', 'Chim', 'Cá', 'Bò sát', 'Hamster', 'Khác']
const PET_GENDERS = ['Đực', 'Cái']

// Danh mục Thú cưng → trang cá nhân riêng cho pet kiểu fanpage (mạng xã hội phụ cho thú cưng)
const isPetPage = (category: string) => category === 'Thú cưng'

// Icon nhóm: ảnh đại diện Trang nếu có, không thì chữ cái nền emerald (trang thú cưng → chân thú cưng nền hổ phách)
function PageAvatar({ page, size = 44 }: { page: { name: string; avatar?: string | null; category?: string | null }; size?: number }) {
  if (page.avatar) {
    return <img src={page.avatar} alt={page.name} style={{ width: size, height: size }} className="shrink-0 rounded-xl border-2 border-white object-cover shadow" />
  }
  if (page.category === 'Thú cưng') {
    return (
      <span style={{ width: size, height: size }}
        className="flex shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow">
        <PawPrint style={{ width: size * 0.5, height: size * 0.5 }} />
      </span>
    )
  }
  return (
    <span style={{ width: size, height: size, fontSize: size * 0.42 }}
      className="flex shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 font-black text-white shadow">
      {page.name.charAt(0).toUpperCase()}
    </span>
  )
}

export default function PagesView({ me, focusPageId, onConsumedFocus }: { me: VxUserInfo; focusPageId?: string | null; onConsumedFocus?: () => void }) {
  const [tab, setTab] = useState<'mine' | 'discover'>('mine')
  const [mine, setMine] = useState<PageT[]>([])
  const [discover, setDiscover] = useState<PageT[]>([])
  const [loading, setLoading] = useState(true)
  const [activeId, setActiveId] = useState<string | null>(null)
  const [detail, setDetail] = useState<PageDetailT | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [createOpen, setCreateOpen] = useState(false)
  const [q, setQ] = useState('')

  const load = useCallback(() => {
    setLoading(true)
    fetch('/api/vx/pages')
      .then((r) => r.json())
      .then((d) => {
        if (Array.isArray(d.mine)) setMine(d.mine)
        if (Array.isArray(d.discover)) setDiscover(d.discover)
      })
      .catch(() => toast.error('Không tải được Trang'))
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(() => load(), [load])

  const openDetail = useCallback((id: string) => {
    setActiveId(id)
    setDetailLoading(true)
    setDetail(null)
    fetch(`/api/vx/pages/${id}`)
      .then((r) => r.json())
      .then((d) => { if (d?.id) setDetail(d); else toast.error(d?.error || 'Không mở được Trang') })
      .catch(() => toast.error('Không mở được Trang'))
      .finally(() => setDetailLoading(false))
  }, [])

  // Mở TRANG THÚ CƯNG trực tiếp khi bấm thẻ pet ở tab Giới thiệu (hồ sơ → trang pet)
  useEffect(() => {
    if (focusPageId) {
      openDetail(focusPageId)
      onConsumedFocus?.()
    }
  }, [focusPageId, openDetail, onConsumedFocus])

  const toggleFollow = async (p: PageT) => {
    const res = await fetch(`/api/vx/pages/${p.id}/follow`, { method: 'POST' }).catch(() => null)
    if (!res || !res.ok) { toast.error('Không theo dõi được Trang'); return }
    const d = await res.json()
    const patch = (x: PageT) => (x.id === p.id ? { ...x, isFollowing: d.following, followerCount: d.followerCount } : x)
    setMine((ms) => ms.map(patch))
    setDiscover((ds) => ds.map(patch))
    if (detail?.id === p.id) setDetail((dd) => (dd ? { ...dd, isFollowing: d.following, followerCount: d.followerCount } : dd))
    toast.success(d.following ? `Đã theo dõi "${p.name}"` : `Đã bỏ theo dõi "${p.name}"`)
  }

  if (activeId) {
    return (
      <PageDetailView
        me={me} detail={detail} loading={detailLoading}
        onBack={() => { setActiveId(null); setDetail(null); load() }}
        onToggleFollow={() => detail && toggleFollow(detail)}
        onRefresh={() => openDetail(activeId)}
        onDeleted={() => { setActiveId(null); setDetail(null); load() }}
      />
    )
  }

  const list = (tab === 'mine' ? mine : discover).filter((p) => p.name.toLowerCase().includes(q.toLowerCase()))

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-xl font-black text-stone-800"><Flag className="h-5 w-5 text-emerald-600" /> Trang</h1>
          <p className="text-sm text-muted-foreground">Fanpage riêng cho cửa hàng, thương hiệu, khác trang cá nhân</p>
        </div>
        <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => setCreateOpen(true)}><Plus className="mr-1 h-4 w-4" /> Tạo trang</Button>
      </div>

      {/* Trang doanh nghiệp: tài khoản cá nhân cần nâng cấp doanh nghiệp để mở Trang chính thức */}
      <BusinessUpgradeCard me={me} banner />

      <div className="flex items-center gap-2">
        <div className="flex rounded-lg border bg-white p-1">
          {(['mine', 'discover'] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)}
              className={`rounded-md px-3.5 py-1.5 text-sm font-medium transition-colors ${tab === t ? 'bg-emerald-600 text-white shadow' : 'text-stone-600 hover:bg-emerald-50'}`}>
              {t === 'mine' ? 'Trang của tôi' : 'Khám phá'}
            </button>
          ))}
        </div>
        <div className="relative max-w-64 flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-stone-400" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm trang..." className="pl-8" aria-label="Tìm trang" />
        </div>
      </div>

      {loading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-48 rounded-xl" />)}
        </div>
      ) : list.length === 0 ? (
        <div className="rounded-xl border border-dashed bg-white p-10 text-center">
          <Flag className="mx-auto h-10 w-10 text-stone-300" />
          <p className="mt-2 text-sm text-muted-foreground">
            {tab === 'mine' ? 'Bạn chưa có Trang nào, tạo Trang để bán hàng, xây thương hiệu!' : 'Chưa có Trang nào để khám phá'}
          </p>
          {tab === 'mine' && (
            <Button size="sm" className="mt-3 bg-emerald-600 hover:bg-emerald-700" onClick={() => setCreateOpen(true)}><Plus className="mr-1 h-4 w-4" /> Tạo trang</Button>
          )}
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((p) => (
            <div key={p.id} className="overflow-hidden rounded-xl border bg-white shadow-sm transition-shadow hover:shadow-md">
              <button className="block w-full text-left" onClick={() => openDetail(p.id)} aria-label={`Mở trang ${p.name}`}>
                <div className="flex h-20 items-end bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600">
                  {p.cover
                    ? <img src={p.cover} alt="" className="h-full w-full object-cover" />
                    : isPetPage(p.category)
                      ? <span className="flex h-full items-center gap-2 px-4 text-2xl font-black text-white/90"><PawPrint className="h-7 w-7" /> Thú cưng</span>
                      : <span className="flex h-full items-center gap-2 px-4 text-2xl font-black text-white/90"><Store className="h-7 w-7" /> {p.category}</span>}
                </div>
                <div className="flex items-end gap-2.5 px-3 pb-2">
                  <span className="-mt-6"><PageAvatar page={p} size={52} /></span>
                  <span className="flex min-w-0 flex-1 items-center gap-1 pb-0.5">
                    <p className="truncate font-bold text-stone-800">{p.name}</p>
                    {p.verified && <BadgeCheck className="h-4 w-4 shrink-0 text-sky-500" />}
                  </span>
                </div>
              </button>
              <div className="px-3 pb-3">
                <p className="line-clamp-1 text-xs text-muted-foreground">{isPetPage(p.category) ? [p.petSpecies, p.petBreed].filter(Boolean).join(' · ') || 'Thú cưng' : p.category}</p>
                <p className="mt-0.5 text-xs text-stone-500">{p.followerCount} người theo dõi, {p.postCount} bài</p>
                <div className="mt-2.5 flex gap-2">
                  {p.isOwner ? (
                    <Button size="sm" variant="outline" className="h-8 flex-1" onClick={() => openDetail(p.id)}>Quản lý Trang</Button>
                  ) : (
                    <Button size="sm" className={`h-8 flex-1 ${p.isFollowing ? '' : 'bg-emerald-600 hover:bg-emerald-700'}`}
                      variant={p.isFollowing ? 'outline' : 'default'} onClick={() => toggleFollow(p)}>
                      {p.isFollowing ? 'Đang theo dõi' : '+ Theo dõi'}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <CreatePageDialog open={createOpen} onOpenChange={setCreateOpen}
        onCreated={(id) => { setCreateOpen(false); load(); openDetail(id) }} />
    </div>
  )
}

// ============ CHI TIẾT TRANG — bìa + avatar + đăng bài với tư cách Trang ============
function PageDetailView({ me, detail, loading, onBack, onToggleFollow, onRefresh, onDeleted }: {
  me: VxUserInfo; detail: PageDetailT | null; loading: boolean
  onBack: () => void; onToggleFollow: () => void; onRefresh: () => void; onDeleted: () => void
}) {
  const [content, setContent] = useState('')
  const [images, setImages] = useState<string[]>([])
  const [posting, setPosting] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  const [form, setForm] = useState({ name: '', category: '', bio: '', petSpecies: '', petBreed: '', petGender: '', petBirthday: '' })
  const [saving, setSaving] = useState(false)
  const avatarInputRef = useRef<HTMLInputElement>(null)
  const coverInputRef = useRef<HTMLInputElement>(null)

  const pickImage = async (file: File | undefined, target: 'post' | 'avatar' | 'cover') => {
    if (!file) return
    if (file.size > 6_000_000) { toast.error('Ảnh quá lớn (tối đa ~6MB trước khi nén)'); return }
    try {
      const url = await compressImage(file, target === 'avatar' ? 512 : 1280)
      if (target === 'post') { setImages((xs) => [...xs, url].slice(0, 4)); return }
      if (!detail) return
      const res = await fetch(`/api/vx/pages/${detail.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(target === 'avatar' ? { avatar: url } : { cover: url }),
      })
      if (!res.ok) throw new Error('Không lưu được ảnh')
      toast.success(target === 'avatar' ? 'Đã đổi ảnh đại diện Trang' : 'Đã đổi ảnh bìa Trang')
      onRefresh()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không tải được ảnh')
    }
  }

  const submitPost = async () => {
    if (!detail || (!content.trim() && images.length === 0)) return
    setPosting(true)
    try {
      const res = await fetch('/api/vx/posts', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: content.trim(), images, pageId: detail.id, visibility: 'public' }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      setContent(''); setImages([])
      toast.success(`Đã đăng bài với tư cách "${detail.name}"`)
      if (d.reward > 0) window.dispatchEvent(new Event('vx-coins-changed'))
      onRefresh()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không đăng được')
    } finally { setPosting(false) }
  }

  const saveInfo = async () => {
    if (!detail) return
    if (!form.name.trim()) { toast.error('Tên Trang không được trống'); return }
    setSaving(true)
    try {
      const res = await fetch(`/api/vx/pages/${detail.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name.trim(), category: form.category, bio: form.bio.trim() || null,
          petSpecies: isPetPage(form.category) ? form.petSpecies.trim() || null : null,
          petBreed: isPetPage(form.category) ? form.petBreed.trim() || null : null,
          petGender: isPetPage(form.category) ? form.petGender.trim() || null : null,
          petBirthday: isPetPage(form.category) ? form.petBirthday.trim() || null : null,
        }),
      })
      if (!res.ok) throw new Error('Không lưu được')
      toast.success('Đã cập nhật Trang')
      setEditOpen(false)
      onRefresh()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không lưu được')
    } finally { setSaving(false) }
  }

  const like = async (postId: string) => {
    await fetch(`/api/vx/posts/${postId}/like`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'LIKE' }) }).catch(() => {})
    onRefresh()
  }

  const deletePage = async () => {
    if (!detail || !window.confirm(`Xoá Trang "${detail.name}" cùng toàn bộ bài đăng?`)) return
    const res = await fetch(`/api/vx/pages/${detail.id}`, { method: 'DELETE' })
    if (!res.ok) { toast.error('Không xoá được Trang'); return }
    toast.success('Đã xoá Trang')
    onDeleted()
  }

  if (loading || !detail) {
    return (
      <div className="space-y-3">
        <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="mr-1 h-4 w-4" /> Trang</Button>
        <Skeleton className="h-44 rounded-xl" />
        <Skeleton className="h-64 rounded-xl" />
      </div>
    )
  }

  const startEdit = () => {
    setForm({ name: detail.name, category: detail.category, bio: detail.bio || '', petSpecies: detail.petSpecies || '', petBreed: detail.petBreed || '', petGender: detail.petGender || '', petBirthday: detail.petBirthday || '' })
    setEditOpen(true)
  }

  return (
    <div className="space-y-4">
      <Button variant="ghost" size="sm" onClick={onBack} aria-label="Về danh sách trang"><ArrowLeft className="mr-1 h-4 w-4" /> Tất cả trang</Button>

      {/* Bìa Trang kiểu Facebook */}
      <div className="overflow-hidden rounded-xl border bg-white shadow-sm">
        <div className="group relative h-36 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 sm:h-44">
          {detail.cover && <img src={detail.cover} alt="Ảnh bìa trang" className="h-full w-full object-cover" />}
          {detail.isOwner && (
            <>
              <button onClick={() => coverInputRef.current?.click()}
                className="absolute bottom-2.5 right-2.5 flex items-center gap-1.5 rounded-full bg-black/45 px-3 py-1.5 text-xs font-medium text-white opacity-0 backdrop-blur transition-opacity group-hover:opacity-100"
                aria-label="Đổi ảnh bìa trang">
                <Camera className="h-3.5 w-3.5" /> Sửa ảnh bìa
              </button>
              <input ref={coverInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => { pickImage(e.target.files?.[0], 'cover'); e.target.value = '' }} />
            </>
          )}
        </div>

        <div className="px-5 pb-4">
          <div className="-mt-10 flex flex-wrap items-end justify-between gap-3">
            <div className="relative">
              <PageAvatar page={detail} size={84} />
              {detail.isOwner && (
                <>
                  <button onClick={() => avatarInputRef.current?.click()} title="Đổi ảnh đại diện Trang"
                    className="absolute -bottom-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full bg-emerald-600 text-white shadow hover:bg-emerald-700" aria-label="Đổi ảnh đại diện trang">
                    <Camera className="h-4 w-4" />
                  </button>
                  <input ref={avatarInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => { pickImage(e.target.files?.[0], 'avatar'); e.target.value = '' }} />
                </>
              )}
            </div>
            <div className="flex gap-2 pb-1">
              {detail.isOwner ? (
                <>
                  <Button size="sm" variant="outline" onClick={startEdit}><Pencil className="mr-1 h-3.5 w-3.5" /> Chỉnh sửa Trang</Button>
                  <Button size="sm" variant="outline" className="text-rose-600 hover:bg-rose-50" onClick={deletePage} aria-label="Xóa trang"><Trash2 className="h-3.5 w-3.5" /></Button>
                </>
              ) : (
                <Button size="sm" className={detail.isFollowing ? '' : 'bg-emerald-600 hover:bg-emerald-700'}
                  variant={detail.isFollowing ? 'outline' : 'default'} onClick={onToggleFollow}>
                  {detail.isFollowing ? 'Đang theo dõi' : '+ Theo dõi'}
                </Button>
              )}
            </div>
          </div>

          <h1 className="mt-2 flex flex-wrap items-center gap-2 text-xl font-black text-stone-800">
            {detail.name}
            {detail.verified && <span className="flex items-center gap-1 rounded-full bg-sky-50 px-2 py-0.5 text-[11px] font-semibold text-sky-600"><BadgeCheck className="h-3.5 w-3.5" /> Đã xác minh</span>}
            {isPetPage(detail.category) && <span className="flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-semibold text-amber-700"><PawPrint className="h-3 w-3" /> Trang thú cưng</span>}
          </h1>
          <p className="text-sm text-muted-foreground">{isPetPage(detail.category) ? `Trang cá nhân riêng cho thú cưng, ${detail.followerCount} người theo dõi, ${detail.posts.length} bài` : `${detail.category}, ${detail.followerCount} người theo dõi, ${detail.posts.length} bài`}</p>
          {/* Thông tin thú cưng: loài · giống · giới tính · sinh nhật — kiểu hồ sơ pet riêng */}
          {isPetPage(detail.category) && (detail.petSpecies || detail.petBreed || detail.petGender || detail.petBirthday) && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {detail.petSpecies && <Badge variant="secondary" className="bg-amber-50 text-amber-800 hover:bg-amber-50">Loài: {detail.petSpecies}</Badge>}
              {detail.petBreed && <Badge variant="secondary" className="bg-amber-50 text-amber-800 hover:bg-amber-50">Giống: {detail.petBreed}</Badge>}
              {detail.petGender && <Badge variant="secondary" className="bg-amber-50 text-amber-800 hover:bg-amber-50">Giới tính: {detail.petGender}</Badge>}
              {detail.petBirthday && <Badge variant="secondary" className="bg-amber-50 text-amber-800 hover:bg-amber-50">Sinh: {detail.petBirthday}</Badge>}
            </div>
          )}
          {detail.bio && <p className="mt-1.5 max-w-2xl text-sm text-stone-600">{detail.bio}</p>}
          <p className="mt-1 text-xs text-stone-400">Chủ Trang: {detail.owner.fullName}, Tạo {timeAgo(detail.createdAt)}</p>
        </div>
      </div>

      {/* Đăng bài với tư cách Trang */}
      {detail.isOwner && (
        <div className="rounded-xl border bg-white p-3 shadow-sm">
          <p className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-stone-400">
            <Megaphone className="h-3.5 w-3.5 text-emerald-600" /> Đăng với tư cách <span className="text-emerald-700">{detail.name}</span>
          </p>
          <Textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder={`${detail.name} đang có gì mới?`} rows={2} aria-label="Soạn bài đăng trang" />
          {images.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">
              {images.map((src, i) => (
                <div key={i} className="relative">
                  <img src={src} alt={`Ảnh ${i + 1}`} className="h-16 w-16 rounded-lg object-cover" />
                  <button onClick={() => setImages((xs) => xs.filter((_, j) => j !== i))} className="absolute -right-1.5 -top-1.5 rounded-full bg-rose-600 p-0.5 text-white" aria-label={`Bỏ ảnh ${i + 1}`}><X className="h-3 w-3" /></button>
                </div>
              ))}
            </div>
          )}
          <div className="mt-2 flex items-center justify-between">
            <label className="flex cursor-pointer items-center gap-1.5 text-sm text-stone-600 hover:text-emerald-700" aria-label="Thêm ảnh vào bài trang">
              <ImagePlus className="h-4 w-4" /> Ảnh
              <input type="file" accept="image/*" className="hidden" onChange={(e) => { pickImage(e.target.files?.[0], 'post'); e.target.value = '' }} />
            </label>
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={submitPost} disabled={posting || (!content.trim() && images.length === 0)}>
              {posting ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Share2 className="mr-1 h-4 w-4" />} Đăng bài
            </Button>
          </div>
        </div>
      )}

      {/* Bài đăng của Trang — hiển thị tác giả là Trang (khác trang cá nhân) */}
      <div className="space-y-3">
        {detail.posts.map((p) => {
          const totalReactions = Object.values(p.reactions).reduce((a, b) => a + b, 0)
          return (
            <article key={p.id} className="rounded-xl border bg-white p-4 shadow-sm">
              <div className="flex items-center gap-2.5">
                <PageAvatar page={detail} size={38} />
                <div className="min-w-0">
                  <p className="flex items-center gap-1 text-sm font-semibold">
                    {detail.name}
                    {detail.verified && <BadgeCheck className="h-3.5 w-3.5 text-sky-500" />}
                    {isPetPage(detail.category)
                      ? <span className="ml-1 inline-flex items-center gap-0.5 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-semibold text-amber-700"><PawPrint className="h-2.5 w-2.5" />Trang thú cưng</span>
                      : <span className="ml-1 rounded bg-stone-100 px-1.5 py-0.5 text-[10px] font-medium text-stone-500">Trang</span>}
                  </p>
                  <p className="text-[11px] text-stone-400">{timeAgo(p.createdAt)}</p>
                </div>
              </div>
              {p.content && <div className="mt-2 text-sm"><RichContent text={p.content} mentions={[]} /></div>}
              {p.images.length > 0 && (
                <div className={`mt-2 grid gap-1 ${p.images.length === 1 ? '' : 'grid-cols-2'}`}>
                  {p.images.map((src, i) => <img key={i} src={src} alt={`Ảnh ${i + 1}`} className="max-h-80 w-full rounded-lg bg-stone-100 object-contain" />)}
                </div>
              )}
              <div className="mt-3 flex items-center gap-4 border-t pt-2.5 text-sm text-stone-500">
                <button onClick={() => like(p.id)} className="flex items-center gap-1.5 hover:text-emerald-600" aria-label="Thích bài của trang">
                  <ThumbsUp className="h-4 w-4" /> {totalReactions || 'Thích'}
                </button>
                <span className="flex items-center gap-1.5"><MessageCircle className="h-4 w-4" /> {p.commentCount} bình luận</span>
              </div>
              {p.comments.length > 0 && (
                <div className="mt-2 space-y-1.5 rounded-lg bg-stone-50 p-2.5">
                  {p.comments.slice(-4).map((c) => (
                    <p key={c.id} className="text-xs"><b className="text-stone-700">{c.user.fullName}:</b> <span className="text-stone-600">{c.content}</span></p>
                  ))}
                </div>
              )}
            </article>
          )
        })}
        {detail.posts.length === 0 && (
          <p className="rounded-xl border border-dashed bg-white p-10 text-center text-sm text-muted-foreground">
            Trang chưa có bài đăng {detail.isOwner ? '— đăng bài đầu tiên nhé!' : ''}
          </p>
        )}
      </div>

      {/* Dialog chỉnh sửa Trang */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Pencil className="h-4 w-4 text-emerald-600" /> Chỉnh sửa Trang</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label htmlFor="pg-name">Tên Trang</Label>
              <Input id="pg-name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} aria-label="Tên trang" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="pg-cat">Danh mục</Label>
              <select id="pg-cat" value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm" aria-label="Danh mục trang">
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="pg-bio">Giới thiệu ngắn</Label>
              <Textarea id="pg-bio" value={form.bio} onChange={(e) => setForm((f) => ({ ...f, bio: e.target.value }))} rows={3} maxLength={300} placeholder="Trang này về điều gì?" aria-label="Giới thiệu trang" />
            </div>
            {/* Danh mục Thú cưng → thêm thông tin pet riêng (loài/giống/giới tính/sinh nhật) */}
            {isPetPage(form.category) && (
              <div className="space-y-2 rounded-xl border border-amber-200 bg-amber-50/60 p-3">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-amber-700"><PawPrint className="h-3.5 w-3.5" /> Thông tin thú cưng</p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label htmlFor="pg-species">Loài</Label>
                    <select id="pg-species" value={form.petSpecies} onChange={(e) => setForm((f) => ({ ...f, petSpecies: e.target.value }))}
                      className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm" aria-label="Loài thú cưng">
                      <option value="">— Chọn loài —</option>
                      {PET_SPECIES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="pg-breed">Giống</Label>
                    <Input id="pg-breed" value={form.petBreed} onChange={(e) => setForm((f) => ({ ...f, petBreed: e.target.value }))} placeholder="VD: Alaska, Tam Thể" aria-label="Giống thú cưng" />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="pg-gender">Giới tính</Label>
                    <select id="pg-gender" value={form.petGender} onChange={(e) => setForm((f) => ({ ...f, petGender: e.target.value }))}
                      className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm" aria-label="Giới tính thú cưng">
                      <option value="">— Chọn —</option>
                      {PET_GENDERS.map((g) => <option key={g} value={g}>{g}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="pg-birthday">Sinh nhật</Label>
                    <Input id="pg-birthday" type="date" value={form.petBirthday} onChange={(e) => setForm((f) => ({ ...f, petBirthday: e.target.value }))} aria-label="Sinh nhật thú cưng" />
                  </div>
                </div>
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setEditOpen(false)}>Huỷ</Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={saveInfo} disabled={saving}>
                {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : null} Lưu
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ DIALOG TẠO TRANG ============
function CreatePageDialog({ open, onOpenChange, onCreated }: { open: boolean; onOpenChange: (v: boolean) => void; onCreated: (id: string) => void }) {
  const [name, setName] = useState('')
  const [category, setCategory] = useState(CATEGORIES[0])
  const [bio, setBio] = useState('')
  const [petSpecies, setPetSpecies] = useState('')
  const [petBreed, setPetBreed] = useState('')
  const [petGender, setPetGender] = useState('')
  const [petBirthday, setPetBirthday] = useState('')
  const [avatar, setAvatar] = useState<string | null>(null)
  const [cover, setCover] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const avatarInputRef = useRef<HTMLInputElement>(null)
  const coverInputRef = useRef<HTMLInputElement>(null)

  const pick = async (file: File | undefined, target: 'avatar' | 'cover') => {
    if (!file) return
    if (file.size > 6_000_000) { toast.error('Ảnh quá lớn (tối đa ~6MB trước khi nén)'); return }
    try {
      const url = await compressImage(file, target === 'avatar' ? 512 : 1280)
      if (target === 'avatar') setAvatar(url)
      else setCover(url)
    } catch { toast.error('Không tải được ảnh') }
  }

  const create = async () => {
    if (!name.trim()) { toast.error('Nhập tên Trang'); return }
    setSaving(true)
    try {
      const res = await fetch('/api/vx/pages', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(), category, bio: bio.trim() || null, avatar, cover,
          petSpecies: isPetPage(category) ? petSpecies || null : null,
          petBreed: isPetPage(category) ? petBreed.trim() || null : null,
          petGender: isPetPage(category) ? petGender || null : null,
          petBirthday: isPetPage(category) ? petBirthday || null : null,
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success(`Đã tạo Trang "${name.trim()}"`)
      setName(''); setBio(''); setAvatar(null); setCover(null); setCategory(CATEGORIES[0]); setPetSpecies(''); setPetBreed(''); setPetGender(''); setPetBirthday('')
      onCreated(d.id)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không tạo được Trang')
    } finally { setSaving(false) }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
        <DialogHeader><DialogTitle className="flex items-center gap-2"><Flag className="h-4 w-4 text-emerald-600" /> Tạo Trang mới</DialogTitle></DialogHeader>
        <div className="space-y-3">
          {/* Ảnh bìa + avatar kiểu Facebook */}
          <div className="overflow-hidden rounded-xl border">
            <div className="group relative h-24 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600">
              {cover && <img src={cover} alt="" className="h-full w-full object-cover" />}
              <button onClick={() => coverInputRef.current?.click()}
                className="absolute bottom-2 right-2 flex items-center gap-1.5 rounded-full bg-black/45 px-2.5 py-1 text-xs font-medium text-white backdrop-blur transition-opacity hover:bg-black/60"
                aria-label="Chọn ảnh bìa trang">
                <Camera className="h-3.5 w-3.5" /> {cover ? 'Đổi ảnh bìa' : 'Thêm ảnh bìa'}
              </button>
              <input ref={coverInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => { pick(e.target.files?.[0], 'cover'); e.target.value = '' }} />
            </div>
            <div className="relative px-3 pb-3">
              <div className="relative -mt-7 w-fit">
                {avatar ? (
                  <img src={avatar} alt="" className="h-16 w-16 rounded-xl border-[3px] border-white object-cover shadow" />
                ) : (
                  <span className="flex h-16 w-16 items-center justify-center rounded-xl border-[3px] border-white bg-gradient-to-br from-emerald-500 to-teal-600 text-xl font-black text-white shadow">
                    {name.trim() ? name.trim().charAt(0).toUpperCase() : <Globe className="h-6 w-6" />}
                  </span>
                )}
                <button onClick={() => avatarInputRef.current?.click()} title="Thêm ảnh đại diện"
                  className="absolute -bottom-1 -right-1 flex h-7 w-7 items-center justify-center rounded-full bg-emerald-600 text-white shadow hover:bg-emerald-700" aria-label="Chọn ảnh đại diện trang">
                  <Camera className="h-3.5 w-3.5" />
                </button>
                <input ref={avatarInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => { pick(e.target.files?.[0], 'avatar'); e.target.value = '' }} />
              </div>
            </div>
          </div>

          <div className="space-y-1">
            <Label htmlFor="cpg-name">Tên Trang</Label>
            <Input id="cpg-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Tiệm bánh Hoa Vàng" aria-label="Tên trang mới" />
          </div>
          <div className="space-y-1">
            <Label htmlFor="cpg-cat">Danh mục</Label>
            <select id="cpg-cat" value={category} onChange={(e) => setCategory(e.target.value)}
              className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm" aria-label="Danh mục trang mới">
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="space-y-1">
            <Label htmlFor="cpg-bio">Giới thiệu ngắn</Label>
            <Textarea id="cpg-bio" value={bio} onChange={(e) => setBio(e.target.value)} rows={2} maxLength={300} placeholder={isPetPage(category) ? 'Ví dụ: Tôi là Milu, chuyên phá nhà và nịnh chủ...' : 'Trang này về điều gì?'} aria-label="Giới thiệu trang mới" />
          </div>
          {/* Danh mục Thú cưng → trang cá nhân riêng cho pet: thêm loài/giống/giới tính/sinh nhật */}
          {isPetPage(category) && (
            <div className="space-y-2 rounded-xl border border-amber-200 bg-amber-50/60 p-3">
              <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-amber-700"><PawPrint className="h-3.5 w-3.5" /> Thông tin thú cưng</p>
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <Label htmlFor="cpg-species">Loài</Label>
                  <select id="cpg-species" value={petSpecies} onChange={(e) => setPetSpecies(e.target.value)}
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm" aria-label="Loài thú cưng mới">
                    <option value="">— Chọn loài —</option>
                    {PET_SPECIES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <Label htmlFor="cpg-breed">Giống</Label>
                  <Input id="cpg-breed" value={petBreed} onChange={(e) => setPetBreed(e.target.value)} placeholder="VD: Alaska, Tam Thể" aria-label="Giống thú cưng mới" />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="cpg-gender">Giới tính</Label>
                  <select id="cpg-gender" value={petGender} onChange={(e) => setPetGender(e.target.value)}
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm" aria-label="Giới tính thú cưng mới">
                    <option value="">— Chọn —</option>
                    {PET_GENDERS.map((g) => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <Label htmlFor="cpg-birthday">Sinh nhật</Label>
                  <Input id="cpg-birthday" type="date" value={petBirthday} onChange={(e) => setPetBirthday(e.target.value)} aria-label="Sinh nhật thú cưng mới" />
                </div>
              </div>
              <p className="text-[11px] text-stone-500">Trang thú cưng hoạt động như một trang cá nhân riêng kiểu fanpage: đăng bài với tư cách pet, người khác theo dõi và thả tim.</p>
            </div>
          )}
          <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={create} disabled={saving || !name.trim()}>
            {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Plus className="mr-1 h-4 w-4" />} Tạo trang
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
