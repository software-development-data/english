'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Avatar } from './shared'
import type { VxUserInfo } from './AuthView'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import {
  Search, SlidersHorizontal, MapPin, Crosshair, Loader2, Eye, EyeOff, Clock, Zap, Sparkles,
  Hand, Send, UserPlus, MessageCircle, ChevronDown, Building2, X, RotateCw, Globe2,
} from 'lucide-react'

/**
 * TRANG CHỦ — Tìm kiếm người dùng toàn quốc (kiểu NearLink/Heesay gửi kèm file zip)
 * Tab: Gần đây · Online · Mới tham gia + Bộ lọc (tên · khoảng cách · độ tuổi · đang online)
 * Gộp thêm Radar cũ: GPS thật, ẩn/hiện vị trí, gửi lời chào (ping), kết bạn nhanh.
 */

interface Person {
  id: string
  fullName: string
  username: string
  avatarColor: string
  avatarImage: string | null
  bio: string | null
  hometown: string | null
  locationName: string | null
  department: string
  title: string
  accountType: string
  companyName: string | null
  age: number
  active: boolean
  online: boolean
  lastSeenMinutes: number
  statusText: string
  distanceKm: number | null
  distanceText: string
  isFriend: boolean
  pending: boolean
  isNew: boolean
}

interface Ping {
  id: string
  message: string
  createdAt: string
  from: { id: string; fullName: string; avatarColor: string }
}

const PING_MESSAGES = ['Xin chào! Mình tìm thấy bạn qua Vexon.', 'Rất vui được kết nối với bạn!', 'Bạn có rảnh trò chuyện không?']

type Tab = 'all' | 'online' | 'new'

export default function DiscoverView({ me, onMessage, onOpenProfile }: {
  me: VxUserInfo
  onMessage: (userId: string) => void
  onOpenProfile?: (userId: string) => void
}) {
  const { toast } = useToast()
  const [people, setPeople] = useState<Person[]>([])
  const [pings, setPings] = useState<Ping[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<Tab>('all')
  const [q, setQ] = useState('')
  const [showFilter, setShowFilter] = useState(false)
  const [openSection, setOpenSection] = useState<string | null>(null)
  const [ageMin, setAgeMin] = useState(0)
  const [ageMax, setAgeMax] = useState(99)
  const [distMax, setDistMax] = useState(2500) // 2500km ≈ cả nước — không giới hạn
  const [onlineOnly, setOnlineOnly] = useState(false)
  const [locating, setLocating] = useState(false)
  const [visible, setVisible] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [pingTarget, setPingTarget] = useState<Person | null>(null)
  const [pingMsg, setPingMsg] = useState(PING_MESSAGES[0])
  const watchRef = useRef<number | null>(null)

  const load = useCallback(async (opts?: { silent?: boolean }) => {
    if (!opts?.silent) setLoading(true)
    const p = new URLSearchParams({ tab, onlineOnly: onlineOnly ? '1' : '0' })
    if (q.trim()) p.set('q', q.trim())
    if (ageMin > 0) p.set('ageMin', String(ageMin))
    if (ageMax < 99) p.set('ageMax', String(ageMax))
    if (distMax < 2500) p.set('distMax', String(distMax))
    try {
      const [d1, d2] = await Promise.all([
        fetch(`/api/vx/discover?${p.toString()}`).then((r) => r.json()),
        fetch('/api/vx/nearby?radius=25').then((r) => r.json()).catch(() => ({})),
      ])
      if (Array.isArray(d1.people)) setPeople(d1.people)
      if (Array.isArray(d2.pings)) setPings(d2.pings)
      if (typeof d1.me?.locationVisible === 'boolean') setVisible(d1.me.locationVisible)
    } catch {
      /* giữ danh sách cũ */
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [tab, q, ageMin, ageMax, distMax, onlineOnly])

  useEffect(() => {
    const t = setTimeout(() => load(), 250) // debounce khi đổi bộ lọc
    return () => clearTimeout(t)
  }, [load])

  // Tự làm mới mỗi 60s — trạng thái online luôn tươi
  useEffect(() => {
    const t = setInterval(() => load({ silent: true }), 60000)
    return () => clearInterval(t)
  }, [load])

  const pushLocation = useCallback((lat: number, lng: number) => {
    return fetch('/api/vx/nearby', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ latitude: lat, longitude: lng }),
    })
  }, [])

  const locateMe = useCallback(() => {
    if (!('geolocation' in navigator)) {
      toast({ title: 'Trình duyệt không hỗ trợ định vị', variant: 'destructive' })
      return
    }
    setLocating(true)
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(false)
        pushLocation(pos.coords.latitude, pos.coords.longitude).then(() => {
          toast({ title: 'Đã bật GPS — hiện khoảng cách thật tới mọi người' })
          load({ silent: true })
        })
        if (watchRef.current == null) {
          watchRef.current = navigator.geolocation.watchPosition(
            (p) => pushLocation(p.coords.latitude, p.coords.longitude),
            () => {},
            { maximumAge: 60000, timeout: 30000 }
          )
        }
      },
      () => {
        setLocating(false)
        toast({ title: 'Không lấy được GPS — vẫn tìm được bạn bè toàn quốc' })
      },
      { enableHighAccuracy: true, timeout: 10000 }
    )
  }, [pushLocation, load, toast])

  const toggleVisible = async (v: boolean) => {
    setVisible(v)
    await fetch('/api/vx/nearby', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ locationVisible: v }),
    })
    toast({ title: v ? 'Đã HIỆN vị trí trên bản tìm kiếm' : 'Đã ẨN vị trí (chế độ riêng tư)' })
    load({ silent: true })
  }

  const sendPing = async () => {
    if (!pingTarget) return
    const res = await fetch('/api/vx/nearby', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ toUserId: pingTarget.id, message: pingMsg }),
    })
    if (res.ok) {
      toast({ title: `Đã gửi lời chào tới ${pingTarget.fullName}` })
      setPingTarget(null)
    } else toast({ title: 'Không gửi được lời chào', variant: 'destructive' })
  }

  const addFriend = async (userId: string) => {
    const res = await fetch('/api/vx/friends', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'request', userId }),
    })
    if (res.ok) {
      toast({ title: 'Đã gửi lời mời kết bạn' })
      setPeople((ps) => ps.map((u) => (u.id === userId ? { ...u, pending: true } : u)))
    } else toast({ title: 'Không gửi được lời mời', variant: 'destructive' })
  }

  const isDefaultFilter = ageMin === 0 && ageMax === 99 && distMax === 2500 && !onlineOnly && !q.trim()
  // r31: đếm người ĐANG HOẠT ĐỘNG thật (≤75s) — không tính người đã offline trong 30 phút
  const onlineCount = useMemo(() => people.filter((u) => u.active).length, [people])

  const TABS: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: 'all', label: 'Gần đây', icon: <Clock className="h-4 w-4" /> },
    { key: 'online', label: 'Online', icon: <Zap className="h-4 w-4" /> },
    { key: 'new', label: 'Mới tham gia', icon: <Sparkles className="h-4 w-4" /> },
  ]

  return (
    <div className="space-y-4">
      {/* Banner tìm kiếm kiểu NearLink — xanh emerald đồng bộ toàn app */}
      <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600 p-4 text-white shadow-lg sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="min-w-0">
            <h1 className="flex items-center gap-2 text-lg font-black sm:text-xl">
              <Globe2 className="h-5 w-5 shrink-0" /> Tìm bạn bè cả nước
            </h1>
            <p className="mt-0.5 text-xs text-emerald-50 sm:text-sm">Không giới hạn khoảng cách · lọc online / độ tuổi · kiểu Heesay</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleVisible(!visible)}
              className="flex items-center gap-1.5 rounded-lg bg-white/15 px-2.5 py-2 text-xs font-semibold transition-colors hover:bg-white/25"
              aria-label={visible ? 'Ẩn vị trí của tôi' : 'Hiện vị trí của tôi'}
            >
              {visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
              <span className="hidden sm:inline">{visible ? 'Đang hiện' : 'Đang ẩn'}</span>
            </button>
            <Button size="sm" className="bg-white font-bold text-emerald-700 hover:bg-emerald-50" onClick={locateMe} disabled={locating}>
              {locating ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Crosshair className="mr-1 h-4 w-4" />}
              GPS
            </Button>
          </div>
        </div>

        {/* Ô tìm tên — gộp từ code zip (nlSearchInput) */}
        <div className="mt-3 flex items-center gap-2 rounded-xl bg-white p-1.5 pl-3 shadow-md">
          <Search className="h-4.5 w-4.5 shrink-0 text-emerald-600" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Nhập tên người dùng để tìm kiếm..."
            className="w-full border-0 bg-transparent text-sm font-medium text-stone-800 outline-none placeholder:text-stone-400"
            aria-label="Tìm người dùng"
          />
          {q && (
            <button onClick={() => setQ('')} className="rounded-full p-1.5 text-stone-400 hover:bg-stone-100" aria-label="Xóa tìm kiếm">
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      {/* Lời chào nhận được 24h */}
      {pings.length > 0 && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-3">
          <p className="mb-2 flex items-center gap-1.5 text-sm font-bold text-amber-900"><Hand className="h-4 w-4" /> Ai đó vừa chào bạn ({pings.length})</p>
          <div className="space-y-2">
            {pings.slice(0, 3).map((p) => (
              <div key={p.id} className="flex items-center gap-3 rounded-lg bg-white p-2.5 text-sm">
                <Avatar name={p.from.fullName} color={p.from.avatarColor} size={32} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{p.from.fullName}</p>
                  <p className="truncate text-xs text-stone-500">{p.message}</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => onMessage(p.from.id)}>Nhắn lại</Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab + nút bộ lọc — đúng cấu trúc zip: 3 tab 1 hàng + filter bên phải */}
      <div className="flex items-center gap-2">
        <div className="flex flex-1 gap-1.5 overflow-x-auto rounded-xl border bg-white p-1.5 shadow-sm">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex shrink-0 flex-1 items-center justify-center gap-1 rounded-lg px-2 py-2 text-[13px] font-bold whitespace-nowrap transition-colors sm:text-sm ${
                tab === t.key ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow' : 'text-stone-500 hover:bg-emerald-50 hover:text-emerald-800'
              }`}
              aria-pressed={tab === t.key}
            >
              {t.icon}
              {t.label}
            </button>
          ))}
        </div>
        <button
          onClick={() => setShowFilter((v) => !v)}
          className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border shadow-sm transition-colors ${
            showFilter || !isDefaultFilter ? 'border-emerald-600 bg-emerald-600 text-white' : 'bg-white text-stone-500 hover:bg-emerald-50 hover:text-emerald-700'
          }`}
          aria-label="Bộ lọc tìm kiếm"
          title="Bộ lọc tìm kiếm"
        >
          <SlidersHorizontal className="h-5 w-5" />
        </button>
      </div>

      {/* Panel bộ lọc — accordion kiểu zip: Tìm người · Khoảng cách · Độ tuổi · Đang online */}
      {showFilter && (
        <div className="space-y-2 rounded-xl border bg-white p-3 shadow-sm">
          <div className="flex items-center justify-between px-1 pb-1">
            <p className="flex items-center gap-1.5 text-sm font-bold"><SlidersHorizontal className="h-4 w-4 text-emerald-600" /> Bộ lọc tìm kiếm</p>
            <button
              onClick={() => { setAgeMin(0); setAgeMax(99); setDistMax(2500); setOnlineOnly(false); setQ('') }}
              className="rounded-full border px-3 py-1 text-xs font-bold text-stone-500 hover:bg-stone-50"
            >
              Xóa lọc
            </button>
          </div>

          {/* Khoảng cách */}
          <div className="overflow-hidden rounded-lg border">
            <button onClick={() => setOpenSection(openSection === 'dist' ? null : 'dist')} className="flex w-full items-center gap-2.5 p-3 text-left" aria-expanded={openSection === 'dist'}>
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600"><MapPin className="h-4.5 w-4.5" /></span>
              <strong className="flex-1 text-sm">Khoảng cách</strong>
              <em className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-bold not-italic text-emerald-700">{distMax >= 2500 ? 'Cả nước' : `≤ ${distMax} km`}</em>
              <ChevronDown className={`h-4 w-4 text-stone-400 transition-transform ${openSection === 'dist' ? 'rotate-180' : ''}`} />
            </button>
            {openSection === 'dist' && (
              <div className="border-t bg-stone-50/60 p-3">
                <div className="mb-1.5 flex items-center justify-between text-xs font-semibold text-stone-500">
                  <span>Gần tôi</span>
                  <Badge variant="secondary" className="bg-emerald-100 text-emerald-800">{distMax >= 2500 ? 'Không giới hạn — cả nước Việt Nam' : `Trong bán kính ${distMax} km`}</Badge>
                </div>
                <Slider value={[distMax]} min={1} max={2500} step={1} onValueChange={(v) => setDistMax(v[0])} aria-label="Bán kính km" />
                <p className="mt-1.5 text-[11px] text-stone-400">Kéo hết cỡ = tìm bạn bè khắp cả nước, không giới hạn khoảng cách.</p>
              </div>
            )}
          </div>

          {/* Độ tuổi */}
          <div className="overflow-hidden rounded-lg border">
            <button onClick={() => setOpenSection(openSection === 'age' ? null : 'age')} className="flex w-full items-center gap-2.5 p-3 text-left" aria-expanded={openSection === 'age'}>
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600"><Sparkles className="h-4.5 w-4.5" /></span>
              <strong className="flex-1 text-sm">Độ tuổi</strong>
              <em className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-bold not-italic text-emerald-700">{ageMin === 0 && ageMax === 99 ? 'Mọi độ tuổi' : `${ageMin} - ${ageMax} tuổi`}</em>
              <ChevronDown className={`h-4 w-4 text-stone-400 transition-transform ${openSection === 'age' ? 'rotate-180' : ''}`} />
            </button>
            {openSection === 'age' && (
              <div className="space-y-3 border-t bg-stone-50/60 p-3">
                <div>
                  <p className="mb-1.5 flex items-center justify-between text-xs font-semibold text-stone-500"><span>Từ tuổi</span><b className="text-stone-800">{ageMin}</b></p>
                  <Slider value={[ageMin]} min={0} max={99} step={1} onValueChange={(v) => setAgeMin(Math.min(v[0], ageMax))} aria-label="Tuổi tối thiểu" />
                </div>
                <div>
                  <p className="mb-1.5 flex items-center justify-between text-xs font-semibold text-stone-500"><span>Đến tuổi</span><b className="text-stone-800">{ageMax}</b></p>
                  <Slider value={[ageMax]} min={0} max={99} step={1} onValueChange={(v) => setAgeMax(Math.max(v[0], ageMin))} aria-label="Tuổi tối đa" />
                </div>
              </div>
            )}
          </div>

          {/* Đang online */}
          <div className="flex items-center gap-2.5 rounded-lg border p-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600"><Zap className="h-4.5 w-4.5" /></span>
            <strong className="flex-1 text-sm">Chỉ người đang online</strong>
            <Switch checked={onlineOnly} onCheckedChange={setOnlineOnly} aria-label="Chỉ hiện người online" />
          </div>

          {!isDefaultFilter && (
            <p className="rounded-lg bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-800">
              Đang lọc: {q.trim() ? `tên "${q.trim()}" · ` : ''}
              {distMax < 2500 ? `≤ ${distMax}km · ` : ''}
              {ageMin > 0 || ageMax < 99 ? `${ageMin}-${ageMax} tuổi · ` : ''}
              {onlineOnly ? 'online' : ''}
            </p>
          )}
        </div>
      )}

      {/* Tiêu đề khu kết quả + làm mới */}
      <div className="flex items-center justify-between px-0.5">
        <p className="text-sm font-bold text-stone-700">
          {TABS.find((t) => t.key === tab)?.label} <span className="font-normal text-stone-400">· {loading ? '...' : `${people.length} người`} · {onlineCount} online</span>
        </p>
        <button onClick={() => { setRefreshing(true); load({ silent: true }) }} className="flex items-center gap-1 rounded-full border bg-white px-2.5 py-1.5 text-xs font-semibold text-stone-500 hover:bg-emerald-50 hover:text-emerald-700" aria-label="Làm mới danh sách">
          <RotateCw className={`h-3.5 w-3.5 ${refreshing ? 'animate-spin' : ''}`} /> Làm mới
        </button>
      </div>

      {/* Lưới thẻ người — 2 cột mobile / 3 cột desktop như index.php */}
      {loading ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-56 animate-pulse rounded-2xl bg-stone-200/70" />
          ))}
        </div>
      ) : people.length === 0 ? (
        <div className="rounded-2xl border border-dashed p-10 text-center">
          <Search className="mx-auto mb-2 h-8 w-8 text-stone-300" />
          <p className="text-sm font-semibold text-stone-500">Không tìm thấy người dùng phù hợp</p>
          <p className="mt-1 text-xs text-stone-400">Thử bỏ bộ lọc hoặc bấm GPS để xem khoảng cách chính xác hơn.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {people.map((u) => (
            <div key={u.id} className="group relative flex min-h-52 flex-col overflow-hidden rounded-2xl border bg-white shadow-sm transition-shadow hover:shadow-md">
              {/* Ảnh nền thẻ = avatar lớn kiểu thẻ NearLink */}
              <button className="relative block h-32 w-full overflow-hidden" onClick={() => onOpenProfile?.(u.id)} aria-label={`Xem hồ sơ ${u.fullName}`}>
                {u.avatarImage ? (
                  <img src={u.avatarImage} alt={u.fullName} className="h-full w-full object-cover" />
                ) : (
                  <span className="flex h-full w-full items-center justify-center bg-gradient-to-br from-emerald-100 via-teal-50 to-cyan-50 text-5xl font-black text-emerald-700">
                    {u.fullName.charAt(0).toUpperCase()}
                  </span>
                )}
                {/* Badge trạng thái r31: "Online" chỉ dành cho người đang hoạt động thật, người offline hiện "Offline X phút" (tối đa 30 phút) */}
                <span className={`absolute left-2 top-2 flex items-center gap-1.5 rounded-full px-2 py-1 text-[10px] font-black backdrop-blur ${u.active ? 'bg-black/60 text-white' : 'bg-black/60 text-stone-200'}`}>
                  <span className={`h-2 w-2 rounded-full ${u.active ? 'bg-emerald-400' : 'bg-stone-400'}`} />
                  {u.active ? 'Online' : u.statusText}
                </span>
                {u.isNew && (
                  <span className="absolute right-2 top-2 flex items-center gap-1 rounded-full bg-emerald-600 px-2 py-1 text-[10px] font-black text-white shadow">
                    <Sparkles className="h-3 w-3" /> Mới
                  </span>
                )}
              </button>

              <div className="flex min-w-0 flex-1 flex-col p-2.5">
                <button onClick={() => onOpenProfile?.(u.id)} className="truncate text-left text-sm font-black text-stone-800 hover:text-emerald-700" title={u.fullName}>
                  {u.fullName}{u.age ? `, ${u.age}` : ''}
                </button>
                <p className="mt-0.5 flex items-center gap-1 truncate text-[11px] font-semibold text-emerald-700">
                  <MapPin className="h-3 w-3 shrink-0" />
                  {u.distanceKm != null ? u.distanceText : u.hometown || u.locationName || 'Toàn quốc'}
                </p>
                {(u.companyName || u.title !== 'Nhân viên') && (
                  <p className="mt-0.5 flex items-center gap-1 truncate text-[11px] text-stone-500">
                    <Building2 className="h-3 w-3 shrink-0" /> {u.companyName || u.title}
                  </p>
                )}
                <div className="mt-auto flex gap-1.5 pt-2">
                  {u.isFriend ? (
                    <Button size="sm" className="h-8 flex-1 bg-emerald-600 text-xs hover:bg-emerald-700" onClick={() => onMessage(u.id)}>
                      <MessageCircle className="mr-1 h-3.5 w-3.5" /> Nhắn tin
                    </Button>
                  ) : u.pending ? (
                    <Button size="sm" variant="outline" className="h-8 flex-1 text-xs" disabled>Đã mời</Button>
                  ) : (
                    <Button size="sm" variant="outline" className="h-8 flex-1 text-xs" onClick={() => addFriend(u.id)}>
                      <UserPlus className="mr-1 h-3.5 w-3.5" /> Kết bạn
                    </Button>
                  )}
                  <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={() => { setPingTarget(u); setPingMsg(PING_MESSAGES[0]) }} aria-label={`Gửi lời chào tới ${u.fullName}`} title="Gửi lời chào">
                    <Hand className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Dialog gửi lời chào */}
      <Dialog open={!!pingTarget} onOpenChange={(o) => !o && setPingTarget(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Gửi lời chào tới {pingTarget?.fullName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {PING_MESSAGES.map((m) => (
              <button
                key={m}
                className={`w-full rounded-lg border p-3 text-left text-sm transition-colors ${pingMsg === m ? 'border-emerald-500 bg-emerald-50' : 'hover:bg-stone-50'}`}
                onClick={() => setPingMsg(m)}
              >
                {m}
              </button>
            ))}
            <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={sendPing}><Send className="mr-1 h-4 w-4" /> Gửi lời chào</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
