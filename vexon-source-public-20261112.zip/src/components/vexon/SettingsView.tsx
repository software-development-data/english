'use client'

// ============ CÀI ĐẶT KIỂU ZALO ============
// Tài khoản (nâng cấp doanh nghiệp), Quyền riêng tư (năm sinh...), Giao diện (ngày/đêm + hiệu ứng 4 mùa), Thông báo, Về app

import { useRef, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import type { VxUserInfo } from './AuthView'
import { useVxTheme, type ThemeEffect, type ThemeMode } from '@/lib/vx-theme'
import { Avatar } from './shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Skeleton } from '@/components/ui/skeleton'
import { useDialogAutoFit } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'sonner'
import { fmtXuWithUsd, fmtUsdFromXu, fmtUsdNumber, xuToUsd } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'
import { VN_PROVINCE_NAMES_34, COUNTRIES, VN_ETHNIC_GROUPS_54, RELATIONSHIP_OPTIONS, SMOKING_OPTIONS, DRINKING_OPTIONS } from '@/lib/vx-locations'
import {
  UserCog, ShieldCheck, Palette, Bell, Info, Loader2, Camera, Sun, Moon, Sparkles, Flower2, SunMedium, Leaf, Snowflake, CloudRain, CircleOff, Save, MapPin, Check, KeyRound, Database, Download, Eraser, Eye, Clock3, Building2, Cake, Globe2, Lock, UsersRound, FileText, Home as HomeIcon, Briefcase, GraduationCap, Phone, SlidersHorizontal, Ruler, Weight, Heart, Wine, Smile, BadgeCheck, CheckCircle2, XCircle, Coins, Hourglass, Handshake, LogOut, IdCard, Landmark, Plus, X, UserRound,
} from 'lucide-react'

const SECTIONS = [
  { key: 'account', label: 'Tài khoản', icon: <UserCog className="h-4 w-4" /> },
  { key: 'profile', label: 'Hồ sơ chi tiết', icon: <FileText className="h-4 w-4" /> },
  { key: 'security', label: 'Bảo mật', icon: <KeyRound className="h-4 w-4" /> },
  { key: 'privacy', label: 'Quyền riêng tư', icon: <ShieldCheck className="h-4 w-4" /> },
  { key: 'appearance', label: 'Giao diện', icon: <Palette className="h-4 w-4" /> },
  { key: 'notify', label: 'Thông báo', icon: <Bell className="h-4 w-4" /> },
  { key: 'data', label: 'Dữ liệu', icon: <Database className="h-4 w-4" /> },
  { key: 'wallet', label: 'Ví & Ngân hàng', icon: <Coins className="h-4 w-4" /> },
  { key: 'about', label: 'Về Vexon', icon: <Info className="h-4 w-4" /> },
  // Riêng Ban Giám đốc (admin): duyệt đơn nâng cấp doanh nghiệp + duyệt nạp/rút + duyệt hoàn tiền
  { key: 'approve', label: 'Duyệt doanh nghiệp', icon: <BadgeCheck className="h-4 w-4" /> },
  { key: 'approveWallet', label: 'Duyệt nạp/rút', icon: <Coins className="h-4 w-4" /> },
  { key: 'approveRefund', label: 'Duyệt hoàn tiền', icon: <Handshake className="h-4 w-4" /> },
] as const

type SectionKey = (typeof SECTIONS)[number]['key']

const EFFECTS: { key: ThemeEffect; label: string; icon: React.ReactNode; desc: string }[] = [
  { key: 'auto', label: 'Tự động', icon: <Sparkles className="h-4 w-4" />, desc: 'Theo mùa + thời tiết thật tại vị trí của bạn (GPS)' },
  { key: 'spring', label: 'Xuân', icon: <Flower2 className="h-4 w-4" />, desc: 'Cánh hoa anh đào rơi nhẹ nhàng, dịu mắt' },
  { key: 'summer', label: 'Hạ', icon: <SunMedium className="h-4 w-4" />, desc: 'Đom đóm phát sáng lung linh buổi chiều hè' },
  { key: 'autumn', label: 'Thu', icon: <Leaf className="h-4 w-4" />, desc: 'Lá vàng rơi bay nhẹ trong gió' },
  { key: 'winter', label: 'Đông', icon: <Snowflake className="h-4 w-4" />, desc: 'Tuyết rơi êm đềm, thư giãn' },
  { key: 'rain', label: 'Mưa', icon: <CloudRain className="h-4 w-4" />, desc: 'Mưa nhiều tầng sâu rơi nhẹ, dễ chịu' },
  { key: 'off', label: 'Tắt', icon: <CircleOff className="h-4 w-4" />, desc: 'Không hiệu ứng, nhẹ máy' },
]

const AVATAR_COLORS = ['#10b981', '#ec4899', '#f59e0b', '#4f46e5', '#0ea5e9', '#ef4444', '#8b5cf6', '#14b8a6', '#b45309', '#334155']

export default function SettingsView({ me, onRefreshUser }: { me: VxUserInfo; onRefreshUser: () => void }) {
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho nạp/rút & đơn nâng cấp
  const [section, setSection] = useState<SectionKey>('account')
  const theme = useVxTheme()
  // Kiểu AJAX: modal hoàn tiền tự bung vừa nội dung / tự thu nhỏ khi tràn màn hình (không kéo cuộn)
  const refundFit = useDialogAutoFit<HTMLDivElement>()

  // Form tài khoản
  const [fullName, setFullName] = useState(me.fullName)
  const [bio, setBio] = useState(me.bio || '')
  const [department, setDepartment] = useState(me.department || '')
  const [title, setTitle] = useState(me.title || '')
  const [avatarColor, setAvatarColor] = useState(me.avatarColor)
  const [avatarImage, setAvatarImage] = useState<string | null>(me.avatarImage || null)
  const [locationVisible, setLocationVisible] = useState(true)
  const [saving, setSaving] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  // Quyền riêng tư mở rộng: ẩn trạng thái hoạt động / thời gian gần nhất (đọc từ user.settings)
  const [showOnline, setShowOnline] = useState(me.settings?.showOnline !== false)
  const [showLastSeen, setShowLastSeen] = useState(me.settings?.showLastSeen !== false)
  // Bảo mật: đổi mật khẩu
  const [curPw, setCurPw] = useState('')
  const [newPw, setNewPw] = useState('')
  const [rePw, setRePw] = useState('')
  const [pwBusy, setPwBusy] = useState(false)
  // Quyền riêng tư năm sinh: công khai | bạn bè | riêng tư
  const [bdayVis, setBdayVis] = useState<'public' | 'friends' | 'private'>(me.settings?.birthdayVisibility === 'friends' || me.settings?.birthdayVisibility === 'private' ? me.settings.birthdayVisibility : 'public')
  // Quyền riêng tư TỪNG MỤC hồ sơ kiểu Facebook: bio/quê quán/chức vụ/học vấn/SĐT + hẹn hò (chiều cao/cân nặng/tình trạng/lối sống/sở thích) + mục mở rộng (dân tộc/CCCD/MST)
  type FvKey = 'bio' | 'gender' | 'hometown' | 'job' | 'education' | 'phone' | 'height' | 'weight' | 'relationship' | 'lifestyle' | 'interests' | 'ethnicity' | 'citizenId' | 'taxCode'
  type FvValue = 'public' | 'friends' | 'private'
  const normFv = (v: unknown): FvValue => (v === 'friends' || v === 'private' ? v : 'public')
  const [fieldVis, setFieldVis] = useState<Record<FvKey, FvValue>>({
    bio: normFv(me.settings?.fieldVis?.bio),
    gender: normFv(me.settings?.fieldVis?.gender),
    hometown: normFv(me.settings?.fieldVis?.hometown),
    job: normFv(me.settings?.fieldVis?.job),
    education: normFv(me.settings?.fieldVis?.education),
    phone: normFv(me.settings?.fieldVis?.phone),
    height: normFv(me.settings?.fieldVis?.height),
    weight: normFv(me.settings?.fieldVis?.weight),
    relationship: normFv(me.settings?.fieldVis?.relationship),
    lifestyle: normFv(me.settings?.fieldVis?.lifestyle),
    interests: normFv(me.settings?.fieldVis?.interests),
    ethnicity: normFv(me.settings?.fieldVis?.ethnicity),
    citizenId: normFv(me.settings?.fieldVis?.citizenId),
    taxCode: normFv(me.settings?.fieldVis?.taxCode),
  })
  const saveFieldVis = async (key: FvKey, val: FvValue, label: string) => {
    const next = { ...fieldVis, [key]: val }
    setFieldVis(next)
    const res = await fetch('/api/vx/profile', {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ settings: { fieldVis: next, birthdayVisibility: bdayVis } }),
    })
    if (res.ok) toast.success(`${label}: ${val === 'public' ? 'CÔNG KHAI' : val === 'friends' ? 'chỉ BẠN BÈ xem' : 'chỉ MÌNH TÔI xem'}`)
    else toast.error('Không lưu được quyền riêng tư')
  }
  // Nâng cấp tài khoản cá nhân → doanh nghiệp: NỘP ĐƠN TRỪ TIỀN VÍ → CHỜ ADMIN DUYỆT (từ chối hoàn 100%)
  const [bizName, setBizName] = useState('')
  const [bizBusy, setBizBusy] = useState(false)
  type BizApp = { id: string; companyName: string; status: 'pending' | 'approved' | 'rejected'; note?: string | null; xuPaid: number; createdAt: string } | null
  const [bizApp, setBizApp] = useState<BizApp>(null)
  const [bizCost, setBizCost] = useState(500)
  // Quyền lợi thành viên doanh nghiệp (gia nhập công ty, chủ duyệt)
  type Membership = { id: string; status: string; company: { id: string; name: string; industry: string } } | null
  const [membership, setMembership] = useState<Membership>(null)
  // Admin: danh sách đơn nâng cấp doanh nghiệp
  type AdminApp = BizApp & { user?: { fullName: string; username: string; avatarColor: string; avatarImage?: string | null; accountType?: string; coins?: number } }
  const [adminApps, setAdminApps] = useState<NonNullable<AdminApp>[]>([])
  const [adminLoading, setAdminLoading] = useState(false)
  // AI viết bio
  const [bioBusy, setBioBusy] = useState(false)

  // ---- HỒ SƠ CHI TIẾT (mục Hồ sơ chi tiết): quê quán 34 tỉnh VN / quốc gia, dân tộc, CCCD, MST, chiều cao, cân nặng, sở thích...
  const [pfBirthday, setPfBirthday] = useState<string>(me.birthday ? new Date(me.birthday).toISOString().slice(0, 10) : '')
  const [pfHometown, setPfHometown] = useState<string>(me.hometown || '')
  const [pfHometownCountry, setPfHometownCountry] = useState<string>(me.hometown && !VN_PROVINCE_NAMES_34.includes(me.hometown) ? (me.hometown.startsWith('Khác: ') ? 'Khác' : me.hometown) : '')
  const [pfEducation, setPfEducation] = useState<string>(me.education || '')
  const [pfPhone, setPfPhone] = useState<string>(me.phone || '')
  const [pfEthnicity, setPfEthnicity] = useState<string>(me.ethnicity || '')
  const [pfCitizenId, setPfCitizenId] = useState<string>(me.citizenId || '')
  const [pfTaxCode, setPfTaxCode] = useState<string>(me.taxCode || '')
  const [pfHeight, setPfHeight] = useState<string>(me.heightCm != null ? String(me.heightCm) : '')
  const [pfWeight, setPfWeight] = useState<string>(me.weightKg != null ? String(me.weightKg) : '')
  const [pfRelationship, setPfRelationship] = useState<string>(me.relationship || '')
  const [pfSmoking, setPfSmoking] = useState<string>(me.smoking || '')
  const [pfDrinking, setPfDrinking] = useState<string>(me.drinking || '')
  const [pfPets, setPfPets] = useState<string>(me.pets || '')
  const [pfInterests, setPfInterests] = useState<string[]>(Array.isArray(me.interests) ? me.interests : [])
  const [pfInterestInput, setPfInterestInput] = useState<string>('')
  const [pfSaving, setPfSaving] = useState(false)

  const addInterest = () => {
    const v = pfInterestInput.trim().slice(0, 40)
    if (!v) return
    if (pfInterests.includes(v)) { setPfInterestInput(''); return }
    if (pfInterests.length >= 10) { toast.error('Tối đa 10 sở thích'); return }
    setPfInterests([...pfInterests, v]); setPfInterestInput('')
  }
  const removeInterest = (i: string) => setPfInterests(pfInterests.filter((x) => x !== i))

  const saveProfile = async () => {
    setPfSaving(true)
    try {
      // Quy ước quê quán: nếu pfHometown là 1 trong 34 tỉnh → lưu nguyên tên; nếu "Khác" thì lưu quốc gia; nếu "__none__" → null
      let hometownVal: string | null = pfHometown
      if (pfHometown === '__none__') {
        hometownVal = null
      } else if (pfHometown === '__other__' || (!pfHometown && pfHometownCountry)) {
        if (!pfHometownCountry || pfHometownCountry === 'Khác') {
          toast.error('Chọn tỉnh thành hoặc nhập quốc gia khác')
          setPfSaving(false)
          return
        }
        hometownVal = pfHometownCountry
      } else if (pfHometown === '__other__' && pfHometownCountry === 'Khác') {
        toast.error('Vui lòng chọn quốc gia cụ thể')
        setPfSaving(false)
        return
      }
      // Quy ước các dropdown "Chưa chọn": __none__ → null
      const noneIfEmpty = (v: string) => (v === '__none__' ? '' : v)
      const res = await fetch('/api/vx/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          birthday: pfBirthday || null,
          hometown: hometownVal,
          education: pfEducation,
          phone: pfPhone,
          ethnicity: noneIfEmpty(pfEthnicity) || null,
          citizenId: pfCitizenId || null,
          taxCode: pfTaxCode || null,
          heightCm: pfHeight === '' ? null : Number(pfHeight),
          weightKg: pfWeight === '' ? null : Number(pfWeight),
          relationship: noneIfEmpty(pfRelationship) || null,
          smoking: noneIfEmpty(pfSmoking) || null,
          drinking: noneIfEmpty(pfDrinking) || null,
          pets: pfPets || null,
          interests: pfInterests,
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success('Đã lưu hồ sơ chi tiết')
      onRefreshUser()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không lưu được hồ sơ')
    } finally { setPfSaving(false) }
  }

  // ---- VÍ & NGÂN HÀNG ----
  type BankCard = { id: string; bankName: string; bankSwift?: string | null; accountNumber: string; accountHolder: string; branch?: string | null; isPrimary: boolean; status: string; note?: string | null }
  const [bankCards, setBankCards] = useState<BankCard[]>([])
  const [walletLoading, setWalletLoading] = useState(false)
  // Form thêm thẻ
  const [bcBankName, setBcBankName] = useState('Techcombank')
  const [bcBankSwift, setBcBankSwift] = useState('VTCBVNVX')
  const [bcAccountNumber, setBcAccountNumber] = useState('')
  const [bcAccountHolder, setBcAccountHolder] = useState('')
  const [bcBranch, setBcBranch] = useState('')
  const [bcNote, setBcNote] = useState('')
  const [bcSaving, setBcSaving] = useState(false)
  // Số dư ví & lịch sử nạp/rút
  const [walletCoins, setWalletCoins] = useState(0)
  type WalletTx = { id: string; type: 'deposit' | 'withdraw'; amountVnd: number; amountXu: number; taxVnd: number; status: string; proofCode?: string | null; userNote?: string | null; adminNote?: string | null; bankName?: string | null; accountNumber?: string | null; createdAt: string; reviewedAt?: string | null }
  const [walletTxs, setWalletTxs] = useState<WalletTx[]>([])
  // Form nạp/rút
  const [depositUsd, setDepositUsd] = useState('')
  const [depositCard, setDepositCard] = useState('')
  const [depositProof, setDepositProof] = useState('')
  const [depositNote, setDepositNote] = useState('')
  const [depositBusy, setDepositBusy] = useState(false)
  const [withdrawUsd, setWithdrawUsd] = useState('')
  const [withdrawCard, setWithdrawCard] = useState('')
  const [withdrawNote, setWithdrawNote] = useState('')
  const [withdrawBusy, setWithdrawBusy] = useState(false)
  // Yêu cầu hoàn tiền
  type RefundReq = { id: string; reason: string; refundVnd: number; status: string; adminNote?: string | null; createdAt: string; walletTxId: string; messages: RefundMsg[] }
  type RefundMsg = { id: string; role: string; content: string; createdAt: string; senderId: string }
  const [myRefunds, setMyRefunds] = useState<RefundReq[]>([])
  const [refundModal, setRefundModal] = useState<{ txId: string; amountVnd: number } | null>(null)
  const [refundReason, setRefundReason] = useState('')
  const [refundBusy, setRefundBusy] = useState(false)
  const [refundChatInput, setRefundChatInput] = useState('')
  const [refundChatTarget, setRefundChatTarget] = useState<string>('')
  // Admin: duyệt nạp/rút + duyệt hoàn tiền
  type AdminWalletTx = WalletTx & { user?: { fullName: string; username: string; avatarColor: string; avatarImage?: string | null; coins?: number } }
  const [adminWalletTxs, setAdminWalletTxs] = useState<AdminWalletTx[]>([])
  const [adminWalletLoading, setAdminWalletLoading] = useState(false)
  type AdminRefund = RefundReq & { user?: { fullName: string; username: string; avatarColor: string; avatarImage?: string | null } }
  const [adminRefunds, setAdminRefunds] = useState<AdminRefund[]>([])
  const [adminRefundLoading, setAdminRefundLoading] = useState(false)

  // Thông tin TK Techcombank của web (người dùng chuyển khoản nạp tiền vào đây)
  const WEB_BANK = { bank: 'Techcombank', account: '2461388888', holder: 'Trần Ngọc Sơn', swift: 'VTCBVNVX' }

  const loadWallet = () => {
    setWalletLoading(true)
    fetch('/api/vx/bank-cards').then((r) => r.json()).then((d) => Array.isArray(d.cards) && setBankCards(d.cards)).catch(() => {}).finally(() => setWalletLoading(false))
    fetch('/api/vx/wallet-tx').then((r) => r.json()).then((d) => { if (d) { if (typeof d.coins === 'number') setWalletCoins(d.coins); if (Array.isArray(d.txs)) setWalletTxs(d.txs); if (Array.isArray(d.refunds)) setMyRefunds(d.refunds) } }).catch(() => {})
  }

  const saveBankCard = async () => {
    if (!bcBankName.trim() || !bcAccountNumber.trim() || !bcAccountHolder.trim()) { toast.error('Nhập tên ngân hàng, số tài khoản và tên chủ tài khoản'); return }
    setBcSaving(true)
    try {
      const res = await fetch('/api/vx/bank-cards', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bankName: bcBankName, bankSwift: bcBankSwift, accountNumber: bcAccountNumber, accountHolder: bcAccountHolder, branch: bcBranch, note: bcNote }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success('Đã thêm thẻ ngân hàng')
      setBcAccountNumber(''); setBcAccountHolder(''); setBcBranch(''); setBcNote('')
      loadWallet()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không lưu được thẻ')
    } finally { setBcSaving(false) }
  }

  const setPrimaryCard = async (id: string) => {
    const res = await fetch('/api/vx/bank-cards', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, action: 'setPrimary' }) })
    const d = await res.json()
    if (res.ok) { toast.success('Đã đặt làm thẻ mặc định'); loadWallet() } else toast.error(d.error || 'Không đặt được')
  }
  const deleteCard = async (id: string) => {
    if (!window.confirm('Xoá thẻ ngân hàng này? Lịch sử giao dịch vẫn giữ nguyên.')) return
    const res = await fetch('/api/vx/bank-cards', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) })
    const d = await res.json()
    if (res.ok) { toast.success('Đã xoá thẻ'); loadWallet() } else toast.error(d.error || 'Không xoá được')
  }

  // Nạp tiền: user nhập số USD muốn có trong ví → API quy ra VND theo tỷ giá sống → admin duyệt (r30)
  const submitDeposit = async () => {
    const usd = Number(depositUsd.replace(',', '.').replace(/[^\d.]/g, '')) || 0
    if (!usd || usd < 0.2) { toast.error('Nhập số USD muốn nạp, tối thiểu $0,20'); return }
    setDepositBusy(true)
    try {
      const res = await fetch('/api/vx/wallet-tx', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'deposit', amountUsd: usd, bankCardId: depositCard || undefined, proofCode: depositProof, userNote: depositNote }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success(`Đã gửi yêu cầu nạp +${fmtUsdNumber(usd)} vào ví (≈ ${Math.round(usd * rate).toLocaleString('vi-VN')}đ). Chờ admin duyệt.`)
      setDepositUsd(''); setDepositProof(''); setDepositNote('')
      loadWallet()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không gửi được yêu cầu nạp')
    } finally { setDepositBusy(false) }
  }

  // Rút tiền: user nhập số USD → giữ chỗ ngay, admin duyệt → chuyển VND theo tỷ giá vào thẻ của user (trừ thuế 10%) (r30)
  const submitWithdraw = async () => {
    const usd = Number(withdrawUsd.replace(',', '.').replace(/[^\d.]/g, '')) || 0
    if (!usd || usd < 2) { toast.error('Nhập số USD muốn rút, tối thiểu $2,00'); return }
    if (usd > xuToUsd(walletCoins, rate)) { toast.error(`Không đủ tiền. Bạn đang có ${fmtUsdFromXu(walletCoins, rate)}`); return }
    const card = bankCards.find((c) => c.id === withdrawCard)
    if (!card) { toast.error('Chọn thẻ ngân hàng nhận tiền (thêm thẻ ở trên nếu chưa có)'); return }
    setWithdrawBusy(true)
    try {
      const res = await fetch('/api/vx/wallet-tx', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'withdraw', amountUsd: usd, bankName: card.bankName, accountNumber: card.accountNumber, accountHolder: card.accountHolder, userNote: withdrawNote }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success(`Đã gửi yêu cầu rút $${fmtUsdNumber(usd)} → nhận ${(d.tx?.netVnd ?? 0).toLocaleString('vi-VN')}đ (đã trừ thuế 10%). Chờ admin duyệt.`)
      setWithdrawUsd(''); setWithdrawNote('')
      loadWallet()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không gửi được yêu cầu rút')
    } finally { setWithdrawBusy(false) }
  }

  // Yêu cầu hoàn tiền (chỉ cho nạp chưa tiêu tiền)
  const submitRefund = async () => {
    if (!refundModal) return
    if (!refundReason.trim()) { toast.error('Nhập lý do hoàn tiền'); return }
    setRefundBusy(true)
    try {
      const res = await fetch('/api/vx/refund', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ walletTxId: refundModal.txId, reason: refundReason }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success(d.message || 'Đã gửi yêu cầu hoàn tiền, admin xử lý trong 7 ngày')
      setRefundModal(null); setRefundReason('')
      loadWallet()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không gửi được yêu cầu hoàn')
    } finally { setRefundBusy(false) }
  }

  // Gửi tin nhắn trong chatbox hỗ trợ hoàn tiền
  const sendRefundMsg = async (refundRequestId: string) => {
    const v = refundChatInput.trim()
    if (!v) return
    try {
      const res = await fetch('/api/vx/refund', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refundRequestId, action: 'sendMsg', content: v }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      setRefundChatInput('')
      loadWallet()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không gửi được tin nhắn')
    }
  }

  // Admin duyệt/từ chối giao dịch nạp/rút
  const reviewWalletTx = async (id: string, action: 'approve' | 'reject', note?: string) => {
    const res = await fetch('/api/vx/wallet-tx', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, action, adminNote: note }) })
    const d = await res.json()
    if (res.ok) { toast.success(d.message || 'Đã xử lý'); loadAdminWallet() } else toast.error(d.error || 'Không xử lý được')
  }
  const loadAdminWallet = () => {
    setAdminWalletLoading(true)
    fetch('/api/vx/wallet-tx?admin=1').then((r) => r.json()).then((d) => Array.isArray(d.adminList) && setAdminWalletTxs(d.adminList)).catch(() => {}).finally(() => setAdminWalletLoading(false))
  }
  // Admin duyệt/từ chối yêu cầu hoàn tiền
  const reviewRefund = async (id: string, action: 'approve' | 'reject', note?: string) => {
    const res = await fetch('/api/vx/refund', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refundRequestId: id, action, adminNote: note }) })
    const d = await res.json()
    if (res.ok) { toast.success(d.message || 'Đã xử lý'); loadAdminRefund() } else toast.error(d.error || 'Không xử lý được')
  }
  const loadAdminRefund = () => {
    setAdminRefundLoading(true)
    fetch('/api/vx/refund?admin=1').then((r) => r.json()).then((d) => Array.isArray(d.adminList) && setAdminRefunds(d.adminList)).catch(() => {}).finally(() => setAdminRefundLoading(false))
  }

  const pickAvatar = (file?: File) => {
    if (!file) return
    if (file.size > 1_500_000) { toast.error('Ảnh đại diện tối đa ~1.5MB'); return }
    const reader = new FileReader()
    reader.onload = () => setAvatarImage(String(reader.result))
    reader.readAsDataURL(file)
  }

  const saveAccount = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/vx/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName, bio, department, title, avatarColor, avatarImage }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success('Đã lưu thông tin tài khoản')
      onRefreshUser()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không lưu được')
    } finally { setSaving(false) }
  }

  const savePrivacy = async (visible: boolean) => {
    setLocationVisible(visible)
    const res = await fetch('/api/vx/profile', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ locationVisible: visible }) })
    if (res.ok) toast.success(visible ? 'Đã BẬT định vị, bạn xuất hiện trong Radar người gần' : 'Đã TẮT định vị, bạn ẩn khỏi Radar')
    else toast.error('Không lưu được')
  }

  // Lưu tuỳ chọn riêng tư vào settings JSON (showOnline / showLastSeen / birthdayVisibility)
  const savePresencePref = async (patch: { showOnline?: boolean; showLastSeen?: boolean; birthdayVisibility?: 'public' | 'friends' | 'private' }, okMsg: string) => {
    const res = await fetch('/api/vx/profile', {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ settings: { mode: theme.mode, effect: theme.effect, effectsOn: theme.effectsOn, notifSound: theme.notifSound, fontSize: theme.fontSize, showOnline, showLastSeen, birthdayVisibility: bdayVis, ...patch } }),
    })
    if (res.ok) toast.success(okMsg)
    else toast.error('Không lưu được tuỳ chọn')
  }

  // AI viết giùm dòng giới thiệu bản thân (bio)
  const writeBioWithAi = async () => {
    setBioBusy(true)
    try {
      const res = await fetch('/api/assistant', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'chat',
          messages: [{ role: 'user', content: `Viết một dòng giới thiệu bản thân (bio) tiếng Việt, tối đa 120 ký tự, tự nhiên thân thiện, KHÔNG hashtag, KHÔNG dấu ngoặc kép, chỉ trả về đúng nội dung bio. Thông tin: tên ${fullName}${title ? `, chức danh ${title}` : ''}${department ? `, phòng ${department}` : ''}${Array.isArray(me.interests) && me.interests.length ? `, sở thích ${me.interests.slice(0, 3).join(', ')}` : ''}.` }],
        }),
      })
      const d = await res.json()
      if (!res.ok || !d.text) throw new Error(d.error || 'AI đang bận')
      setBio(String(d.text).trim().replace(/^"|"$/g, '').slice(0, 140))
      toast.success('AI đã viết bio, bấm Lưu thay đổi để áp dụng')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'AI đang bận, thử lại sau')
    } finally { setBioBusy(false) }
  }

  // Nộp đơn nâng cấp DOANH NGHIỆP: trừ tiền ví → tạo đơn → chờ admin duyệt (từ chối hoàn 100%)
  const upgradeBusiness = async () => {
    if (!bizName.trim()) { toast.error('Nhập tên công ty để nộp đơn'); return }
    setBizBusy(true)
    try {
      const res = await fetch('/api/vx/business-upgrade', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ companyName: bizName }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success(d.message || 'Đã nộp đơn, chờ admin duyệt')
      setBizApp(d.application)
      setBizName('')
      onRefreshUser()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không nộp được đơn')
    } finally { setBizBusy(false) }
  }

  // ADMIN duyệt / từ chối đơn nâng cấp doanh nghiệp
  const reviewBusiness = async (id: string, action: 'approve' | 'reject') => {
    // DUYỆT không cần lý do; chỉ TỪ CHỐI mới hỏi lý do (bấm Huỷ prompt = bỏ qua hành động)
    let note: string | null = null
    if (action === 'reject') {
      const input = window.prompt('Lý do từ chối (để trống nếu không cần):')
      if (input === null) return
      note = input
    }
    const res = await fetch('/api/vx/business-upgrade', {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, action, note }),
    })
    const d = await res.json()
    if (res.ok) { toast.success(d.message || 'Đã xử lý đơn'); loadAdminApps() } else toast.error(d.error || 'Không xử lý được')
  }

  // Tải trạng thái đơn nâng cấp + quyền lợi thành viên (kéo nhẹ sau khi UI hiển thị)
  const loadBizState = () => {
    fetch('/api/vx/business-upgrade').then((r) => r.json()).then((d) => { if (d && typeof d.cost === 'number') { setBizCost(d.cost); setBizApp(d.application ?? null) } }).catch(() => {})
    fetch('/api/vx/companies/members?self=1').then((r) => r.json()).then((d) => setMembership(d.membership ?? null)).catch(() => {})
  }
  const loadAdminApps = () => {
    setAdminLoading(true)
    fetch('/api/vx/business-upgrade?admin=1').then((r) => r.json()).then((d) => Array.isArray(d.adminList) && setAdminApps(d.adminList)).catch(() => {}).finally(() => setAdminLoading(false))
  }
  useDeferredLoad(() => {
    loadBizState()
    if (me.role === 'admin' && section === 'approve') loadAdminApps()
    if (section === 'wallet') loadWallet()
    if (me.role === 'admin' && section === 'approveWallet') loadAdminWallet()
    if (me.role === 'admin' && section === 'approveRefund') loadAdminRefund()
  }, [me.role, section])

  // Thành viên rời doanh nghiệp (mất quyền lợi x2 thưởng...)
  const leaveCompany = async () => {
    if (!membership) return
    if (!window.confirm(`Rời khỏi ${membership.company.name}? Bạn sẽ mất quyền lợi thành viên (x2 thưởng điểm danh, badge công ty).`)) return
    const res = await fetch('/api/vx/companies/join', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ companyId: membership.company.id, action: 'leave' }) })
    const d = await res.json()
    if (res.ok) { toast.success(d.message || 'Đã rời doanh nghiệp'); setMembership(null); onRefreshUser() } else toast.error(d.error || 'Không rời được')
  }
  const cancelJoinRequest = async () => {
    if (!membership) return
    const res = await fetch('/api/vx/companies/join', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ companyId: membership.company.id, action: 'cancel' }) })
    const d = await res.json()
    if (res.ok) { toast.success(d.message || 'Đã huỷ yêu cầu'); setMembership(null) } else toast.error(d.error || 'Không huỷ được')
  }

  // Đổi mật khẩu (Cài đặt → Bảo mật)
  const changePassword = async () => {
    if (!curPw || !newPw) { toast.error('Nhập đủ mật khẩu hiện tại và mật khẩu mới'); return }
    if (newPw.length < 6) { toast.error('Mật khẩu mới tối thiểu 6 ký tự'); return }
    if (newPw !== rePw) { toast.error('Mật khẩu mới và nhập lại không khớp'); return }
    setPwBusy(true)
    try {
      const res = await fetch('/api/vx/auth', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'change-password', currentPassword: curPw, newPassword: newPw }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success('Đã đổi mật khẩu, lần sau đăng nhập bằng mật khẩu mới nhé')
      setCurPw(''); setNewPw(''); setRePw('')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không đổi được mật khẩu')
    } finally { setPwBusy(false) }
  }

  // Dữ liệu: xoá tìm kiếm gần đây + xuất dữ liệu cá nhân
  const clearRecentSearches = () => {
    try { localStorage.removeItem('vx-recent-searches') } catch { /* bỏ qua */ }
    toast.success('Đã xoá danh sách tìm kiếm gần đây')
  }
  const exportMyData = async () => {
    try {
      const res = await fetch('/api/vx/auth')
      const d = await res.json()
      const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), user: d.user }, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `vexon-my-data-${me.username}.json`
      a.click()
      URL.revokeObjectURL(url)
      toast.success('Đã tải dữ liệu cá nhân dạng JSON')
    } catch { toast.error('Không tải được dữ liệu') }
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="flex items-center gap-2 text-xl font-black text-stone-800"><UserCog className="h-5 w-5 text-emerald-600" /> Cài đặt</h1>
        <p className="text-sm text-muted-foreground">Quản lý tài khoản, quyền riêng tư và giao diện, kiểu Zalo</p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[220px_1fr]">
        <nav className="flex gap-1 overflow-x-auto rounded-xl border bg-white p-1.5 lg:flex-col lg:overflow-visible" aria-label="Mục cài đặt">
          {SECTIONS.filter((s) => !['approve', 'approveWallet', 'approveRefund'].includes(s.key) || me.role === 'admin').map((s) => (
            <button key={s.key} onClick={() => setSection(s.key)}
              className={`flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${section === s.key ? 'bg-emerald-600 text-white shadow' : 'text-stone-600 hover:bg-emerald-50 hover:text-emerald-800'}`}
              aria-current={section === s.key ? 'page' : undefined}>
              {s.icon} <span className="whitespace-nowrap">{s.label}</span>
            </button>
          ))}
        </nav>

        <section className="space-y-4">
          {/* ---- TÀI KHOẢN ---- */}
          {section === 'account' && (
            <div className="space-y-4 rounded-xl border bg-white p-4 shadow-sm sm:p-5">
              <div className="flex flex-wrap items-center gap-4">
                <div className="relative">
                  <Avatar name={me.fullName} color={avatarColor} size={72} img={avatarImage} ring />
                  <button onClick={() => fileRef.current?.click()} title="Đổi ảnh đại diện"
                    className="absolute -bottom-1 -right-1 flex h-7 w-7 items-center justify-center rounded-full bg-emerald-600 text-white shadow hover:bg-emerald-700" aria-label="Tải ảnh đại diện">
                    <Camera className="h-3.5 w-3.5" />
                  </button>
                  <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => pickAvatar(e.target.files?.[0])} />
                </div>
                <div>
                  <p className="font-bold text-stone-800">{me.fullName}</p>
                  <p className="text-xs text-muted-foreground">@{me.username}, {me.accountType === 'business' ? `Doanh nghiệp ${me.companyName || ''}` : 'Cá nhân'}</p>
                  <button onClick={() => setAvatarImage(null)} className="mt-1 text-[11px] text-rose-500 hover:underline" disabled={!avatarImage}>{avatarImage ? 'Xoá ảnh đại diện, dùng chữ màu' : 'Dùng ảnh đại diện bằng cách bấm nút ảnh'}</button>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Màu đại diện">
                {AVATAR_COLORS.map((c) => (
                  <button key={c} onClick={() => setAvatarColor(c)} aria-label={`Màu ${c}`}
                    className={`h-7 w-7 rounded-full border-2 transition-transform hover:scale-110 ${avatarColor === c ? 'border-emerald-600' : 'border-transparent'}`}
                    style={{ backgroundColor: c }} />
                ))}
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5"><Label htmlFor="st-name">Họ và tên</Label><Input id="st-name" value={fullName} onChange={(e) => setFullName(e.target.value)} /></div>
                <div className="space-y-1.5"><Label htmlFor="st-dept">Phòng ban</Label><Input id="st-dept" value={department} onChange={(e) => setDepartment(e.target.value)} /></div>
                <div className="space-y-1.5"><Label htmlFor="st-title">Chức danh</Label><Input id="st-title" value={title} onChange={(e) => setTitle(e.target.value)} /></div>
                <div className="space-y-1.5 sm:col-span-2">
                  <div className="flex items-center justify-between gap-2">
                    <Label htmlFor="st-bio">Giới thiệu bản thân</Label>
                    <Button type="button" variant="outline" size="sm" className="border-emerald-300 text-emerald-700 hover:bg-emerald-50" onClick={() => void writeBioWithAi()} disabled={bioBusy} aria-label="AI viết giới thiệu giùm">
                      {bioBusy ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <Sparkles className="mr-1 h-3.5 w-3.5" />} AI viết giùm
                    </Button>
                  </div>
                  <Input id="st-bio" value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Một dòng về bạn..." />
                </div>
              </div>
              <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={saveAccount} disabled={saving}>
                {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Save className="mr-1 h-4 w-4" />} Lưu thay đổi
              </Button>

              {/* Loại tài khoản: cá nhân NỘP ĐƠN nâng cấp lên doanh nghiệp bằng tiền ví → chờ admin duyệt */}
              {me.accountType === 'business' ? (
                <div className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow"><Building2 className="h-4 w-4" /></span>
                  <div className="min-w-0">
                    <p className="flex items-center gap-1.5 text-sm font-bold text-amber-800">Tài khoản DOANH NGHIỆP{me.companyName ? `, ${me.companyName}` : ''}</p>
                    <p className="text-xs text-amber-700/90">Hồ sơ năng lực công ty, bot trả lời khách tự động, đăng tin tuyển dụng và rao vặt, tạo fanpage. Quản lý doanh nghiệp trong mục Doanh nghiệp trên menu.</p>
                  </div>
                </div>
              ) : bizApp?.status === 'pending' ? (
                /* Đơn đang chờ admin duyệt */
                <div className="flex items-start gap-3 rounded-lg border border-sky-200 bg-sky-50 p-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-sky-500 text-white shadow"><Hourglass className="h-4 w-4" /></span>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-sky-800">Đơn nâng cấp DOANH NGHIỆP "{bizApp.companyName}" đang CHỜ ADMIN DUYỆT</p>
                    <p className="mt-0.5 text-xs text-sky-700/90">Nộp lúc {new Date(bizApp.createdAt).toLocaleString('vi-VN')}, đã trừ {fmtXuWithUsd(bizApp.xuPaid, rate)} vào Ví tiền. Ban Giám đốc duyệt xong tài khoản tự chuyển thành doanh nghiệp; nếu bị từ chối sẽ hoàn 100% vào ví.</p>
                  </div>
                </div>
              ) : (
                <div className="rounded-lg border border-amber-200 bg-amber-50 p-3">
                  {bizApp?.status === 'rejected' && (
                    <p className="mb-2 flex items-start gap-1.5 rounded border border-rose-200 bg-rose-50 p-2 text-xs text-rose-700">
                      <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                      Đơn "{bizApp.companyName}" bị từ chối{bizApp.note ? `: ${bizApp.note}` : ''}. Đã hoàn {fmtXuWithUsd(bizApp.xuPaid, rate)} — bạn có thể nộp đơn lại bên dưới.
                    </p>
                  )}
                  <p className="flex items-center gap-1.5 text-sm font-bold text-amber-800"><Building2 className="h-3.5 w-3.5" /> Nâng cấp lên tài khoản DOANH NGHIỆP <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-700">{fmtXuWithUsd(bizCost, rate)}</span></p>
                  <ul className="mt-1 list-inside list-disc text-xs text-amber-700/90">
                    <li>Hồ sơ năng lực công ty + portfolio + đánh giá uy tín</li>
                    <li>Bot trả lời khách tự động theo kịch bản riêng</li>
                    <li>Đăng tin tuyển dụng, rao vặt và tạo fanpage doanh nghiệp</li>
                    <li>Tạo nhóm thành viên doanh nghiệp: nhân viên xin gia nhập và hưởng quyền lợi công ty</li>
                    <li>Nộp đơn trừ {fmtXuWithUsd(bizCost, rate)} → chờ Ban Giám đốc duyệt (từ chối hoàn 100% vào ví)</li>
                  </ul>
                  <div className="mt-2 flex flex-col gap-2 sm:flex-row">
                    <Input value={bizName} onChange={(e) => setBizName(e.target.value)} placeholder="Tên công ty, ví dụ: Công ty TNHH ABC" aria-label="Tên công ty" className="sm:max-w-xs" />
                    <Button className="bg-amber-500 hover:bg-amber-600" onClick={upgradeBusiness} disabled={bizBusy}>
                      {bizBusy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Coins className="mr-1 h-4 w-4" />} Nộp đơn nâng cấp ({fmtXuWithUsd(bizCost, rate)})
                    </Button>
                  </div>
                </div>
              )}

              {/* Quyền lợi thành viên doanh nghiệp: xin gia nhập ở mục Doanh nghiệp → chủ công ty duyệt */}
              {me.accountType !== 'business' && membership && (
                membership.status === 'active' ? (
                  <div className="flex items-start gap-3 rounded-lg border border-emerald-200 bg-emerald-50 p-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow"><Handshake className="h-4 w-4" /></span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-bold text-emerald-800">Thành viên {membership.company.name}</p>
                      <p className="mt-0.5 text-xs text-emerald-700/90">Quyền lợi đang hưởng: <b>x2 thưởng điểm danh hàng ngày</b>, badge "Nhân viên {membership.company.name}" trên hồ sơ &amp; tin nhắn, ưu đãi công cụ AI. Nhờ chủ doanh nghiệp duyệt đơn gia nhập mới có quyền lợi.</p>
                      <Button size="sm" variant="outline" className="mt-2 h-7 border-rose-300 text-rose-600 hover:bg-rose-50" onClick={leaveCompany} aria-label="Rời doanh nghiệp">
                        <LogOut className="mr-1 h-3 w-3" /> Rời doanh nghiệp
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start gap-3 rounded-lg border border-stone-200 bg-stone-50 p-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-stone-400 text-white shadow"><Hourglass className="h-4 w-4" /></span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-bold text-stone-700">Đang chờ duyệt gia nhập {membership.company.name}</p>
                      <p className="text-xs text-stone-500">Chủ doanh nghiệp duyệt xong bạn sẽ được hưởng quyền lợi thành viên.</p>
                      <Button size="sm" variant="outline" className="mt-2 h-7" onClick={cancelJoinRequest} aria-label="Huỷ yêu cầu gia nhập">Huỷ yêu cầu</Button>
                    </div>
                  </div>
                )
              )}
            </div>
          )}

          {/* ---- HỒ SƠ CHI TIẾT (sở thích, chiều cao, cân nặng, dân tộc, CCCD, MST, quê quán 34 tỉnh...) ---- */}
          {section === 'profile' && (
            <div className="space-y-5 rounded-xl border bg-white p-4 shadow-sm sm:p-5">
              <div>
                <p className="flex items-center gap-2 text-sm font-bold"><FileText className="h-4 w-4 text-emerald-600" /> Hồ sơ chi tiết</p>
                <p className="text-xs text-muted-foreground">Mạng xã hội Vexon vừa để tìm người yêu vừa để làm việc: cập nhật đủ thông tin cá nhân để phù hợp hơn trong tìm kiếm. Quyền riêng tư từng mục ở tab Quyền riêng tư (kiểu Facebook).</p>
              </div>

              {/* Nhóm THÔNG TIN CÁ NHÂN CƠ BẢN */}
              <div className="space-y-3 rounded-lg border bg-stone-50/60 p-3">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-stone-500"><Cake className="h-3.5 w-3.5" /> Thông tin cá nhân</p>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="pf-bday">Ngày sinh</Label>
                    <Input id="pf-bday" type="date" value={pfBirthday} onChange={(e) => setPfBirthday(e.target.value)} />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="pf-ethnicity">Dân tộc</Label>
                    <Select value={pfEthnicity} onValueChange={setPfEthnicity}>
                      <SelectTrigger id="pf-ethnicity"><SelectValue placeholder="Chọn dân tộc" /></SelectTrigger>
                      <SelectContent className="max-h-72">
                        <SelectItem value="__none__">(Chưa chọn)</SelectItem>
                        {VN_ETHNIC_GROUPS_54.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="pf-citizenid" className="flex items-center gap-1"><IdCard className="h-3.5 w-3.5 text-emerald-600" /> Căn cước công dân (CCCD)</Label>
                    <Input id="pf-citizenid" inputMode="numeric" pattern="[0-9]*" maxLength={12} value={pfCitizenId} onChange={(e) => setPfCitizenId(e.target.value.replace(/[^0-9]/g, '').slice(0, 12))} placeholder="12 chữ số" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="pf-taxcode" className="flex items-center gap-1"><Landmark className="h-3.5 w-3.5 text-emerald-600" /> Mã số thuế cá nhân</Label>
                    <Input id="pf-taxcode" inputMode="numeric" pattern="[0-9]*" maxLength={20} value={pfTaxCode} onChange={(e) => setPfTaxCode(e.target.value.replace(/[^0-9]/g, '').slice(0, 20))} placeholder="MST (số thuế cá nhân)" />
                  </div>
                  <div className="space-y-1.5 sm:col-span-2">
                    <Label htmlFor="pf-phone" className="flex items-center gap-1"><Phone className="h-3.5 w-3.5 text-emerald-600" /> Số điện thoại</Label>
                    <Input id="pf-phone" value={pfPhone} onChange={(e) => setPfPhone(e.target.value.slice(0, 20))} placeholder="Số liên hệ" />
                  </div>
                </div>
              </div>

              {/* Nhóm QUÊ QUÁN + HỌC VẤN */}
              <div className="space-y-3 rounded-lg border bg-stone-50/60 p-3">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-stone-500"><HomeIcon className="h-3.5 w-3.5" /> Quê quán & học vấn</p>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="pf-hometown">Quê quán (34 tỉnh/thành Việt Nam)</Label>
                    <Select value={pfHometown || ''} onValueChange={(v) => { setPfHometown(v); if (v !== '__other__') setPfHometownCountry('') }}>
                      <SelectTrigger id="pf-hometown"><SelectValue placeholder="Chọn tỉnh/thành" /></SelectTrigger>
                      <SelectContent className="max-h-72">
                        <SelectItem value="__none__">(Chưa chọn)</SelectItem>
                        {VN_PROVINCE_NAMES_34.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                        <SelectItem value="__other__">Khác (quốc gia ngoài Việt Nam)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {pfHometown === '__other__' && (
                    <div className="space-y-1.5">
                      <Label htmlFor="pf-hometown-country">Quốc gia</Label>
                      <Select value={pfHometownCountry} onValueChange={setPfHometownCountry}>
                        <SelectTrigger id="pf-hometown-country"><SelectValue placeholder="Chọn quốc gia" /></SelectTrigger>
                        <SelectContent className="max-h-72">
                          {COUNTRIES.filter((c) => c !== 'Việt Nam').map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  <div className="space-y-1.5 sm:col-span-2">
                    <Label htmlFor="pf-education" className="flex items-center gap-1"><GraduationCap className="h-3.5 w-3.5 text-emerald-600" /> Học vấn</Label>
                    <Input id="pf-education" value={pfEducation} onChange={(e) => setPfEducation(e.target.value.slice(0, 120))} placeholder="Trường, chuyên ngành, bằng cấp..." />
                  </div>
                </div>
              </div>

              {/* Nhóm HẸN HÒ + XÃ GIAO (mạng xã hội tìm người yêu) */}
              <div className="space-y-3 rounded-lg border bg-stone-50/60 p-3">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-stone-500"><Heart className="h-3.5 w-3.5" /> Hồ sơ hẹn hò &amp; xã giao</p>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="pf-height" className="flex items-center gap-1"><Ruler className="h-3.5 w-3.5 text-teal-600" /> Chiều cao (cm)</Label>
                    <Input id="pf-height" inputMode="numeric" value={pfHeight} onChange={(e) => setPfHeight(e.target.value.replace(/[^0-9]/g, '').slice(0, 3))} placeholder="Ví dụ: 170" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="pf-weight" className="flex items-center gap-1"><Weight className="h-3.5 w-3.5 text-teal-600" /> Cân nặng (kg)</Label>
                    <Input id="pf-weight" inputMode="numeric" value={pfWeight} onChange={(e) => setPfWeight(e.target.value.replace(/[^0-9]/g, '').slice(0, 3))} placeholder="Ví dụ: 65" />
                  </div>
                  <div className="space-y-1.5 sm:col-span-2">
                    <Label htmlFor="pf-relationship" className="flex items-center gap-1"><Heart className="h-3.5 w-3.5 text-rose-500" /> Tình trạng quan hệ</Label>
                    <Select value={pfRelationship} onValueChange={(v) => setPfRelationship(v)}>
                      <SelectTrigger id="pf-relationship"><SelectValue placeholder="Chọn tình trạng" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">(Chưa chọn)</SelectItem>
                        {RELATIONSHIP_OPTIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="pf-smoking" className="flex items-center gap-1"><Wine className="h-3.5 w-3.5 text-purple-600" /> Hút thuốc lá</Label>
                    <Select value={pfSmoking} onValueChange={(v) => setPfSmoking(v)}>
                      <SelectTrigger id="pf-smoking"><SelectValue placeholder="Chọn" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">(Chưa chọn)</SelectItem>
                        {SMOKING_OPTIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="pf-drinking" className="flex items-center gap-1"><Wine className="h-3.5 w-3.5 text-purple-600" /> Rượu bia</Label>
                    <Select value={pfDrinking} onValueChange={(v) => setPfDrinking(v)}>
                      <SelectTrigger id="pf-drinking"><SelectValue placeholder="Chọn" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">(Chưa chọn)</SelectItem>
                        {DRINKING_OPTIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5 sm:col-span-2">
                    <Label htmlFor="pf-pets">Thú cưng yêu thích</Label>
                    <Input id="pf-pets" value={pfPets} onChange={(e) => setPfPets(e.target.value.slice(0, 80))} placeholder="Chó, mèo, cá..." />
                  </div>
                </div>
              </div>

              {/* Nhóm SỞ THÍCH */}
              <div className="space-y-3 rounded-lg border bg-stone-50/60 p-3">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-stone-500"><Smile className="h-3.5 w-3.5" /> Sở thích</p>
                <div className="flex flex-wrap gap-1.5">
                  {pfInterests.map((i) => (
                    <span key={i} className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-medium text-emerald-800">
                      {i}
                      <button onClick={() => removeInterest(i)} className="text-emerald-500 hover:text-rose-500" aria-label={`Xoá sở thích ${i}`}><X className="h-3 w-3" /></button>
                    </span>
                  ))}
                  {pfInterests.length === 0 && <p className="text-xs text-muted-foreground">Chưa có sở thích nào.</p>}
                </div>
                <div className="flex gap-2">
                  <Input value={pfInterestInput} onChange={(e) => setPfInterestInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addInterest() } }} placeholder="Thêm sở thích, ví dụ: Đọc sách, Du lịch..." maxLength={40} />
                  <Button type="button" variant="outline" size="sm" onClick={addInterest} className="border-emerald-300 text-emerald-700 hover:bg-emerald-50"><Plus className="mr-1 h-3.5 w-3.5" /> Thêm</Button>
                </div>
              </div>

              <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={saveProfile} disabled={pfSaving}>
                {pfSaving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Save className="mr-1 h-4 w-4" />} Lưu hồ sơ chi tiết
              </Button>
            </div>
          )}

          {/* ---- BẢO MẬT ---- */}
          {section === 'security' && (
            <div className="space-y-4 rounded-xl border bg-white p-4 shadow-sm sm:p-5">
              <p className="flex items-center gap-2 text-sm font-bold"><KeyRound className="h-4 w-4 text-emerald-600" /> Đổi mật khẩu</p>
              <p className="text-xs text-muted-foreground">Dùng mật khẩu mạnh ít nhất 6 ký tự, không dùng ngày sinh hoặc họ tên.</p>
              <div className="grid max-w-md gap-3">
                <div className="space-y-1.5"><Label htmlFor="st-pw-cur">Mật khẩu hiện tại</Label><Input id="st-pw-cur" type="password" value={curPw} onChange={(e) => setCurPw(e.target.value)} autoComplete="current-password" /></div>
                <div className="space-y-1.5"><Label htmlFor="st-pw-new">Mật khẩu mới</Label><Input id="st-pw-new" type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} autoComplete="new-password" /></div>
                <div className="space-y-1.5"><Label htmlFor="st-pw-re">Nhập lại mật khẩu mới</Label><Input id="st-pw-re" type="password" value={rePw} onChange={(e) => setRePw(e.target.value)} autoComplete="new-password" /></div>
                <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={changePassword} disabled={pwBusy || !curPw || !newPw}>
                  {pwBusy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <KeyRound className="mr-1 h-4 w-4" />} Đổi mật khẩu
                </Button>
              </div>
              <p className="rounded-lg bg-stone-50 p-3 text-xs text-muted-foreground">Phiên đăng nhập giữ tối đa 30 ngày trên trình duyệt này. Đổi mật khẩu xong vẫn giữ đăng nhập hiện tại, lần đăng nhập sau dùng mật khẩu mới.</p>
            </div>
          )}

          {/* ---- QUYỀN RIÊNG TƯ ---- */}
          {section === 'privacy' && (
            <div className="space-y-4 rounded-xl border bg-white p-4 shadow-sm sm:p-5">
              <div className="flex items-center justify-between gap-3 rounded-lg border p-3">
                <div className="flex items-start gap-3">
                  <MapPin className="mt-0.5 h-5 w-5 text-sky-600" />
                  <div>
                    <p className="text-sm font-semibold">Định vị & Radar người gần</p>
                    <p className="text-xs text-muted-foreground">Bật để bạn bè, đồng nghiệp thấy bạn trong bán kính 500m–vài chục km. Tắt để ẩn hoàn toàn.</p>
                  </div>
                </div>
                <Switch checked={locationVisible} onCheckedChange={savePrivacy} aria-label="Bật/tắt định vị" />
              </div>
              <p className="rounded-lg bg-stone-50 p-3 text-xs text-muted-foreground">Vexon chỉ dùng vị trí cho tính năng Radar + thời tiết. Bạn tắt bất cứ lúc nào, dữ liệu vị trí không chia sẻ cho bên thứ ba.</p>

              <p className="flex items-center gap-2 text-sm font-bold pt-1"><Eye className="h-4 w-4 text-emerald-600" /> Hiển thị trạng thái hoạt động</p>
              <label className="flex items-center justify-between gap-3 rounded-lg border p-3">
                <span>
                  <span className="block text-sm font-medium">Hiện “Đang hoạt động”</span>
                  <span className="block text-xs text-muted-foreground">Tắt để luôn hiện Ngoại tuyến kể cả đang online</span>
                </span>
                <Switch checked={showOnline} onCheckedChange={(v) => { setShowOnline(v); void savePresencePref({ showOnline: v }, v ? 'Đã hiện lại trạng thái hoạt động' : 'Đã ẩn trạng thái hoạt động') }} aria-label="Hiện trạng thái đang hoạt động" />
              </label>
              <label className="flex items-center justify-between gap-3 rounded-lg border p-3">
                <span>
                  <span className="flex items-center gap-1.5 text-sm font-medium"><Clock3 className="h-3.5 w-3.5 text-emerald-600" /> Hiện “Hoạt động X phút trước”</span>
                  <span className="block text-xs text-muted-foreground">Tắt để không lộ thời gian hoạt động gần nhất</span>
                </span>
                <Switch checked={showLastSeen} onCheckedChange={(v) => { setShowLastSeen(v); void savePresencePref({ showLastSeen: v }, v ? 'Đã hiện thời gian hoạt động' : 'Đã ẩn thời gian hoạt động') }} aria-label="Hiện thời gian hoạt động gần nhất" />
              </label>
              <p className="rounded-lg bg-stone-50 p-3 text-xs text-muted-foreground">Khi tắt, người khác trong tìm kiếm sẽ thấy bạn “Ngoại tuyến” hoàn toàn. Riêng bạn vẫn thấy trạng thái của chính mình.</p>

              {/* Quyền riêng tư năm sinh & tuổi */}
              <p className="flex items-center gap-2 pt-1 text-sm font-bold"><Cake className="h-4 w-4 text-emerald-600" /> Năm sinh &amp; tuổi</p>
              <div className="rounded-lg border p-3">
                <p className="text-xs text-muted-foreground">Chọn ai được thấy năm sinh và độ tuổi của bạn trên hồ sơ và tìm kiếm.</p>
                <div className="mt-2 grid grid-cols-3 gap-2" role="radiogroup" aria-label="Chế độ hiển thị năm sinh">
                  {([
                    ['public', 'Công khai', <Globe2 key="p" className="h-4 w-4" />],
                    ['friends', 'Bạn bè', <UsersRound key="f" className="h-4 w-4" />],
                    ['private', 'Chỉ mình tôi', <Lock key="l" className="h-4 w-4" />],
                  ] as const).map(([k, label, icon]) => (
                    <button key={k} onClick={() => { setBdayVis(k); void savePresencePref({ birthdayVisibility: k }, k === 'public' ? 'Đã CÔNG KHAI năm sinh' : k === 'friends' ? 'Chỉ BẠN BÈ thấy năm sinh' : 'Đã ẨN năm sinh, chỉ mình bạn thấy') }}
                      aria-label={`Hiển thị năm sinh: ${label}`}
                      className={`flex flex-col items-center gap-1 rounded-lg border p-2.5 text-xs font-semibold transition-colors ${bdayVis === k ? 'border-emerald-500 bg-emerald-50 text-emerald-800' : 'border-stone-200 text-stone-600 hover:bg-stone-50'}`}>
                      {icon} {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quyền riêng tư TỪNG MỤC thông tin cá nhân kiểu Facebook */}
              <p className="flex items-center gap-2 pt-1 text-sm font-bold"><SlidersHorizontal className="h-4 w-4 text-emerald-600" /> Thông tin cá nhân — chọn ai được xem từng mục</p>
              <p className="rounded-lg bg-stone-50 p-3 text-xs text-muted-foreground">Giống Facebook: mỗi mục một quyền riêng. Người không đủ quyền sẽ không thấy mục đó trên hồ sơ của bạn (ẩn hẳn, không hiện “Chưa cập nhật”).</p>
              {([
                ['bio', 'Dòng giới thiệu (bio)', 'Câu giới thiệu ngắn ở đầu hồ sơ', <FileText key="i" className="h-4 w-4 text-emerald-600" />],
                ['gender', 'Giới tính', 'Nam / Nữ / Khác hiển thị trên hồ sơ', <UserRound key="i" className="h-4 w-4 text-sky-600" />],
                ['hometown', 'Quê quán', 'Nơi bạn sinh ra/ lớn lên', <HomeIcon key="i" className="h-4 w-4 text-emerald-600" />],
                ['job', 'Chức vụ & phòng ban', 'Chức danh, đơn vị công tác', <Briefcase key="i" className="h-4 w-4 text-amber-600" />],
                ['education', 'Học vấn & giáo dục', 'Trường, chuyên ngành đào tạo', <GraduationCap key="i" className="h-4 w-4 text-sky-600" />],
                ['phone', 'Số điện thoại', 'Liên hệ trực tiếp — nên để “Bạn bè”', <Phone key="i" className="h-4 w-4 text-stone-500" />],
                // Nhóm hẹn hò (mạng xã hội tìm người yêu): chọn ai được xem từng mục, giống FB
                ['height', 'Chiều cao', 'Mục hẹn hò — hiển thị cm trên hồ sơ', <Ruler key="i" className="h-4 w-4 text-teal-600" />],
                ['weight', 'Cân nặng', 'Mục hẹn hò — hiển thị kg trên hồ sơ', <Weight key="i" className="h-4 w-4 text-teal-600" />],
                ['relationship', 'Tình trạng quan hệ', 'Độc thân / Hẹn hò / Đã kết hôn...', <Heart key="i" className="h-4 w-4 text-rose-500" />],
                ['lifestyle', 'Lối sống', 'Rượu bia, thuốc lá, thú cưng', <Wine key="i" className="h-4 w-4 text-purple-600" />],
                ['interests', 'Sở thích', 'Danh sách sở thích hiển thị trên hồ sơ', <Smile key="i" className="h-4 w-4 text-amber-600" />],
                // Mục mở rộng (theo yêu cầu): dân tộc, CCCD, mã số thuế — khuyến nghị "Riêng tư"
                ['ethnicity', 'Dân tộc', 'Dân tộc thiểu số / Kinh...', <Globe2 key="i" className="h-4 w-4 text-emerald-600" />],
                ['citizenId', 'Căn cước công dân', 'Số CCCD 12 chữ số — KHUYẾN NGHỊ "Riêng tư"', <IdCard key="i" className="h-4 w-4 text-rose-500" />],
                ['taxCode', 'Mã số thuế', 'MST cá nhân — KHUYẾN NGHỊ "Riêng tư"', <Landmark key="i" className="h-4 w-4 text-rose-500" />],
              ] as const).map(([k, label, desc, icon]) => (
                <div key={k} className="rounded-lg border p-3">
                  <div className="flex items-start gap-3">
                    <span className="mt-0.5 shrink-0">{icon}</span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold">{label}</p>
                      <p className="text-xs text-muted-foreground">{desc}</p>
                    </div>
                  </div>
                  <div className="mt-2 grid grid-cols-3 gap-1.5" role="radiogroup" aria-label={`Quyền xem ${label}`}>
                    {([['public', 'Công khai', <Globe2 key="p" className="h-3.5 w-3.5" />], ['friends', 'Bạn bè', <UsersRound key="f" className="h-3.5 w-3.5" />], ['private', 'Chỉ mình tôi', <Lock key="l" className="h-3.5 w-3.5" />]] as const).map(([vk, vlabel, vicon]) => (
                      <button key={vk} onClick={() => void saveFieldVis(k, vk, label)}
                        aria-label={`${label}: ${vlabel}`}
                        className={`flex flex-col items-center gap-0.5 rounded-lg border px-1 py-2 text-[11px] font-semibold transition-colors ${fieldVis[k] === vk ? 'border-emerald-500 bg-emerald-50 text-emerald-800' : 'border-stone-200 text-stone-600 hover:bg-stone-50'}`}>
                        {vicon} {vlabel}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ---- GIAO DIỆN ---- */}
          {section === 'appearance' && (
            <div className="space-y-4 rounded-xl border bg-white p-4 shadow-sm sm:p-5">
              <div>
                <p className="flex items-center gap-2 text-sm font-bold"><Palette className="h-4 w-4 text-emerald-600" /> Chế độ hiển thị</p>
                <div className="mt-2 grid grid-cols-2 gap-2 sm:max-w-sm">
                  {([['day', 'Ban ngày', <Sun key="s" className="h-4 w-4" />], ['night', 'Ban đêm', <Moon key="m" className="h-4 w-4" />]] as const).map(([k, label, icon]) => (
                    <button key={k} onClick={() => theme.set({ mode: k as ThemeMode })} aria-label={`Chế độ ${label}`}
                      className={`flex items-center justify-center gap-2 rounded-lg border p-2.5 text-sm font-semibold transition-colors ${theme.mode === k ? 'border-emerald-500 bg-emerald-50 text-emerald-800' : 'border-stone-200 text-stone-600 hover:bg-stone-50'}`}>
                      {icon} {label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="flex items-center gap-2 text-sm font-bold"><span className="flex h-8 w-8 items-center justify-center rounded-lg bg-stone-100 text-sm font-black">Aa</span> Cỡ chữ toàn app</p>
                <div className="mt-2 grid grid-cols-3 gap-2 sm:max-w-sm">
                  {([['small', 'Nhỏ', 'text-sm'], ['medium', 'Vừa', 'text-base'], ['large', 'To', 'text-lg']] as const).map(([k, label, cls]) => (
                    <button key={k} onClick={() => theme.set({ fontSize: k as 'small' | 'medium' | 'large' })} aria-label={`Cỡ chữ ${label}`}
                      className={`rounded-lg border p-2.5 text-center font-semibold transition-colors ${theme.fontSize === k ? 'border-emerald-500 bg-emerald-50 text-emerald-800' : 'border-stone-200 text-stone-600 hover:bg-stone-50'}`}>
                      <span className={cls}>{label}</span>
                    </button>
                  ))}
                </div>
                <p className="mt-1.5 text-xs text-muted-foreground">Nhỏ phù hợp màn hình nhỏ, To phù hợp người lớn tuổi — áp dụng toàn app ngay lập tức.</p>
              </div>

              <div>
                <p className="flex items-center gap-2 text-sm font-bold"><Sparkles className="h-4 w-4 text-emerald-600" /> Hiệu ứng thời tiết &amp; 4 mùa <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-[10px] font-bold text-emerald-700">4 MÙA</span></p>
                <div className="mt-1 text-xs text-muted-foreground">Hoa anh đào, đom đóm, lá vàng, tuyết và mưa rơi nhẹ nhàng bằng CSS mượt — không che nội dung, không nặng máy; chế độ Tự động cập nhật theo thời tiết thật (GPS).</div>
                <label className="mt-3 flex items-center justify-between gap-3 rounded-lg border p-3">
                  <span className="text-sm font-medium">Bật hiệu ứng</span>
                  <Switch checked={theme.effectsOn} onCheckedChange={(v) => theme.set({ effectsOn: v })} aria-label="Bật/tắt hiệu ứng" />
                </label>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  {EFFECTS.map((e) => (
                    <button key={e.key} onClick={() => theme.set({ effect: e.key })} disabled={!theme.effectsOn}
                      className={`flex items-start gap-2.5 rounded-lg border p-2.5 text-left transition-colors disabled:opacity-40 ${theme.effect === e.key ? 'border-emerald-500 bg-emerald-50' : 'border-stone-200 hover:bg-stone-50'}`}
                      aria-label={`Hiệu ứng ${e.label}`}>
                      <span className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${theme.effect === e.key ? 'bg-emerald-600 text-white' : 'bg-stone-100 text-stone-500'}`}>{e.icon}</span>
                      <span>
                        <span className="block text-sm font-semibold">{e.label}{theme.effect === e.key && <Check className="ml-1 inline h-3.5 w-3.5 text-emerald-600" />}</span>
                        <span className="block text-[11px] text-muted-foreground">{e.desc}</span>
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ---- THÔNG BÁO ---- */}
          {section === 'notify' && (
            <div className="space-y-3 rounded-xl border bg-white p-4 shadow-sm sm:p-5">
              <p className="flex items-center gap-2 text-sm font-bold"><Bell className="h-4 w-4 text-emerald-600" /> Thông báo</p>
              <label className="flex items-center justify-between gap-3 rounded-lg border p-3">
                <span>
                  <span className="block text-sm font-medium">Âm thanh thông báo</span>
                  <span className="block text-xs text-muted-foreground">Tiếng “ting” khi có tin nhắn, lượt thích mới</span>
                </span>
                <Switch checked={theme.notifSound} onCheckedChange={(v) => theme.set({ notifSound: v })} aria-label="Âm thanh thông báo" />
              </label>
              <p className="rounded-lg bg-stone-50 p-3 text-xs text-muted-foreground">Thông báo trong app luôn bật: lời mời kết bạn, lượt thích, bình luận, duyệt đơn từ, giao việc, quà live...</p>
            </div>
          )}

          {/* ---- DỮ LIỆU ---- */}
          {section === 'data' && (
            <div className="space-y-3 rounded-xl border bg-white p-4 shadow-sm sm:p-5">
              <p className="flex items-center gap-2 text-sm font-bold"><Database className="h-4 w-4 text-emerald-600" /> Dữ liệu &amp; bộ nhớ</p>
              <div className="flex items-center justify-between gap-3 rounded-lg border p-3">
                <div>
                  <p className="flex items-center gap-1.5 text-sm font-medium"><Eraser className="h-3.5 w-3.5 text-teal-600" /> Xoá tìm kiếm gần đây</p>
                  <p className="text-xs text-muted-foreground">Xoá danh sách từ khoá bạn từng tìm ở Trang chủ (chỉ trên máy này)</p>
                </div>
                <Button variant="outline" size="sm" onClick={clearRecentSearches} aria-label="Xoá tìm kiếm gần đây">Xoá</Button>
              </div>
              <div className="flex items-center justify-between gap-3 rounded-lg border p-3">
                <div>
                  <p className="flex items-center gap-1.5 text-sm font-medium"><Download className="h-3.5 w-3.5 text-sky-600" /> Tải dữ liệu cá nhân</p>
                  <p className="text-xs text-muted-foreground">Xuất hồ sơ, cài đặt của bạn thành file JSON dự phòng</p>
                </div>
                <Button variant="outline" size="sm" onClick={() => void exportMyData()} aria-label="Tải dữ liệu cá nhân">Tải file</Button>
              </div>
              <p className="rounded-lg bg-stone-50 p-3 text-xs text-muted-foreground">Ảnh bạn đăng được nén ngay trên máy trước khi upload nên không tốn nhiều bộ nhớ demo. Dữ liệu tin nhắn, bài viết lưu trên máy chủ demo của app.</p>
            </div>
          )}

          {/* ---- VỀ ---- */}
          {section === 'about' && (
            <div className="space-y-3 rounded-xl border bg-white p-4 shadow-sm text-sm sm:p-5">
              <p className="flex items-center gap-2 font-bold"><Info className="h-4 w-4 text-emerald-600" /> Về Vexon</p>
              <p className="text-muted-foreground">Super App Quản trị Doanh nghiệp All-in-One, miễn phí 100%.</p>
              <ul className="list-inside list-disc space-y-1 text-xs text-muted-foreground">
                <li>Phiên bản 2.1, Next.js 16 + Prisma + SQLite</li>
                <li>Splash logo + thanh loading, trang 404 chibi tự về trang chủ sau 5 giây</li>
                <li>AI tích hợp: viết bài giùm, tóm tắt bài dài, gợi ý trả lời tin nhắn, Trợ lý AI nổi, Chatbot AI /chat</li>
                <li>Hiệu ứng 4 mùa nhẹ nhàng: hoa anh đào, đom đóm, lá vàng, tuyết, mưa nhiều tầng và sao đêm (CSS mượt, nhẹ máy)</li>
                <li>Thời tiết thực: Open-Meteo theo GPS của bạn</li>
                <li>Chatbox Vexon Bot trong Tin nhắn: thông báo quà tặng live + trò chuyện AI</li>
                <li>Quyền riêng tư năm sinh: Công khai / Bạn bè / Chỉ mình tôi</li>
                <li>Quyền riêng tư từng mục kiểu Facebook (bio, quê quán, học vấn, SĐT...) + nhóm hẹn hò: chiều cao, cân nặng, tình trạng quan hệ, lối sống, sở thích</li>
                <li>Đăng ký chỉ tạo tài khoản cá nhân; nâng cấp DOANH NGHIỆP nộp đơn trừ tiền ví, chờ Ban Giám đốc duyệt (từ chối hoàn 100%)</li>
                <li>Gia nhập doanh nghiệp: chủ công ty duyệt thành viên, thành viên hưởng x2 thưởng điểm danh + badge công ty</li>
                <li>Một ví tiền USD, Nhóm kiểu Facebook, Lưu bài viết &amp; Kho lưu trữ, Cài đặt kiểu Zalo</li>
                <li>Hồ sơ chi tiết: quê quán 34 tỉnh/thành Việt Nam sau sáp nhập + quốc gia, dân tộc, CCCD, MST, chiều cao, cân nặng, sở thích...</li>
                <li>Ví &amp; Ngân hàng: quản lý thẻ ngân hàng cá nhân, nạp/rút bằng USD có admin duyệt, đổi theo tỷ giá USD/VND thị trường thực tế, rút chịu thuế 10%, quà tặng live bị trừ 30% phí nền tảng, yêu cầu hoàn tiền trong 7 ngày nếu chưa tiêu tiền</li>
              </ul>
            </div>
          )}

          {/* ---- VÍ & NGÂN HÀNG ---- */}
          {section === 'wallet' && (
            <div className="space-y-4 rounded-xl border bg-white p-4 shadow-sm sm:p-5">
              <div className="flex items-center justify-between gap-2">
                <p className="flex items-center gap-2 text-sm font-bold"><Coins className="h-4 w-4 text-emerald-600" /> Ví tiền &amp; Ngân hàng</p>
                <Button size="sm" variant="outline" onClick={loadWallet} disabled={walletLoading} aria-label="Tải lại ví">{walletLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Tải lại'}</Button>
              </div>
              <p className="rounded-lg bg-stone-50 p-3 text-xs text-muted-foreground">Số dư ví dùng chung cho cả mạng xã hội &amp; công cụ AI, tính bằng <b>USD</b> theo tỷ giá thị trường thực tế. Nạp/rút có admin Ban Giám đốc duyệt: <b>NẠP</b> nhập số USD → chuyển khoản VND tương ứng qua ngân hàng, <b>RÚT</b> nhập số USD → nhận VND về thẻ (trừ thuế 10%). Quà tặng live người nhận chỉ được 70% (bị trừ 30% phí nền tảng).</p>

              {/* Số dư ví */}
              <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3">
                <p className="text-xs font-semibold text-emerald-700">Số dư ví hiện tại</p>
                <p className="mt-0.5 text-2xl font-black text-emerald-700">{fmtXuWithUsd(walletCoins, rate)}</p>
                <p className="mt-1 text-[11px] text-emerald-700/80">Rút hết về ngân hàng nhận ≈ {(walletCoins * 100 * 0.9).toLocaleString('vi-VN', { maximumFractionDigits: 0 })}đ (đã trừ thuế 10%)</p>
              </div>

              {/* THÔNG TIN TK NGÂN HÀNG CỦA WEB (để user chuyển khoản nạp tiền) */}
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-3">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-amber-700"><Landmark className="h-3.5 w-3.5" /> Tài khoản nhận tiền nạp của Vexon</p>
                <div className="mt-2 grid gap-1.5 text-sm text-amber-900">
                  <p>Ngân hàng: <b>{WEB_BANK.bank}</b> (SWIFT: <b>{WEB_BANK.swift}</b>)</p>
                  <p>Số tài khoản: <b>{WEB_BANK.account}</b></p>
                  <p>Chủ tài khoản: <b>{WEB_BANK.holder}</b></p>
                </div>
                <p className="mt-1.5 text-[11px] text-amber-700/80">Bạn chuyển khoản vào TK trên kèm nội dung MÃ REF (bất kỳ 6-8 ký tự, ví dụ số điện thoại của bạn), quay lại đây nhập số USD muốn nạp + MÃ REF rồi gửi yêu cầu → admin kiểm tra sao kê ngân hàng rồi duyệt, ví được cộng đúng số USD đã nhập (quy theo tỷ giá thị trường).</p>
              </div>

              {/* THẺ NGÂN HÀNG CỦA TÔI (để nhận tiền khi rút) */}
              <div className="space-y-3">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-stone-500"><IdCard className="h-3.5 w-3.5" /> Thẻ ngân hàng của tôi (nhận tiền rút)</p>
                {bankCards.length === 0 ? (
                  <p className="rounded-xl border border-dashed p-4 text-center text-xs text-muted-foreground">Chưa có thẻ ngân hàng. Thêm thẻ bên dưới để rút tiền về tài khoản của bạn.</p>
                ) : (
                  <div className="space-y-2">
                    {bankCards.map((c) => (
                      <div key={c.id} className={`rounded-lg border p-3 ${c.isPrimary ? 'border-emerald-300 bg-emerald-50/50' : 'border-stone-200'}`}>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="rounded bg-stone-100 px-2 py-0.5 text-xs font-bold text-stone-700">{c.bankName}</span>
                          {c.bankSwift && <span className="text-[10px] text-muted-foreground">SWIFT: {c.bankSwift}</span>}
                          {c.isPrimary && <span className="rounded bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700">MẶC ĐỊNH</span>}
                        </div>
                        <p className="mt-1.5 font-mono text-sm font-semibold">{c.accountNumber}</p>
                        <p className="text-xs text-muted-foreground">{c.accountHolder}{c.branch ? ` · ${c.branch}` : ''}{c.note ? ` · ${c.note}` : ''}</p>
                        <div className="mt-2 flex gap-2">
                          {!c.isPrimary && <Button size="sm" variant="outline" className="h-7" onClick={() => setPrimaryCard(c.id)}>Đặt mặc định</Button>}
                          <Button size="sm" variant="outline" className="h-7 border-rose-300 text-rose-600 hover:bg-rose-50" onClick={() => deleteCard(c.id)}>Xoá</Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                {/* Form thêm thẻ */}
                <div className="rounded-lg border border-dashed p-3">
                  <p className="text-xs font-semibold text-stone-600">Thêm thẻ ngân hàng</p>
                  <div className="mt-2 grid gap-2 sm:grid-cols-2">
                    <Input value={bcBankName} onChange={(e) => setBcBankName(e.target.value)} placeholder="Tên ngân hàng, ví dụ Techcombank" />
                    <Input value={bcBankSwift} onChange={(e) => setBcBankSwift(e.target.value)} placeholder="Mã SWIFT/BIC (tuỳ chọn)" />
                    <Input value={bcAccountNumber} onChange={(e) => setBcAccountNumber(e.target.value.replace(/[^0-9]/g, ''))} placeholder="Số tài khoản" inputMode="numeric" />
                    <Input value={bcAccountHolder} onChange={(e) => setBcAccountHolder(e.target.value)} placeholder="Tên chủ TK (IN HOA không dấu)" />
                    <Input value={bcBranch} onChange={(e) => setBcBranch(e.target.value)} placeholder="Chi nhánh (tuỳ chọn)" />
                    <Input value={bcNote} onChange={(e) => setBcNote(e.target.value)} placeholder="Ghi chú (tuỳ chọn)" />
                  </div>
                  <Button size="sm" className="mt-2 bg-emerald-600 hover:bg-emerald-700" onClick={saveBankCard} disabled={bcSaving}>
                    {bcSaving ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <Plus className="mr-1 h-3.5 w-3.5" />} Thêm thẻ
                  </Button>
                </div>
              </div>

              {/* NẠP TIỀN */}
              <div className="rounded-lg border p-3">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-emerald-700"><Coins className="h-3.5 w-3.5" /> Nạp tiền (USD)</p>
                <p className="mt-1 text-[11px] text-muted-foreground">Bước 1: chuyển khoản vào TK Techcombank của Vexon ở trên với nội dung MÃ REF (số VND = số USD × tỷ giá thị trường). Bước 2: nhập số USD + MÃ REF bên dưới rồi gửi — ví được cộng đúng số USD. Chờ admin duyệt.</p>
                <div className="mt-2 grid gap-2 sm:grid-cols-2">
                  <Input value={depositUsd} onChange={(e) => setDepositUsd(e.target.value)} placeholder="Số USD muốn nạp (ví dụ 5)" inputMode="decimal" />
                  <Input value={depositProof} onChange={(e) => setDepositProof(e.target.value)} placeholder="Mã REF (nội dung CK)" maxLength={32} />
                  <Select value={depositCard} onValueChange={setDepositCard}>
                    <SelectTrigger className="sm:col-span-1"><SelectValue placeholder="Thẻ đã dùng chuyển (tuỳ chọn)" /></SelectTrigger>
                    <SelectContent>{bankCards.filter((c) => c.status === 'active').map((c) => <SelectItem key={c.id} value={c.id}>{c.bankName} · {c.accountNumber}</SelectItem>)}</SelectContent>
                  </Select>
                  <Input value={depositNote} onChange={(e) => setDepositNote(e.target.value)} placeholder="Ghi chú cho admin (tuỳ chọn)" />
                </div>
                <Button size="sm" className="mt-2 bg-emerald-600 hover:bg-emerald-700" onClick={submitDeposit} disabled={depositBusy}>
                  {depositBusy ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <Coins className="mr-1 h-3.5 w-3.5" />} Gửi yêu cầu nạp
                </Button>
              </div>

              {/* RÚT TIỀN */}
              <div className="rounded-lg border p-3">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-rose-600"><Coins className="h-3.5 w-3.5" /> Rút tiền (USD)</p>
                <p className="mt-1 text-[11px] text-muted-foreground">Nhập số USD muốn rút — đổi theo tỷ giá thị trường tại lúc gửi và chịu thuế 10% (ví dụ rút $10 → nhận 90% giá trị quy ra VND). Số dư bị trừ ngay khi gửi yêu cầu, hoàn lại 100% nếu admin từ chối. Tiền chuyển vào thẻ ngân hàng của bạn (mất 1-3 ngày làm việc).</p>
                <div className="mt-2 grid gap-2 sm:grid-cols-2">
                  <Input value={withdrawUsd} onChange={(e) => setWithdrawUsd(e.target.value)} placeholder={`Số USD muốn rút (đang có ${fmtUsdFromXu(walletCoins, rate)})`} inputMode="decimal" />
                  <Select value={withdrawCard} onValueChange={setWithdrawCard}>
                    <SelectTrigger><SelectValue placeholder="Thẻ nhận tiền rút" /></SelectTrigger>
                    <SelectContent>{bankCards.filter((c) => c.status === 'active').map((c) => <SelectItem key={c.id} value={c.id}>{c.bankName} · {c.accountNumber}</SelectItem>)}</SelectContent>
                  </Select>
                  <Input value={withdrawNote} onChange={(e) => setWithdrawNote(e.target.value)} placeholder="Ghi chú cho admin (tuỳ chọn)" className="sm:col-span-2" />
                </div>
                <Button size="sm" className="mt-2 bg-rose-600 hover:bg-rose-700" onClick={submitWithdraw} disabled={withdrawBusy}>
                  {withdrawBusy ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <Coins className="mr-1 h-3.5 w-3.5" />} Gửi yêu cầu rút
                </Button>
              </div>

              {/* LỊCH SỬ GIAO DỊCH NẠP/RÚT */}
              <div className="space-y-2">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-stone-500"><Clock3 className="h-3.5 w-3.5" /> Lịch sử nạp/rút tiền</p>
                {walletTxs.length === 0 ? (
                  <p className="rounded-xl border border-dashed p-4 text-center text-xs text-muted-foreground">Chưa có giao dịch nào.</p>
                ) : (
                  <div className="space-y-1.5">
                    {walletTxs.map((t) => (
                      <div key={t.id} className="rounded-lg border p-2.5 text-sm">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${t.type === 'deposit' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>{t.type === 'deposit' ? 'NẠP' : 'RÚT'}</span>
                          <span className="font-semibold">{fmtXuWithUsd(t.amountXu, rate)}</span>
                          <span className="text-xs text-muted-foreground">↔ {t.amountVnd.toLocaleString('vi-VN')}đ{t.taxVnd ? ` (thuế ${t.taxVnd.toLocaleString('vi-VN')}đ)` : ''}</span>
                          <span className="ml-auto text-[10px] text-muted-foreground">{new Date(t.createdAt).toLocaleString('vi-VN')}</span>
                        </div>
                        <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                          {t.status === 'pending' && <span className="rounded bg-sky-100 px-1.5 py-0.5 text-sky-700">CHỜ DUYỆT</span>}
                          {t.status === 'approved' && <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-emerald-700">ĐÃ DUYỆT</span>}
                          {t.status === 'rejected' && <span className="rounded bg-rose-100 px-1.5 py-0.5 text-rose-700">TỪ CHỐI</span>}
                          {t.proofCode && <span>REF: {t.proofCode}</span>}
                          {t.bankName && <span>{t.bankName} · {t.accountNumber}</span>}
                          {t.userNote && <span>· Ghi chú: {t.userNote}</span>}
                          {t.adminNote && <span>· Admin: {t.adminNote}</span>}
                        </div>
                        {/* Yêu cầu hoàn tiền (chỉ cho nạp đã duyệt, chưa tiêu tiền) */}
                        {t.type === 'deposit' && t.status === 'approved' && (
                          <div className="mt-1.5">
                            <Button size="sm" variant="outline" className="h-7 border-amber-300 text-amber-700 hover:bg-amber-50" onClick={() => setRefundModal({ txId: t.id, amountVnd: t.amountVnd })} aria-label="Yêu cầu hoàn tiền">
                              <Handshake className="mr-1 h-3 w-3" /> Yêu cầu hoàn tiền (nếu chưa tiêu tiền)
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* DANH SÁCH YÊU CẦU HOÀN TIỀN + CHATBOX HỖ TRỢ */}
              {myRefunds.length > 0 && (
                <div className="space-y-2">
                  <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-stone-500"><Handshake className="h-3.5 w-3.5" /> Yêu cầu hoàn tiền của tôi + chatbox hỗ trợ</p>
                  {myRefunds.map((r) => (
                    <div key={r.id} className="rounded-lg border p-3">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        {r.status === 'pending' && <span className="rounded bg-sky-100 px-1.5 py-0.5 text-sky-700">CHỜ ADMIN</span>}
                        {r.status === 'approved' && <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-emerald-700">ĐÃ DUYỆT (đã hoàn {r.refundVnd.toLocaleString('vi-VN')}đ)</span>}
                        {r.status === 'rejected' && <span className="rounded bg-rose-100 px-1.5 py-0.5 text-rose-700">TỪ CHỐI</span>}
                        <span className="ml-auto text-muted-foreground">{new Date(r.createdAt).toLocaleString('vi-VN')}</span>
                      </div>
                      <p className="mt-1 text-xs"><b>Lý do:</b> {r.reason}</p>
                      {r.adminNote && <p className="text-xs text-muted-foreground">Admin: {r.adminNote}</p>}
                      {/* Chatbox hỗ trợ */}
                      <div className="mt-2 space-y-1.5 rounded border bg-stone-50 p-2">
                        <p className="text-[10px] font-bold uppercase tracking-wide text-stone-500">Chatbox hỗ trợ (admin phản hồi trong 7 ngày)</p>
                        <div className="max-h-40 space-y-1 overflow-y-auto">
                          {r.messages.map((m) => (
                            <div key={m.id} className={`text-xs ${m.role === 'user' ? 'text-right' : ''}`}>
                              <span className={`inline-block rounded-lg px-2 py-1 ${m.role === 'user' ? 'bg-emerald-100 text-emerald-800' : m.role === 'admin' ? 'bg-sky-100 text-sky-800' : 'bg-stone-200 text-stone-700'}`}>{m.content}</span>
                            </div>
                          ))}
                          {r.messages.length === 0 && <p className="text-[10px] text-muted-foreground">Chưa có tin nhắn. Hãy mô tả thêm yêu cầu của bạn.</p>}
                        </div>
                        {r.status === 'pending' && (
                          <div className="flex gap-1.5">
                            <Input value={refundChatTarget === r.id ? refundChatInput : ''} onChange={(e) => { setRefundChatTarget(r.id); setRefundChatInput(e.target.value) }} placeholder="Nhập tin nhắn cho admin..." className="h-7 text-xs" onKeyDown={(e) => { if (e.key === 'Enter' && refundChatTarget === r.id) sendRefundMsg(r.id) }} />
                            <Button size="sm" className="h-7 bg-emerald-600 hover:bg-emerald-700" onClick={() => sendRefundMsg(r.id)}>Gửi</Button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* MODAL YÊU CẦU HOÀN TIỀN */}
              {refundModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
                  <div
                    ref={refundFit.attach}
                    style={refundFit.supportsZoom && refundFit.fit ? { zoom: refundFit.fit.z, maxHeight: refundFit.fit.maxH } : undefined}
                    className={refundFit.supportsZoom ? (refundFit.fit?.maxH ? 'w-full max-w-md overflow-y-auto rounded-xl border bg-white p-4 shadow-lg' : 'w-full max-w-md rounded-xl border bg-white p-4 shadow-lg') : 'max-h-[calc(100dvh-2rem)] w-full max-w-md overflow-y-auto rounded-xl border bg-white p-4 shadow-lg'}
                  >
                    <p className="flex items-center gap-1.5 text-sm font-bold"><Handshake className="h-4 w-4 text-amber-600" /> Yêu cầu hoàn tiền</p>
                    <p className="mt-1 text-xs text-muted-foreground">Hoàn tiền chỉ hợp lệ khi bạn <b>chưa tiêu xu</b> từ lần nạp này. Admin sẽ kiểm tra và xử lý trong <b>7 ngày</b>. Số tiền hoàn tối đa: <b>{refundModal.amountVnd.toLocaleString('vi-VN')}đ</b> chuyển về thẻ ngân hàng của bạn.</p>
                    <Label htmlFor="refund-reason" className="mt-3 block text-xs font-semibold">Lý do hoàn tiền</Label>
                    <textarea id="refund-reason" value={refundReason} onChange={(e) => setRefundReason(e.target.value)} rows={3} className="mt-1 w-full rounded-lg border px-3 py-2 text-sm" placeholder="Mô tả lý do: chưa dùng, nạp nhầm, v.v." />
                    <div className="mt-3 flex gap-2">
                      <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={submitRefund} disabled={refundBusy}>{refundBusy ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : null} Gửi yêu cầu</Button>
                      <Button size="sm" variant="outline" onClick={() => setRefundModal(null)}>Huỷ</Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ---- DUYỆT NẠP/RÚT (riêng admin) ---- */}
          {section === 'approveWallet' && (
            <div className="space-y-3 rounded-xl border bg-white p-4 shadow-sm sm:p-5">
              <div className="flex items-center justify-between gap-2">
                <p className="flex items-center gap-2 text-sm font-bold"><Coins className="h-4 w-4 text-emerald-600" /> Duyệt giao dịch nạp/rút tiền</p>
                <Button size="sm" variant="outline" onClick={loadAdminWallet} disabled={adminWalletLoading} aria-label="Tải lại">{adminWalletLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Tải lại'}</Button>
              </div>
              <p className="rounded-lg bg-stone-50 p-3 text-xs text-muted-foreground">DUYỆT nạp: cộng đúng số USD user đã nạp (quy theo tỷ giá) cho user. TỪ CHỐI: không cộng, ghi lý do. DUYỆT rút: tiền đã trừ sẵn khi gửi, chuyển VND vào thẻ của user (sau thuế 10%). TỪ CHỐI rút: hoàn lại toàn bộ số đã trừ, ghi lý do.</p>
              {adminWalletTxs.length === 0 ? (
                <p className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">Chưa có giao dịch chờ duyệt.</p>
              ) : (
                <div className="space-y-2">
                  {adminWalletTxs.map((t) => (
                    <div key={t.id} className="rounded-lg border p-3">
                      <div className="flex flex-wrap items-center gap-2.5">
                        <Avatar name={t.user?.fullName || '?'} color={t.user?.avatarColor || '#10b981'} size={36} img={t.user?.avatarImage} />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-bold">{t.user?.fullName || '—'} (@{t.user?.username || '—'})</p>
                          <p className="truncate text-xs text-muted-foreground">{t.type === 'deposit' ? 'NẠP' : 'RÚT'} {fmtXuWithUsd(t.amountXu, rate)} ↔ {t.amountVnd.toLocaleString('vi-VN')}đ{t.taxVnd ? ` (thuế ${t.taxVnd.toLocaleString('vi-VN')}đ)` : ''} · {new Date(t.createdAt).toLocaleString('vi-VN')}</p>
                        </div>
                        {t.status === 'pending' && <span className="rounded bg-sky-100 px-2 py-0.5 text-[10px] font-bold text-sky-700">CHỜ DUYỆT</span>}
                        {t.status === 'approved' && <span className="rounded bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700">ĐÃ DUYỆT</span>}
                        {t.status === 'rejected' && <span className="rounded bg-rose-100 px-2 py-0.5 text-[10px] font-bold text-rose-700">TỪ CHỐI</span>}
                      </div>
                      {(t.proofCode || t.userNote || t.bankName) && (
                        <p className="mt-1.5 text-xs text-muted-foreground">
                          {t.proofCode && `REF: ${t.proofCode} · `}
                          {t.bankName && `${t.bankName} · ${t.accountNumber} · `}
                          {t.userNote && `Ghi chú: ${t.userNote}`}
                        </p>
                      )}
                      {t.adminNote && <p className="text-xs text-muted-foreground">Admin: {t.adminNote}</p>}
                      {t.status === 'pending' && (
                        <div className="mt-2 flex gap-2">
                          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => {
                            const note = window.prompt('Ghi chú duyệt (để trống nếu không cần):') || ''
                            reviewWalletTx(t.id, 'approve', note)
                          }}><CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Duyệt</Button>
                          <Button size="sm" variant="outline" className="border-rose-300 text-rose-600 hover:bg-rose-50" onClick={() => {
                            const note = window.prompt('Lý do từ chối (để trống nếu không cần):') || ''
                            reviewWalletTx(t.id, 'reject', note)
                          }}><XCircle className="mr-1 h-3.5 w-3.5" /> Từ chối</Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ---- DUYỆT HOÀN TIỀN (riêng admin) ---- */}
          {section === 'approveRefund' && (
            <div className="space-y-3 rounded-xl border bg-white p-4 shadow-sm sm:p-5">
              <div className="flex items-center justify-between gap-2">
                <p className="flex items-center gap-2 text-sm font-bold"><Handshake className="h-4 w-4 text-emerald-600" /> Duyệt yêu cầu hoàn tiền</p>
                <Button size="sm" variant="outline" onClick={loadAdminRefund} disabled={adminRefundLoading} aria-label="Tải lại">{adminRefundLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Tải lại'}</Button>
              </div>
              <p className="rounded-lg bg-stone-50 p-3 text-xs text-muted-foreground">Hợp lệ = user chưa tiêu tiền từ nạp gốc → DUYỆT → chuyển lại {`{refundVnd}đ`} vào thẻ ngân hàng của user (ghi chú admin). Không hợp lệ = đã tiêu tiền → TỪ CHỐI → thông báo lý do. SLA: 7 ngày kể từ khi user nộp yêu cầu.</p>
              {adminRefunds.length === 0 ? (
                <p className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">Chưa có yêu cầu hoàn tiền nào.</p>
              ) : (
                <div className="space-y-2">
                  {adminRefunds.map((r) => (
                    <div key={r.id} className="rounded-lg border p-3">
                      <div className="flex flex-wrap items-center gap-2.5">
                        <Avatar name={r.user?.fullName || '?'} color={r.user?.avatarColor || '#10b981'} size={36} img={r.user?.avatarImage} />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-bold">{r.user?.fullName || '—'} (@{r.user?.username || '—'})</p>
                          <p className="truncate text-xs text-muted-foreground">Hoàn {r.refundVnd.toLocaleString('vi-VN')}đ · nộp {new Date(r.createdAt).toLocaleString('vi-VN')} ({Math.floor((Date.now() - new Date(r.createdAt).getTime()) / 86400000)}/7 ngày)</p>
                        </div>
                        {r.status === 'pending' && <span className="rounded bg-sky-100 px-2 py-0.5 text-[10px] font-bold text-sky-700">CHỜ</span>}
                        {r.status === 'approved' && <span className="rounded bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700">ĐÃ HOÀN</span>}
                        {r.status === 'rejected' && <span className="rounded bg-rose-100 px-2 py-0.5 text-[10px] font-bold text-rose-700">TỪ CHỐI</span>}
                      </div>
                      <p className="mt-1.5 text-xs"><b>Lý do:</b> {r.reason}</p>
                      {r.adminNote && <p className="text-xs text-muted-foreground">Ghi chú admin: {r.adminNote}</p>}
                      {/* Chatbox với user */}
                      {r.messages.length > 0 && (
                        <div className="mt-2 max-h-32 space-y-1 overflow-y-auto rounded border bg-stone-50 p-2">
                          {r.messages.map((m) => (
                            <div key={m.id} className={`text-xs ${m.role === 'admin' ? 'text-right' : ''}`}>
                              <span className={`inline-block rounded-lg px-2 py-1 ${m.role === 'user' ? 'bg-stone-200 text-stone-700' : m.role === 'admin' ? 'bg-sky-100 text-sky-800' : 'bg-stone-100 text-stone-500'}`}>{m.content}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      {r.status === 'pending' && (
                        <div className="mt-2 flex gap-2">
                          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => {
                            const note = window.prompt('Ghi chú duyệt (để trống nếu không cần):') || ''
                            reviewRefund(r.id, 'approve', note)
                          }}><CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Duyệt (hoàn tiền)</Button>
                          <Button size="sm" variant="outline" className="border-rose-300 text-rose-600 hover:bg-rose-50" onClick={() => {
                            const note = window.prompt('Lý do từ chối (để trống nếu không cần):') || ''
                            reviewRefund(r.id, 'reject', note)
                          }}><XCircle className="mr-1 h-3.5 w-3.5" /> Từ chối</Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ---- DUYỆT DOANH NGHIỆP (riêng admin/Ban Giám đốc) ---- */}
          {section === 'approve' && (
            <div className="space-y-3 rounded-xl border bg-white p-4 shadow-sm sm:p-5">
              <div className="flex items-center justify-between gap-2">
                <p className="flex items-center gap-2 text-sm font-bold"><BadgeCheck className="h-4 w-4 text-emerald-600" /> Duyệt nâng cấp doanh nghiệp</p>
                <Button size="sm" variant="outline" onClick={loadAdminApps} aria-label="Tải lại danh sách đơn">{adminLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Tải lại'}</Button>
              </div>
              <p className="rounded-lg bg-stone-50 p-3 text-xs text-muted-foreground">Đơn nộp từ Cài đặt → Tài khoản: người dùng trừ {fmtUsdFromXu(bizCost, rate)}, bạn DUYỆT thì tài khoản thành doanh nghiệp + bật hồ sơ công ty; TỪ CHỐI thì hoàn 100% và thông báo cho người nộp.</p>
              {adminApps.length === 0 ? (
                <p className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">Chưa có đơn nâng cấp nào chờ xử lý.</p>
              ) : (
                <div className="space-y-2">
                  {adminApps.map((a) => (
                    <div key={a.id} className="rounded-lg border p-3">
                      <div className="flex flex-wrap items-center gap-2.5">
                        <Avatar name={a.user?.fullName || a.companyName} color={a.user?.avatarColor || '#10b981'} size={36} img={a.user?.avatarImage} />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-bold">{a.companyName}</p>
                          <p className="truncate text-xs text-muted-foreground">Người nộp: {a.user?.fullName || '—'} (@{a.user?.username || '—'}), {new Date(a.createdAt).toLocaleString('vi-VN')}</p>
                        </div>
                        {a.status === 'pending' && <span className="rounded bg-sky-100 px-2 py-0.5 text-[10px] font-bold text-sky-700">CHỜ DUYỆT</span>}
                        {a.status === 'approved' && <span className="rounded bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700">ĐÃ DUYỆT</span>}
                        {a.status === 'rejected' && <span className="rounded bg-rose-100 px-2 py-0.5 text-[10px] font-bold text-rose-700">TỪ CHỐI</span>}
                      </div>
                      {a.note && <p className="mt-1.5 text-xs text-muted-foreground">Ghi chú: {a.note}</p>}
                      <p className="mt-1 text-xs text-muted-foreground">Nộp {fmtXuWithUsd(a.xuPaid, rate)}, tài khoản hiện tại: {a.user?.accountType === 'business' ? 'doanh nghiệp' : 'cá nhân'}</p>
                      {a.status === 'pending' && (
                        <div className="mt-2 flex gap-2">
                          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => reviewBusiness(a.id, 'approve')} aria-label={`Duyệt đơn ${a.companyName}`}>
                            <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Duyệt
                          </Button>
                          <Button size="sm" variant="outline" className="border-rose-300 text-rose-600 hover:bg-rose-50" onClick={() => reviewBusiness(a.id, 'reject')} aria-label={`Từ chối đơn ${a.companyName}`}>
                            <XCircle className="mr-1 h-3.5 w-3.5" /> Từ chối (hoàn tiền)
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </section>
      </div>
    </div>
  )
}

// Skeleton dùng khi hồ sơ chưa kịp nạp
export function SettingsFallback() {
  return <div className="space-y-3"><Skeleton className="h-10 w-56" /><Skeleton className="h-64 rounded-xl" /></div>
}
