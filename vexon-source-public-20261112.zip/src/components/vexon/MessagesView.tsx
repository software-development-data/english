'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import type { VxUserInfo } from '@/components/vexon/AuthView'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { compressImage } from '@/lib/image-compress'
import { useToast } from '@/hooks/use-toast'
import { type GifT } from '@/lib/gif'
import { useCallStore } from '@/lib/vx-call-store'
import { openUserMedia, startAudioRecorder, mediaErrorMessage, blobToDataUrl, stopStream, newCallId } from '@/lib/vx-call'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Checkbox } from '@/components/ui/checkbox'
import { Avatar, timeAgo, fmtSize, ReactionIcon, EmojiLikeIcon, STICKERS, StickerStamp, stickerLabel, TOPIC_ICON_ITEMS, TopicStamp, GROUP_ICON_ITEMS, groupIconOf } from '@/components/vexon/shared'
import { Skeleton } from '@/components/ui/skeleton'
import {
  MessagesSquare, Send, Plus, Users, Loader2, ChevronLeft, Search, Phone, Video, Info,
  Smile, Paperclip, Image as ImageIcon, Mic, X, Pencil, Pin, CornerUpLeft, Forward, RotateCcw,
  Check, CheckCheck, MoreHorizontal, Crown, Shield, FileText, Play, Pause, PhoneOff, MicOff, VideoOff, Crown as CrownIcon, PenSquare, Clapperboard, LogOut, Upload,
  EyeOff, BellOff, Bell, Timer, Trash2, ChevronRight, User, Camera, Clock, UsersRound,
  ListTree, Eye, Settings2, Ban, RefreshCw, WifiOff, Sparkles, Gift, Bot,
} from 'lucide-react'

interface UserLite { id: string; username: string; fullName: string; role: string; department?: string; avatarColor: string; online?: boolean; lastSeen?: string }
interface Member extends UserLite { memberRole: string }
interface ConvT {
  id: string; isGroup: boolean; isForum?: boolean; topicCount?: number; avatar?: string | null; avatarImage?: string | null; description?: string | null; name: string; myRole: string
  partner: UserLite | null; members: Member[]
  lastMessage: { content: string; type: string; createdAt: string; senderId: string; senderName: string } | null
  pinnedCount: number; unread: number; lastAt: string; pinned?: boolean
  hidden?: boolean; muted?: boolean; autoDeleteHours?: number
}
// Chủ đề nhóm (kiểu Telegram) — id null = mục "Tổng hợp" (tin ngoài chủ đề)
interface TopicT { id: string | null; name: string; icon: string; messageCount: number; lastMessage: { content: string; senderName: string; createdAt: string } | null }
interface MsgT {
  id: string; content: string; type: string; topicId?: string | null; fileUrl: string | null; fileName: string | null; fileSize: number | null
  duration: number | null; forwardedFrom: string | null; reactions: Record<string, string[]>; status: string
  unsent: boolean; pinned: boolean; createdAt: string; senderId: string; sender: UserLite
  replyTo: { id: string; senderName: string; content: string; type: string } | null
}
interface BlockedT { id: string; username: string; fullName: string; avatarColor: string; avatarImage?: string | null }

// Cảm xúc nhanh dùng key kiểu reaction — hiển thị bằng hình vector (không dùng kí tự emoji)
const QUICK_REACTIONS = ['LOVE', 'HAHA', 'LIKE', 'WOW', 'SAD'] as const

function previewOf(m: { content: string; type: string } | null): string {
  if (!m) return ''
  if (m.type === 'file') return `File: ${m.content}`
  if (m.type === 'voice') return 'Tin nhắn thoại'
  if (m.type === 'sticker') return `Sticker ${stickerLabel(m.content)}`
  if (m.type === 'gif') return 'GIF'
  if (m.type === 'image') return 'Hình ảnh'
  if (m.type === 'gift') return 'Quà tặng'
  if (m.type === 'call') return m.content
  return m.content
}

function lastSeenText(u?: UserLite | null): string {
  if (!u) return ''
  if (u.online) return 'Đang hoạt động'
  if (!u.lastSeen) return 'Ngoại tuyến'
  return `Hoạt động ${timeAgo(u.lastSeen)}`
}

export default function MessagesView({ me, openWithUser, onConsumedOpenWith, onOpenProfile }: { me: VxUserInfo; openWithUser?: string | null; onConsumedOpenWith?: () => void; onOpenProfile?: (userId: string) => void }) {
  const [conversations, setConversations] = useState<ConvT[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [messages, setMessages] = useState<MsgT[]>([])
  const [members, setMembers] = useState<Member[]>([])
  const [typing, setTyping] = useState(false)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(true)
  const [convError, setConvError] = useState(false) // lỗi mạng khi tải danh sách → hiện nút thử lại thay vì đứng im
  const [search, setSearch] = useState('')
  // Bộ lọc danh sách hội thoại kiểu Zalo/Messenger: Tất cả, Gần đây, Chưa đọc, Nhóm
  const [convFilter, setConvFilter] = useState<'all' | 'recent' | 'unread' | 'groups'>('all')
  const [replyTo, setReplyTo] = useState<MsgT | null>(null)
  const [forwardMsg, setForwardMsg] = useState<MsgT | null>(null)
  const [infoOpen, setInfoOpen] = useState(false)
  const [optionsOpen, setOptionsOpen] = useState(false)
  const [hiddenOpen, setHiddenOpen] = useState(false) // Quản lý Tin nhắn ẩn (kiểu Zalo)
  // CÀI ĐẶT TIN NHẮN (kiểu Zalo) — tổng hợp: Tin nhắn ẩn, Người dùng bị chặn
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [showBlocks, setShowBlocks] = useState(false)
  const [blocks, setBlocks] = useState<BlockedT[]>([])
  const [blocksLoaded, setBlocksLoaded] = useState(false)
  const [partnerBlocked, setPartnerBlocked] = useState(false) // bạn chat đang bị chặn?
  // CHỦ ĐỀ (kiểu Telegram) — null = đang xem "Tổng hợp"
  const [topics, setTopics] = useState<TopicT[]>([])
  const [activeTopicId, setActiveTopicId] = useState<string | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()
  const { startCall, openMeeting } = useCallStore()

  const loadConvos = useCallback(() => {
    fetch('/api/vx/conversations')
      .then((r) => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json() })
      .then((d) => {
        if (Array.isArray(d)) { setConversations(d); setConvError(false) }
      })
      .catch(() => setConvError(true))
      .finally(() => setLoading(false))
  }, [])

  // Hội thoại đang mở bị xoá/ẩn/rời nhóm → đóng khung chat
  useEffect(() => {
    if (activeId && conversations.length > 0 && !conversations.some((c) => c.id === activeId)) setActiveId(null)
  }, [conversations, activeId])

  useDeferredLoad(loadConvos, [loadConvos])

  // Mở hội thoại với 1 user (từ trang Bạn bè)
  useEffect(() => {
    if (!openWithUser) return
    ;(async () => {
      const res = await fetch('/api/vx/conversations', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userIds: [openWithUser] }) })
      const d = await res.json()
      if (res.ok) { setActiveId(d.id); loadConvos() }
      onConsumedOpenWith?.()
    })()
  }, [openWithUser])

  // Polling tin nhắn 2.5s: nhận tin mới, trạng thái seen, typing, bot trả lời
  const activeIdRef = useRef<string | null>(null)
  useEffect(() => {
    activeIdRef.current = activeId
    if (!activeId) return
    const fetchMsgs = () => {
      fetch(`/api/vx/conversations/${activeId}/messages`)
        .then((r) => r.json())
        .then((d) => {
          if (activeIdRef.current !== activeId) return
          if (Array.isArray(d.messages)) {
            setMessages((old) => {
              // giữ trạng thái optimistic của tin vừa gửi (chờ server xác nhận id)
              const map = new Map(old.filter((m) => m.id.startsWith('tmp_')).map((m) => [m.id, m]))
              const merged = d.messages as MsgT[]
              return merged.length >= old.length || merged.some((m) => !old.some((o) => o.id === m.id)) ? merged : old
            })
            setMembers(d.members || [])
            setTyping(Boolean(d.typing))
          }
        })
        .catch(() => {})
    }
    fetchMsgs()
    const t = setInterval(fetchMsgs, 2500)
    return () => clearInterval(t)
  }, [activeId])

  // Polling danh sách hội thoại 6s (unread + tin cuối)
  useEffect(() => {
    const t = setInterval(loadConvos, 6000)
    return () => clearInterval(t)
  }, [loadConvos])

  // Đổi hội thoại → reset tin nhắn đang mở
  useDeferredLoad(() => {
    setMessages([])
  }, [activeId])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length, typing])

  // Tìm trong hội thoại (kiểu Telegram) — null = đang tắt
  const [chatSearch, setChatSearch] = useState<string | null>(null)

  const togglePinConv = async () => {
    if (!activeConv) return
    const pin = !activeConv.pinned
    setActiveId(activeConv.id)
    setConversations((cs) => {
      const next = cs.map((c) => (c.id === activeConv.id ? { ...c, pinned: pin } : c))
      // ghim lên đầu danh sách ngay lập tức
      return [...next].sort((a, b) => (a.pinned === b.pinned ? (a.lastAt < b.lastAt ? 1 : -1) : a.pinned ? -1 : 1))
    })
    const res = await fetch(`/api/vx/conversations/${activeConv.id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin }),
    }).catch(() => null)
    if (!res || !res.ok) {
      toast({ title: 'Không ghim được hội thoại', variant: 'destructive' })
      loadConvos()
    } else {
      toast({ title: pin ? 'Đã ghim hội thoại' : 'Đã bỏ ghim hội thoại' })
    }
  }

  // Cập nhật cài đặt hội thoại (Ẩn / Tắt thông báo / Tự xóa) — kiểu TTO inbox v32
  const patchConv = async (body: Record<string, unknown>) => {
    if (!activeConv) return false
    const res = await fetch(`/api/vx/conversations/${activeConv.id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    }).catch(() => null)
    if (res && res.ok) { loadConvos(); return true }
    return false
  }

  const updateConvSetting = async (patch: { hidden?: boolean; muted?: boolean; autoDeleteHours?: number }, okMsg?: string) => {
    if (!activeConv) return
    setConversations((cs) => cs.map((c) => (c.id === activeConv.id ? { ...c, ...patch } : c)))
    const ok = await patchConv(patch)
    if (!ok) { toast({ title: 'Không cập nhật được cài đặt', variant: 'destructive' }); loadConvos() }
    else if (okMsg) toast({ title: okMsg })
  }

  const hideConv = async () => {
    if (!activeConv) return
    const ok = await patchConv({ hidden: true })
    setOptionsOpen(false)
    setActiveId(null)
    toast({ title: ok ? 'Đã ẩn trò chuyện, mở menu Tin nhắn ẩn để bỏ ẩn' : 'Không ẩn được trò chuyện', variant: ok ? undefined : 'destructive' })
  }

  // Bỏ ẩn một hội thoại bất kỳ (dùng trong menu Tin nhắn ẩn — kiểu Zalo)
  const unhideConv = async (id: string) => {
    setConversations((cs) => cs.map((c) => (c.id === id ? { ...c, hidden: false } : c)))
    const res = await fetch(`/api/vx/conversations/${id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ hidden: false }),
    }).catch(() => null)
    if (res && res.ok) toast({ title: 'Đã bỏ ẩn trò chuyện' })
    else { toast({ title: 'Không bỏ ẩn được', variant: 'destructive' }); loadConvos() }
  }

  const clearHistory = async () => {
    if (!activeConv) return
    if (!window.confirm('Xóa toàn bộ lịch sử trò chuyện này?')) return
    const ok = await patchConv({ clearHistory: true })
    if (ok) { setMessages([]); setOptionsOpen(false); toast({ title: 'Đã xóa lịch sử trò chuyện' }) }
    else toast({ title: 'Không xóa được lịch sử', variant: 'destructive' })
  }

  // Rời nhóm trực tiếp từ menu Tùy chọn (nhóm chat) — cùng luật với Thông tin nhóm:
  // thành viên rời tự do; trưởng nhóm phải chuyển quyền trước (lỗi 403 → mở Thông tin nhóm để chuyển)
  const leaveGroupDirect = async () => {
    if (!activeConv || !activeConv.isGroup) return
    if (!window.confirm('Rời nhóm này? Lịch sử tin nhắn sẽ không còn hiển thị với bạn.')) return
    try {
      const res = await fetch(`/api/vx/conversations/${activeConv.id}`, { method: 'DELETE' })
      const d = await res.json().catch(() => ({}))
      if (!res.ok) {
        if (res.status === 403) {
          toast({ title: 'Bạn là trưởng nhóm', description: d.error || 'Hãy chuyển quyền trưởng nhóm cho 1 thành viên khác trước khi rời nhóm (mở Thông tin nhóm, bấm Chuyển quyền).', variant: 'destructive' })
          setOptionsOpen(false)
          setInfoOpen(true)
          return
        }
        throw new Error(d.error || 'Không rời được nhóm')
      }
      setOptionsOpen(false)
      setActiveId(null)
      loadConvos()
      toast({ title: d.mode === 'dissolved' ? 'Nhóm chỉ còn bạn, đã giải tán nhóm' : 'Đã rời nhóm' })
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không rời được nhóm', variant: 'destructive' })
    }
  }

  const activeConv = conversations.find((c) => c.id === activeId)
  const partner = activeConv && !activeConv.isGroup ? activeConv.partner : null
  const partnerId = partner?.id ?? null

  // Bắt đầu cuộc gọi: hội thoại 1-1 → gọi WebRTC; hội thoại nhóm → phòng họp nhóm kiểu Zoom
  const openGroupMeeting = () => {
    if (!activeConv) return
    openMeeting({ conversationId: activeConv.id, name: activeConv.name, isGroup: true, isHost: true, avatar: activeConv.avatar, avatarImage: activeConv.avatarImage })
  }
  const startVoiceCall = () => {
    if (!activeConv) return
    if (activeConv.isGroup) {
      openGroupMeeting()
      return
    }
    if (!partner) return
    startCall({ callId: newCallId(), conversationId: activeConv.id, kind: 'voice', peer: { userId: partner.id, userName: activeConv.name, avatarColor: partner.avatarColor || '#10b981' }, peerOnline: partner.online })
  }
  const startVideoCall = () => {
    if (!activeConv) return
    if (activeConv.isGroup) {
      openGroupMeeting()
      return
    }
    if (!partner) return
    startCall({ callId: newCallId(), conversationId: activeConv.id, kind: 'video', peer: { userId: partner.id, userName: activeConv.name, avatarColor: partner.avatarColor || '#38bdf8' }, peerOnline: partner.online })
  }

  // ---- CÀI ĐẶT TIN NHẮN + CHẶN (kiểu Zalo) ----
  const loadBlocks = useCallback(() => {
    return fetch('/api/vx/blocks')
      .then((r) => r.json())
      .then((d) => setBlocks(Array.isArray(d.blocked) ? d.blocked : []))
      .catch(() => setBlocks([]))
      .finally(() => setBlocksLoaded(true))
  }, [])

  // Mở Cài đặt tin nhắn lần đầu → nạp danh sách chặn
  useEffect(() => {
    if (settingsOpen && !blocksLoaded) loadBlocks()
  }, [settingsOpen, blocksLoaded, loadBlocks])

  // Mở Tùy chọn hội thoại 1-1 → kiểm tra đối phương có bị chặn không
  useEffect(() => {
    if (optionsOpen && partnerId) {
      fetch('/api/vx/blocks')
        .then((r) => r.json())
        .then((d) => setPartnerBlocked(Array.isArray(d.blocked) && d.blocked.some((b: BlockedT) => b.id === partnerId)))
        .catch(() => {})
    } else setPartnerBlocked(false)
  }, [optionsOpen, partnerId])

  // Chặn / bỏ chặn bạn chat: 2 chiều không thấy nhau trong tìm kiếm, không nhắn tin được
  const toggleBlockPartner = async () => {
    if (!partner) return
    const action = partnerBlocked ? 'unblock' : 'block'
    if (!window.confirm(partnerBlocked ? `Bỏ chặn ${partner.fullName}?` : `Chặn ${partner.fullName}? Hai bên sẽ không tìm thấy nhau trong tìm kiếm và không nhắn tin được cho nhau.`)) return
    const res = await fetch('/api/vx/blocks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: partner.id, action }) }).catch(() => null)
    if (res && res.ok) {
      setPartnerBlocked(!partnerBlocked)
      setBlocksLoaded(false)
      toast({ title: partnerBlocked ? `Đã bỏ chặn ${partner.fullName}` : `Đã chặn ${partner.fullName}`, description: partnerBlocked ? 'Hai bên đã nhắn tin được bình thường' : 'Hai bên không thấy nhau trong tìm kiếm và không nhắn tin được' })
    } else toast({ title: 'Thao tác thất bại, thử lại nhé', variant: 'destructive' })
  }

  // Bỏ chặn từ danh sách trong Cài đặt tin nhắn
  const unblockUser = async (u: BlockedT) => {
    const res = await fetch('/api/vx/blocks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: u.id, action: 'unblock' }) }).catch(() => null)
    if (res && res.ok) {
      setBlocks((bs) => bs.filter((b) => b.id !== u.id))
      toast({ title: `Đã bỏ chặn ${u.fullName}` })
    } else toast({ title: 'Không bỏ chặn được', variant: 'destructive' })
  }

  // Nhóm đang bật CHỦ ĐỀ (kiểu Telegram)
  const forumMode = Boolean(activeConv?.isGroup && (activeConv.isForum || (activeConv.topicCount ?? 0) > 0))

  const loadTopics = useCallback(() => {
    if (!activeId) return
    fetch(`/api/vx/conversations/${activeId}/topics`)
      .then((r) => r.json())
      .then((d) => Array.isArray(d.topics) && setTopics(d.topics))
      .catch(() => {})
  }, [activeId])

  // Đổi hội thoại → reset chủ đề; nhóm có Chủ đề thì nạp danh sách
  useEffect(() => {
    setTopics([])
    setActiveTopicId(null)
    if (activeId && forumMode) loadTopics()
  }, [activeId, forumMode, loadTopics])

  const send = async (extra?: Partial<{ type: string; fileUrl: string; fileName: string; fileSize: number; duration: number }>) => {
    if (!activeId) return
    const content = input.trim()
    if (!content && !extra) return
    setInput('')
    const tmp: MsgT = {
      id: `tmp_${Date.now()}`, content: content || previewOf({ content: '', type: extra?.type || 'text' }) || '', type: extra?.type || 'text',
      topicId: forumMode ? activeTopicId : null,
      fileUrl: extra?.fileUrl || null, fileName: extra?.fileName || null, fileSize: extra?.fileSize || null, duration: extra?.duration || null,
      forwardedFrom: null, reactions: {}, status: 'sent', unsent: false, pinned: false, createdAt: new Date().toISOString(),
      senderId: me.id, sender: { id: me.id, username: me.username, fullName: me.fullName, role: me.role, avatarColor: me.avatarColor },
      replyTo: replyTo ? { id: replyTo.id, senderName: replyTo.sender.fullName, content: replyTo.content, type: replyTo.type } : null,
    }
    setMessages((ms) => [...ms, tmp])
    const res = await fetch(`/api/vx/conversations/${activeId}/messages`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, type: extra?.type || 'text', replyToId: replyTo?.id, topicId: forumMode ? activeTopicId : null, ...extra }),
    })
    const d = await res.json()
    if (!res.ok) {
      setMessages((ms) => ms.filter((m) => m.id !== tmp.id))
      toast({ title: 'Lỗi', description: d.error, variant: 'destructive' })
      return
    }
    setReplyTo(null)
    loadConvos()
  }

  const patchMsg = async (id: string, body: Record<string, unknown>) => {
    const res = await fetch(`/api/vx/messages/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    return res.ok ? res.json() : null
  }

  const sendSticker = async (key: string) => {
    if (!activeId) return
    const tmp: MsgT = {
      id: `tmp_${Date.now()}`, content: key, type: 'sticker', topicId: forumMode ? activeTopicId : null, fileUrl: null, fileName: null, fileSize: null, duration: null,
      forwardedFrom: null, reactions: {}, status: 'sent', unsent: false, pinned: false, createdAt: new Date().toISOString(),
      senderId: me.id, sender: { id: me.id, username: me.username, fullName: me.fullName, role: me.role, avatarColor: me.avatarColor }, replyTo: null,
    }
    setMessages((ms) => [...ms, tmp])
    await fetch(`/api/vx/conversations/${activeId}/messages`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: key, type: 'sticker', topicId: forumMode ? activeTopicId : null }) })
    loadConvos()
  }

  const baseFiltered = conversations.filter((c) => (!c.hidden || c.id === activeId) && c.name.toLowerCase().includes(search.toLowerCase()))
  // Lọc theo tab: Gần đây = có hoạt động trong 24h, Chưa đọc = có tin chưa xem, Nhóm = chat nhóm
  const recentCutoff = Date.now() - 24 * 60 * 60 * 1000
  const filtered = baseFiltered.filter((c) => {
    if (convFilter === 'unread') return c.unread > 0
    if (convFilter === 'groups') return c.isGroup
    if (convFilter === 'recent') return !c.lastMessage || new Date(c.lastMessage.createdAt).getTime() >= recentCutoff || new Date(c.lastAt).getTime() >= recentCutoff
    return true
  })
  const unreadTotal = baseFiltered.reduce((n, c) => n + (c.unread > 0 ? 1 : 0), 0)
  const pinned = messages.filter((m) => m.pinned)
  // Tìm trong tin nhắn: lọc theo nội dung/tên file
  const kw = (chatSearch || '').trim().toLowerCase()
  const searchHit = (m: MsgT) =>
    !kw ||
    m.content.toLowerCase().includes(kw) ||
    (m.fileName || '').toLowerCase().includes(kw) ||
    (m.replyTo?.content || '').toLowerCase().includes(kw)
  const visibleMessages = (forumMode ? messages.filter((m) => (m.topicId ?? null) === activeTopicId) : messages).filter(searchHit)
  const activeTopic = topics.find((t) => t.id === activeTopicId) || null
  const myLastMsg = [...messages].reverse().find((m) => m.senderId === me.id)
  // Ảnh, file, link dùng chung trong hội thoại (dải xem nhanh trong Tùy chọn — kiểu TTO v32)
  const sharedMedia = messages.filter((m) => ['image', 'gif', 'file'].includes(m.type) && m.fileUrl).slice(-12).reverse()

  const headerStatus = typing
    ? 'Đang soạn tin...'
    : activeConv?.isGroup
      ? `${activeConv.members.length} thành viên, ${activeConv.members.filter((m) => m.online).length} đang online`
      : partner
        ? partner.online ? 'Đang hoạt động' : lastSeenText(partner)
        : ''

  return (
    <div className="mx-auto grid h-[calc(100vh-190px)] min-h-[540px] max-w-6xl gap-4 sm:grid-cols-[320px_1fr]">
      {/* Danh sách hội thoại */}
      <div className={`flex flex-col overflow-hidden rounded-xl border bg-white shadow-sm ${activeId ? 'hidden sm:flex' : 'flex'}`}>
        <div className="flex items-center justify-between border-b p-3">
          <h2 className="flex items-center gap-2 text-sm font-bold"><MessagesSquare className="h-4 w-4 text-emerald-600" /> Tin nhắn</h2>
          <div className="flex items-center gap-1">
            {/* Cài đặt tin nhắn (kiểu Zalo): Tin nhắn ẩn, Người dùng bị chặn — Tin nhắn ẩn nằm đủ ở đây, không cần nút riêng */}
            <Button variant="ghost" size="icon" className="h-8 w-8 text-stone-500 hover:text-stone-700" onClick={() => setSettingsOpen(true)} aria-label="Cài đặt tin nhắn">
              <Settings2 className="h-4 w-4" />
            </Button>
            <NewChatDialog me={me} onCreated={(id) => { loadConvos(); setActiveId(id) }} />
          </div>
        </div>
        <div className="p-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Tìm hội thoại..." className="pl-8" aria-label="Tìm hội thoại" />
          </div>
          {/* Bộ lọc: Tất cả, Gần đây, Chưa đọc, Nhóm (như Zalo/Messenger) */}
          <div className="mt-2 flex gap-1.5 overflow-x-auto pb-0.5" role="tablist" aria-label="Bộ lọc hội thoại">
            {([
              ['all', 'Tất cả', <MessagesSquare key="a" className="h-3.5 w-3.5" />],
              ['recent', 'Gần đây', <Clock key="r" className="h-3.5 w-3.5" />],
              ['unread', unreadTotal > 0 ? `Chưa đọc (${unreadTotal})` : 'Chưa đọc', <Check key="u" className="h-3.5 w-3.5" />],
              ['groups', 'Nhóm', <UsersRound key="g" className="h-3.5 w-3.5" />],
            ] as const).map(([k, label, icon]) => (
              <button key={k} role="tab" aria-selected={convFilter === k} onClick={() => setConvFilter(k)}
                className={`flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-medium transition-colors ${
                  convFilter === k ? 'border-emerald-600 bg-emerald-600 text-white shadow' : 'border-stone-200 bg-white text-stone-600 hover:bg-emerald-50'
                }`}>
                {icon} {label}
              </button>
            ))}
          </div>
        </div>
        <ScrollArea className="flex-1">
          {loading ? (
            <div className="space-y-3 p-3" aria-label="Đang tải hội thoại">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="flex items-center gap-3">
                  <Skeleton className="h-11 w-11 shrink-0 rounded-full" />
                  <div className="flex-1 space-y-1.5">
                    <Skeleton className="h-3.5 w-1/2" />
                    <Skeleton className="h-3 w-3/4" />
                  </div>
                </div>
              ))}
            </div>
          ) : convError && filtered.length === 0 ? (
            <div className="px-4 py-8 text-center" role="alert">
              <WifiOff className="mx-auto h-7 w-7 text-stone-300" aria-hidden="true" />
              <p className="mt-2 text-xs text-muted-foreground">Mất kết nối, chưa tải được hội thoại.</p>
              <Button variant="outline" size="sm" className="mt-2 border-emerald-300 text-emerald-700 hover:bg-emerald-50"
                onClick={() => { setLoading(true); setConvError(false); loadConvos() }}>
                <RefreshCw className="mr-1 h-3.5 w-3.5" /> Thử lại
              </Button>
            </div>
          ) : filtered.length === 0 ? (
            <p className="px-4 py-8 text-center text-xs text-muted-foreground">Chưa có hội thoại, vào tab Bạn bè để nhắn tin nhé!</p>
          ) : (
            filtered.map((c) => {
              const other = !c.isGroup ? c.partner : null
              return (
                <button key={c.id} onClick={() => { setActiveId(c.id); if (c.hidden) void unhideConv(c.id) }}
                  className={`flex w-full items-center gap-3 border-b p-3 text-left transition-colors hover:bg-muted/60 ${activeId === c.id ? 'bg-emerald-50' : ''}`}>
                  {c.isGroup ? (
                    <GroupIcon avatar={c.avatar} img={c.avatarImage} size={44} />
                  ) : (
                    <Avatar name={c.name} color={other?.avatarColor || '#94a3b8'} size={44} online={other?.online} />
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <p className="truncate text-sm font-semibold">
                      {c.pinned && <span title="Hội thoại đã ghim" className="mr-1 inline-flex align-[-2px]"><Pin className="h-3.5 w-3.5 fill-amber-400 text-amber-500" /></span>}
                      {c.isForum && <span title="Nhóm có Chủ đề" className="mr-0.5 inline-flex align-[-2px] text-sky-600"><ListTree className="h-3.5 w-3.5" /></span>}
                      {!c.isGroup && other?.username === 'vexonbot' && <span className="mr-1 inline-flex items-center gap-0.5 rounded bg-emerald-100 px-1 align-[-2px] text-[9px] font-bold text-emerald-700"><Bot className="h-2.5 w-2.5" /> BOT AI</span>}
                      {c.name}
                    </p>
                      {c.lastMessage && <span className="shrink-0 text-[10px] text-muted-foreground">{timeAgo(c.lastMessage.createdAt)}</span>}
                    </div>
                    <div className="flex items-center justify-between gap-1">
                      <p className={`truncate text-xs ${c.unread > 0 ? 'font-semibold text-foreground' : 'text-muted-foreground'}`}>
                        {c.lastMessage ? (c.lastMessage.senderId === me.id ? `Bạn: ${previewOf(c.lastMessage)}` : previewOf(c.lastMessage)) : 'Chưa có tin nhắn'}
                      </p>
                      {c.unread > 0 && <Badge className="h-5 shrink-0 rounded-full bg-emerald-600 px-1.5 text-[10px] text-white hover:bg-emerald-600">{c.unread}</Badge>}
                    </div>
                    {/* Cờ trạng thái hội thoại: Đã ghim / Đã ẩn / Tắt báo / Tự xóa (kiểu TTO v32) */}
                    {(c.pinned || c.hidden || c.muted || (c.autoDeleteHours ?? 0) > 0) && (
                      <div className="mt-1 flex flex-wrap items-center gap-2 text-[10px] text-muted-foreground">
                        {c.pinned && <span className="flex items-center gap-0.5 text-amber-600"><Pin className="h-3 w-3" /> Đã ghim</span>}
                        {c.hidden && <span className="flex items-center gap-0.5"><EyeOff className="h-3 w-3" /> Đã ẩn</span>}
                        {c.muted && <span className="flex items-center gap-0.5"><BellOff className="h-3 w-3" /> Tắt báo</span>}
                        {(c.autoDeleteHours ?? 0) > 0 && <span className="flex items-center gap-0.5"><Timer className="h-3 w-3" /> Tự xóa</span>}
                      </div>
                    )}
                  </div>
                </button>
              )
            })
          )}
        </ScrollArea>
      </div>

      {/* Khung chat */}
      <div className={`flex flex-col overflow-hidden rounded-xl border bg-white shadow-sm ${activeId ? 'flex' : 'hidden sm:flex'}`}>
        {!activeConv ? (
          <div className="flex flex-1 items-center justify-center text-center text-sm text-muted-foreground">
            <div><MessagesSquare className="mx-auto mb-2 h-10 w-10 opacity-50" />Chọn một hội thoại để bắt đầu</div>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="flex items-center gap-2 border-b p-2.5">
              <Button variant="ghost" size="icon" className="h-8 w-8 sm:hidden" onClick={() => setActiveId(null)} aria-label="Quay lại"><ChevronLeft className="h-5 w-5" /></Button>
              {activeConv.isGroup ? (
                <GroupIcon avatar={activeConv.avatar} img={activeConv.avatarImage} size={36} />
              ) : (
                <Avatar name={activeConv.name} color={partner?.avatarColor || '#94a3b8'} size={36} online={partner?.online} />
              )}
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-1.5 truncate text-sm font-semibold">{activeConv.name}{!activeConv.isGroup && partner?.username === 'vexonbot' && <span className="inline-flex shrink-0 items-center gap-0.5 rounded bg-emerald-100 px-1.5 py-0.5 text-[9px] font-bold text-emerald-700"><Bot className="h-3 w-3" /> BOT AI</span>}</p>
                <p className={`truncate text-xs ${typing ? 'italic text-emerald-600' : 'text-muted-foreground'}`}>{headerStatus}</p>
              </div>
              {!activeConv.isGroup && partner?.username !== 'vexonbot' && (
                <>
                  <Button variant="ghost" size="icon" className="h-9 w-9 text-emerald-700" onClick={startVoiceCall} aria-label={activeConv.isGroup ? 'Họp nhóm' : 'Gọi thoại'}><Phone className="h-4.5 w-4.5" /></Button>
                  <Button variant="ghost" size="icon" className="h-9 w-9 text-sky-700" onClick={startVideoCall} aria-label={activeConv.isGroup ? 'Họp nhóm video' : 'Gọi video'}><Video className="h-5 w-5" /></Button>
                </>
              )}
              {/* Tùy chọn — duy nhất MỘT nút trên header chat (kiểu TTO inbox v32, hết nút rời rạc) */}
              <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => setOptionsOpen(true)} aria-label="Tùy chọn hội thoại">
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </div>

            {/* Thanh tìm trong tin nhắn (kiểu Telegram) */}
            {chatSearch !== null && (
              <div className="flex items-center gap-2 border-b bg-emerald-50/60 px-3 py-2">
                <Search className="h-4 w-4 shrink-0 text-emerald-700" />
                <Input
                  autoFocus
                  value={chatSearch}
                  onChange={(e) => setChatSearch(e.target.value)}
                  placeholder="Tìm trong tin nhắn..."
                  className="h-8"
                  aria-label="Tìm trong tin nhắn"
                />
                {kw && (
                  <span className="shrink-0 text-[11px] font-medium text-emerald-800">
                    {visibleMessages.length} kết quả
                  </span>
                )}
                <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={() => setChatSearch(null)} aria-label="Đóng tìm kiếm">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}

            {/* Ghim */}
            {pinned.length > 0 && (
              <div className="flex items-center gap-2 border-b bg-amber-50/70 px-3 py-1.5 text-xs text-amber-800">
                <Pin className="h-3.5 w-3.5 shrink-0" />
                <span className="truncate">{pinned[pinned.length - 1].sender.fullName}: {previewOf(pinned[pinned.length - 1])}</span>
                {pinned.length > 1 && <span className="ml-auto shrink-0">+{pinned.length - 1} tin ghim khác</span>}
              </div>
            )}

            {/* Thanh CHỦ ĐỀ (kiểu Telegram) — nhóm bật Chủ đề mới hiện */}
            {forumMode && (
              <div className="flex items-center gap-1.5 overflow-x-auto border-b bg-stone-50 px-2.5 py-1.5">
                <span className="shrink-0 text-[10px] font-bold uppercase tracking-wide text-stone-400">Chủ đề</span>
                {topics.map((t) => (
                  <button key={t.id || 'general'}
                    onClick={() => setActiveTopicId(t.id)}
                    className={`flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-medium transition-colors ${
                      activeTopicId === t.id ? 'border-emerald-600 bg-emerald-600 text-white' : 'border-stone-200 bg-white text-stone-600 hover:border-emerald-300 hover:bg-emerald-50'
                    }`}
                    title={t.lastMessage ? `${t.lastMessage.senderName}: ${t.lastMessage.content}` : 'Chưa có tin nhắn'}
                  >
                    <TopicStamp icon={t.icon} size={16} />
                    {t.name}
                    {t.messageCount > 0 && <span className={`text-[10px] ${activeTopicId === t.id ? 'text-emerald-100' : 'text-stone-400'}`}>{t.messageCount}</span>}
                  </button>
                ))}
                <NewTopicDialog conversationId={activeConv.id} onCreated={(id) => { loadTopics(); setActiveTopicId(id) }} />
              </div>
            )}

            {/* Tin nhắn */}
            <div className="flex-1 space-y-1.5 overflow-y-auto bg-muted/30 p-3">
              {forumMode && (
                <p className="mb-1 flex items-center justify-center gap-1 text-center text-[10px] text-muted-foreground">
                  Đang xem chủ đề
                  <b className="inline-flex items-center gap-1 text-emerald-700">
                    <TopicStamp icon={activeTopic?.icon || 'chat'} size={14} />{activeTopic?.name || 'Tổng hợp'}
                  </b>
                  (tin nhắn chỉ gửi vào chủ đề này)
                </p>
              )}
              {visibleMessages.length === 0 && <p className="py-8 text-center text-xs text-muted-foreground">Hãy gửi tin nhắn đầu tiên</p>}
              {visibleMessages.map((m, i) => (
                <MessageBubble
                  key={m.id}
                  msg={m}
                  prev={visibleMessages[i - 1]}
                  me={me}
                  isGroup={activeConv.isGroup}
                  seenAvatar={myLastMsg?.id === m.id && m.status === 'seen' && partner ? partner : null}
                  onReply={() => setReplyTo(m)}
                  onForward={() => setForwardMsg(m)}
                  onReact={async (emoji) => { await patchMsg(m.id, { action: 'react', emoji }); }}
                  onPin={async () => { await patchMsg(m.id, { action: 'pin' }); }}
                  onUnsend={async () => { const r = await patchMsg(m.id, { action: 'unsend' }); if (r) toast({ title: 'Đã thu hồi tin nhắn' }) }}
                />
              ))}
              {typing && (
                <div className="flex items-end gap-2">
                  <Avatar name={partner?.fullName || activeConv.name} color={partner?.avatarColor || '#10b981'} size={26} />
                  <div className="flex items-center gap-1 rounded-2xl rounded-bl-sm bg-white px-3.5 py-2.5 shadow-sm">
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-stone-400 [animation-delay:0ms]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-stone-400 [animation-delay:150ms]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-stone-400 [animation-delay:300ms]" />
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Reply bar */}
            {replyTo && (
              <div className="flex items-center gap-2 border-t bg-muted/40 px-3 py-1.5 text-xs">
                <CornerUpLeft className="h-3.5 w-3.5 text-emerald-600" />
                <span className="text-muted-foreground">Trả lời <b className="text-foreground">{replyTo.sender.fullName}</b>: {previewOf(replyTo).slice(0, 60)}</span>
                <button className="ml-auto" onClick={() => setReplyTo(null)} aria-label="Bỏ trả lời"><X className="h-3.5 w-3.5" /></button>
              </div>
            )}

            {/* Ô soạn tin (có emoji, sticker, GIF, ảnh, file, thoại + AI gợi ý) */}
            <ComposerBar
              onSend={send}
              input={input}
              setInput={setInput}
              onSticker={sendSticker}
              me={me}
              aiContext={{
                partnerName: activeConv?.isGroup ? (activeConv.name || 'nhóm') : (activeConv?.partner?.fullName || activeConv?.name || 'người này'),
                lastTexts: messages.slice(-8).map((m) => `${m.senderId === me.id ? me.fullName : (m.sender?.fullName || 'Người lạ')}: ${previewOf(m)}`),
              }}
            />
          </>
        )}
      </div>

      {/* Chuyển tiếp */}
      <ForwardDialog msg={forwardMsg} conversations={conversations.filter((c) => c.id !== activeId)} onClose={() => setForwardMsg(null)} onDone={() => toast({ title: 'Đã chuyển tiếp tin nhắn' })} />

      {/* Thông tin nhóm + phân quyền + Chủ đề */}
      <GroupInfoDialog conv={activeConv ?? null} open={infoOpen} onOpenChange={setInfoOpen} me={me} onChanged={loadConvos} pinned={pinned} onUnpin={async (m) => { await patchMsg(m.id, { action: 'pin' }) }} topics={topics} loadTopics={loadTopics} />

      {/* TÙY CHỌN HỘI THOẠI — menu đầy đủ kiểu TTO inbox v32 (profile, Xem trang cá nhân, Ảnh/file/link, Ghim, Ẩn, Tắt báo, Tự xóa, Xóa lịch sử) */}
      {activeConv && (
        <Dialog open={optionsOpen} onOpenChange={setOptionsOpen}>
          <DialogContent className="gap-0 overflow-hidden rounded-2xl p-0 sm:max-w-md">
            <DialogHeader className="flex flex-row items-center gap-2 space-y-0 border-b p-3">
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setOptionsOpen(false)} aria-label="Quay lại"><ChevronLeft className="h-4 w-4" /></Button>
              <DialogTitle className="text-base font-bold">Tùy chọn</DialogTitle>
            </DialogHeader>
            <div className="max-h-[68vh] space-y-1 overflow-y-auto p-3">
              {/* Hồ sơ cuộc trò chuyện */}
              <div className="mb-2 flex items-center gap-3 rounded-xl bg-muted/50 p-3">
                {activeConv.isGroup ? (
                  <GroupIcon avatar={activeConv.avatar} img={activeConv.avatarImage} size={46} />
                ) : (
                  <Avatar name={activeConv.name} color={partner?.avatarColor || '#94a3b8'} size={46} online={partner?.online} />
                )}
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold">{activeConv.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {activeConv.isGroup ? `${activeConv.members.length} thành viên` : partner ? `@${partner.username}, ${partner.department || ''}` : ''}
                  </p>
                </div>
              </div>

              {/* Nhóm: mở Cài đặt nhóm; 1-1: mở trang cá nhân */}
              {activeConv.isGroup ? (
                <button className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted/70" onClick={() => { setOptionsOpen(false); setInfoOpen(true) }}>
                  <Info className="h-4.5 w-4.5 text-emerald-600" />
                  <span className="flex-1 text-left">Thông tin nhóm</span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </button>
              ) : partner && onOpenProfile ? (
                <button className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted/70" onClick={() => { setOptionsOpen(false); onOpenProfile(partner.id) }}>
                  <User className="h-4.5 w-4.5 text-emerald-600" />
                  <span className="flex-1 text-left">Xem trang cá nhân</span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </button>
              ) : null}

              {/* Tìm trong tin nhắn (chuyển từ header vào menu — header chỉ còn 1 nút) */}
              <button
                className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted/70"
                onClick={() => { setChatSearch(chatSearch === null ? '' : null); setOptionsOpen(false) }}
              >
                <Search className="h-4.5 w-4.5 text-sky-600" />
                <span className="flex-1 text-left">Tìm trong tin nhắn</span>
                {chatSearch !== null && <Badge className="h-5 bg-emerald-100 px-1.5 text-[10px] text-emerald-800 hover:bg-emerald-100">Đang mở</Badge>}
              </button>

              {/* Ảnh, file, link dùng chung (dải xem nhanh kiểu TTO v32) */}
              <div className="rounded-xl border p-2.5">
                <p className="mb-2 flex items-center gap-2 text-xs font-bold text-stone-500"><ImageIcon className="h-4 w-4 text-emerald-600" /> Ảnh, file, link</p>
                {sharedMedia.length === 0 ? (
                  <p className="px-1 pb-1 text-xs text-muted-foreground">Chưa có ảnh/file/link.</p>
                ) : (
                  <div className="flex gap-1.5 overflow-x-auto pb-1">
                    {sharedMedia.map((m) => (
                      <a key={m.id} href={m.fileUrl || '#'} target="_blank" rel="noopener" className="h-14 w-14 shrink-0 overflow-hidden rounded-lg border bg-muted/40"
                        title={m.type === 'file' ? m.fileName || m.content : previewOf(m)}>
                        {m.type === 'image' || (m.fileName || '').match(/\.(png|jpe?g|gif|webp)$/i) ? (
                          <img src={m.fileUrl || ''} alt="Ảnh dùng chung" className="h-full w-full object-cover" />
                        ) : (
                          <span className="flex h-full w-full items-center justify-center text-muted-foreground"><FileText className="h-5 w-5" /></span>
                        )}
                      </a>
                    ))}
                  </div>
                )}
              </div>

              {/* Công tắc cài đặt: Ghim / Ẩn / Tắt thông báo */}
              <button className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted/70" onClick={togglePinConv}>
                <Pin className={`h-4.5 w-4.5 ${activeConv.pinned ? 'text-amber-500' : 'text-stone-500'}`} />
                <span className="flex-1 text-left">Ghim trò chuyện</span>
                <ToggleDot on={Boolean(activeConv.pinned)} />
              </button>
              <button className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted/70" onClick={() => updateConvSetting({ hidden: false }, 'Đã bỏ ẩn trò chuyện')} hidden={!activeConv.hidden}>
                <EyeOff className="h-4.5 w-4.5 text-stone-500" />
                <span className="flex-1 text-left">Bỏ ẩn trò chuyện</span>
                <ToggleDot on={Boolean(activeConv.hidden)} />
              </button>
              <button className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted/70" onClick={() => updateConvSetting({ hidden: true }, 'Đã ẩn trò chuyện')}>
                <EyeOff className="h-4.5 w-4.5 text-stone-500" />
                <span className="flex-1 text-left">Ẩn trò chuyện</span>
                <ToggleDot on={false} />
              </button>
              <button className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted/70" onClick={() => updateConvSetting({ muted: !activeConv.muted }, activeConv.muted ? 'Đã bật thông báo tin nhắn' : 'Đã tắt thông báo tin nhắn')}>
                {activeConv.muted ? <BellOff className="h-4.5 w-4.5 text-amber-600" /> : <Bell className="h-4.5 w-4.5 text-stone-500" />}
                <span className="flex-1 text-left">{activeConv.muted ? 'Bật thông báo tin nhắn' : 'Tắt thông báo tin nhắn'}</span>
                <ToggleDot on={Boolean(activeConv.muted)} />
              </button>

              {/* Tin nhắn tự xóa */}
              <div className="rounded-xl border p-2.5">
                <p className="mb-2 flex items-center gap-2 text-xs font-bold text-stone-500"><Timer className="h-4 w-4 text-emerald-600" /> Tin nhắn tự xóa</p>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { h: 0, l: 'Không tự xóa' },
                    { h: 24, l: '24 giờ' },
                    { h: 168, l: '7 ngày' },
                    { h: 720, l: '30 ngày' },
                  ].map((o) => (
                    <button key={o.h} onClick={() => updateConvSetting({ autoDeleteHours: o.h }, o.h ? `Tin nhắn tự xóa sau ${o.l}` : 'Đã tắt tự xóa')}
                      className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                        (activeConv.autoDeleteHours ?? 0) === o.h ? 'bg-emerald-600 text-white' : 'bg-muted/60 text-stone-600 hover:bg-emerald-50'
                      }`}>
                      {o.l}
                    </button>
                  ))}
                </div>
              </div>

              {/* Vùng nguy hiểm */}
              {!activeConv.isGroup && partner && (
                <button className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-red-600 transition-colors hover:bg-red-50" onClick={toggleBlockPartner} aria-label={partnerBlocked ? 'Bỏ chặn người dùng' : 'Chặn người dùng'}>
                  <Ban className="h-4.5 w-4.5" />
                  <span className="flex-1 text-left">{partnerBlocked ? 'Bỏ chặn người dùng' : 'Chặn người dùng'}</span>
                  {partnerBlocked && <Badge className="h-5 rounded-full bg-red-100 px-1.5 text-[10px] text-red-700 hover:bg-red-100">Đang chặn</Badge>}
                </button>
              )}
              <button className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-red-600 transition-colors hover:bg-red-50" onClick={clearHistory}>
                <Trash2 className="h-4.5 w-4.5" />
                <span className="flex-1 text-left">Xóa lịch sử trò chuyện</span>
              </button>
              {activeConv.isGroup && (
                <button className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-red-600 transition-colors hover:bg-red-50" onClick={leaveGroupDirect} aria-label="Rời nhóm">
                  <LogOut className="h-4.5 w-4.5" />
                  <span className="flex-1 text-left">Rời nhóm</span>
                </button>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* CÀI ĐẶT TIN NHẮN (kiểu Zalo) — tổng hợp cài đặt riêng cho phần Tin nhắn */}
      <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
        <DialogContent className="gap-0 overflow-hidden rounded-2xl p-0 sm:max-w-md">
          <DialogHeader className="flex flex-row items-center gap-2 space-y-0 border-b p-3">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSettingsOpen(false)} aria-label="Quay lại"><ChevronLeft className="h-4 w-4" /></Button>
            <DialogTitle className="flex items-center gap-2 text-base font-bold"><Settings2 className="h-4.5 w-4.5 text-emerald-600" /> Cài đặt tin nhắn</DialogTitle>
          </DialogHeader>
          <div className="max-h-[64vh] space-y-1 overflow-y-auto p-3">
            <p className="px-1 pb-1 text-[11px] font-bold uppercase tracking-wide text-stone-400">Quản lý trò chuyện</p>
            <button
              className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted/70"
              onClick={() => { setSettingsOpen(false); setHiddenOpen(true) }}
              aria-label="Tin nhắn ẩn"
            >
              <EyeOff className="h-4.5 w-4.5 text-stone-500" />
              <span className="flex-1 text-left">Tin nhắn ẩn</span>
              {conversations.some((c) => c.hidden) && (
                <Badge className="h-5 rounded-full bg-stone-200 px-1.5 text-[10px] text-stone-700 hover:bg-stone-200">{conversations.filter((c) => c.hidden).length}</Badge>
              )}
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>

            <p className="px-1 pb-1 pt-2 text-[11px] font-bold uppercase tracking-wide text-stone-400">Quyền riêng tư và an ninh</p>
            <button
              className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted/70"
              onClick={() => { setShowBlocks((v) => !v); if (!blocksLoaded) loadBlocks() }}
              aria-label="Người dùng bị chặn"
            >
              <Ban className={`h-4.5 w-4.5 ${blocks.length > 0 ? 'text-red-500' : 'text-stone-500'}`} />
              <span className="flex-1 text-left">Người dùng bị chặn</span>
              {blocks.length > 0 && <Badge className="h-5 rounded-full bg-red-100 px-1.5 text-[10px] text-red-700 hover:bg-red-100">{blocks.length}</Badge>}
              <ChevronRight className={`h-4 w-4 text-muted-foreground transition-transform ${showBlocks ? 'rotate-90' : ''}`} />
            </button>
            {showBlocks && (
              <div className="rounded-xl border p-1.5">
                {blocks.length === 0 ? (
                  <p className="px-3 py-4 text-xs text-muted-foreground">Chưa chặn ai. Muốn chặn, mở hội thoại rồi bấm Tùy chọn chọn Chặn người dùng, hoặc chặn ngay trên trang cá nhân của họ.</p>
                ) : (
                  blocks.map((u) => (
                    <div key={u.id} className="flex items-center gap-3 border-b p-2 last:border-0">
                      <Avatar name={u.fullName} color={u.avatarColor} size={36} />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">{u.fullName}</p>
                        <p className="truncate text-xs text-muted-foreground">@{u.username}</p>
                      </div>
                      <Button size="sm" variant="outline" className="h-8 gap-1 text-xs" onClick={() => unblockUser(u)} aria-label={`Bỏ chặn ${u.fullName}`}>
                        <Check className="h-3.5 w-3.5" /> Bỏ chặn
                      </Button>
                    </div>
                  ))
                )}
              </div>
            )}

            <p className="rounded-lg bg-muted/50 p-3 text-[11px] leading-relaxed text-muted-foreground">
              Người bị chặn không tìm thấy bạn trong tìm kiếm và không nhắn tin được cho bạn, cả hai phía cùng áp dụng. Trò chuyện đã ẩn không hiện trong danh sách, xem lại ở mục Tin nhắn ẩn. Ghim, tắt thông báo, tự xóa cho từng hội thoại nằm trong Tùy chọn của hội thoại đó.
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* TIN NHẮN ẨN (kiểu Zalo) — nơi quản lý: xem toàn bộ trò chuyện đã ẩn, bỏ ẩn hoặc mở lại */}
      <Dialog open={hiddenOpen} onOpenChange={setHiddenOpen}>
        <DialogContent className="gap-0 overflow-hidden rounded-2xl p-0 sm:max-w-md">
          <DialogHeader className="flex flex-row items-center gap-2 space-y-0 border-b p-3">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setHiddenOpen(false)} aria-label="Quay lại"><ChevronLeft className="h-4 w-4" /></Button>
            <DialogTitle className="flex items-center gap-2 text-base font-bold"><EyeOff className="h-4.5 w-4.5 text-stone-500" /> Tin nhắn ẩn</DialogTitle>
          </DialogHeader>
          <div className="max-h-[60vh] overflow-y-auto p-2">
            {conversations.filter((c) => c.hidden).length === 0 ? (
              <p className="px-4 py-8 text-center text-xs text-muted-foreground">Chưa có trò chuyện nào bị ẩn. Muốn ẩn, mở hội thoại rồi bấm Tùy chọn chọn Ẩn trò chuyện.</p>
            ) : (
              conversations.filter((c) => c.hidden).map((c) => {
                const other = !c.isGroup ? c.partner : null
                return (
                  <div key={c.id} className="flex items-center gap-3 border-b p-2.5 last:border-0">
                    {c.isGroup ? (
                      <GroupIcon avatar={c.avatar} img={c.avatarImage} size={44} />
                    ) : (
                      <Avatar name={c.name} color={other?.avatarColor || '#94a3b8'} size={44} online={other?.online} />
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{c.name}</p>
                      <p className="truncate text-xs text-muted-foreground">{c.isGroup ? 'Nhóm' : other ? `@${other.username}` : ''}</p>
                    </div>
                    <Button size="sm" variant="outline" className="h-8 gap-1 text-xs" onClick={() => void unhideConv(c.id)} aria-label={`Bỏ ẩn ${c.name}`}>
                      <Eye className="h-3.5 w-3.5" /> Bỏ ẩn
                    </Button>
                    <Button size="sm" className="h-8 gap-1 bg-emerald-600 text-xs hover:bg-emerald-700" onClick={() => { setHiddenOpen(false); setActiveId(c.id); void unhideConv(c.id) }} aria-label={`Mở lại ${c.name}`}>
                      <MessagesSquare className="h-3.5 w-3.5" /> Mở lại
                    </Button>
                  </div>
                )
              })
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}


// ============ BONG BÓNG TIN NHẮN ============
function MessageBubble({ msg, prev, me, isGroup, seenAvatar, onReply, onForward, onReact, onPin, onUnsend }: {
  msg: MsgT
  prev?: MsgT
  me: VxUserInfo
  isGroup: boolean
  seenAvatar: UserLite | null
  onReply: () => void
  onForward: () => void
  onReact: (emoji: string) => void
  onPin: () => void
  onUnsend: () => void
}) {
  const mine = msg.senderId === me.id
  const [playing, setPlaying] = useState(false)
  const [vProgress, setVProgress] = useState(0)
  const voiceAudioRef = useRef<HTMLAudioElement | null>(null)
  const { toast } = useToast()
  const showDate = !prev || new Date(prev.createdAt).toDateString() !== new Date(msg.createdAt).toDateString()
  const reactionEntries = Object.entries(msg.reactions || {})

  // Phát/tạm dừng bản ghi âm thật của tin nhắn thoại (file audio đính kèm)
  const toggleVoicePlay = () => {
    if (!msg.fileUrl) {
      toast({ title: 'Tin nhắn thoại cũ không có bản ghi âm (gửi trước khi có tính năng ghi âm thật)' })
      return
    }
    const a = voiceAudioRef.current
    if (!a) return
    if (playing) {
      a.pause()
      setPlaying(false)
    } else {
      a.play().then(() => setPlaying(true)).catch(() => toast({ title: 'Không phát được bản ghi âm', variant: 'destructive' }))
    }
  }

  if (msg.type === 'call') {
    return (
      <>
        {showDate && <DateSep date={msg.createdAt} />}
        <div className="flex justify-center py-1">
          <span className="flex items-center gap-1.5 rounded-full bg-muted px-3.5 py-1 text-xs text-muted-foreground"><Phone className="h-3 w-3" /> {msg.unsent ? 'Tin nhắn đã thu hồi' : msg.content}</span>
        </div>
      </>
    )
  }

  // Tin nhắn Quà tặng từ Vexon Bot: thẻ thông báo nổi bật kiểu hệ thống
  if (msg.type === 'gift') {
    return (
      <>
        {showDate && <DateSep date={msg.createdAt} />}
        <div className="flex justify-center py-1">
          <span className="flex max-w-[88%] items-center gap-2.5 rounded-2xl border border-amber-200 bg-gradient-to-r from-amber-50 via-white to-emerald-50 px-4 py-2.5 shadow-sm">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow"><Gift className="h-4 w-4" /></span>
            <span className="min-w-0">
              <b className="block text-[11px] font-black uppercase tracking-wide text-amber-700">Quà tặng</b>
              <span className="block break-words text-xs text-stone-700">{msg.unsent ? 'Tin nhắn đã thu hồi' : msg.content}</span>
            </span>
          </span>
        </div>
      </>
    )
  }

  return (
    <>
      {showDate && <DateSep date={msg.createdAt} />}
      <div className={`group flex items-end gap-2 ${mine ? 'justify-end' : ''}`}>
        {!mine && <Avatar name={msg.sender.fullName} color={msg.sender.avatarColor} size={26} />}

        {msg.unsent ? (
          <p className={`rounded-2xl px-3 py-2 text-xs italic text-muted-foreground ${mine ? 'bg-emerald-100' : 'bg-white'}`}>Tin nhắn đã bị thu hồi</p>
        ) : (
          <div className="relative max-w-[75%]">
            <div className={
              msg.type === 'sticker'
                ? 'py-0.5'
                : mine
                  ? 'rounded-2xl rounded-br-sm bg-emerald-600 px-3.5 py-2 text-sm text-white shadow-sm'
                  : 'rounded-2xl rounded-bl-sm bg-white px-3.5 py-2 text-sm shadow-sm'
            }>
              {isGroup && !mine && msg.type !== 'sticker' && <p className="mb-0.5 text-[10px] font-bold text-emerald-700">{msg.sender.fullName}</p>}
              {msg.forwardedFrom && <p className="mb-0.5 flex items-center gap-1 text-[10px] italic opacity-70"><Forward className="h-3 w-3" /> Đã chuyển tiếp từ {msg.forwardedFrom}</p>}
              {msg.replyTo && (
                <div className={`mb-1.5 rounded-md border-l-2 px-2 py-1 text-[11px] ${mine ? 'border-emerald-200 bg-emerald-500/20' : 'border-emerald-500 bg-muted'}`}>
                  <p className="font-semibold opacity-80">{msg.replyTo.senderName}</p>
                  <p className="truncate opacity-70">{msg.replyTo.type === 'file' ? 'File: ' : msg.replyTo.type === 'voice' ? 'Thoại: ' : ''}{msg.replyTo.content || 'Sticker'}</p>
                </div>
              )}

              {msg.type === 'sticker' ? (
                <StickerStamp content={msg.content} size={76} />
              ) : (msg.type === 'image' || msg.type === 'gif') && msg.fileUrl ? (
                <img src={msg.fileUrl} alt={msg.type === 'gif' ? 'GIF trong tin nhắn' : 'Hình trong tin nhắn'} className="max-h-60 rounded-lg" />
              ) : msg.type === 'file' ? (
                <a href={msg.fileUrl || undefined} download={msg.fileUrl ? (msg.fileName || 'file') : undefined}
                  className={`flex items-center gap-2.5 rounded-lg p-2 ${mine ? 'bg-emerald-500/25' : 'bg-muted'}`}>
                  <div className={`flex h-9 w-9 items-center justify-center rounded-md ${mine ? 'bg-white/20' : 'bg-sky-100'}`}><FileText className={`h-4 w-4 ${mine ? 'text-white' : 'text-sky-700'}`} /></div>
                  <div className="min-w-0"><p className="max-w-40 truncate text-xs font-semibold">{msg.fileName}</p><p className="text-[10px] opacity-70">{fmtSize(msg.fileSize)}, {msg.fileUrl ? 'Bấm để tải' : 'Đính kèm'}</p></div>
                </a>
              ) : msg.type === 'voice' ? (
                <>
                  <button
                    className="flex items-center gap-2.5 py-0.5"
                    onClick={toggleVoicePlay}
                    aria-label="Phát tin nhắn thoại"
                  >
                    <span className={`flex h-8 w-8 items-center justify-center rounded-full ${mine ? 'bg-white/20' : 'bg-emerald-100'}`}>
                      {playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                    </span>
                    <span className="flex items-end gap-0.5">{[4, 8, 5, 10, 6, 9, 4, 7, 5].map((h, i) => {
                      const fill = vProgress >= (i + 1) / 10
                      return <span key={i} className={`w-0.5 rounded ${mine ? (fill ? 'bg-white' : 'bg-emerald-100/60') : (fill ? 'bg-emerald-500' : 'bg-emerald-500/30')} ${playing ? 'animate-pulse' : ''}`} style={{ height: h * 1.5 }} />
                    })}</span>
                    <span className="text-xs font-medium opacity-80">{msg.duration || 0}&quot;</span>
                  </button>
                  {msg.fileUrl && (
                    <audio
                      ref={voiceAudioRef}
                      src={msg.fileUrl}
                      preload="metadata"
                      className="hidden"
                      onTimeUpdate={() => { const a = voiceAudioRef.current; if (a && a.duration) setVProgress(a.currentTime / a.duration) }}
                      onEnded={() => { setPlaying(false); setVProgress(0) }}
                      aria-hidden
                    />
                  )}
                </>
              ) : (
                <p className="break-words">{msg.content}</p>
              )}

              <p className={`mt-0.5 text-right text-[9px] ${mine ? 'text-emerald-100/80' : 'text-muted-foreground'}`}>
                {new Date(msg.createdAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>

            {/* Reactions hiện trên bong bóng */}
            {reactionEntries.length > 0 && (
              <div className={`absolute -bottom-2.5 flex gap-0.5 rounded-full border bg-white px-1.5 py-0.5 shadow-sm ${mine ? 'left-2' : 'right-2'}`}>
                {reactionEntries.map(([emoji, names]) => (
                  <span key={emoji} className="flex items-center text-xs" title={names.join(', ')}>
                    <EmojiLikeIcon emoji={emoji} className="h-3.5 w-3.5" />
                    {names.length > 1 && <span className="ml-0.5 text-[9px] font-semibold">{names.length}</span>}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Menu thao tác tin nhắn */}
        <div className={`flex items-center gap-0.5 opacity-0 transition-opacity group-hover:opacity-100 ${mine ? 'order-first' : ''}`}>
          <Popover>
            <PopoverTrigger asChild>
              <button className="rounded-full p-1 text-muted-foreground hover:bg-muted" aria-label="Thả cảm xúc tin nhắn"><Smile className="h-3.5 w-3.5" /></button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-1" side="top">
              <div className="flex gap-0.5">
                {QUICK_REACTIONS.map((e) => (
                  <button key={e} className="rounded-full p-1 transition-transform hover:scale-125" onClick={onReact && (() => onReact(e))} aria-label={`Cảm xúc ${e}`}><ReactionIcon type={e} className="h-6 w-6" /></button>
                ))}
              </div>
            </PopoverContent>
          </Popover>
          <button className="rounded-full p-1 text-muted-foreground hover:bg-muted" onClick={onReply} aria-label="Trả lời tin nhắn"><CornerUpLeft className="h-3.5 w-3.5" /></button>
          <button className="rounded-full p-1 text-muted-foreground hover:bg-muted" onClick={onForward} aria-label="Chuyển tiếp tin nhắn"><Forward className="h-3.5 w-3.5" /></button>
          <button className="rounded-full p-1 text-amber-600 hover:bg-amber-50" onClick={onPin} aria-label={msg.pinned ? 'Bỏ ghim' : 'Ghim tin nhắn'}><Pin className={`h-3.5 w-3.5 ${msg.pinned ? 'fill-amber-400' : ''}`} /></button>
          {mine && !msg.unsent && msg.type !== 'call' && (
            <button className="rounded-full p-1 text-red-500 hover:bg-red-50" onClick={onUnsend} aria-label="Thu hồi tin nhắn"><RotateCcw className="h-3.5 w-3.5" /></button>
          )}
        </div>

        {/* Trạng thái seen: avatar nhỏ */}
        {mine && seenAvatar && <Avatar name={seenAvatar.fullName} color={seenAvatar.avatarColor} size={14} />}
        {mine && !seenAvatar && msg.id === msg.id && myIsLast(msg) && (
          <span className="mb-1 flex items-center text-emerald-600" aria-label={`Trạng thái: ${statusText(msg.status)}`}>
            {msg.status === 'sent' ? <Check className="h-3.5 w-3.5" /> : <CheckCheck className={`h-3.5 w-3.5 ${msg.status === 'seen' ? 'text-sky-500' : ''}`} />}
          </span>
        )}
      </div>
    </>
  )
}

function myIsLast(_m: MsgT) {
  return true
}
function statusText(s: string) {
  return s === 'sent' ? 'Đã gửi' : s === 'delivered' ? 'Đã nhận' : 'Đã xem'
}

function DateSep({ date }: { date: string }) {
  const d = new Date(date)
  const today = new Date().toDateString() === d.toDateString()
  const yest = new Date(Date.now() - 86400000).toDateString() === d.toDateString()
  return (
    <div className="flex justify-center py-1.5">
      <span className="rounded-full bg-muted px-3 py-0.5 text-[10px] font-medium text-muted-foreground">
        {today ? 'Hôm nay' : yest ? 'Hôm qua' : d.toLocaleDateString('vi-VN')}
      </span>
    </div>
  )
}

// ============ GIF HUB (thư viện GIF dùng chung) ============
function GifPickerDialog({ onSendGif }: { onSendGif: (gif: GifT) => void }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const [gifs, setGifs] = useState<GifT[]>([])
  const [loading, setLoading] = useState(false)
  // r32: GIF cả công ty tải lên hub + form đăng GIF mới (file máy hoặc dán link)
  const [uploads, setUploads] = useState<(GifT & { uploader?: string })[]>([])
  const [upOpen, setUpOpen] = useState(false)
  const [gifFile, setGifFile] = useState<File | null>(null)
  const [gifUrl, setGifUrl] = useState('')
  const [gifTitle, setGifTitle] = useState('')
  const [upBusy, setUpBusy] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  useEffect(() => {
    if (!open) return
    let alive = true
    // debounce 350ms khi gõ; setTimeout cũng tránh setState đồng bộ trong effect
    const t = setTimeout(() => {
      setLoading(true)
      fetch(`/api/vx/gif?q=${encodeURIComponent(q)}`)
        .then((r) => r.json())
        .then((d) => {
          if (!alive) return
          setGifs(Array.isArray(d.gifs) ? d.gifs : [])
          setUploads(Array.isArray(d.uploads) ? d.uploads : [])
        })
        .catch(() => { if (alive) { setGifs([]); setUploads([]) } })
        .finally(() => { if (alive) setLoading(false) })
    }, q ? 350 : 0)
    return () => { alive = false; clearTimeout(t) }
  }, [open, q])

  // Nạp lại hub sau khi đăng GIF mới (giữ từ khoá đang gõ)
  const reloadGifs = (query: string) => {
    fetch(`/api/vx/gif?q=${encodeURIComponent(query)}`)
      .then((r) => r.json())
      .then((d) => { setGifs(Array.isArray(d.gifs) ? d.gifs : []); setUploads(Array.isArray(d.uploads) ? d.uploads : []) })
      .catch(() => {})
  }

  // r32: đăng GIF lên hub — file thật gửi FormData, link dán gửi JSON; server kiểm tra đuôi .gif ≤ 8MB
  const submitUpload = async () => {
    if (upBusy) return
    if (!gifTitle.trim()) { toast({ title: 'Nhập tên/từ khoá cho GIF để mọi người tìm được' }); return }
    if (!gifFile && !gifUrl.trim()) { toast({ title: 'Chọn file GIF hoặc dán link GIF trước đã' }); return }
    setUpBusy(true)
    try {
      let res: Response
      if (gifFile) {
        const fd = new FormData()
        fd.set('file', gifFile)
        fd.set('title', gifTitle.trim())
        res = await fetch('/api/vx/gif', { method: 'POST', body: fd })
      } else {
        res = await fetch('/api/vx/gif', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: gifUrl.trim(), title: gifTitle.trim() }) })
      }
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không tải được GIF lên hub')
      toast({ title: 'Đã đăng GIF lên GIF hub — cả công ty cùng dùng được' })
      setGifFile(null); setGifUrl(''); setGifTitle('')
      if (fileRef.current) fileRef.current.value = ''
      setUpOpen(false)
      reloadGifs(q)
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không tải được GIF lên hub', variant: 'destructive' })
    } finally { setUpBusy(false) }
  }

  // Nút GIF trong lưới — extra = chú thích (ai tải lên)
  const renderGifBtn = (g: GifT, extra?: string) => (
    <button
      key={g.id}
      onClick={() => { onSendGif(g); setOpen(false) }}
      className="overflow-hidden rounded-lg border bg-white transition hover:ring-2 hover:ring-emerald-400"
      aria-label={`Gửi GIF ${g.title}`}
      title={extra || g.title}
    >
      <img src={g.url} alt={g.title} loading="lazy" className="h-28 w-full object-cover" />
    </button>
  )

  // GIF tải lên đã được tách riêng thành khu — lưới chính chỉ còn GIF thư viện (không trùng)
  const mainGifs = gifs.filter((g) => !uploads.some((u) => u.url === g.url))

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button className="rounded-full p-2 text-emerald-600 transition hover:bg-emerald-50" aria-label="Gửi GIF" title="GIF hub, gửi GIF vui cho hội thoại">
          <Clapperboard className="h-5 w-5" />
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-2.5" side="top" align="start">
        <div className="mb-1.5 flex items-center justify-between">
          <p className="text-[10px] font-bold tracking-wide text-muted-foreground">GIF HUB (TÌM &amp; GỬI)</p>
          <button
            onClick={() => setUpOpen((v) => !v)}
            aria-expanded={upOpen}
            className={`flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-bold transition ${upOpen ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'}`}
            aria-label="Tải GIF lên hub"
            title="Đăng GIF của bạn lên hub dùng chung cả công ty"
          >
            <Upload className="h-3 w-3" /> Tải lên
          </button>
        </div>
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm GIF: chúc mừng, like, cười..." className="mb-2 h-8 text-sm" aria-label="Tìm GIF" />
        {upOpen && (
          <div className="mb-2 space-y-1.5 rounded-lg border border-emerald-200 bg-emerald-50/60 p-2">
            <p className="text-[10px] font-bold text-emerald-800">ĐĂNG GIF LÊN HUB — CẢ CÔNG TY DÙNG CHUNG</p>
            <input ref={fileRef} type="file" accept="image/gif,.gif" className="hidden" aria-label="Chọn file GIF" onChange={(e) => setGifFile(e.target.files?.[0] || null)} />
            <button
              onClick={() => fileRef.current?.click()}
              className="w-full rounded-md border border-dashed border-emerald-400 bg-white px-2 py-1.5 text-[11px] font-semibold text-emerald-700 hover:bg-emerald-50"
              aria-label="Chọn file GIF từ máy"
            >
              {gifFile ? `Đã chọn: ${gifFile.name.length > 22 ? gifFile.name.slice(0, 22) + '…' : gifFile.name}` : 'Chọn file GIF (≤ 8MB)'}
            </button>
            <Input value={gifUrl} onChange={(e) => setGifUrl(e.target.value)} placeholder="hoặc dán link GIF http(s)://..." className="h-7 text-[11px]" aria-label="Link GIF" />
            <Input value={gifTitle} onChange={(e) => setGifTitle(e.target.value)} placeholder="Tên + từ khoá tìm (vd: ăn mừng tiệc)" className="h-7 text-[11px]" aria-label="Tên và từ khoá GIF" />
            <Button size="sm" disabled={upBusy} onClick={submitUpload} className="h-7 w-full gap-1 bg-gradient-to-r from-emerald-600 to-teal-600 text-[11px] font-bold text-white hover:brightness-105">
              {upBusy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Upload className="h-3 w-3" />} Đăng lên GIF hub
            </Button>
          </div>
        )}
        <div className="h-56 overflow-y-auto">
          {loading ? (
            <p className="flex items-center justify-center gap-2 py-10 text-xs text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Đang tải GIF...</p>
          ) : uploads.length === 0 && mainGifs.length === 0 ? (
            <p className="py-10 text-center text-xs text-muted-foreground">Không tìm thấy GIF nào</p>
          ) : (
            <>
              {uploads.length > 0 && (
                <>
                  <p className="mb-1 text-[9px] font-bold tracking-wide text-emerald-700">GIF MỌI NGƯỜI TẢI LÊN ({uploads.length})</p>
                  <div className="mb-2 grid grid-cols-2 gap-1.5">
                    {uploads.map((g) => renderGifBtn(g, `Tải lên bởi ${g.uploader || 'Vexon'}`))}
                  </div>
                </>
              )}
              {mainGifs.length > 0 && (
                <div className="grid grid-cols-2 gap-1.5">
                  {mainGifs.map((g) => renderGifBtn(g))}
                </div>
              )}
            </>
          )}
        </div>
        <p className="mt-1.5 text-[9px] text-muted-foreground">GIF hub dùng chung cho mọi hội thoại &amp; nhóm chat Vexon — bấm “Tải lên” để đăng GIF của bạn</p>
      </PopoverContent>
    </Popover>
  )
}

// ============ Ô SOẠN TIN ============
function ComposerBar({ onSend, input, setInput, onSticker, me, aiContext }: {
  onSend: (extra?: Partial<{ type: string; fileUrl: string; fileName: string; fileSize: number; duration: number }>) => void
  input: string
  setInput: (v: string) => void
  onSticker: (e: string) => void
  me: VxUserInfo
  aiContext?: { partnerName: string; lastTexts: string[] } // ngữ cảnh hội thoại gần nhất cho AI gợi ý trả lời
}) {
  const [recording, setRecording] = useState<number | null>(null)
  const recRef = useRef<MediaRecorder | null>(null)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const streamRef = useRef<MediaStream | null>(null)
  const secRef = useRef(0)
  const [aiSugs, setAiSugs] = useState<string[]>([])
  const [aiBusy, setAiBusy] = useState(false)
  const { toast } = useToast()

  // AI gợi ý trả lời: đọc ngữ cảnh hội thoại, đề xuất 3 câu trả lời ngắn
  const aiSuggest = async () => {
    if (!aiContext || aiBusy) return
    setAiBusy(true)
    try {
      const res = await fetch('/api/tiai/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system: 'Bạn là trợ lý gợi ý trả lời tin nhắn tiếng Việt trong app công sở. Dựa vào hội thoại, đề xuất đúng 3 câu trả lời ngắn (mỗi câu dưới 50 ký tự, lịch sự thân thiện, 3 câu khác nhau về hướng: xác nhận, bày tỏ quan điểm, đề xuất hành động). Chỉ trả về 3 câu, mỗi câu một dòng, KHÔNG đánh số, KHÔNG emoji, không giải thích.',
          prompt: `Hội thoại gần nhất:\n${aiContext.lastTexts.join('\n')}\n\nHãy đề xuất 3 câu trả lời tiếp theo thay cho ${me.fullName} khi nhắn với ${aiContext.partnerName}.`,
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'AI bận')
      const sugs = String(d.text).split('\n').map((s: string) => s.replace(/^[-•\d.)\s]+/, '').trim()).filter(Boolean).slice(0, 3)
      setAiSugs(sugs.length > 0 ? sugs : [])
      if (sugs.length === 0) toast({ title: 'AI chưa gợi ý được, thử lại nhé' })
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'AI chưa trả lời được', variant: 'destructive' })
    } finally { setAiBusy(false) }
  }

  // Giới hạn demo: tối đa 5 phút / 3MB mỗi bản ghi thoại
  const MAX_VOICE_SEC = 300

  const cleanupRec = () => {
    if (timerRef.current) clearInterval(timerRef.current)
    timerRef.current = null
    stopStream(streamRef.current)
    streamRef.current = null
    chunksRef.current = []
  }

  const cancelRec = () => {
    const rec = recRef.current
    recRef.current = null
    if (rec && rec.state !== 'inactive') {
      rec.ondataavailable = null
      rec.onstop = null
      try { rec.stop() } catch {}
    }
    cleanupRec()
    setRecording(null)
  }

  // Ghi âm THẬT bằng micro (MediaRecorder + getUserMedia chuẩn, chống hú/lọc ồn)
  const startRec = async () => {
    try {
      const stream = await openUserMedia('voice')
      const chunks: Blob[] = []
      chunksRef.current = chunks
      streamRef.current = stream
      const rec = startAudioRecorder(stream, (b) => chunks.push(b), (msg) => {
        toast({ title: msg, variant: 'destructive' })
        cancelRec()
      })
      if (!rec) {
        cleanupRec()
        setRecording(null)
        return
      }
      recRef.current = rec
      secRef.current = 0
      setRecording(0)
      timerRef.current = setInterval(() => {
        secRef.current += 1
        setRecording(secRef.current)
        if (secRef.current >= MAX_VOICE_SEC) void stopRec(true)
      }, 1000)
    } catch (err) {
      cleanupRec()
      setRecording(null)
      toast({ title: mediaErrorMessage(err), variant: 'destructive' })
    }
  }

  const stopRec = async (sendIt: boolean) => {
    const rec = recRef.current
    const dur = Math.max(1, secRef.current)
    recRef.current = null
    if (timerRef.current) clearInterval(timerRef.current)
    timerRef.current = null
    setRecording(null)
    if (!rec || rec.state === 'inactive') {
      cleanupRec()
      return
    }
    await new Promise<void>((res) => {
      rec.onstop = async () => {
        try {
          if (sendIt && chunksRef.current.length > 0) {
            const blob = new Blob(chunksRef.current, { type: rec.mimeType || 'audio/webm' })
            if (blob.size > 3_000_000) {
              toast({ title: 'Bản ghi quá lớn (giới hạn demo 3MB), không gửi được', variant: 'destructive' })
            } else {
              const url = await blobToDataUrl(blob)
              onSend({ type: 'voice', fileUrl: url, duration: dur })
            }
          }
        } finally {
          chunksRef.current = []
          stopStream(streamRef.current)
          streamRef.current = null
          res()
        }
      }
      try { rec.stop() } catch { res() }
    })
  }

  return (
    <div className="border-t p-2.5">
      {/* AI gợi ý trả lời — chips bấm vào là điền thẳng vào ô soạn */}
      {recording === null && aiSugs.length > 0 && (
        <div className="mb-2 flex flex-wrap items-center gap-1.5" aria-label="Gợi ý trả lời từ AI">
          <span className="flex items-center gap-1 rounded-full bg-teal-50 px-2 py-1 text-[10px] font-bold text-teal-700"><Sparkles className="h-3 w-3" /> AI gợi ý</span>
          {aiSugs.map((s, i) => (
            <button key={i} onClick={() => { setInput(s); setAiSugs([]) }} className="rounded-full border border-teal-200 bg-white px-2.5 py-1 text-xs text-teal-800 hover:bg-teal-50" aria-label={`Chọn gợi ý: ${s}`}>{s}</button>
          ))}
          <button onClick={() => setAiSugs([])} className="rounded-full p-1 text-stone-400 hover:bg-stone-100" aria-label="Bỏ gợi ý"><X className="h-3.5 w-3.5" /></button>
        </div>
      )}
      {recording === null ? (
        <div className="flex items-center gap-1.5">
          <Popover>
            <PopoverTrigger asChild>
              <button className="rounded-full p-2 text-muted-foreground hover:bg-muted" aria-label="Gửi sticker hình ảnh"><Smile className="h-5 w-5" /></button>
            </PopoverTrigger>
            <PopoverContent className="w-72 p-2" side="top" align="start">
              <p className="mb-1 text-[10px] font-semibold text-muted-foreground">STICKER (hình ảnh vector)</p>
              <div className="grid grid-cols-6 gap-1">
                {STICKERS.map((s) => (
                  <button key={s.key} className="rounded-lg p-0.5 transition-transform hover:scale-110" onClick={() => onSticker(s.key)} aria-label={`Gửi sticker ${s.label}`}>
                    <StickerStamp content={s.key} size={38} className="w-full" />
                  </button>
                ))}
              </div>
            </PopoverContent>
          </Popover>
          <GifPickerDialog onSendGif={(g) => onSend({ type: 'gif', fileUrl: g.url, fileName: g.title })} />
          <label className="cursor-pointer rounded-full p-2 text-sky-600 hover:bg-sky-50" aria-label="Gửi hình ảnh">
            <ImageIcon className="h-5 w-5" />
            <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
              const f = e.target.files?.[0]
              if (!f) return
              if (f.size > 1_500_000) { toast({ title: 'Ảnh quá lớn (demo ~1.5MB)', variant: 'destructive' }); return }
              const url = await new Promise<string>((res) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.readAsDataURL(f) })
              onSend({ type: 'image', fileUrl: url, fileName: f.name, fileSize: f.size })
            }} />
          </label>
          <label className="cursor-pointer rounded-full p-2 text-muted-foreground hover:bg-muted" aria-label="Gửi file (PDF, Excel, CAD...)">
            <Paperclip className="h-5 w-5" />
            <input type="file" className="hidden" onChange={async (e) => {
              const f = e.target.files?.[0]
              if (!f) return
              if (f.size > 1_500_000) { toast({ title: 'File >1.5MB: demo chỉ gửi tên file', description: f.name }); onSend({ type: 'file', fileName: f.name, fileSize: f.size }); return }
              const url = await new Promise<string>((res) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.readAsDataURL(f) })
              onSend({ type: 'file', fileUrl: url, fileName: f.name, fileSize: f.size })
            }} />
          </label>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && onSend()}
            placeholder="Nhập tin nhắn..."
            className="flex-1 rounded-full border bg-muted/40 px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-emerald-500/40"
            aria-label="Nội dung tin nhắn"
          />
          {aiContext && (
            <button className="rounded-full p-2 text-teal-600 hover:bg-teal-50 disabled:opacity-50" onClick={() => void aiSuggest()} disabled={aiBusy} aria-label="AI gợi ý trả lời nhanh" title="AI gợi ý trả lời">
              {aiBusy ? <Loader2 className="h-5 w-5 animate-spin" /> : <Sparkles className="h-5 w-5" />}
            </button>
          )}
          <button className="rounded-full p-2 text-emerald-600 hover:bg-emerald-50" onClick={() => void startRec()} aria-label="Ghi âm tin nhắn thoại"><Mic className="h-5 w-5" /></button>
          <Button size="icon" className="h-10 w-10 shrink-0 rounded-full bg-emerald-600 hover:bg-emerald-700" onClick={() => onSend()} disabled={!input.trim()} aria-label="Gửi tin nhắn"><Send className="h-4 w-4" /></Button>
        </div>
      ) : (
        <div className="flex items-center gap-2">
          <span className="flex flex-1 items-center gap-2 text-sm font-medium text-red-600">
            <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-red-500" /> Đang ghi âm... {recording}s / 5:00
          </span>
          <Button size="sm" variant="outline" onClick={cancelRec}>Huỷ</Button>
          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => void stopRec(true)}><Send className="mr-1 h-3.5 w-3.5" /> Gửi thoại</Button>
        </div>
      )}
      <p className="mt-1 pl-1 text-[9px] text-muted-foreground">Đang nhắn với vai trò {me.fullName}, Enter để gửi</p>
    </div>
  )
}

// ============ HỘI THOẠI MỚI / NHÓM ============
// Biểu tượng nhóm = hình vector (lưu key, dùng chung GROUP_ICON_ITEMS từ shared) — không dùng kí tự emoji

function GroupIcon({ avatar, img, size = 44 }: { avatar?: string | null; img?: string | null; size?: number }) {
  // Ưu tiên ảnh nhóm tự tải lên (kiểu Facebook), không thì hình vector mặc định (tự nhận cả dữ liệu emoji cũ)
  if (img) {
    return <img src={img} alt="Ảnh nhóm" style={{ width: size, height: size }} className="shrink-0 rounded-full border object-cover" />
  }
  const Ic = groupIconOf(avatar)
  return (
    <div className="flex shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white" style={{ width: size, height: size }}>
      {Ic ? <Ic style={{ width: size * 0.45, height: size * 0.45 }} strokeWidth={2.2} /> : <Users style={{ width: size * 0.45, height: size * 0.45 }} strokeWidth={2.2} />}
    </div>
  )
}

// Công tắc nhỏ kiểu iOS dùng trong menu Tùy chọn hội thoại (TTO v32)
function ToggleDot({ on }: { on: boolean }) {
  return (
    <span className={`flex h-5 w-9 shrink-0 items-center rounded-full p-0.5 transition-colors ${on ? 'bg-emerald-600' : 'bg-stone-300'}`}>
      <span className={`h-4 w-4 rounded-full bg-white shadow transition-transform ${on ? 'translate-x-4' : ''}`} />
    </span>
  )
}

function NewChatDialog({ me, onCreated }: { me: VxUserInfo; onCreated: (id: string) => void }) {
  const [open, setOpen] = useState(false)
  const [users, setUsers] = useState<UserLite[]>([])
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState<UserLite[]>([])
  const [saving, setSaving] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    if (!open) return
    fetch('/api/vx/users').then((r) => r.json()).then((d) => Array.isArray(d) && setUsers(d)).catch(() => {})
  }, [open])

  const toggle = (u: UserLite) =>
    setSelected((s) => (s.some((x) => x.id === u.id) ? s.filter((x) => x.id !== u.id) : [...s, u]))

  const create = async () => {
    if (selected.length < 1) { toast({ title: 'Chọn ít nhất 1 người để nhắn tin', variant: 'destructive' }); return }
    setSaving(true)
    try {
      // Kiểu Messenger/fmess: chọn 1 người → nhắn riêng, chọn nhiều người → nhóm tự đặt tên, không cần điền form
      const isGroup = selected.length > 1
      const autoName = selected
        .map((u) => u.fullName.split(' ').pop() || u.fullName)
        .slice(0, 3)
        .join(', ') + (selected.length > 3 ? ` +${selected.length - 3}` : '')
      const res = await fetch('/api/vx/conversations', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
        userIds: selected.map((u) => u.id),
        name: isGroup ? autoName : undefined,
      }) })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast({ title: isGroup ? `Đã tạo nhóm: ${autoName}` : 'Đã mở hội thoại' })
      setOpen(false); setSelected([]); setQuery('')
      onCreated(d.id)
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không tạo được', variant: 'destructive' })
    } finally { setSaving(false) }
  }

  const shown = users.filter(
    (u) =>
      u.id !== me.id &&
      (!query.trim() ||
        u.fullName.toLowerCase().includes(query.trim().toLowerCase()) ||
        u.username.toLowerCase().includes(query.trim().toLowerCase())),
  )

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Button
        size="sm"
        onClick={() => setOpen(true)}
        className="gap-1.5 bg-emerald-600 text-white hover:bg-emerald-700"
        aria-label="Tin nhắn mới, nhắn riêng hoặc kéo thêm bạn bè thành nhóm"
        title="Tin nhắn mới: chọn 1 người nhắn riêng, chọn nhiều người thành nhóm"
      >
        <PenSquare className="h-4 w-4" />
        <span className="hidden sm:inline">Tin nhắn mới</span>
      </Button>
      <DialogContent>
        <DialogHeader><DialogTitle>Tin nhắn mới</DialogTitle></DialogHeader>
        <div className="space-y-3">
          {/* Người đã chọn — kiểu Messenger, bấm để bỏ ra */}
          {selected.length > 0 && (
            <div className="flex flex-wrap gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50/60 p-2" aria-label="Người đã chọn">
              {selected.map((u) => (
                <button
                  key={u.id}
                  onClick={() => toggle(u)}
                  className="flex items-center gap-1 rounded-full bg-white py-0.5 pl-0.5 pr-2 text-xs font-semibold shadow-sm transition hover:bg-stone-100"
                  aria-label={`Bỏ ${u.fullName} khỏi hội thoại`}
                >
                  <Avatar name={u.fullName} color={u.avatarColor} size={20} />
                  {u.fullName.split(' ').pop()}
                  <X className="h-3 w-3 text-stone-400" />
                </button>
              ))}
            </div>
          )}
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Tìm tên người nhận..." aria-label="Tìm người nhận" />
          <div className="max-h-64 space-y-1 overflow-y-auto rounded-lg border p-2">
            {shown.map((u) => (
              <label key={u.id} className="flex cursor-pointer items-center gap-3 rounded-lg p-2 hover:bg-muted/60">
                <Checkbox checked={selected.some((x) => x.id === u.id)} onCheckedChange={() => toggle(u)} aria-label={`Chọn ${u.fullName}`} />
                <Avatar name={u.fullName} color={u.avatarColor} size={32} online={u.online} />
                <div><p className="text-sm font-medium">{u.fullName}</p><p className="text-xs text-muted-foreground">{u.department}{u.online ? ', Đang online' : ''}</p></div>
              </label>
            ))}
            {users.length === 0 && <p className="py-4 text-center text-xs text-muted-foreground">Đang tải...</p>}
            {users.length > 0 && shown.length === 0 && <p className="py-4 text-center text-xs text-muted-foreground">Không tìm thấy ai tên này.</p>}
          </div>
          <p className="text-[11px] text-muted-foreground">Chọn 1 người để nhắn riêng, chọn nhiều người để tự tạo nhóm chat (tên nhóm ghép từ tên thành viên, đổi được sau trong Thông tin nhóm)</p>
          <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={create} disabled={saving || selected.length === 0}>
            {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : selected.length > 1 ? <Users className="mr-1 h-4 w-4" /> : <Send className="mr-1 h-4 w-4" />}
            {selected.length > 1 ? `Tạo nhóm (${selected.length} người)` : 'Bắt đầu nhắn tin'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ============ TẠO CHỦ ĐỀ ============
// Biểu tượng chủ đề là hình vector chọn từ bảng (lưu key) — chỉ dùng cho chủ đề
function NewTopicDialog({ conversationId, onCreated }: { conversationId: string; onCreated: (id: string) => void }) {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [icon, setIcon] = useState('chat')
  const [saving, setSaving] = useState(false)
  const { toast } = useToast()

  const create = async () => {
    if (!name.trim()) { toast({ title: 'Nhập tên chủ đề', variant: 'destructive' }); return }
    setSaving(true)
    try {
      const res = await fetch(`/api/vx/conversations/${conversationId}/topics`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: name.trim(), icon }) })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast({ title: `Đã tạo chủ đề "${name.trim()}"` })
      setOpen(false); setName(''); setIcon('chat')
      onCreated(d.id)
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không tạo được chủ đề', variant: 'destructive' })
    } finally { setSaving(false) }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <button onClick={() => setOpen(true)} title="Tạo chủ đề mới"
        className="flex h-7 shrink-0 items-center gap-1 rounded-full border border-dashed border-stone-300 px-2.5 text-xs font-medium text-stone-500 transition-colors hover:border-emerald-500 hover:text-emerald-700"
        aria-label="Tạo chủ đề mới">
        <Plus className="h-3.5 w-3.5" /> Chủ đề
      </button>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><ListTree className="h-5 w-5 text-sky-600" /> Tạo chủ đề mới</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="tp-name">Tên chủ đề</Label>
            <Input id="tp-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Thiết kế, Báo giá, Vận chuyển..." onKeyDown={(e) => e.key === 'Enter' && create()} />
          </div>
          <div className="space-y-2">
            <Label>Biểu tượng</Label>
            <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Chọn biểu tượng chủ đề">
              {TOPIC_ICON_ITEMS.map((t) => (
                <button key={t.key} onClick={() => setIcon(t.key)} aria-label={`Biểu tượng chủ đề ${t.label}`}
                  className={`flex h-9 w-9 items-center justify-center rounded-lg border transition-colors ${icon === t.key ? 'border-emerald-600 bg-emerald-100' : 'border-stone-200 hover:bg-stone-100'}`}>
                  <TopicStamp icon={t.key} size={26} />
                </button>
              ))}
            </div>
          </div>
          <p className="text-[11px] text-muted-foreground">Tạo chủ đề tự bật Chế độ Chủ đề cho nhóm, tin nhắn gửi vào từng chủ đề riêng, đỡ loãng.</p>
          <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={create} disabled={saving}>
            {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Plus className="mr-1 h-4 w-4" />} Tạo chủ đề
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ============ CHUYỂN TIẾP ============
function ForwardDialog({ msg, conversations, onClose, onDone }: { msg: MsgT | null; conversations: ConvT[]; onClose: () => void; onDone: () => void }) {
  const [busyId, setBusyId] = useState<string | null>(null)
  if (!msg) return null
  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader><DialogTitle>Chuyển tiếp tin nhắn</DialogTitle></DialogHeader>
        <p className="truncate rounded-md bg-muted px-3 py-2 text-xs text-muted-foreground">{msg.type === 'file' ? 'File: ' : msg.type === 'voice' ? 'Thoại: ' : ''}{msg.content || '(đính kèm)'}</p>
        <ScrollArea className="h-56">
          {conversations.map((c) => (
            <button key={c.id} disabled={busyId === c.id}
              className="flex w-full items-center gap-3 rounded-lg p-2.5 text-left hover:bg-muted disabled:opacity-50"
              onClick={async () => {
                setBusyId(c.id)
                await fetch(`/api/vx/messages/${msg.id}/forward`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ conversationId: c.id }) })
                setBusyId(null); onClose(); onDone()
              }}>
              {c.isGroup ? <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white"><Users className="h-4 w-4" /></div>
                : <Avatar name={c.name} color={c.partner?.avatarColor || '#94a3b8'} size={36} />}
              <span className="text-sm font-medium">{c.name}</span>
              {busyId === c.id && <Loader2 className="ml-auto h-4 w-4 animate-spin" />}
            </button>
          ))}
          {conversations.length === 0 && <p className="py-6 text-center text-xs text-muted-foreground">Không có hội thoại khác</p>}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}

// ============ THÔNG TIN NHÓM + PHÂN QUYỀN + CHỦ ĐỀ ============
function GroupInfoDialog({ conv, open, onOpenChange, me, onChanged, pinned, onUnpin, topics, loadTopics }: {
  conv: ConvT | null
  open: boolean
  onOpenChange: (v: boolean) => void
  me: VxUserInfo
  onChanged: () => void
  pinned: MsgT[]
  onUnpin: (m: MsgT) => void
  topics: TopicT[]
  loadTopics: () => void
}) {
  const [busy, setBusy] = useState<string | null>(null)
  const [editing, setEditing] = useState(false)
  const [eName, setEName] = useState('')
  const [eDesc, setEDesc] = useState('')
  const [eAvatar, setEAvatar] = useState('')
  const [eAvatarImg, setEAvatarImg] = useState<string | null>(null)
  const [eForum, setEForum] = useState(false)
  const [avatarBusy, setAvatarBusy] = useState(false)
  const [editTopic, setEditTopic] = useState<{ id: string; name: string; icon: string } | null>(null)
  const avatarInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  if (!conv || !conv.isGroup) return null
  const iAmAdmin = conv.myRole === 'admin'

  const startEdit = () => {
    setEName(conv.name); setEDesc(conv.description || ''); setEAvatar(conv.avatar || ''); setEAvatarImg(conv.avatarImage || null); setEForum(Boolean(conv.isForum)); setEditing(true)
  }

  // Đổi ảnh nhóm kiểu Facebook: chọn ảnh → nén → lưu ngay
  const uploadGroupAvatar = async (file: File | undefined) => {
    if (!file) return
    if (file.size > 6_000_000) { toast({ title: 'Ảnh quá lớn (tối đa ~6MB trước khi nén)', variant: 'destructive' }); return }
    setAvatarBusy(true)
    try {
      const url = await compressImage(file, 512)
      const res = await fetch(`/api/vx/conversations/${conv.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ avatarImage: url }),
      })
      if (!res.ok) throw new Error('Không lưu được ảnh nhóm')
      setEAvatarImg(url)
      toast({ title: 'Đã đổi ảnh nhóm' })
      onChanged()
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không tải được ảnh', variant: 'destructive' })
    } finally { setAvatarBusy(false) }
  }

  const saveEdit = async () => {
    setBusy('edit')
    const res = await fetch(`/api/vx/conversations/${conv.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: eName, description: eDesc, avatar: eAvatar, isForum: eForum }) })
    setBusy(null)
    if (res.ok) {
      toast({ title: eForum && !conv.isForum ? 'Đã bật Chủ đề, tạo chủ đề đầu tiên nhé!' : 'Đã cập nhật nhóm' })
      setEditing(false); onChanged(); loadTopics()
    } else {
      const d = await res.json().catch(() => ({}))
      toast({ title: 'Lỗi', description: d.error || 'Không lưu được', variant: 'destructive' })
    }
  }

  // Xoá chủ đề — tin nhắn trong chủ đề chuyển về "Tổng hợp"
  const deleteTopic = async (topicId: string, name: string) => {
    setBusy(topicId)
    const res = await fetch(`/api/vx/conversations/${conv.id}/topics/${topicId}`, { method: 'DELETE' })
    setBusy(null)
    if (res.ok) { toast({ title: `Đã xoá chủ đề ${name}, tin nhắn chuyển về Tổng hợp` }); loadTopics() }
    else { const d = await res.json().catch(() => ({})); toast({ title: 'Lỗi', description: d.error || 'Không xoá được chủ đề', variant: 'destructive' }) }
  }

  const setRole = async (userId: string, role: string) => {
    const target = conv.members.find((m) => m.id === userId)
    setBusy(userId)
    try {
      const res = await fetch(`/api/vx/conversations/${conv.id}/role`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId, role }) })
      const d = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(d.error || 'Không đổi được vai trò')
      if (role === 'admin') {
        toast({ title: `Đã chuyển quyền trưởng nhóm cho ${target?.fullName || 'thành viên'}`, description: 'Bạn giờ là thành viên, bấm Rời nhóm ở dưới để ra khỏi nhóm.' })
      }
      onChanged()
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không đổi được vai trò', variant: 'destructive' })
    } finally { setBusy(null) }
  }

  // Chuyển nhượng quyền trưởng nhóm (kiểu TTO group-manage) — có xác nhận rõ ràng
  const transferOwner = (m: Member) => {
    if (!window.confirm(`Chuyển quyền trưởng nhóm cho ${m.fullName}?\n\n- ${m.fullName} sẽ trở thành trưởng nhóm\n- Bạn sẽ trở thành thành viên và có thể rời nhóm`)) return
    void setRole(m.id, 'admin')
  }

  // Rời nhóm (kiểu TTO group-manage): trưởng nhóm phải chuyển quyền trước, thành viên rời tự do
  const leaveGroup = async () => {
    if (!window.confirm('Rời nhóm này? Lịch sử tin nhắn sẽ không còn hiển thị với bạn.')) return
    setBusy('leave')
    try {
      const res = await fetch(`/api/vx/conversations/${conv.id}`, { method: 'DELETE' })
      const d = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(d.error || 'Không rời được nhóm')
      toast({ title: d.mode === 'dissolved' ? 'Nhóm chỉ còn bạn, đã giải tán nhóm' : 'Đã rời nhóm' })
      onOpenChange(false)
      onChanged()
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không rời được nhóm', variant: 'destructive' })
    } finally { setBusy(null) }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader><DialogTitle className="flex items-center gap-2"><GroupIcon avatar={conv.avatar} img={conv.avatarImage} size={28} /> {conv.name}</DialogTitle></DialogHeader>
        <div className="space-y-4">
          {/* Mô tả nhóm */}
          {!editing && (
            <div className="flex items-start justify-between gap-2 rounded-lg bg-muted/50 p-3">
              <div className="min-w-0">
                <p className="text-xs font-semibold text-muted-foreground">
                  MÔ TẢ NHÓM
                  {conv.isForum && <Badge className="ml-1.5 gap-1 bg-sky-100 text-[10px] text-sky-800 hover:bg-sky-100"><ListTree className="h-3 w-3" /> Chế độ Chủ đề</Badge>}
                </p>
                <p className="mt-1 text-sm">{conv.description || <span className="text-muted-foreground italic">Chưa có mô tả</span>}</p>
              </div>
              {iAmAdmin && <Button size="sm" variant="outline" className="h-7 shrink-0 px-2 text-[10px]" onClick={startEdit}>Sửa</Button>}
            </div>
          )}

          {/* Form sửa nhóm */}
          {editing && (
            <div className="space-y-3 rounded-lg border p-3">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <GroupIcon avatar={eAvatarImg ? null : eAvatar} img={eAvatarImg} size={48} />
                  <button onClick={() => avatarInputRef.current?.click()} title="Đổi ảnh nhóm (kiểu Facebook)"
                    className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-white shadow hover:bg-emerald-700"
                    aria-label="Đổi ảnh nhóm">
                    {avatarBusy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Camera className="h-3.5 w-3.5" />}
                  </button>
                  <input ref={avatarInputRef} type="file" accept="image/*" className="hidden"
                    onChange={(e) => { uploadGroupAvatar(e.target.files?.[0]); e.target.value = '' }} />
                </div>
                <div className="flex flex-wrap gap-1">
                  {GROUP_ICON_ITEMS.map((g) => {
                    const Ic = g.Icon
                    return (
                      <button key={g.key} onClick={() => { setEAvatar(g.key); setEAvatarImg(null) }} title={g.label} aria-label={`Chọn biểu tượng ${g.label}`}
                        className={`flex h-7 w-7 items-center justify-center rounded-lg border text-stone-600 ${!eAvatarImg && eAvatar === g.key ? 'border-emerald-600 bg-emerald-100 text-emerald-700' : 'border-stone-200 hover:bg-stone-100'}`}><Ic className="h-4 w-4" /></button>
                    )
                  })}
                </div>
              </div>
              <div className="space-y-1"><Label htmlFor="ed-name">Tên nhóm</Label><Input id="ed-name" value={eName} onChange={(e) => setEName(e.target.value)} /></div>
              <div className="space-y-1"><Label htmlFor="ed-desc">Mô tả</Label><Input id="ed-desc" value={eDesc} onChange={(e) => setEDesc(e.target.value)} placeholder="Mô tả nhóm..." /></div>
              <div className="flex justify-end gap-2">
                <Button size="sm" variant="outline" onClick={() => setEditing(false)}>Huỷ</Button>
                <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" disabled={busy === 'edit' || !eName.trim()} onClick={saveEdit}>
                  {busy === 'edit' ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : null} Lưu
                </Button>
              </div>
            </div>
          )}

          {/* CHỦ ĐỀ (kiểu Telegram) — quản lý trong Thông tin nhóm */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <p className="text-xs font-semibold text-muted-foreground">CHỦ ĐỀ ({topics.length})</p>
              <NewTopicDialog conversationId={conv.id} onCreated={() => { loadTopics(); onChanged() }} />
            </div>
            {topics.length === 0 ? (
              <p className="rounded-lg bg-muted/50 p-3 text-xs text-muted-foreground">Nhóm chưa có chủ đề. Bấm "Chủ đề" ở trên để tạo chủ đề đầu tiên (tự bật Chế độ Chủ đề).</p>
            ) : (
              <div className="space-y-1">
                {topics.map((t) => {
                  const topicId = t.id
                  const canManage = topicId !== null && (iAmAdmin || conv.myRole === 'mod')
                  return (
                    <div key={t.id || 'general'} className="flex items-center gap-2 rounded-lg p-2 hover:bg-muted/60">
                      <TopicStamp icon={t.icon} size={32} />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{t.name}{topicId === null && <span className="ml-1 text-[10px] text-muted-foreground">(mặc định)</span>}</p>
                        <p className="truncate text-xs text-muted-foreground">
                          {t.messageCount} tin{t.lastMessage ? `, ${t.lastMessage.senderName}: ${t.lastMessage.content.slice(0, 30)}` : ''}
                        </p>
                      </div>
                      {canManage && (
                        <button className="shrink-0 rounded p-1.5 text-stone-400 hover:bg-sky-50 hover:text-sky-600" disabled={busy === topicId}
                          onClick={() => setEditTopic({ id: topicId as string, name: t.name, icon: t.icon })} title="Sửa tên chủ đề và biểu tượng" aria-label={`Sửa chủ đề ${t.name}`}>
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                      )}
                      {topicId && iAmAdmin && (
                        <button className="shrink-0 rounded p-1.5 text-stone-400 hover:bg-red-50 hover:text-red-600" disabled={busy === topicId}
                          onClick={() => deleteTopic(topicId, t.name)} title="Xoá chủ đề (tin nhắn giữ lại ở Tổng hợp)" aria-label={`Xoá chủ đề ${t.name}`}>
                          {busy === topicId ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <X className="h-3.5 w-3.5" />}
                        </button>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </div>

          {/* Thành viên & phân quyền */}
          <div>
            <p className="mb-2 text-xs font-semibold text-muted-foreground">THÀNH VIÊN & PHÂN QUYỀN ({conv.members.length})</p>
            {iAmAdmin && (
              <div className="mb-2 flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 p-2.5 text-[11px] leading-relaxed text-amber-800">
                <Crown className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span>Bạn là <b>trưởng nhóm</b>. Bấm <b>Chuyển quyền</b> để nhượng quyền cho một thành viên (bạn thành thành viên và rời nhóm được), hoặc <b>Bổ nhiệm phó</b> để trợ giúp quản lý.</span>
              </div>
            )}
            <div className="space-y-1">
              {conv.members.map((m) => (
                <div key={m.id} className="flex items-center gap-3 rounded-lg p-2 hover:bg-muted/60">
                  <Avatar name={m.fullName} color={m.avatarColor} size={36} online={m.online} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{m.fullName}{m.id === me.id && ' (bạn)'}</p>
                    <p className="text-xs text-muted-foreground">{m.department}{m.online ? ', Đang online' : `, ${lastSeenText(m)}`}</p>
                  </div>
                  <div className="flex shrink-0 items-center gap-1.5">
                    {m.memberRole === 'admin' && <Badge className="gap-1 bg-amber-100 text-[10px] text-amber-800 hover:bg-amber-100"><Crown className="h-3 w-3" /> Trưởng nhóm</Badge>}
                    {m.memberRole === 'mod' && <Badge className="gap-1 bg-sky-100 text-[10px] text-sky-800 hover:bg-sky-100"><Shield className="h-3 w-3" /> Phó nhóm</Badge>}
                    {iAmAdmin && m.id !== me.id && (
                      <>
                        <Button size="sm" variant="outline" className="h-7 px-2 text-[10px]" disabled={busy === m.id}
                          onClick={() => setRole(m.id, m.memberRole === 'mod' ? 'member' : 'mod')}>
                          {m.memberRole === 'mod' ? 'Gỡ phó nhóm' : 'Bổ nhiệm phó'}
                        </Button>
                        <Button size="sm" variant="outline" className="h-7 gap-1 border-amber-300 px-2 text-[10px] text-amber-700 hover:bg-amber-50" disabled={busy === m.id}
                          onClick={() => transferOwner(m)}>
                          {busy === m.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <CrownIcon className="h-3 w-3" />} Chuyển quyền
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Tin ghim */}
          <div>
            <p className="mb-2 text-xs font-semibold text-muted-foreground">TIN GHIM ({pinned.length})</p>
            {pinned.length === 0 ? (
              <p className="rounded-lg bg-muted/50 p-3 text-xs text-muted-foreground">Chưa ghim tin nhắn nào, di chuột lên tin rồi bấm Ghim</p>
            ) : (
              <div className="space-y-1.5">
                {pinned.map((m) => (
                  <div key={m.id} className="flex items-center gap-2 rounded-lg bg-amber-50 p-2 text-xs">
                    <Pin className="h-3 w-3 shrink-0 text-amber-600" />
                    <span className="min-w-0 flex-1 truncate"><b>{m.sender.fullName}:</b> {m.type === 'file' ? (m.fileName || m.content) : m.content}</span>
                    <button className="shrink-0 text-muted-foreground hover:text-red-600" onClick={() => onUnpin(m)} aria-label="Bỏ ghim tin nhắn"><X className="h-3.5 w-3.5" /></button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Rời nhóm — kiểu TTO inbox (Quyền: Rời nhóm; trưởng nhóm chuyển quyền ở danh sách trên) */}
          <div className="border-t pt-3">
            {iAmAdmin ? (
              <Button variant="outline" disabled className="w-full gap-2 border-red-200 text-red-400" aria-label="Chuyển quyền trưởng nhóm để rời nhóm">
                <LogOut className="h-4 w-4" /> Rời nhóm, chuyển quyền ở danh sách trên trước
              </Button>
            ) : (
              <Button variant="outline" disabled={busy === 'leave'} onClick={leaveGroup} className="w-full gap-2 border-red-200 text-red-600 hover:bg-red-50" aria-label="Rời nhóm">
                {busy === 'leave' ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogOut className="h-4 w-4" />} Rời nhóm
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
      <EditTopicDialog
        conversationId={conv.id}
        topic={editTopic}
        onDone={() => { loadTopics(); onChanged() }}
        onClose={() => setEditTopic(null)}
      />
    </Dialog>
  )
}

// ============ SỬA CHỦ ĐỀ (đổi tên và biểu tượng) — trưởng/phó nhóm ============
function EditTopicDialog({ conversationId, topic, onDone, onClose }: {
  conversationId: string
  topic: { id: string; name: string; icon: string } | null
  onDone: () => void
  onClose: () => void
}) {
  const [name, setName] = useState('')
  const [icon, setIcon] = useState('chat')
  const [saving, setSaving] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    if (topic) {
      setName(topic.name)
      setIcon(TOPIC_ICON_ITEMS.some((t) => t.key === topic.icon) ? topic.icon : 'chat')
    }
  }, [topic])

  if (!topic) return null

  const save = async () => {
    if (!name.trim()) { toast({ title: 'Nhập tên chủ đề', variant: 'destructive' }); return }
    setSaving(true)
    try {
      const res = await fetch(`/api/vx/conversations/${conversationId}/topics/${topic.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), icon }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không sửa được chủ đề')
      toast({ title: `Đã đổi chủ đề thành "${name.trim()}"` })
      onDone(); onClose()
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không sửa được chủ đề', variant: 'destructive' })
    } finally { setSaving(false) }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><ListTree className="h-5 w-5 text-sky-600" /> Sửa chủ đề</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="et-name">Tên chủ đề</Label>
            <Input id="et-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Thiết kế, Báo giá, Vận chuyển..." onKeyDown={(e) => e.key === 'Enter' && save()} />
          </div>
          <div className="space-y-2">
            <Label>Biểu tượng</Label>
            <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Chọn biểu tượng chủ đề">
              {TOPIC_ICON_ITEMS.map((t) => (
                <button key={t.key} onClick={() => setIcon(t.key)} aria-label={`Biểu tượng chủ đề ${t.label}`}
                  className={`flex h-9 w-9 items-center justify-center rounded-lg border transition-colors ${icon === t.key ? 'border-emerald-600 bg-emerald-100' : 'border-stone-200 hover:bg-stone-100'}`}>
                  <TopicStamp icon={t.key} size={26} />
                </button>
              ))}
            </div>
          </div>
          <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={save} disabled={saving || !name.trim()}>
            {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Pencil className="mr-1 h-4 w-4" />} Lưu thay đổi
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// Cuộc gọi & họp nhóm đã chuyển sang CallLayer.tsx (WebRTC thật) + MeetingRoom.tsx (họp nhóm kiểu Zoom),
// được mount toàn cục trong VexonApp — modal cũ chỉ mô phỏng nên đã bỏ.
