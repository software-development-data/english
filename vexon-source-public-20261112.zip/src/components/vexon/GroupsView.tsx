'use client'

// ============ NHÓM KIỂU FACEBOOK ============
// Nhóm của tôi / Khám phá, tạo nhóm, chi tiết nhóm với bảng tin riêng,
// thành viên, mời bạn, riêng tư/công khai — đăng bài trong nhóm có thưởng vào ví.

import { useCallback, useRef, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { compressImage } from '@/lib/image-compress'
import type { VxUserInfo } from './AuthView'
import { Avatar, timeAgo, GradMedia, GROUP_ICON_ITEMS, groupIconOf } from './shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { useUsdRate } from '@/lib/use-usd-rate'
import { fmtUsdFromXu } from '@/lib/format'
import {
  Users, Plus, Globe, Lock, ArrowLeft, Loader2, Trash2, UserPlus, Send, ImagePlus, Search, Heart, MessageCircle, Camera, X,
} from 'lucide-react'

interface GroupT {
  id: string; name: string; avatar: string; avatarImage?: string | null; description: string | null; privacy: string
  creator: { id: string; fullName: string; avatarColor: string }
  memberCount: number; postCount?: number; myRole: string | null; joined: boolean
  members: { id: string; fullName: string; avatarColor: string; avatarImage?: string | null; memberRole?: string }[]
}
interface GroupDetailT extends GroupT { locked?: boolean; posts: GroupPostT[] }
interface GroupPostT {
  id: string; author: { id: string; fullName: string; avatarColor: string; avatarImage?: string | null }
  content: string; images: string[]; createdAt: string
  likes: { userId: string; type: string }[]
  comments: { id: string; content: string; user: { fullName: string; avatarColor: string }; createdAt: string }[]
}

// Biểu tượng nhóm là hình vector (key đồng bộ GROUP_ICON_ITEMS dùng chung) — không dùng kí tự emoji

// Ảnh đại diện nhóm: ưu tiên ảnh tự tải lên (kiểu Facebook), không thì hình vector
function GroupAvatar({ g, size = 56 }: { g: { name: string; avatar?: string | null; avatarImage?: string | null }; size?: number }) {
  if (g.avatarImage) {
    return <img src={g.avatarImage} alt={g.name} style={{ width: size, height: size }} className="shrink-0 rounded-xl border-4 border-white object-cover shadow" />
  }
  const Ic = groupIconOf(g.avatar)
  return (
    <span style={{ width: size, height: size }} className="flex shrink-0 items-center justify-center rounded-xl border-4 border-white bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow">
      {Ic ? <Ic style={{ width: size * 0.45, height: size * 0.45 }} strokeWidth={2.2} /> : <Users style={{ width: size * 0.45, height: size * 0.45 }} strokeWidth={2.2} />}
    </span>
  )
}

export default function GroupsView({ me, onRefreshUser }: { me: VxUserInfo; onRefreshUser: () => void }) {
  const rate = useUsdRate() // tỷ giá sống — thưởng đăng bài nhóm quy USD
  const [tab, setTab] = useState<'mine' | 'discover'>('mine')
  const [groups, setGroups] = useState<GroupT[]>([])
  const [loading, setLoading] = useState(true)
  const [activeId, setActiveId] = useState<string | null>(null)
  const [detail, setDetail] = useState<GroupDetailT | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [createOpen, setCreateOpen] = useState(false)
  const [q, setQ] = useState('')

  const load = useCallback((t: 'mine' | 'discover') => {
    setLoading(true)
    fetch(`/api/vx/groups?tab=${t}`)
      .then((r) => r.json())
      .then((d) => Array.isArray(d) && setGroups(d))
      .catch(() => toast.error('Không tải được nhóm'))
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(() => load(tab), [tab, load])

  const openDetail = useCallback((id: string) => {
    setActiveId(id)
    setDetailLoading(true)
    setDetail(null)
    fetch(`/api/vx/groups/${id}`)
      .then((r) => r.json())
      .then((d) => { if (d?.id) setDetail(d); else toast.error(d?.error || 'Không mở được nhóm') })
      .catch(() => toast.error('Không mở được nhóm'))
      .finally(() => setDetailLoading(false))
  }, [])

  const patchGroup = async (id: string, payload: Record<string, unknown>, okMsg?: string) => {
    const res = await fetch(`/api/vx/groups/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    const d = await res.json()
    if (!res.ok) { toast.error(d.error || 'Thao tác thất bại'); return false }
    if (okMsg) toast.success(okMsg)
    return true
  }

  // ---- Chi tiết nhóm ----
  if (activeId) {
    return (
      <GroupDetail
        groupId={activeId} me={me} detail={detail} loading={detailLoading}
        onBack={() => { setActiveId(null); setDetail(null); load(tab) }}
        onAction={async (payload, msg) => {
          const ok = await patchGroup(activeId, payload, msg)
          if (ok) openDetail(activeId)
        }}
        onDelete={async () => {
          const res = await fetch(`/api/vx/groups/${activeId}`, { method: 'DELETE' })
          if (!res.ok) { toast.error('Chỉ chủ nhóm được xóa'); return }
          toast.success('Đã xóa nhóm')
          setActiveId(null); setDetail(null); load(tab)
        }}
        onPosted={(p) => {
          setDetail((d) => (d ? { ...d, posts: [p, ...d.posts], postCount: (d.postCount || 0) + 1 } : d))
          if (p.reward > 0) { toast.success(`Đăng bài +${fmtUsdFromXu(p.reward, rate)} vào ví!`); onRefreshUser() }
        }}
        onRefreshDetail={() => openDetail(activeId)}
      />
    )
  }

  // ---- Danh sách nhóm ----
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-xl font-black text-stone-800"><Users className="h-5 w-5 text-emerald-600" /> Nhóm</h1>
          <p className="text-sm text-muted-foreground">Cộng đồng theo sở thích, phòng ban, dự án, kiểu Facebook</p>
        </div>
        <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => setCreateOpen(true)}><Plus className="mr-1 h-4 w-4" /> Tạo nhóm</Button>
      </div>

      <div className="flex items-center gap-2">
        <div className="flex rounded-lg border bg-white p-1">
          {(['mine', 'discover'] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)}
              className={`rounded-md px-3.5 py-1.5 text-sm font-medium transition-colors ${tab === t ? 'bg-emerald-600 text-white shadow' : 'text-stone-600 hover:bg-emerald-50'}`}>
              {t === 'mine' ? 'Nhóm của tôi' : 'Khám phá'}
            </button>
          ))}
        </div>
        <div className="relative flex-1 max-w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-stone-400" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm nhóm..." className="pl-8" aria-label="Tìm nhóm" />
        </div>
      </div>

      {loading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-44 rounded-xl" />)}
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {groups.filter((g) => g.name.toLowerCase().includes(q.toLowerCase())).map((g) => (
            <button key={g.id} onClick={() => openDetail(g.id)}
              className="group overflow-hidden rounded-xl border bg-white text-left shadow-sm transition-shadow hover:shadow-md">
              <div className="flex h-16 items-end bg-gradient-to-br from-emerald-500 to-teal-600 px-3 pb-1">
                <span className="translate-y-4"><GroupAvatar g={g} size={56} /></span>
              </div>
              <div className="p-3 pt-6">
                <p className="flex items-center gap-1.5 font-bold text-stone-800">
                  {g.name}
                  {g.privacy === 'private' && <Lock className="h-3.5 w-3.5 text-stone-400" />}
                </p>
                <p className="mt-0.5 line-clamp-2 min-h-8 text-xs text-muted-foreground">{g.description || 'Nhóm chưa có mô tả'}</p>
                <div className="mt-2 flex items-center justify-between text-xs text-stone-500">
                  <span>{g.memberCount} thành viên, {g.postCount ?? 0} bài</span>
                  {g.joined ? <Badge className="border-0 bg-emerald-100 text-emerald-700">Đã tham gia</Badge> : <Badge variant="outline">Công khai</Badge>}
                </div>
              </div>
            </button>
          ))}
          {groups.length === 0 && (
            <div className="col-span-full rounded-xl border border-dashed bg-white p-10 text-center">
              <Users className="mx-auto h-10 w-10 text-stone-300" />
              <p className="mt-2 text-sm text-muted-foreground">{tab === 'mine' ? 'Bạn chưa tham gia nhóm nào, khám phá hoặc tạo nhóm đầu tiên!' : 'Chưa có nhóm công khai nào'}</p>
              <Button size="sm" className="mt-3 bg-emerald-600 hover:bg-emerald-700" onClick={() => setCreateOpen(true)}><Plus className="mr-1 h-4 w-4" /> Tạo nhóm</Button>
            </div>
          )}
        </div>
      )}

      <CreateGroupDialog open={createOpen} onOpenChange={setCreateOpen}
        onCreated={(id) => { setCreateOpen(false); load(tab); openDetail(id) }} />
    </div>
  )
}

// ============ CHI TIẾT NHÓM ============
function GroupDetail({ groupId, me, detail, loading, onBack, onAction, onDelete, onPosted, onRefreshDetail }: {
  groupId: string; me: VxUserInfo; detail: GroupDetailT | null; loading: boolean
  onBack: () => void; onAction: (payload: Record<string, unknown>, okMsg?: string) => Promise<void>
  onDelete: () => Promise<void>; onPosted: (p: GroupPostT & { reward: number }) => void; onRefreshDetail: () => void
}) {
  const [content, setContent] = useState('')
  const [images, setImages] = useState<string[]>([])
  const [posting, setPosting] = useState(false)
  const [inviteOpen, setInviteOpen] = useState(false)
  const [avatarBusy, setAvatarBusy] = useState(false)
  const avatarInputRef = useRef<HTMLInputElement>(null)

  // Đổi ảnh nhóm kiểu Facebook: chọn ảnh → nén → PATCH avatarImage
  const uploadGroupAvatar = async (file: File | undefined) => {
    if (!file || !groupId) return
    if (file.size > 6_000_000) { toast.error('Ảnh quá lớn (tối đa ~6MB trước khi nén)'); return }
    setAvatarBusy(true)
    try {
      const url = await compressImage(file, 512)
      const res = await fetch(`/api/vx/groups/${groupId}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ avatarImage: url }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không lưu được ảnh nhóm')
      toast.success('Đã đổi ảnh nhóm')
      onRefreshDetail()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không tải được ảnh')
    } finally { setAvatarBusy(false) }
  }

  const submitPost = async () => {
    if (!content.trim() && images.length === 0) return
    setPosting(true)
    try {
      const res = await fetch(`/api/vx/groups/${groupId}/posts`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: content.trim(), images }) })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      onPosted(d)
      setContent(''); setImages([])
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không đăng được')
    } finally { setPosting(false) }
  }

  const pickImage = (file?: File) => {
    if (!file || file.size > 1_500_000) { toast.error('Ảnh tối đa ~1.5MB'); return }
    const reader = new FileReader()
    reader.onload = () => setImages((xs) => [...xs, String(reader.result)].slice(0, 4))
    reader.readAsDataURL(file)
  }

  const like = async (postId: string) => {
    await fetch(`/api/vx/posts/${postId}/like`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'like' }) }).catch(() => {})
    // Cập nhật nhẹ: cha refetch lại chi tiết nhóm (đơn giản, ít code)
    onRefreshDetail()
  }

  if (loading || !detail) {
    return (
      <div className="space-y-3">
        <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="mr-1 h-4 w-4" /> Nhóm</Button>
        <Skeleton className="h-40 rounded-xl" />
        <Skeleton className="h-24 rounded-xl" />
        <Skeleton className="h-64 rounded-xl" />
      </div>
    )
  }

  const isOwner = detail.myRole === 'owner' || me.role === 'admin'

  return (
    <div className="space-y-4">
      <Button variant="ghost" size="sm" onClick={onBack} aria-label="Về danh sách nhóm"><ArrowLeft className="mr-1 h-4 w-4" /> Tất cả nhóm</Button>

      {/* Bìa nhóm */}
      <div className="overflow-hidden rounded-xl border bg-white shadow-sm">
        <div className="flex h-32 items-end bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-600 px-5 pb-2">
          <span className="relative translate-y-6">
            <GroupAvatar g={detail} size={64} />
            {isOwner && (
              <>
                <button
                  onClick={() => avatarInputRef.current?.click()}
                  title="Đổi ảnh nhóm (kiểu Facebook)"
                  className="absolute -bottom-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full bg-emerald-600 text-white shadow hover:bg-emerald-700"
                  aria-label="Đổi ảnh nhóm"
                >
                  {avatarBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
                </button>
                <input ref={avatarInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => { uploadGroupAvatar(e.target.files?.[0]); e.target.value = '' }} />
              </>
            )}
          </span>
        </div>
        <div className="flex flex-wrap items-end justify-between gap-3 p-4 pt-9">
          <div>
            <h1 className="flex items-center gap-2 text-lg font-black text-stone-800">
              {detail.name}
              {detail.privacy === 'private' ? <Lock className="h-4 w-4 text-stone-400" /> : <Globe className="h-4 w-4 text-stone-400" />}
            </h1>
            <p className="text-sm text-muted-foreground">{detail.memberCount} thành viên, {detail.postCount || detail.posts.length} bài đăng{detail.creator ? `, tạo bởi ${detail.creator.fullName}` : ''}</p>
            {detail.description && <p className="mt-1 max-w-2xl text-sm">{detail.description}</p>}
          </div>
          <div className="flex gap-2">
            {detail.joined ? (
              detail.myRole !== 'owner' && (
                <Button variant="outline" size="sm" onClick={() => onAction({ action: 'leave' }, 'Đã rời nhóm')}>Rời nhóm</Button>
              )
            ) : (
              <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" disabled={detail.locked}
                onClick={() => onAction({ action: 'join' }, 'Đã tham gia nhóm')}>{detail.locked ? 'Riêng tư' : '+ Tham gia'}</Button>
            )}
            {detail.joined && <Button variant="outline" size="sm" onClick={() => setInviteOpen(true)}><UserPlus className="mr-1 h-4 w-4" /> Mời</Button>}
            {isOwner && (
              <Button variant="outline" size="sm" className="text-rose-600" onClick={onDelete} aria-label="Xóa nhóm"><Trash2 className="h-4 w-4" /></Button>
            )}
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
        {/* Bảng tin nhóm */}
        <div className="space-y-3">
          {detail.joined && (
            <div className="rounded-xl border bg-white p-3 shadow-sm">
              <Textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder={`Đăng gì đó cho nhóm ${detail.name}... (đăng bài có thưởng vào ví)`} rows={2} aria-label="Soạn bài đăng nhóm" />
              {images.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-2">
                  {images.map((src, i) => (
                    <div key={i} className="relative">
                      <img src={src} alt={`Ảnh ${i + 1}`} className="h-16 w-16 rounded-lg object-cover" />
                      <button onClick={() => setImages((xs) => xs.filter((_, j) => j !== i))} className="absolute -right-1.5 -top-1.5 rounded-full bg-rose-600 p-0.5 text-white" aria-label="Xóa ảnh"><X className="h-3 w-3" /></button>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-2 flex items-center justify-between">
                <label className="flex cursor-pointer items-center gap-1.5 text-sm text-stone-600 hover:text-emerald-700">
                  <ImagePlus className="h-4 w-4" /> Ảnh
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => pickImage(e.target.files?.[0])} />
                </label>
                <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={submitPost} disabled={posting || (!content.trim() && images.length === 0)}>
                  {posting ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Send className="mr-1 h-4 w-4" />} Đăng
                </Button>
              </div>
            </div>
          )}

          {detail.locked && (
            <p className="rounded-xl border border-dashed bg-white p-8 text-center text-sm text-muted-foreground">Nhóm riêng tư, tham gia để xem bài đăng và thành viên.</p>
          )}

          {detail.posts.map((p0) => {
            // Phòng thủ: likes/images/comments có thể thiếu trong dữ liệu cũ
            const p = { ...p0, likes: p0.likes || [], images: p0.images || [], comments: p0.comments || [] }
            const liked = p.likes.some((l) => l.userId === me.id)
            return (
              <article key={p.id} className="rounded-xl border bg-white p-4 shadow-sm">
                <div className="flex items-center gap-2.5">
                  <Avatar name={p.author.fullName} color={p.author.avatarColor} size={38} img={p.author.avatarImage} />
                  <div>
                    <p className="text-sm font-semibold">{p.author.fullName}</p>
                    <p className="text-[11px] text-stone-400">{timeAgo(p.createdAt)}</p>
                  </div>
                </div>
                <p className="mt-2 whitespace-pre-wrap text-sm">{p.content}</p>
                {p.images.length > 0 && (
                  <div className="mt-2 grid gap-1" style={{ gridTemplateColumns: `repeat(${Math.min(2, p.images.length)}, 1fr)` }}>
                    {p.images.map((src, i) => <GradMedia key={i} value={src} className="max-h-80 w-full rounded-lg bg-stone-100 object-contain" />)}
                  </div>
                )}
                <div className="mt-3 flex items-center gap-4 border-t pt-2.5 text-sm text-stone-500">
                  <button onClick={() => like(p.id)} className={`flex items-center gap-1.5 hover:text-rose-600 ${liked ? 'font-semibold text-rose-600' : ''}`} aria-label="Thích bài">
                    <Heart className={`h-4 w-4 ${liked ? 'fill-current' : ''}`} /> {p.likes.length}
                  </button>
                  <span className="flex items-center gap-1.5"><MessageCircle className="h-4 w-4" /> {p.comments.length} bình luận</span>
                </div>
                {p.comments.length > 0 && (
                  <div className="mt-2 space-y-1.5 rounded-lg bg-stone-50 p-2.5">
                    {p.comments.slice(-4).map((c) => (
                      <p key={c.id} className="text-xs"><b className="text-stone-700">{c.user?.fullName || 'Thành viên'}:</b> <span className="text-stone-600">{c.content}</span></p>
                    ))}
                  </div>
                )}
              </article>
            )
          })}
          {!detail.locked && detail.posts.length === 0 && (
            <p className="rounded-xl border border-dashed bg-white p-10 text-center text-sm text-muted-foreground">Nhóm chưa có bài đăng, hãy là người đầu tiên!</p>
          )}
        </div>

        {/* Thành viên */}
        <aside className="h-fit space-y-2 rounded-xl border bg-white p-4 shadow-sm">
          <p className="text-sm font-bold">Thành viên ({detail.memberCount})</p>
          <div className="max-h-96 space-y-1.5 overflow-y-auto">
            {detail.members.map((m) => (
              <div key={m.id} className="flex items-center gap-2.5">
                <Avatar name={m.fullName} color={m.avatarColor} size={30} img={m.avatarImage} />
                <div className="min-w-0">
                  <p className="truncate text-xs font-medium">{m.fullName}</p>
                  <p className="text-[10px] text-stone-400">{m.memberRole === 'owner' ? 'Chủ nhóm' : m.memberRole === 'admin' ? 'Quản trị viên' : 'Thành viên'}</p>
                </div>
              </div>
            ))}
          </div>
        </aside>
      </div>

      {/* Mời thành viên */}
      <InviteDialog groupId={groupId} open={inviteOpen} onOpenChange={setInviteOpen}
        onInvited={() => { toast.success('Đã mời thành viên'); onRefreshDetail() }} />
    </div>
  )
}

// ============ DIALOG TẠO NHÓM ============
function CreateGroupDialog({ open, onOpenChange, onCreated }: { open: boolean; onOpenChange: (v: boolean) => void; onCreated: (id: string) => void }) {
  const [name, setName] = useState('')
  const [avatar, setAvatar] = useState('members')
  const [avatarImg, setAvatarImg] = useState<string | null>(null)
  const [description, setDescription] = useState('')
  const [privacy, setPrivacy] = useState<'public' | 'private'>('public')
  const [saving, setSaving] = useState(false)
  const avatarInputRef = useRef<HTMLInputElement>(null)

  const pickAvatar = async (file: File | undefined) => {
    if (!file) return
    if (file.size > 6_000_000) { toast.error('Ảnh quá lớn (tối đa ~6MB trước khi nén)'); return }
    try { setAvatarImg(await compressImage(file, 512)) } catch { toast.error('Không tải được ảnh') }
  }

  const create = async () => {
    if (!name.trim()) { toast.error('Nhập tên nhóm'); return }
    setSaving(true)
    try {
      const res = await fetch('/api/vx/groups', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: name.trim(), avatar, description: description.trim() || undefined, privacy }) })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      // Có ảnh nhóm → lưu luôn ảnh sau khi tạo
      if (avatarImg && d.id) {
        await fetch(`/api/vx/groups/${d.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ avatarImage: avatarImg }) }).catch(() => {})
      }
      toast.success(`Đã tạo nhóm "${name.trim()}"`)
      setName(''); setDescription(''); setAvatar('members'); setAvatarImg(null); setPrivacy('public')
      onCreated(d.id)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không tạo được')
    } finally { setSaving(false) }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
        <DialogHeader><DialogTitle className="flex items-center gap-2"><Users className="h-4 w-4 text-emerald-600" /> Tạo nhóm mới</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="relative">
              {avatarImg ? (
                <img src={avatarImg} alt="" className="h-14 w-14 rounded-xl border object-cover" />
              ) : (
                (() => {
                  const Ic = groupIconOf(avatar)
                  return (
                    <span className="flex h-14 w-14 items-center justify-center rounded-xl border bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                      {Ic ? <Ic className="h-6 w-6" /> : <Users className="h-6 w-6" />}
                    </span>
                  )
                })()
              )}
              <button onClick={() => avatarInputRef.current?.click()} title="Đặt ảnh nhóm (kiểu Facebook)"
                className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-white shadow hover:bg-emerald-700" aria-label="Chọn ảnh nhóm">
                <Camera className="h-3.5 w-3.5" />
              </button>
              <input ref={avatarInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => { pickAvatar(e.target.files?.[0]); e.target.value = '' }} />
            </div>
            <div className="flex-1 space-y-1.5">
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Tên nhóm (bắt buộc)" aria-label="Tên nhóm" />
              <div className="flex flex-wrap gap-1">
                {GROUP_ICON_ITEMS.map((g) => {
                  const Ic = g.Icon
                  return (
                    <button key={g.key} onClick={() => { setAvatar(g.key); setAvatarImg(null) }} aria-label={`Biểu tượng ${g.label}`}
                      className={`flex h-7 w-7 items-center justify-center rounded-lg border text-stone-600 ${!avatarImg && avatar === g.key ? 'border-emerald-600 bg-emerald-100 text-emerald-700' : 'border-stone-200 hover:bg-stone-100'}`}><Ic className="h-4 w-4" /></button>
                  )
                })}
              </div>
            </div>
          </div>
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Mô tả nhóm (nhóm này về điều gì?)" rows={2} aria-label="Mô tả nhóm" />
          <div className="grid grid-cols-2 gap-2">
            {([['public', 'Công khai', <Globe key="g" className="h-4 w-4" />, 'Ai cũng thấy & tham gia'], ['private', 'Riêng tư', <Lock key="l" className="h-4 w-4" />, 'Chỉ thành viên thấy']] as const).map(([k, label, icon, desc]) => (
              <button key={k} onClick={() => setPrivacy(k)} aria-label={`Nhóm ${label}`}
                className={`rounded-lg border p-2.5 text-left text-sm transition-colors ${privacy === k ? 'border-emerald-500 bg-emerald-50' : 'border-stone-200 hover:bg-stone-50'}`}>
                <p className="flex items-center gap-1.5 font-semibold">{icon} {label}</p>
                <p className="mt-0.5 text-[11px] text-muted-foreground">{desc}</p>
              </button>
            ))}
          </div>
          <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={create} disabled={saving}>
            {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Plus className="mr-1 h-4 w-4" />} Tạo nhóm
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ============ DIALOG MỜI THÀNH VIÊN ============
function InviteDialog({ groupId, open, onOpenChange, onInvited }: { groupId: string; open: boolean; onOpenChange: (v: boolean) => void; onInvited: () => void }) {
  const [users, setUsers] = useState<{ id: string; fullName: string; avatarColor: string; online?: boolean }[]>([])
  const [selected, setSelected] = useState<string[]>([])
  const [busy, setBusy] = useState(false)

  useDeferredLoad(() => {
    if (!open) return
    fetch('/api/vx/users').then((r) => r.json()).then((d) => Array.isArray(d) && setUsers(d.slice(0, 50))).catch(() => {})
  }, [open])

  const invite = async () => {
    if (selected.length === 0) { toast.error('Chọn người để mời'); return }
    setBusy(true)
    try {
      const res = await fetch(`/api/vx/groups/${groupId}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'invite', userIds: selected }) })
      if (!res.ok) throw new Error((await res.json()).error)
      onInvited(); onOpenChange(false); setSelected([])
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không mời được')
    } finally { setBusy(false) }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm" aria-describedby={undefined}>
        <DialogHeader><DialogTitle>Mời vào nhóm</DialogTitle></DialogHeader>
        <div className="max-h-80 space-y-1 overflow-y-auto rounded-lg border p-2">
          {users.map((u) => (
            <label key={u.id} className="flex cursor-pointer items-center gap-3 rounded-lg p-2 hover:bg-muted/60">
              <input type="checkbox" className="accent-emerald-600" checked={selected.includes(u.id)}
                onChange={(e) => setSelected((s) => (e.target.checked ? [...s, u.id] : s.filter((x) => x !== u.id)))} aria-label={`Chọn ${u.fullName}`} />
              <Avatar name={u.fullName} color={u.avatarColor} size={30} online={u.online} />
              <span className="text-sm">{u.fullName}</span>
            </label>
          ))}
        </div>
        <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={invite} disabled={busy}>
          {busy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <UserPlus className="mr-1 h-4 w-4" />} Mời {selected.length || ''} người
        </Button>
      </DialogContent>
    </Dialog>
  )
}
