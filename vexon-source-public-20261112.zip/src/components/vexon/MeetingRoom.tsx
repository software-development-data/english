'use client'

// ============ PHÒNG HỌP NHÓM KIỂU ZOOM (WebRTC mesh) ============
// - Lưới người tham gia (grid tự co theo số người), audio/video thật
// - Im mic, tắt/bật camera, chia sẻ màn hình, giơ tay phát biểu
// - Trò chuyện trong cuộc họp, danh sách người tham gia
// - Ghi âm/ghi hình cuộc họp (MediaRecorder + trộn audio mọi người) → tải file .webm
// - Signaling qua vexon-socket: meet:join/peers/signal/state/chat/leave/end

import { useEffect, useRef, useState } from 'react'
import type { VxUserInfo } from '@/components/vexon/AuthView'
import { Avatar } from '@/components/vexon/shared'
import { useToast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { getSocket } from '@/lib/vx-socket'
import type { MeetingSession } from '@/lib/vx-call-store'
import {
  openUserMedia, mediaErrorMessage, newPeerConnection, stopStream, fmtCallTime,
  mixAudioStreams, pickAudioMime,
} from '@/lib/vx-call'
import {
  Mic, MicOff, Video, VideoOff, ScreenShare, ScreenShareOff, Hand, MessageSquare,
  Users, X, PhoneOff, LogOut, Loader2,
} from 'lucide-react'

type SignalData =
  | { type: 'offer'; sdp: { type: string; sdp?: string } }
  | { type: 'answer'; sdp: { type: string; sdp?: string } }
  | { type: 'ice'; candidate: RTCIceCandidateInit | null }

type MeetPeerT = {
  socketId: string; userId: string; userName: string; avatarColor: string
  micOff: boolean; camOff: boolean; hand: boolean; sharing: boolean
}
type MeetChat = { userId: string; userName: string; content: string; at: number }

export default function MeetingRoom({ session, me, onDone }: {
  session: MeetingSession
  me: VxUserInfo
  onDone: (sec: number) => void
}) {
  const roomId = session.conversationId
  const [phase, setPhase] = useState<'preparing' | 'live' | 'error'>('preparing')
  const [errText, setErrText] = useState('')
  const [peers, setPeers] = useState<MeetPeerT[]>([])
  const [streams, setStreams] = useState<Map<string, MediaStream>>(new Map())
  const [speaking, setSpeaking] = useState<Set<string>>(new Set())
  const [micOff, setMicOff] = useState(false)
  const [camOff, setCamOff] = useState(false)
  const [handRaised, setHandRaised] = useState(false)
  const [sharing, setSharing] = useState(false)
  const [panel, setPanel] = useState<'chat' | 'people' | null>(null)
  const [chats, setChats] = useState<MeetChat[]>([])
  const [chatInput, setChatInput] = useState('')
  const [recording, setRecording] = useState(false)
  const [sec, setSec] = useState(0)
  const [count, setCount] = useState(1)
  const { toast } = useToast()

  const localRef = useRef<MediaStream | null>(null)
  const localVideoRef = useRef<HTMLVideoElement>(null)
  const pcMap = useRef<Map<string, RTCPeerConnection>>(new Map())
  const streamsMap = useRef<Map<string, MediaStream>>(new Map())
  const shareRef = useRef<MediaStream | null>(null)
  const recRef = useRef<MediaRecorder | null>(null)
  const recChunks = useRef<Blob[]>([])
  const secRef = useRef(0)
  const endedRef = useRef(false)
  const audioCtxRef = useRef<AudioContext | null>(null)
  const analysersRef = useRef<Map<string, AnalyserNode>>(new Map())
  const anDataRef = useRef<Map<string, Uint8Array>>(new Map())

  const emitState = (patch: { micOff?: boolean; camOff?: boolean; hand?: boolean; sharing?: boolean }) => {
    getSocket().emit('meet:state', { roomId, patch })
  }

  const cleanupAll = () => {
    if (endedRef.current) return
    endedRef.current = true
    const s = getSocket()
    ;['meet:peers', 'meet:peer-joined', 'meet:signal', 'meet:state', 'meet:peer-left', 'meet:chat', 'meet:count', 'meet:end'].forEach((ev) => s.off(ev))
    pcMap.current.forEach((pc) => pc.close())
    pcMap.current.clear()
    streamsMap.current.forEach((st) => stopStream(st))
    streamsMap.current.clear()
    stopStream(shareRef.current)
    stopStream(localRef.current)
    localRef.current = null
    recRef.current?.state === 'recording' && recRef.current.stop()
    audioCtxRef.current?.close().catch(() => {})
    audioCtxRef.current = null
    if (speakIvRef.current) clearInterval(speakIvRef.current)
    speakIvRef.current = null
  }

  const leave = (sec: number, endAll?: boolean) => {
    const s = getSocket()
    if (endAll) s.emit('meet:end', { roomId })
    else s.emit('meet:leave', { roomId })
    cleanupAll()
    onDone(sec)
  }

  // ===== WebRTC mesh: người vào sau tạo offer cho người có sẵn =====
  const createPc = async (socketId: string, initiator: boolean, remoteOffer?: SignalData) => {
    if (!localRef.current || pcMap.current.has(socketId)) return
    const s = getSocket()
    const pc = newPeerConnection()
    pcMap.current.set(socketId, pc)
    for (const t of localRef.current.getTracks()) pc.addTrack(t, localRef.current)
    pc.onicecandidate = (ev) => {
      if (ev.candidate) s.emit('meet:signal', { roomId, toSocket: socketId, data: { type: 'ice', candidate: ev.candidate.toJSON() } })
    }
    pc.ontrack = (ev) => {
      const st = ev.streams[0]
      if (!st) return
      streamsMap.current.set(socketId, st)
      setStreams(new Map(streamsMap.current))
    }
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'failed') {
        pcMap.current.get(socketId)?.close()
        pcMap.current.delete(socketId)
      }
    }
    try {
      if (initiator) {
        const offer = await pc.createOffer()
        await pc.setLocalDescription(offer)
        s.emit('meet:signal', { roomId, toSocket: socketId, data: { type: 'offer', sdp: { type: pc.localDescription!.type, sdp: pc.localDescription!.sdp || undefined } } })
      } else if (remoteOffer && remoteOffer.type === 'offer') {
        await pc.setRemoteDescription(new RTCSessionDescription(remoteOffer.sdp as RTCSessionDescriptionInit))
        const answer = await pc.createAnswer()
        await pc.setLocalDescription(answer)
        s.emit('meet:signal', { roomId, toSocket: socketId, data: { type: 'answer', sdp: { type: pc.localDescription!.type, sdp: pc.localDescription!.sdp || undefined } } })
      }
    } catch {
      // tín hiệu lỗi: để ICE tự thử lại
    }
  }

  const applySignal = async (socketId: string, data: SignalData) => {
    const pc = pcMap.current.get(socketId)
    if (!pc || !data) return
    try {
      if (data.type === 'answer') {
        if (pc.signalingState !== 'stable') await pc.setRemoteDescription(new RTCSessionDescription(data.sdp as RTCSessionDescriptionInit))
      } else if (data.type === 'ice' && data.candidate) {
        await pc.addIceCandidate(new RTCIceCandidate(data.candidate))
      }
    } catch {
      // bỏ qua ICE trễ
    }
  }

  // ===== Vào phòng =====
  useEffect(() => {
    const s = getSocket()
    let cancelled = false

    ;(async () => {
      try {
        let stream: MediaStream
        try {
          stream = await openUserMedia('meeting')
        } catch {
          // máy không có camera → vẫn họp bằng micro
          stream = await openUserMedia('voice')
          toast({ title: 'Không dùng được camera, cuộc họp chỉ có âm thanh' })
        }
        if (cancelled) {
          stopStream(stream)
          return
        }
        localRef.current = stream
        const lv = localVideoRef.current
        if (lv) lv.srcObject = stream
        setPhase('live')

        const onPeers = (list: Array<{ socketId: string; userId: string; userName: string; avatarColor: string; micOff: boolean; camOff: boolean; hand: boolean; sharing: boolean }>) => {
          setPeers((old) => {
            const known = new Set(old.map((p) => p.socketId))
            const news = list.filter((p) => !known.has(p.socketId))
            news.forEach((p) => createPc(p.socketId, true))
            return [...old, ...news.map((p) => ({ ...p }))]
          })
        }
        const onPeerJoined = (p: { socketId: string; userId: string; userName: string; avatarColor: string }) => {
          setPeers((old) => (old.some((o) => o.socketId === p.socketId) ? old : [...old, { ...p, micOff: false, camOff: false, hand: false, sharing: false }]))
        }
        const onSignal = (p: { from: string; roomId: string; data: SignalData }) => {
          if (p.roomId !== roomId) return
          if (p.data?.type === 'offer') createPc(p.from, false, p.data)
          else applySignal(p.from, p.data)
        }
        const onState = (p: { socketId: string; roomId: string; patch: Partial<Pick<MeetPeerT, 'micOff' | 'camOff' | 'hand' | 'sharing'>> }) => {
          if (p.roomId !== roomId) return
          setPeers((old) => old.map((o) => (o.socketId === p.socketId ? { ...o, ...p.patch } : o)))
        }
        const onPeerLeft = (p: { socketId: string; roomId: string }) => {
          if (p.roomId !== roomId) return
          pcMap.current.get(p.socketId)?.close()
          pcMap.current.delete(p.socketId)
          const st = streamsMap.current.get(p.socketId)
          if (st) {
            stopStream(st)
            streamsMap.current.delete(p.socketId)
            setStreams(new Map(streamsMap.current))
          }
          setPeers((old) => old.filter((o) => o.socketId !== p.socketId))
        }
        const onChat = (p: { roomId: string; chat: MeetChat }) => {
          if (p.roomId !== roomId || !p.chat) return
          setChats((old) => [...old, p.chat])
        }
        const onCount = (p: { roomId: string; count: number }) => {
          if (p.roomId === roomId) setCount(Math.max(1, p.count))
        }
        const onMeetEnd = () => {
          toast({ title: 'Trưởng nhóm đã kết thúc cuộc họp' })
          cleanupAll()
          onDone(secRef.current)
        }

        s.on('meet:peers', onPeers)
        s.on('meet:peer-joined', onPeerJoined)
        s.on('meet:signal', onSignal)
        s.on('meet:state', onState)
        s.on('meet:peer-left', onPeerLeft)
        s.on('meet:chat', onChat)
        s.on('meet:count', onCount)
        s.on('meet:end', onMeetEnd)

        s.emit('meet:join', { roomId, userId: me.id, userName: me.fullName, avatarColor: me.avatarColor })
      } catch (err) {
        if (!cancelled) {
          setErrText(mediaErrorMessage(err))
          setPhase('error')
        }
      }
    })()

    return () => {
      cancelled = true
      s.emit('meet:leave', { roomId })
      cleanupAll()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Đồng hồ họp
  useEffect(() => {
    if (phase !== 'live') return
    const iv = setInterval(() => {
      secRef.current += 1
      setSec(secRef.current)
    }, 1000)
    return () => clearInterval(iv)
  }, [phase])

  // ===== Đèn speaking: phân tích RMS từng luồng âm thanh =====
  const speakIvRef = useRef<ReturnType<typeof setInterval> | null>(null)
  useEffect(() => {
    if (phase !== 'live') return
    const ensureAnalyser = (key: string, stream: MediaStream) => {
      if (analysersRef.current.has(key)) return
      const track = stream.getAudioTracks()[0]
      if (!track) return
      try {
        if (!audioCtxRef.current) audioCtxRef.current = new AudioContext()
        const ctx = audioCtxRef.current
        if (ctx.state === 'suspended') ctx.resume().catch(() => {})
        const an = ctx.createAnalyser()
        an.fftSize = 512
        ctx.createMediaStreamSource(new MediaStream([track])).connect(an)
        analysersRef.current.set(key, an)
        anDataRef.current.set(key, new Uint8Array(an.fftSize))
      } catch {
        // stream đã đóng
      }
    }
    ensureAnalyser('me', localRef.current || new MediaStream())
    streamsMap.current.forEach((st, key) => ensureAnalyser(key, st))
    speakIvRef.current = setInterval(() => {
      const next = new Set<string>()
      analysersRef.current.forEach((an, key) => {
        const data = anDataRef.current.get(key)
        if (!data) return
        an.getByteTimeDomainData(data as Uint8Array<ArrayBuffer>)
        let sum = 0
        for (let i = 0; i < data.length; i++) {
          const v = (data[i] - 128) / 128
          sum += v * v
        }
        if (Math.sqrt(sum / data.length) > 0.08) next.add(key)
      })
      setSpeaking((old) => {
        if (old.size === next.size && [...next].every((k) => old.has(k))) return old
        return next
      })
    }, 400)
    return () => {
      if (speakIvRef.current) clearInterval(speakIvRef.current)
      speakIvRef.current = null
    }
  }, [phase, streams])

  // ===== Nút bấm =====
  const toggleMic = () => {
    const t = localRef.current?.getAudioTracks()[0]
    setMicOff((m) => {
      const next = !m
      if (t) t.enabled = !next
      emitState({ micOff: next })
      return next
    })
  }
  const toggleCam = () => {
    const t = localRef.current?.getVideoTracks()[0]
    setCamOff((c) => {
      const next = !c
      if (t) t.enabled = !next
      emitState({ camOff: next })
      return next
    })
  }
  const toggleHand = () => {
    setHandRaised((h) => {
      const next = !h
      emitState({ hand: next })
      toast({ title: next ? 'Bạn đã giơ tay phát biểu' : 'Bạn đã hạ tay' })
      return next
    })
  }

  // Chia sẻ màn hình: thay video track trên mọi peer connection
  const stopShare = async () => {
    if (!shareRef.current) return
    const screenTrack = shareRef.current.getVideoTracks()[0]
    stopStream(shareRef.current)
    shareRef.current = null
    const camTrack = localRef.current?.getVideoTracks()[0] || null
    for (const [, pc] of pcMap.current) {
      const sender = pc.getSenders().find((sd) => sd.track === screenTrack)
      if (sender) {
        try {
          await sender.replaceTrack(camTrack)
        } catch {
          // track đã đóng
        }
      }
    }
    setSharing(false)
    emitState({ sharing: false })
  }
  const toggleShare = async () => {
    if (sharing) {
      await stopShare()
      return
    }
    try {
      const display = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false })
      const track = display.getVideoTracks()[0]
      shareRef.current = display
      let replaced = false
      for (const [, pc] of pcMap.current) {
        const sender = pc.getSenders().find((sd) => sd.track?.kind === 'video')
        if (sender) {
          try {
            await sender.replaceTrack(track)
            replaced = true
          } catch {
            // bỏ qua
          }
        }
      }
      if (!replaced && pcMap.current.size > 0) {
        toast({ title: 'Không chia sẻ được màn hình ngay bây giờ', variant: 'destructive' })
        stopStream(display)
        shareRef.current = null
        return
      }
      setSharing(true)
      emitState({ sharing: true })
      track.onended = () => stopShare()
    } catch {
      toast({ title: 'Trình duyệt không cho chia sẻ màn hình (cần chọn nguồn chia sẻ)' })
    }
  }

  // Ghi âm/ghi hình cuộc họp: trộn audio của mọi người + camera của mình
  const toggleRecord = () => {
    if (recording) {
      recRef.current?.stop()
      recRef.current = null
      setRecording(false)
      return
    }
    const allStreams: MediaStream[] = [localRef.current || new MediaStream(), ...streamsMap.current.values()]
    const mixed = mixAudioStreams(allStreams)
    if (!mixed) {
      toast({ title: 'Trình duyệt không hỗ trợ trộn âm thanh để ghi', variant: 'destructive' })
      return
    }
    audioCtxRef.current = mixed.ctx
    const tracks: MediaStreamTrack[] = [...mixed.dest.stream.getAudioTracks()]
    const camTrack = localRef.current?.getVideoTracks()[0]
    if (camTrack && camTrack.enabled) tracks.push(camTrack)
    const hasVideo = tracks.some((t) => t.kind === 'video')
    const mime = hasVideo ? 'video/webm;codecs=vp8,opus' : pickAudioMime() || 'audio/webm'
    try {
      const rec = new MediaRecorder(new MediaStream(tracks), { mimeType: mime, audioBitsPerSecond: 48000, videoBitsPerSecond: 1_000_000 })
      recChunks.current = []
      rec.ondataavailable = (ev: BlobEvent) => {
        if (ev.data.size > 0) recChunks.current.push(ev.data)
      }
      rec.onstop = () => {
        const blob = new Blob(recChunks.current, { type: mime })
        if (blob.size > 0) {
          const url = URL.createObjectURL(blob)
          const a = document.createElement('a')
          a.href = url
          a.download = `vexon-hop-nhom-${new Date().toISOString().slice(0, 10)}.webm`
          a.click()
          setTimeout(() => URL.revokeObjectURL(url), 5000)
          toast({ title: 'Đã lưu bản ghi cuộc họp về máy' })
        }
        mixed.ctx.close().catch(() => {})
        if (audioCtxRef.current === mixed.ctx) audioCtxRef.current = null
      }
      rec.start(1000)
      recRef.current = rec
      setRecording(true)
      toast({ title: 'Bắt đầu ghi cuộc họp' })
    } catch {
      toast({ title: 'Không bắt đầu ghi được cuộc họp', variant: 'destructive' })
      mixed.ctx.close().catch(() => {})
    }
  }

  const sendChat = () => {
    const content = chatInput.trim()
    if (!content) return
    getSocket().emit('meet:chat', { roomId, chat: { userId: me.id, userName: me.fullName, content, at: Date.now() } })
    setChatInput('')
  }

  // ===== UI =====
  if (phase === 'preparing') {
    return (
      <div className="fixed inset-0 z-[80] flex flex-col items-center justify-center bg-stone-950 text-white" role="dialog" aria-label="Đang vào cuộc họp">
        <Loader2 className="h-9 w-9 animate-spin text-emerald-500" />
        <p className="mt-4 text-sm text-stone-300">Đang chuẩn bị micro/camera...</p>
        <Button variant="outline" className="mt-5 border-white/30 bg-transparent text-white hover:bg-white/10" onClick={() => leave(0)}>
          Huỷ
        </Button>
      </div>
    )
  }
  if (phase === 'error') {
    return (
      <div className="fixed inset-0 z-[80] flex flex-col items-center justify-center bg-stone-950 px-6 text-center text-white" role="dialog" aria-label="Lỗi cuộc họp">
        <MicOff className="h-10 w-10 text-red-400" />
        <p className="mt-4 max-w-sm text-sm text-stone-300">{errText}</p>
        <Button className="mt-5 bg-emerald-600 hover:bg-emerald-500" onClick={() => leave(0)}>Đóng</Button>
      </div>
    )
  }

  const total = peers.length + 1
  const gridCls = total <= 1 ? 'grid-cols-1 max-w-3xl' : total <= 4 ? 'grid-cols-2' : 'grid-cols-2 sm:grid-cols-3'

  return (
    <div className="fixed inset-0 z-[80] flex flex-col bg-stone-950 text-white" role="dialog" aria-label={`Cuộc họp nhóm: ${session.name}`}>
      {/* Thanh trên */}
      <div className="flex items-center gap-2 border-b border-white/10 px-3 py-2.5">
        <Users className="h-4 w-4 shrink-0 text-emerald-400" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">{session.name}</p>
          <p className="text-[10px] text-stone-400">Cuộc họp nhóm - {fmtCallTime(sec)} - {count} người tham gia</p>
        </div>
        {recording && (
          <span className="flex items-center gap-1.5 rounded-full bg-red-600/90 px-2.5 py-1 text-[10px] font-bold" aria-label="Đang ghi cuộc họp">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" /> GHI
          </span>
        )}
        {handRaised && <Hand className="h-4 w-4 text-amber-400" aria-label="Đang giơ tay" />}
      </div>

      {/* Lưới người tham gia */}
      <div className="relative flex-1 overflow-y-auto p-3">
        <div className={`grid gap-2 ${gridCls}`}>
          {/* Của tôi */}
          <div className={`relative overflow-hidden rounded-xl border bg-stone-800 ${speaking.has('me') ? 'border-emerald-400 ring-2 ring-emerald-400/50' : 'border-white/10'}`} style={{ aspectRatio: '4 / 3' }}>
            <video ref={localVideoRef} autoPlay playsInline muted className="h-full w-full object-cover" style={{ transform: 'scaleX(-1)' }} aria-label="Camera của tôi" />
            {camOff && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-stone-900">
                <Avatar name={me.fullName} color={me.avatarColor} size={56} />
                <span className="text-[10px] text-stone-400">Camera đang tắt</span>
              </div>
            )}
            <span className="absolute bottom-1.5 left-2 rounded bg-black/60 px-2 py-0.5 text-[10px] font-medium">Bạn{session.isHost ? ' (Trưởng nhóm)' : ''}</span>
            <span className="absolute bottom-1.5 right-2 flex items-center gap-1">
              {micOff && <span className="rounded-full bg-red-600 p-1" aria-label="Mic đang tắt"><MicOff className="h-3 w-3 text-white" /></span>}
              {handRaised && <span className="rounded-full bg-amber-500 p-1" aria-label="Đang giơ tay"><Hand className="h-3 w-3 text-white" /></span>}
              {sharing && <span className="rounded-full bg-sky-600 p-1" aria-label="Đang chia sẻ màn hình"><ScreenShare className="h-3 w-3 text-white" /></span>}
            </span>
          </div>
          {/* Người khác */}
          {peers.map((p) => (
            <MeetTile key={p.socketId} peer={p} stream={streams.get(p.socketId) || null} speaking={speaking.has(p.socketId)} />
          ))}
        </div>
        {total === 1 && (
          <div className="mx-auto mt-4 max-w-md rounded-lg border border-white/10 bg-white/5 p-3 text-center text-xs text-stone-300">
            Bạn đang một mình trong cuộc họp. Hãy mở hội thoại nhóm và bấm gọi video để mời mọi người vào cuộc họp.
          </div>
        )}

        {/* Panel trò chuyện / người tham gia */}
        {panel && (
          <div className="absolute bottom-2 right-3 top-2 z-10 flex w-72 flex-col overflow-hidden rounded-xl border border-white/10 bg-white text-stone-900 shadow-2xl">
            <div className="flex items-center gap-1 border-b px-2 py-1.5">
              <button className={`rounded-full px-3 py-1.5 text-xs font-semibold ${panel === 'chat' ? 'bg-emerald-600 text-white' : 'text-stone-600 hover:bg-stone-100'}`} onClick={() => setPanel('chat')}>
                Trò chuyện
              </button>
              <button className={`rounded-full px-3 py-1.5 text-xs font-semibold ${panel === 'people' ? 'bg-emerald-600 text-white' : 'text-stone-600 hover:bg-stone-100'}`} onClick={() => setPanel('people')}>
                Người tham gia ({total})
              </button>
              <button className="ml-auto rounded-full p-1.5 text-stone-500 hover:bg-stone-100" onClick={() => setPanel(null)} aria-label="Đóng bảng">
                <X className="h-4 w-4" />
              </button>
            </div>
            {panel === 'chat' ? (
              <>
                <div className="flex-1 space-y-2 overflow-y-auto p-2.5">
                  {chats.length === 0 ? (
                    <p className="py-8 text-center text-xs text-stone-400">Chưa có tin nhắn nào trong cuộc họp</p>
                  ) : (
                    chats.map((c, i) => (
                      <div key={i} className="rounded-lg bg-stone-50 p-2">
                        <p className="text-[10px] font-bold text-emerald-700">{c.userName}</p>
                        <p className="break-words text-xs">{c.content}</p>
                      </div>
                    ))
                  )}
                </div>
                <div className="flex gap-1.5 border-t p-2">
                  <input
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && sendChat()}
                    placeholder="Nhắn tin trong cuộc họp..."
                    className="flex-1 rounded-full border bg-stone-50 px-3 py-1.5 text-xs outline-none focus:ring-2 focus:ring-emerald-500/40"
                    aria-label="Tin nhắn cuộc họp"
                  />
                  <Button size="sm" className="h-8 rounded-full bg-emerald-600 px-3 hover:bg-emerald-500" onClick={sendChat}>Gửi</Button>
                </div>
              </>
            ) : (
              <div className="flex-1 space-y-1.5 overflow-y-auto p-2.5">
                <div className="flex items-center gap-2 rounded-lg bg-stone-50 p-2">
                  <Avatar name={me.fullName} color={me.avatarColor} size={28} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-semibold">Bạn {session.isHost ? '- Trưởng nhóm' : ''}</p>
                    <p className="text-[10px] text-stone-400">{micOff ? 'Mic đang tắt' : 'Đang tham gia'}</p>
                  </div>
                </div>
                {peers.map((p) => (
                  <div key={p.socketId} className="flex items-center gap-2 rounded-lg bg-stone-50 p-2">
                    <Avatar name={p.userName} color={p.avatarColor} size={28} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-semibold">{p.userName}</p>
                      <p className="text-[10px] text-stone-400">{p.micOff ? 'Mic đang tắt' : 'Đang tham gia'}</p>
                    </div>
                    {p.hand && <Hand className="h-3.5 w-3.5 text-amber-500" />}
                    {p.sharing && <ScreenShare className="h-3.5 w-3.5 text-sky-600" />}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Thanh điều khiển */}
      <div className="flex items-center justify-center gap-2 border-t border-white/10 px-3 py-3 sm:gap-2.5">
        <MeetBtn label={micOff ? 'Bật mic' : 'Tắt mic'} onClick={toggleMic} active={micOff}>
          {micOff ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
        </MeetBtn>
        <MeetBtn label={camOff ? 'Bật camera' : 'Tắt camera'} onClick={toggleCam} active={camOff}>
          {camOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
        </MeetBtn>
        <MeetBtn label={sharing ? 'Dừng chia sẻ' : 'Chia sẻ màn hình'} onClick={toggleShare} active={sharing}>
          {sharing ? <ScreenShareOff className="h-5 w-5" /> : <ScreenShare className="h-5 w-5" />}
        </MeetBtn>
        <MeetBtn label={handRaised ? 'Hạ tay' : 'Giơ tay phát biểu'} onClick={toggleHand} active={handRaised}>
          <Hand className="h-5 w-5" />
        </MeetBtn>
        <MeetBtn label={recording ? 'Dừng ghi cuộc họp' : 'Ghi âm/ghi hình cuộc họp'} onClick={toggleRecord} active={recording}>
          <span className={`h-4 w-4 rounded-full border-2 ${recording ? 'border-red-400 bg-red-500' : 'border-white/70'}`} aria-hidden />
        </MeetBtn>
        <MeetBtn label="Trò chuyện trong họp" onClick={() => setPanel((p) => (p === 'chat' ? null : 'chat'))} active={panel === 'chat'}>
          <MessageSquare className="h-5 w-5" />
        </MeetBtn>
        <MeetBtn label="Người tham gia" onClick={() => setPanel((p) => (p === 'people' ? null : 'people'))} active={panel === 'people'}>
          <Users className="h-5 w-5" />
        </MeetBtn>
        {/* Rời cuộc họp */}
        <Popover>
          <PopoverTrigger asChild>
            <button className="rounded-full bg-red-600 p-3.5 text-white hover:bg-red-500" aria-label="Rời cuộc họp">
              <PhoneOff className="h-5 w-5" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-56 p-2" side="top" align="center">
            <button
              className="flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-sm text-stone-700 hover:bg-stone-100"
              onClick={() => leave(secRef.current)}
            >
              <LogOut className="h-4 w-4 text-stone-500" /> Rời cuộc họp
            </button>
            {session.isHost && (
              <button
                className="flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-sm text-red-600 hover:bg-red-50"
                onClick={() => leave(secRef.current, true)}
              >
                <PhoneOff className="h-4 w-4" /> Kết thúc cho tất cả
              </button>
            )}
          </PopoverContent>
        </Popover>
      </div>
    </div>
  )
}

// Ô của một người tham gia
function MeetTile({ peer, stream, speaking }: { peer: MeetPeerT; stream: MediaStream | null; speaking: boolean }) {
  const videoRef = useRef<HTMLVideoElement>(null)
  useEffect(() => {
    const el = videoRef.current
    if (el && stream && el.srcObject !== stream) el.srcObject = stream
  }, [stream])

  return (
    <div className={`relative overflow-hidden rounded-xl border bg-stone-800 ${speaking ? 'border-emerald-400 ring-2 ring-emerald-400/50' : 'border-white/10'}`} style={{ aspectRatio: '4 / 3' }}>
      {stream && !peer.camOff ? (
        <video ref={videoRef} autoPlay playsInline className="h-full w-full object-cover" aria-label={`Hình ảnh của ${peer.userName}`} />
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-stone-900">
          <Avatar name={peer.userName} color={peer.avatarColor} size={56} />
          <span className="text-[10px] text-stone-400">{peer.camOff ? 'Camera đang tắt' : 'Đang kết nối...'}</span>
        </div>
      )}
      <span className="absolute bottom-1.5 left-2 max-w-[70%] truncate rounded bg-black/60 px-2 py-0.5 text-[10px] font-medium">{peer.userName}</span>
      <span className="absolute bottom-1.5 right-2 flex items-center gap-1">
        {peer.micOff && <span className="rounded-full bg-red-600 p-1" aria-label="Mic đang tắt"><MicOff className="h-3 w-3 text-white" /></span>}
        {peer.hand && <span className="rounded-full bg-amber-500 p-1" aria-label="Đang giơ tay"><Hand className="h-3 w-3 text-white" /></span>}
        {peer.sharing && <span className="rounded-full bg-sky-600 p-1" aria-label="Đang chia sẻ màn hình"><ScreenShare className="h-3 w-3 text-white" /></span>}
      </span>
    </div>
  )
}

function MeetBtn({ label, onClick, active, children }: { label: string; onClick: () => void; active?: boolean; children: React.ReactNode }) {
  return (
    <button
      className={`rounded-full p-3 transition-colors ${active ? 'bg-white text-stone-900' : 'bg-white/10 text-white hover:bg-white/20'}`}
      onClick={onClick}
      aria-label={label}
      title={label}
    >
      {children}
    </button>
  )
}
