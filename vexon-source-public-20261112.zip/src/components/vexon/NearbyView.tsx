'use client'

import { useCallback, useRef, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { Avatar } from './shared'
import type { VxUserInfo } from './AuthView'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { toast } from 'sonner'
import { MapPin, Radar, Loader2, Send, EyeOff, Eye, Crosshair, Hand } from 'lucide-react'

interface Person {
  id: string
  fullName: string
  username: string
  role: string
  department: string
  title: string
  avatarColor: string
  bio: string | null
  accountType: string
  companyName: string | null
  interests: string[]
  distanceKm: number | null
  locationName: string | null
  locationUpdatedAt: string | null
  online: boolean
  isFriend: boolean
  pending: boolean
}

interface Ping {
  id: string
  message: string
  createdAt: string
  from: { id: string; fullName: string; avatarColor: string; accountType: string; companyName: string | null }
}

const PING_MESSAGES = ['Xin chào! Mình tìm thấy bạn qua Radar Vexon.', 'Rất vui được kết nối với bạn!', 'Gặp nhau cà phê khi bạn rảnh nhé?']

export default function NearbyView({ me, onMessage }: { me: VxUserInfo; onMessage: (userId: string) => void }) {
  const [people, setPeople] = useState<Person[]>([])
  const [pings, setPings] = useState<Ping[]>([])
  const [loading, setLoading] = useState(true)
  const [locating, setLocating] = useState(false)
  const [hasLocation, setHasLocation] = useState(false)
  const [radius, setRadius] = useState(10)
  const [industry, setIndustry] = useState('')
  const [onlyFriends, setOnlyFriends] = useState(false)
  const [visible, setVisible] = useState(true)
  const [pingTarget, setPingTarget] = useState<Person | null>(null)
  const [pingMsg, setPingMsg] = useState(PING_MESSAGES[0])
  const watchRef = useRef<number | null>(null)

  const load = useCallback(() => {
    fetch(`/api/vx/nearby?radius=${radius}&industry=${encodeURIComponent(industry)}&onlyFriends=${onlyFriends ? '1' : '0'}`)
      .then((r) => r.json())
      .then((d) => {
        if (Array.isArray(d.people)) setPeople(d.people)
        if (Array.isArray(d.pings)) setPings(d.pings)
        setHasLocation(!!d.me?.hasLocation)
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [radius, industry, onlyFriends])

  useDeferredLoad(() => load(), [load])

  // Polling làm mới danh sách + nhận ping mới mỗi 15s
  useDeferredLoad(() => {
    const t = setInterval(load, 15000)
    return () => clearInterval(t)
  }, [load])

  const pushLocation = useCallback((lat: number, lng: number, name?: string) => {
    fetch('/api/vx/nearby', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ latitude: lat, longitude: lng, locationName: name }),
    })
      .then(() => load())
      .catch(() => {})
  }, [load])

  // Định vị thật từ trình duyệt (tự động cập nhật khi di chuyển)
  const locateMe = useCallback(() => {
    if (!('geolocation' in navigator)) {
      toast.error('Trình duyệt không hỗ trợ định vị')
      return
    }
    setLocating(true)
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(false)
        setHasLocation(true)
        pushLocation(pos.coords.latitude, pos.coords.longitude)
        toast.success('Đã cập nhật vị trí thực của bạn!')
        // Theo dõi liên tục — vị trí tự cập nhật theo định vị thật
        if (watchRef.current == null) {
          watchRef.current = navigator.geolocation.watchPosition(
            (p) => pushLocation(p.coords.latitude, p.coords.longitude),
            () => {},
            { maximumAge: 60000, timeout: 30000 }
          )
        }
      },
      () => {
        setLocating(false)
        toast.error('Không lấy được GPS. Bạn vẫn xem được người khác quanh khu vực mặc định.')
      },
      { enableHighAccuracy: true, timeout: 10000 }
    )
  }, [pushLocation])

  const toggleVisible = async (v: boolean) => {
    setVisible(v)
    await fetch('/api/vx/nearby', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ locationVisible: v }),
    })
    toast.success(v ? 'Đã HIỆN vị trí trên radar' : 'Đã ẨN vị trí (chế độ bảo mật)')
    load()
  }

  const sendPing = async () => {
    if (!pingTarget) return
    const res = await fetch('/api/vx/nearby', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ toUserId: pingTarget.id, message: pingMsg }),
    })
    const d = await res.json()
    if (res.ok) {
      toast.success(`Đã gửi chào tới ${pingTarget.fullName}`)
      setPingTarget(null)
    } else toast.error(d.error || 'Không gửi được')
  }

  const addFriend = async (userId: string) => {
    const res = await fetch('/api/vx/friends', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'request', userId }),
    })
    if (res.ok) {
      toast.success('Đã gửi lời mời kết bạn')
      load()
    } else toast.error('Không gửi được lời mời')
  }

  return (
    <div className="space-y-5">
      {/* Header + radar */}
      <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-sky-600 via-cyan-600 to-emerald-600 p-5 text-white shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="flex items-center gap-2 text-xl font-black">
              <Radar className="h-6 w-6 animate-pulse" /> Radar Người gần đây
            </h1>
            <p className="mt-1 text-sm text-sky-100">Định vị GPS thật, tự cập nhật theo di chuyển, lọc gần/xa như Heesay</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 rounded-lg bg-white/15 px-3 py-2 text-xs">
              {visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
              <span>Hiện vị trí</span>
              <Switch checked={visible} onCheckedChange={toggleVisible} aria-label="Ẩn/hiện vị trí" />
            </div>
            <Button size="sm" className="bg-white font-bold text-sky-700 hover:bg-sky-50" onClick={locateMe} disabled={locating}>
              {locating ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Crosshair className="mr-1 h-4 w-4" />}
              {hasLocation ? 'Cập nhật GPS' : 'Bật định vị'}
            </Button>
          </div>
        </div>
      </div>

      {/* Bộ lọc gần/xa */}
      <div className="flex flex-wrap items-center gap-4 rounded-xl border bg-white p-4 shadow-sm">
        <div className="min-w-56 flex-1">
          <p className="mb-2 flex items-center justify-between text-xs font-semibold text-stone-500">
            <span>Bán kính tìm kiếm</span>
            <Badge variant="secondary" className="bg-sky-100 text-sky-800">Tối đa {radius} km</Badge>
          </p>
          <Slider value={[radius]} min={1} max={50} step={1} onValueChange={(v) => setRadius(v[0])} aria-label="Bán kính km" />
        </div>
        <div className="flex items-center gap-2">
          <Input value={industry} onChange={(e) => setIndustry(e.target.value)} placeholder="Lọc công ty / phòng ban..." className="w-52" aria-label="Lọc theo công ty" />
        </div>
        <label className="flex items-center gap-2 text-sm font-medium text-stone-600">
          <Switch checked={onlyFriends} onCheckedChange={(v) => setOnlyFriends(v)} aria-label="Chỉ bạn bè" />
          Chỉ bạn bè
        </label>
        <span className="ml-auto text-xs text-stone-500">
          {loading ? <Loader2 className="inline h-3.5 w-3.5 animate-spin" /> : `${people.length} người trong bán kính ${radius}km`}
        </span>
      </div>

      {/* Ping nhận được 24h */}
      {pings.length > 0 && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
          <p className="mb-2 flex items-center gap-1.5 text-sm font-bold text-amber-900"><Hand className="h-4 w-4" /> Ai đó vừa chào bạn ({pings.length})</p>
          <div className="space-y-2">
            {pings.slice(0, 3).map((p) => (
              <div key={p.id} className="flex items-center gap-3 rounded-lg bg-white p-2.5 text-sm">
                <Avatar name={p.from.fullName} color={p.from.avatarColor} size={32} />
                <div className="flex-1">
                  <p className="font-semibold">{p.from.fullName} {p.from.companyName ? <Badge className="ml-1 bg-amber-600 text-[10px] text-white">{p.from.companyName}</Badge> : null}</p>
                  <p className="text-xs text-stone-500">{p.message}</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => onMessage(p.from.id)}>Nhắn lại</Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Danh sách người gần */}
      <div className="grid gap-3 sm:grid-cols-2">
        {people.map((u) => (
          <div key={u.id} className="flex flex-col gap-3 rounded-xl border bg-white p-4 shadow-sm transition-shadow hover:shadow-md">
            <div className="flex items-start gap-3">
              <Avatar name={u.fullName} color={u.avatarColor} size={48} online={u.online} />
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-1.5 font-bold">
                  <span className="truncate">{u.fullName}</span>
                  {u.accountType === 'business' && <Badge className="shrink-0 bg-amber-600 text-[10px] text-white hover:bg-amber-600">DN</Badge>}
                </p>
                <p className="truncate text-xs text-stone-500">{u.title}, {u.companyName || u.department}</p>
                <p className="mt-1 flex items-center gap-1 text-xs font-semibold text-sky-700">
                  <MapPin className="h-3 w-3" />
                  {u.distanceKm != null ? `${u.distanceKm < 1 ? `${Math.round(u.distanceKm * 1000)} m` : `${u.distanceKm} km`}` : '?'}, {u.locationName || 'Không rõ'}
                </p>
              </div>
            </div>
            {u.bio ? <p className="line-clamp-2 text-xs text-stone-600">{u.bio}</p> : null}
            {u.interests.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {u.interests.map((i) => (
                  <Badge key={i} variant="secondary" className="text-[10px]">{i}</Badge>
                ))}
              </div>
            )}
            <div className="mt-auto flex gap-2">
              <Button size="sm" className="flex-1 bg-sky-600 hover:bg-sky-700" onClick={() => { setPingTarget(u); setPingMsg(PING_MESSAGES[0]) }}>
                <Send className="mr-1 h-3.5 w-3.5" /> Chào
              </Button>
              {u.isFriend ? (
                <Button size="sm" variant="secondary" className="flex-1" onClick={() => onMessage(u.id)}>Nhắn tin</Button>
              ) : u.pending ? (
                <Button size="sm" variant="outline" className="flex-1" disabled>Đã gửi lời mời</Button>
              ) : (
                <Button size="sm" variant="outline" className="flex-1" onClick={() => addFriend(u.id)}>+ Kết bạn</Button>
              )}
            </div>
          </div>
        ))}
      </div>

      {!loading && people.length === 0 && (
        <div className="rounded-xl border border-dashed p-10 text-center text-sm text-stone-500">
          Không có ai trong bán kính {radius}km. Thử tăng bán kính hoặc bấm <b>Bật định vị</b> để tính khoảng cách chính xác.
        </div>
      )}

      {/* Dialog gửi chào */}
      <Dialog open={!!pingTarget} onOpenChange={(o) => !o && setPingTarget(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Gửi tín hiệu chào tới {pingTarget?.fullName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {PING_MESSAGES.map((m) => (
              <button
                key={m}
                className={`w-full rounded-lg border p-3 text-left text-sm transition-colors ${pingMsg === m ? 'border-sky-500 bg-sky-50' : 'hover:bg-stone-50'}`}
                onClick={() => setPingMsg(m)}
              >
                {m}
              </button>
            ))}
            <Button className="w-full bg-sky-600 hover:bg-sky-700" onClick={sendPing}><Send className="mr-1 h-4 w-4" /> Gửi chào</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
