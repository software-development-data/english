'use client'

// ============ MÀN HÌNH CHÀO (SPLASH) ============
// Logo Vexon + thanh tiến trình loading khi vào app — thay thế spinner đơn giản.

import { useEffect, useState } from 'react'

/** Chibi mascot AI động — vẽ SVG thuần, mắt nhấp nháy + tay vẫy (dùng chung splash/404) */
export function ChibiBot({ className = 'h-24 w-24', waving = false }: { className?: string; waving?: boolean }) {
  return (
    <svg viewBox="0 0 120 120" className={className} role="img" aria-label="Robot chibi Vexon">
      {/* ăng-ten */}
      <line x1="60" y1="18" x2="60" y2="30" stroke="#0d9488" strokeWidth="4" strokeLinecap="round" />
      <circle cx="60" cy="14" r="6" fill="#10b981" className="vx-chibi-antenna" />
      {/* tai */}
      <rect x="14" y="52" width="10" height="20" rx="5" fill="#5eead4" />
      <rect x="96" y="52" width="10" height="20" rx="5" fill="#5eead4" />
      {/* đầu */}
      <rect x="24" y="28" width="72" height="58" rx="20" fill="#34d399" />
      <rect x="24" y="28" width="72" height="58" rx="20" fill="url(#vxChibiShine)" />
      {/* màn hình mặt */}
      <rect x="34" y="42" width="52" height="34" rx="12" fill="#064e3b" />
      {/* mắt nhấp nháy */}
      <g className="vx-chibi-eyes">
        <circle cx="49" cy="58" r="4.5" fill="#6ee7b7" />
        <circle cx="71" cy="58" r="4.5" fill="#6ee7b7" />
      </g>
      <g className="vx-chibi-smile" aria-hidden="true">
        <path d="M52 67 Q60 73 68 67" stroke="#6ee7b7" strokeWidth="3" fill="none" strokeLinecap="round" />
      </g>
      {/* má hồng */}
      <circle cx="38" cy="64" r="4" fill="#fda4af" opacity="0.85" />
      <circle cx="82" cy="64" r="4" fill="#fda4af" opacity="0.85" />
      {/* thân */}
      <rect x="38" y="88" width="44" height="24" rx="10" fill="#0d9488" />
      <circle cx="60" cy="100" r="6" fill="#5eead4" className="vx-chibi-heart" />
      {/* tay vẫy */}
      <g className={waving ? 'vx-chibi-wave' : ''} style={{ transformOrigin: '82px 96px' }}>
        <rect x="78" y="90" width="9" height="22" rx="4.5" fill="#14b8a6" transform="rotate(18 82 96)" />
      </g>
      <rect x="33" y="90" width="9" height="22" rx="4.5" fill="#14b8a6" transform="rotate(-14 38 96)" />
      <defs>
        <linearGradient id="vxChibiShine" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.28" />
          <stop offset="0.5" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
      </defs>
    </svg>
  )
}

export default function SplashScreen({ label = 'Đang tải Vexon...' }: { label?: string }) {
  const [progress, setProgress] = useState(12)

  // Thanh tiến trình chạy mượt tới 92% rồi chờ app nạp xong (như trình duyệt)
  useEffect(() => {
    const t = setInterval(() => {
      setProgress((p) => (p < 92 ? p + Math.max(1, Math.round((92 - p) / 12)) : p))
    }, 90)
    return () => clearInterval(t)
  }, [])

  return (
    <div className="fixed inset-0 z-[999] flex flex-col items-center justify-center bg-gradient-to-b from-emerald-50 via-white to-teal-50" role="status" aria-label={label}>
      <div className="flex flex-col items-center gap-1">
        <div className="relative flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-xl shadow-emerald-300/50">
          <img src="/vexon-logo.png" alt="Logo Vexon" className="h-14 w-14 vx-splash-bounce" />
          <span className="absolute -right-2 -top-2 vx-splash-ring" aria-hidden="true" />
        </div>
        <p className="mt-3 text-3xl font-black tracking-tight text-emerald-800">Vexon</p>
        <p className="text-xs font-medium text-teal-700/80">Super App All-in-One — kết nối & vận hành</p>
      </div>

      {/* Thanh loading */}
      <div className="mt-8 w-64 sm:w-72">
        <div className="h-2.5 w-full overflow-hidden rounded-full bg-emerald-100" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}>
          <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-[width] duration-200 ease-out" style={{ width: `${progress}%` }} />
        </div>
        <p className="mt-2 flex items-center justify-between text-[11px] font-medium text-stone-400">
          <span>{label}</span>
          <span>{Math.min(progress, 100)}%</span>
        </p>
      </div>

      <ChibiBot className="mt-8 h-20 w-20 vx-splash-bob" waving />
    </div>
  )
}
