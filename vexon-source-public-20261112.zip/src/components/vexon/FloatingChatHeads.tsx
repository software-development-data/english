'use client'

// Chat Heads nổi: bong bóng chat thu gọn ở góc màn hình để vừa làm việc vừa nhắn tin
import { useCallback, useEffect, useRef, useState } from 'react'
import type { VxUserInfo } from '@/components/vexon/AuthView'
import { Avatar, timeAgo } from '@/components/vexon/shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { X, Minus, Send, MessagesSquare } from 'lucide-react'

interface ConvT {
  id: string; isGroup: boolean; name: string
  partner: { id: string; fullName: string; avatarColor: string; online?: boolean } | null
  lastMessage: { content: string; type: string; createdAt: string; senderId: string; senderName: string } | null
  unread: number
}
interface MsgLite { id: string; content: string; type: string; senderId: string; unsent: boolean; createdAt: string }

export default function FloatingChatHeads({ me }: { me: VxUserInfo }) {
  const [convs, setConvs] = useState<ConvT[]>([])
  const [openId, setOpenId] = useState<string | null>(null)
  const [minimized, setMinimized] = useState<string | null>(null)
  const [msgs, setMsgs] = useState<MsgLite[]>([])
  const [input, setInput] = useState('')

  const poll = useCallback(() => {
    fetch('/api/vx/conversations')
      .then((r) => r.json())
      .then((d) => Array.isArray(d) && setConvs(d))
      .catch(() => {})
  }, [])

  useEffect(() => {
    poll()
    const t = setInterval(poll, 6000)
    return () => clearInterval(t)
  }, [poll])

  // Load tin nhắn cho popup đang mở
  useEffect(() => {
    const t = setTimeout(() => { if (!openId) setMsgs([]) }, 0)
    if (!openId) return () => clearTimeout(t)
    const load = () => {
      fetch(`/api/vx/conversations/${openId}/messages`)
        .then((r) => r.json())
        .then((d) => Array.isArray(d.messages) && setMsgs(d.messages))
        .catch(() => {})
    }
    load()
    const iv = setInterval(load, 2500)
    return () => { clearTimeout(t); clearInterval(iv) }
  }, [openId])

  const send = async () => {
    if (!openId || !input.trim()) return
    const content = input.trim()
    setInput('')
    await fetch(`/api/vx/conversations/${openId}/messages`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content }) })
    poll()
  }

  const heads = convs.filter((c) => c.unread > 0 && c.id !== openId).slice(0, 3)
  const openConv = convs.find((c) => c.id === openId)

  return (
    <>
      {/* Cửa sổ chat mini */}
      {openConv && !minimized && (
        <div className="fixed bottom-20 right-4 z-50 flex h-96 w-80 flex-col overflow-hidden rounded-xl border bg-white shadow-2xl lg:bottom-4" role="dialog" aria-label={`Chat nhanh với ${openConv.name}`}>
          <div className="flex items-center gap-2 border-b bg-gradient-to-r from-emerald-600 to-teal-600 p-2.5 text-white">
            {!openConv.isGroup && <Avatar name={openConv.name} color={openConv.partner?.avatarColor || '#10b981'} size={30} online={openConv.partner?.online} />}
            {openConv.isGroup && <div className="flex h-[30px] w-[30px] items-center justify-center rounded-full bg-white/20"><MessagesSquare className="h-4 w-4" /></div>}
            <p className="min-w-0 flex-1 truncate text-sm font-semibold">{openConv.name}</p>
            <button className="rounded p-1 hover:bg-white/20" onClick={() => setMinimized(openConv.id)} aria-label="Thu nhỏ cửa sổ chat"><Minus className="h-4 w-4" /></button>
            <button className="rounded p-1 hover:bg-white/20" onClick={() => { setOpenId(null); setMinimized(null) }} aria-label="Đóng cửa sổ chat"><X className="h-4 w-4" /></button>
          </div>
          <div className="flex-1 space-y-1.5 overflow-y-auto bg-muted/40 p-2.5">
            {msgs.slice(-30).map((m) => {
              const mine = m.senderId === me.id
              return (
                <div key={m.id} className={`flex ${mine ? 'justify-end' : ''}`}>
                  <div className={`max-w-[80%] rounded-2xl px-3 py-1.5 text-xs shadow-sm ${mine ? 'rounded-br-sm bg-emerald-600 text-white' : 'rounded-bl-sm bg-white'} ${m.unsent ? 'italic opacity-60' : ''}`}>
                    {!mine && !openConv.isGroup === false && openConv.isGroup && <p className="text-[9px] font-bold opacity-70">{m.senderId}</p>}
                    {m.type === 'file' ? 'File: ' : m.type === 'voice' ? 'Thoại: ' : m.type === 'sticker' ? <span className="text-2xl">{m.content}</span> : m.unsent ? 'Tin nhắn đã thu hồi' : m.content}
                  </div>
                </div>
              )
            })}
            {msgs.length === 0 && <p className="py-6 text-center text-[10px] text-muted-foreground">Chưa có tin nhắn</p>}
          </div>
          <div className="flex gap-1.5 border-t p-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send()}
              placeholder="Aa"
              className="flex-1 rounded-full border bg-muted/40 px-3 py-1.5 text-sm outline-none focus:ring-2 focus:ring-emerald-500/40"
              aria-label="Nhắn tin nhanh"
            />
            <Button size="icon" className="h-8 w-8 rounded-full bg-emerald-600 hover:bg-emerald-700" onClick={send} aria-label="Gửi tin nhanh"><Send className="h-3.5 w-3.5" /></Button>
          </div>
        </div>
      )}

      {/* Bong bóng thu nhỏ */}
      {minimized && minimized !== openId && (
        (() => {
          const c = convs.find((x) => x.id === minimized)
          if (!c) return null
          return (
            <button className="fixed bottom-20 right-4 z-50 flex items-center gap-2 rounded-full border bg-white py-1.5 pl-1.5 pr-3 shadow-xl hover:shadow-2xl lg:bottom-4"
              onClick={() => { setOpenId(minimized); setMinimized(null) }} aria-label={`Mở lại chat ${c.name}`}>
              <Avatar name={c.name} color={c.partner?.avatarColor || '#10b981'} size={32} />
              <span className="text-xs font-semibold">{c.name}</span>
            </button>
          )
        })()
      )}

      {/* Chat heads — tin nhắn chưa đọc */}
      <div className="fixed bottom-20 z-40 flex flex-col gap-2 lg:bottom-4" style={{ right: openConv && !minimized ? '21.5rem' : minimized ? '9rem' : '1rem' }}>
        {heads.map((c) => (
          <button key={c.id} className="group relative flex items-center" onClick={() => setOpenId(c.id)} aria-label={`Xem ${c.unread} tin nhắn từ ${c.name}`}>
            <Avatar name={c.name} color={c.partner?.avatarColor || '#10b981'} size={48} online={!c.isGroup ? c.partner?.online : undefined} />
            <Badge className="absolute -right-1 -top-1 h-5 min-w-5 rounded-full bg-rose-600 p-0 text-[10px] text-white hover:bg-rose-600">{c.unread}</Badge>
            <span className="pointer-events-none absolute right-14 hidden whitespace-nowrap rounded-md bg-stone-900 px-2 py-1 text-[10px] text-white group-hover:block">
              {c.name}: {c.lastMessage ? (c.lastMessage.type === 'file' ? 'File' : c.lastMessage.type === 'voice' ? 'Thoại' : c.lastMessage.content.slice(0, 40)) : ''}, {timeAgo(c.lastMessage?.createdAt || new Date())}
            </span>
          </button>
        ))}
      </div>
    </>
  )
}
