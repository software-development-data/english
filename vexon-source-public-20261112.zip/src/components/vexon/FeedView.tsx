'use client'

import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { VxUserInfo } from '@/components/vexon/AuthView'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { useToast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Switch } from '@/components/ui/switch'
import { Checkbox } from '@/components/ui/checkbox'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, REACTIONS, POST_BACKGROUNDS, STORY_BGS, STICKERS, StickerStamp, VISIBILITY_OPTIONS, visibilityOf, timeAgo, GradMedia, isGradMedia, RichContent, ReactionIcon } from '@/components/vexon/shared'
import { compressImage } from '@/lib/image-compress'
import { useUsdRate } from '@/lib/use-usd-rate'
import { fmtUsdFromXu } from '@/lib/format'
import {
  Newspaper, Image as ImageIcon, Paperclip, MapPin, AtSign, Megaphone, Palette, Send, Loader2,
  ThumbsUp, MessageCircle, Share2, Plus, X, Play, Pause, Mic, Smile, CornerDownRight,
  Flame, Users2, Building2, Clock, Sparkles, Trash2, ChevronLeft, ChevronRight, ChevronDown, UserPlus, RefreshCw, Heart, PenLine, Check,
  MoreHorizontal, Bookmark, Bell, Archive, ArchiveRestore, EyeOff, FlagTriangleRight, BadgeCheck,
  Repeat2, Link2, CircleUserRound, Search, Wand2, TrendingUp, PawPrint,
} from 'lucide-react'

interface UserLite { id: string; username: string; fullName: string; role: string; department?: string; avatarColor: string; accountType?: string; companyName?: string | null }
export interface CommentT {
  id: string; content: string; imageUrl: string | null; sticker: string | null; audioDur: number | null
  parentId?: string | null; editedAt?: string | null
  createdAt: string; user: UserLite; replies: CommentT[]
}
export interface PostT {
  id: string
  author: UserLite
  page?: { id: string; name: string; avatar: string | null; category?: string | null } | null
  content: string
  background: string | null
  images: string[]
  videoUrl: string | null
  fileUrl: string | null
  fileName: string | null
  location: string | null
  mentions: { id: string; fullName: string }[]
  isAnnouncement: boolean
  visibility: string
  createdAt: string
  editedAt?: string | null
  reactions: Record<string, number>
  myReaction: string | null
  commentCount: number
  comments: CommentT[]
  myFlag?: { saved: boolean; notified: boolean; hidden: boolean }
  repostOf?: {
    id: string; content: string; background: string | null; images: string[]; videoUrl: string | null; createdAt: string
    author: UserLite
    page?: { id: string; name: string; avatar: string | null; category?: string | null } | null
  } | null
  myRepostId?: string | null
}
interface ConvLite { id: string; name: string; isGroup: boolean; avatar?: string | null; avatarImage?: string | null; partner?: { avatarColor?: string } | null; hidden?: boolean }
interface StoryGroup {
  author: { id: string; username: string; fullName: string; avatarColor: string }
  stories: { id: string; content: string | null; media: string | null; bg: string; createdAt: string; likeCount?: number; likedByMe?: boolean }[]
}

const TABS = [
  { key: 'all', label: 'Tất cả', icon: <Clock className="h-4 w-4" /> },
  { key: 'hot', label: 'Nổi bật', icon: <Flame className="h-4 w-4" /> },
  { key: 'dept', label: 'Phòng ban của tôi', icon: <Building2 className="h-4 w-4" /> },
  { key: 'announce', label: 'Thông báo', icon: <Megaphone className="h-4 w-4" /> },
]

function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result))
    r.onerror = reject
    r.readAsDataURL(file)
  })
}

export default function FeedView({ me, onOpenProfile }: { me: VxUserInfo; onOpenProfile?: (userId: string) => void }) {
  const [tab, setTab] = useState('all')
  const [posts, setPosts] = useState<PostT[]>([])
  // Gợi ý kết bạn kiểu Facebook: LÂU LÂU mới hiện (≈45% lần vào) và chen vào
  // sau bài thứ 3–5 trong bảng tin, không đứng cố định trên đầu nữa
  const [suggestSlot] = useState(() => (Math.random() < 0.45 ? 2 + Math.floor(Math.random() * 3) : -1))
  const [loading, setLoading] = useState(true)
  const [stories, setStories] = useState<StoryGroup[]>([])
  // Hashtag xu hướng: chip gợi ý gần khung soạn + lọc bảng tin theo tag
  const [trending, setTrending] = useState<{ tag: string; count: number }[]>([])
  const [tagFilter, setTagFilter] = useState<string | null>(null)
  const [composerOpen, setComposerOpen] = useState(false)
  const [collectionsOpen, setCollectionsOpen] = useState(false)
  const [viewer, setViewer] = useState<{ group: number; index: number } | null>(null)
  const { toast } = useToast()

  const loadPosts = useCallback((which = tab) => {
    fetch(`/api/vx/posts?tab=${which}`)
      .then((r) => r.json())
      .then((d) => Array.isArray(d) && setPosts(d))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [tab])

  useDeferredLoad(() => {
    loadPosts('all')
    fetch('/api/vx/stories').then((r) => r.json()).then((d) => Array.isArray(d) && setStories(d)).catch(() => {})
    fetch('/api/vx/posts/trending').then((r) => r.json()).then((d) => Array.isArray(d?.trending) && setTrending(d.trending)).catch(() => {})
  }, [])

  const changeTab = (key: string) => {
    setTab(key)
    setLoading(true)
    fetch(`/api/vx/posts?tab=${key}`).then((r) => r.json()).then((d) => Array.isArray(d) && setPosts(d)).catch(() => {}).finally(() => setLoading(false))
  }

  const reactLocal = (postId: string, data: { myReaction: string | null; reactions: Record<string, number> }) => {
    setPosts((ps) => ps.map((p) => (p.id === postId ? { ...p, myReaction: data.myReaction, reactions: data.reactions } : p)))
  }

  const addPost = (p: PostT) => {
    setPosts((ps) => [p, ...ps])
  }

  // Lọc bài theo hashtag đang chọn (không phân biệt hoa/thường)
  const visiblePosts = useMemo(
    () => (tagFilter ? posts.filter((p) => p.content.toLowerCase().includes(`#${tagFilter.toLowerCase()}`)) : posts),
    [posts, tagFilter]
  )

  // ---- Sửa / Xoá bình luận (kiểu Facebook: chủ bình luận sửa, chủ bài + admin xoá) ----
  const findComment = (cs: CommentT[], id: string): CommentT | null => {
    for (const c of cs) {
      if (c.id === id) return c
      const r = findComment(c.replies, id)
      if (r) return r
    }
    return null
  }
  const countTree = (c: CommentT): number => 1 + c.replies.reduce((n, r) => n + countTree(r), 0)
  const stripComment = (cs: CommentT[], id: string): CommentT[] =>
    cs.filter((c) => c.id !== id).map((c) => ({ ...c, replies: stripComment(c.replies, id) }))

  const onCommentEdited = (postId: string, commentId: string, content: string, editedAt: string) => {
    setPosts((ps) => ps.map((pp) => {
      if (pp.id !== postId) return pp
      const mapC = (c: CommentT): CommentT =>
        c.id === commentId ? { ...c, content, editedAt } : { ...c, replies: c.replies.map(mapC) }
      return { ...pp, comments: pp.comments.map(mapC) }
    }))
  }
  const onCommentDeleted = (postId: string, commentId: string) => {
    setPosts((ps) => ps.map((pp) => {
      if (pp.id !== postId) return pp
      const target = findComment(pp.comments, commentId)
      const removed = target ? countTree(target) : 1
      return { ...pp, comments: stripComment(pp.comments, commentId), commentCount: Math.max(0, pp.commentCount - removed) }
    }))
  }

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-bold">
          <Newspaper className="h-5 w-5 text-emerald-600" />
          Bảng tin
        </h2>
        <div className="flex items-center gap-2">
          <span className="hidden text-xs text-muted-foreground sm:inline">Phòng: <b className="text-foreground">{me.department}</b></span>
          {/* Bài viết đã lưu + Kho lưu trữ — tính năng Lưu bài viết kiểu Facebook */}
          <button
            onClick={() => setCollectionsOpen(true)}
            className="flex items-center gap-1.5 rounded-full border bg-white px-3 py-1.5 text-sm font-medium text-stone-600 transition-colors hover:bg-emerald-50 hover:text-emerald-800"
            aria-label="Bài viết đã lưu và kho lưu trữ"
          >
            <Bookmark className="h-4 w-4 text-emerald-600" />
            Đã lưu
          </button>
        </div>
      </div>

      {/* Bộ lọc bảng tin */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => changeTab(t.key)}
            className={`flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors ${
              tab === t.key ? 'border-emerald-600 bg-emerald-600 text-white shadow' : 'bg-white text-stone-600 hover:bg-emerald-50'
            }`}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>

      {/* Khung soạn bài kiểu Facebook — nằm TRÊN cùng, đúng như FB mobile */}
      <Card>
        <CardContent className="p-4 pb-3">
          <button className="flex w-full items-center gap-3 text-left" onClick={() => setComposerOpen(true)} aria-label="Mở khung soạn bài viết">
            <Avatar name={me.fullName} color={me.avatarColor} size={40} img={me.avatarImage} />
            <span className="flex-1 rounded-full border bg-muted/40 px-4 py-2.5 text-sm text-muted-foreground transition-colors hover:bg-muted/60">
              Bạn đang nghĩ gì?
            </span>
          </button>
        </CardContent>
      </Card>

      {/* Tin nhanh 24h — hàng dưới khung soạn bài, đúng thứ tự Facebook */}
      <StoriesRow me={me} groups={stories} onOpen={(g, i) => setViewer({ group: g, index: i })} onPosted={async () => {
        const d = await fetch('/api/vx/stories').then((r) => r.json()).catch(() => [])
        if (Array.isArray(d)) setStories(d)
        toast({ title: 'Đã đăng story, tự xoá sau 24h' })
      }} />

      {/* Hashtag xu hướng — hàng chip nằm giữa story và danh sách bài */}
      {trending.length > 0 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          <span className="flex shrink-0 items-center gap-1 pr-1 text-xs font-semibold text-muted-foreground">
            <TrendingUp className="h-3.5 w-3.5" /> Xu hướng
          </span>
          {trending.map((t) => (
            <button
              key={t.tag}
              onClick={() => setTagFilter(tagFilter === t.tag ? null : t.tag)}
              aria-label={`Xem bài có hashtag ${t.tag}`}
              className={`shrink-0 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
                tagFilter === t.tag
                  ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                  : 'bg-muted/40 text-muted-foreground hover:bg-muted/70'
              }`}
            >
              #{t.tag} · {t.count}
            </button>
          ))}
        </div>
      )}

      {/* Danh sách bài — gợi ý kết bạn chen giữa kiểu FB (nếu có lượt) */}
      {tagFilter && (
        <div className="flex items-center justify-between rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-3 py-2 text-sm">
          <span className="text-emerald-700 dark:text-emerald-400">Đang xem bài có <b>#{tagFilter}</b></span>
          <button className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground" onClick={() => setTagFilter(null)} aria-label="Bỏ lọc hashtag">
            <X className="h-3.5 w-3.5" /> Bỏ lọc
          </button>
        </div>
      )}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}><CardContent className="space-y-3 p-4"><Skeleton className="h-10 w-1/2" /><Skeleton className="h-16 w-full" /></CardContent></Card>
          ))}
        </div>
      ) : visiblePosts.length === 0 ? (
        <p className="py-16 text-center text-sm text-muted-foreground">{tagFilter ? `Chưa có bài nào dùng hashtag #${tagFilter}` : 'Chưa có bài viết trong mục này'}</p>
      ) : (
        visiblePosts.map((p, i) => (
          <Fragment key={p.id}>
            <PostCard me={me} post={p} onOpenProfile={onOpenProfile} onReacted={reactLocal} onEdited={(id, content, location) => {
              setPosts((ps) => ps.map((pp) => (pp.id !== id ? pp : { ...pp, content, location, editedAt: new Date().toISOString() })))
            }} onDeleted={(id) => setPosts((ps) => ps.filter((pp) => pp.id !== id))}
              onRemoved={(id) => setPosts((ps) => ps.filter((pp) => pp.id !== id))}
              onReposted={(np) => setPosts((ps) => [np, ...ps])} onCommented={(postId, c) => {
              setPosts((ps) => ps.map((pp) => {
                if (pp.id !== postId) return pp
                const comments = c.parentId
                  ? pp.comments.map((root) => root.id === c.parentId ? { ...root, replies: [...root.replies, c] } : root)
                  : [...pp.comments, c]
                return { ...pp, comments, commentCount: pp.commentCount + 1 }
              }))
            }} onCommentEdited={onCommentEdited} onCommentDeleted={onCommentDeleted} />
            {i === suggestSlot && <FriendSuggestions onOpenProfile={onOpenProfile} />}
          </Fragment>
        ))
      )}

      <ComposerDialog me={me} open={composerOpen} onOpenChange={setComposerOpen} onPosted={(p) => { addPost(p); toast({ title: 'Đã đăng bài viết' }) }} />

      {/* Bài viết đã lưu + Kho lưu trữ — lưu thật vào DB */}
      <SavedCollectionsDialog me={me} open={collectionsOpen} onOpenChange={setCollectionsOpen} onOpenProfile={onOpenProfile} />

      {/* Trình xem story */}
      {viewer && stories[viewer.group] && (
        <StoryViewer
          groups={stories}
          group={viewer.group}
          index={viewer.index}
          onClose={() => setViewer(null)}
          onNav={(g, i) => setViewer({ group: g, index: i })}
          onLike={(g, i, liked, count) => {
            setStories((gs) => gs.map((grp, gi) => (
              gi !== g ? grp : { ...grp, stories: grp.stories.map((st, si) => (si !== i ? st : { ...st, likedByMe: liked, likeCount: count })) }
            )))
          }}
        />
      )}
    </div>
  )
}

// ============ STORIES ============
function StoriesRow({ me, groups, onOpen, onPosted }: { me: VxUserInfo; groups: StoryGroup[]; onOpen: (g: number, i: number) => void; onPosted: () => void }) {
  const [open, setOpen] = useState(false)
  // Kiểu Facebook: thẻ "Tạo tin" riêng (nền trắng + nút ⊕ xanh), tin của bạn và tin người khác là thẻ dọc toàn ảnh
  const mine = groups.find((g) => g.author.id === me.id)
  const others = groups.filter((g) => g.author.id !== me.id)
  return (
    <>
      <div className="flex gap-2 overflow-x-auto pb-1" role="list" aria-label="Tin nhanh 24h">
        {/* Tạo tin — kiểu Facebook: ảnh trên, dải trắng dưới với nút ⊕ xanh và nhãn "Tạo tin" */}
        <button
          className="relative flex h-[200px] w-[112px] shrink-0 flex-col overflow-hidden rounded-xl border bg-white shadow-sm transition-transform hover:scale-[1.02]"
          onClick={() => setOpen(true)}
          aria-label="Tạo tin 24h"
        >
          {mine?.stories[0]?.media ? (
            <img src={mine.stories[0].media} alt="" className="h-[152px] w-full object-cover" />
          ) : (
            <div className="flex h-[152px] w-full items-center justify-center bg-gradient-to-br from-emerald-100 via-teal-50 to-sky-100">
              <Avatar name={me.fullName} color={me.avatarColor} size={48} img={me.avatarImage} />
            </div>
          )}
          <div className="relative flex flex-1 items-center justify-center">
            <span className="absolute -top-4 flex h-8 w-8 items-center justify-center rounded-full border-[3px] border-white bg-blue-600 text-white shadow-md">
              <Plus className="h-4 w-4" />
            </span>
            <span className="text-[11px] font-semibold text-stone-800">Tạo tin</span>
          </div>
        </button>

        {/* Tin của bạn (nếu đã đăng) — nhãn "Tin của bạn" kiểu Facebook */}
        {mine && (
          <button
            className="relative h-[200px] w-[112px] shrink-0 overflow-hidden rounded-xl shadow-sm transition-transform hover:scale-[1.02]"
            onClick={() => onOpen(groups.indexOf(mine), 0)}
            aria-label="Xem tin của bạn"
          >
            {mine.stories[0]?.media ? (
              <img src={mine.stories[0].media} alt="" className="absolute inset-0 h-full w-full object-cover" />
            ) : (
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-500 to-teal-600" />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/10" />
            <div className="absolute left-2 top-2"><Avatar name={me.fullName} color={me.avatarColor} size={36} img={me.avatarImage} ring /></div>
            <span className="absolute bottom-2 left-2 right-2 line-clamp-2 text-left text-[11px] font-semibold text-white drop-shadow">Tin của bạn</span>
          </button>
        )}

        {/* Tin của người khác — toàn ảnh/nền màu, avatar viền xanh góc trên, tên ở dưới */}
        {others.map((g) => (
          <button
            key={g.author.id}
            className="relative h-[200px] w-[112px] shrink-0 overflow-hidden rounded-xl shadow-sm transition-transform hover:scale-[1.02]"
            onClick={() => onOpen(groups.indexOf(g), 0)}
            aria-label={`Xem tin của ${g.author.fullName}`}
          >
            {g.stories[0]?.media ? (
              <img src={g.stories[0].media} alt="" className="absolute inset-0 h-full w-full object-cover" />
            ) : (
              <div className="absolute inset-0" style={{ backgroundImage: `linear-gradient(160deg, ${g.stories[0].bg.replace(',', ' 0%, ')} 100%)` }} />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/10" />
            <div className="absolute left-2 top-2 rounded-full ring-2 ring-blue-600"><Avatar name={g.author.fullName} color={g.author.avatarColor} size={36} /></div>
            <span className="absolute bottom-2 left-2 right-2 line-clamp-2 text-left text-[11px] font-semibold text-white drop-shadow">{g.author.fullName}</span>
          </button>
        ))}

        {groups.length === 0 && (
          <div className="flex h-[200px] min-w-[160px] flex-1 items-center justify-center rounded-xl border border-dashed bg-white/60 px-4 text-center text-xs text-muted-foreground">
            Chưa có tin nào trong 24h, bấm "Tạo tin" để bắt đầu
          </div>
        )}
      </div>
      <StoryComposer me={me} open={open} onOpenChange={setOpen} onPosted={onPosted} />
    </>
  )
}

function StoryComposer({ me, open, onOpenChange, onPosted }: { me: VxUserInfo; open: boolean; onOpenChange: (v: boolean) => void; onPosted: () => void }) {
  const [content, setContent] = useState('')
  const [bg, setBg] = useState(STORY_BGS[0])
  const [media, setMedia] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const { toast } = useToast()

  const post = async () => {
    if (!content.trim() && !media) return
    setSaving(true)
    try {
      const res = await fetch('/api/vx/stories', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: content.trim(), bg, media }) })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      setContent(''); setMedia(null)
      onOpenChange(false)
      onPosted()
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không đăng được story', variant: 'destructive' })
    } finally { setSaving(false) }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader><DialogTitle>Tin nhanh 24h</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="relative mx-auto flex aspect-[9/14] w-full max-w-[240px] flex-col justify-between rounded-xl p-4 text-white" style={{ backgroundImage: `linear-gradient(160deg, ${bg.replace(',', ' 0%, ')} 100%)` }}>
            {media && <img src={media} alt="Ảnh story" className="absolute inset-0 h-full w-full rounded-xl object-cover opacity-80" />}
            <div className="relative flex items-center gap-2"><Avatar name={me.fullName} color={me.avatarColor} size={28} /><span className="text-xs font-semibold">{me.fullName}</span></div>
            <p className="relative text-center text-lg font-bold leading-snug drop-shadow">{content || 'Nhập khoảnh khắc của bạn...'}</p>
          </div>
          <div className="flex gap-2">
            {STORY_BGS.map((b) => (
              <button key={b} onClick={() => setBg(b)} aria-label="Đổi nền story" className={`h-7 w-7 rounded-full border-2 ${bg === b ? 'border-emerald-600' : 'border-transparent'}`} style={{ backgroundImage: `linear-gradient(135deg, ${b.replace(',', ' 0%, ')} 100%)` }} />
            ))}
            <label className="ml-auto flex cursor-pointer items-center gap-1 rounded-md border px-2 py-1 text-xs font-medium hover:bg-muted" aria-label="Gắn ảnh vào story">
              <ImageIcon className="h-3.5 w-3.5" /> Ảnh
              <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                const f = e.target.files?.[0]
                if (!f) return
                if (f.size > 2_000_000) { toast({ title: 'Ảnh quá lớn (tối đa 2MB)', variant: 'destructive' }); return }
                setMedia(await readFileAsDataURL(f))
              }} />
            </label>
          </div>
          <Input value={content} onChange={(e) => setContent(e.target.value)} placeholder="Khoảnh khắc làm việc hôm nay..." />
          <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={post} disabled={saving || (!content.trim() && !media)}>
            {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Sparkles className="mr-1 h-4 w-4" />}
            Đăng story (tự xoá sau 24h)
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function StoryViewer({ groups, group, index, onClose, onNav, onLike }: { groups: StoryGroup[]; group: number; index: number; onClose: () => void; onNav: (g: number, i: number) => void; onLike: (g: number, i: number, liked: boolean, count: number) => void }) {
  const g = groups[group]
  const s = g.stories[index]
  const [progress, setProgress] = useState(0)
  const [pop, setPop] = useState(false)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const { toast } = useToast()

  const next = useCallback(() => {
    if (index + 1 < g.stories.length) onNav(group, index + 1)
    else if (group + 1 < groups.length) onNav(group + 1, 0)
    else onClose()
  }, [group, index, groups.length, g.stories.length, onClose, onNav])

  useEffect(() => {
    const t0 = setTimeout(() => setProgress(0), 0)
    const start = Date.now()
    const iv = setInterval(() => setProgress(Math.min(100, ((Date.now() - start) / 5000) * 100)), 50)
    timerRef.current = setTimeout(next, 5000)
    return () => { clearTimeout(t0); clearInterval(iv); if (timerRef.current) clearTimeout(timerRef.current) }
  }, [group, index, next])

  // Thả tim story — double-click cũng thả luôn (kiểu Instagram)
  const like = useCallback(async () => {
    if (!s.id) return
    const liked = !s.likedByMe
    onLike(group, index, liked, (s.likeCount || 0) + (liked ? 1 : -1))
    if (liked) { setPop(true); setTimeout(() => setPop(false), 450) }
    try {
      const res = await fetch(`/api/vx/stories/${s.id}/heart`, { method: 'POST' })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      onLike(group, index, d.liked, d.count)
    } catch {
      onLike(group, index, !liked, (s.likeCount || 0) + (!liked ? 1 : -1))
      toast({ title: 'Lỗi', description: 'Không thả tim được story', variant: 'destructive' })
    }
  }, [s.id, s.likedByMe, s.likeCount, group, index, onLike, toast])

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 p-4" role="dialog" aria-label="Xem story">
      <button className="absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white hover:bg-white/20" onClick={onClose} aria-label="Đóng story"><X className="h-5 w-5" /></button>
      <button className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-2 text-white hover:bg-white/20" onClick={() => (index > 0 ? onNav(group, index - 1) : group > 0 && onNav(group - 1, 0))} aria-label="Story trước"><ChevronLeft className="h-6 w-6" /></button>
      <button className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-2 text-white hover:bg-white/20" onClick={next} aria-label="Story sau"><ChevronRight className="h-6 w-6" /></button>

      <div
        className="relative flex max-h-[88vh] w-full max-w-[360px] flex-col overflow-hidden rounded-2xl"
        style={{ backgroundImage: `linear-gradient(160deg, ${s.bg.replace(',', ' 0%, ')} 100%)`, aspectRatio: '9/14' }}
        onDoubleClick={like}
      >
        {s.media && <img src={s.media} alt="Nội dung story" className="absolute inset-0 h-full w-full object-cover opacity-80" />}
        <div className="absolute left-2 right-2 top-2 flex gap-1">
          {g.stories.map((_, i) => (
            <div key={i} className="h-1 flex-1 overflow-hidden rounded-full bg-white/30">
              <div className="h-full bg-white transition-none" style={{ width: i < index ? '100%' : i === index ? `${progress}%` : '0%' }} />
            </div>
          ))}
        </div>
        <div className="relative flex items-center gap-2 p-4 pt-6 text-white">
          <Avatar name={g.author.fullName} color={g.author.avatarColor} size={34} />
          <div><p className="text-sm font-bold">{g.author.fullName}</p><p className="text-[11px] text-white/80">{timeAgo(s.createdAt)}</p></div>
        </div>
        <div className="relative mt-auto p-6 text-center text-xl font-bold leading-snug text-white drop-shadow">{s.content}</div>

        {/* Thanh tương tác: nút thả tim (nhấp 2 lần vào nền story cũng thả) */}
        <div className="relative flex items-center justify-center gap-2 p-4 pt-0">
          <button
            className="flex items-center gap-2 rounded-full bg-white/15 px-4 py-2.5 text-sm font-bold text-white backdrop-blur transition hover:bg-white/25"
            onClick={like}
            aria-label={s.likedByMe ? 'Bỏ tim story' : 'Thả tim story'}
          >
            <Heart
              className={`h-5 w-5 transition-transform ${s.likedByMe ? 'fill-rose-500 text-rose-500' : 'text-white'} ${pop ? 'scale-150' : 'scale-100'}`}
            />
            {Boolean(s.likeCount) && <span>{s.likeCount}</span>}
          </button>
        </div>
      </div>
    </div>
  )
}

// ============ COMPOSER ============
function ComposerDialog({ me, open, onOpenChange, onPosted }: { me: VxUserInfo; open: boolean; onOpenChange: (v: boolean) => void; onPosted: (p: PostT) => void }) {
  const rate = useUsdRate() // tỷ giá sống — thưởng đăng bài quy USD
  const [content, setContent] = useState('')
  const [bg, setBg] = useState<string | null>(null)
  const [images, setImages] = useState<string[]>([])
  const [videoUrl, setVideoUrl] = useState<string | null>(null)
  const [file, setFile] = useState<{ url: string | null; name: string } | null>(null)
  const [location, setLocation] = useState('')
  const [showLocation, setShowLocation] = useState(false)
  const [mentionOpen, setMentionOpen] = useState(false)
  const [users, setUsers] = useState<UserLite[]>([])
  const [mentions, setMentions] = useState<{ id: string; fullName: string }[]>([])
  const [announce, setAnnounce] = useState(false)
  const [visibility, setVisibility] = useState<string>('public')
  const [visOpen, setVisOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  // AI viết giùm: gợi ý ý tưởng + sinh bài viết tiếng Việt chèn thẳng vào ô soạn
  const [aiOpen, setAiOpen] = useState(false)
  const [aiTopic, setAiTopic] = useState('')
  const [aiBusy, setAiBusy] = useState(false)
  const { toast } = useToast()

  const AI_IDEAS = [
    'Động viên cả team đầu tuần',
    'Chúc cuối tuần vui vẻ',
    'Báo cáo tiến độ dự án',
    'Cảm ơn khách hàng đã tin tưởng',
    'Mời mọi người họp nhanh 15 phút',
    'Chia sẻ mẹo làm việc hiệu quả',
  ]

  const aiWrite = async (topic: string) => {
    const t = topic.trim()
    if (!t) { toast({ title: 'Nhập ý tưởng trước nhé', variant: 'destructive' }); return }
    setAiBusy(true)
    try {
      const res = await fetch('/api/tiai/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system: 'Bạn là trợ lý viết bài đăng mạng xã hội nội bộ bằng tiếng Việt, giọng thân thiện chuyên nghiệp, đúng 2-4 câu, có thể có 1-3 hashtag cuối bài, KHÔNG dùng emoji, KHÔNG đặt trong ngoặc kép, không giải thích gì thêm — chỉ trả về nội dung bài viết.',
          prompt: `Viết bài đăng cho bài có chủ đề: "${t}". Tác giả: ${me.fullName} (${me.title || me.department || 'nhân viên'}).`,
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'AI bận')
      setContent((c) => (c.trim() ? `${c.trim()}\n\n${d.text}` : d.text))
      setAiOpen(false)
      toast({ title: 'AI đã viết xong, bạn chỉnh thêm nhé!' })
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'AI chưa trả lời được', variant: 'destructive' })
    } finally { setAiBusy(false) }
  }

  useEffect(() => {
    if (mentionOpen && users.length === 0) {
      fetch('/api/vx/users').then((r) => r.json()).then((d) => Array.isArray(d) && setUsers(d)).catch(() => {})
    }
  }, [mentionOpen, users.length])

  const reset = () => { setContent(''); setBg(null); setImages([]); setVideoUrl(null); setFile(null); setLocation(''); setShowLocation(false); setMentions([]); setAnnounce(false); setVisibility('public'); setVisOpen(false) }

  const post = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/vx/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: content.trim(), background: bg, images, videoUrl, fileUrl: file?.url || null, fileName: file?.name || null, location: location.trim() || null, mentions, isAnnouncement: announce, visibility }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      reset()
      onOpenChange(false)
      onPosted(d)
      // Thưởng đăng bài: báo USD và cập nhật ví trên header
      if (d.reward > 0) {
        toast({ title: `Đăng bài +${fmtUsdFromXu(d.reward, rate)} vào ví, kiếm thưởng miễn phí cả ngày!` })
        window.dispatchEvent(new Event('vx-coins-changed'))
      }
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không đăng được bài', variant: 'destructive' })
    } finally { setSaving(false) }
  }

  const hasMedia = images.length > 0 || videoUrl || file
  const canPost = content.trim() || hasMedia || bg

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) reset() }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader><DialogTitle>Tạo bài viết</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <Avatar name={me.fullName} color={me.avatarColor} size={40} />
            <div>
              <p className="text-sm font-semibold">{me.fullName}</p>
              {/* Chọn chế độ hiển thị kiểu Facebook: Công khai / Bạn bè / Riêng tư */}
              <Popover open={visOpen} onOpenChange={setVisOpen}>
                <PopoverTrigger asChild>
                  <button
                    className="mt-0.5 flex items-center gap-1 rounded-full bg-stone-100 px-2 py-0.5 text-xs font-semibold text-stone-600 transition hover:bg-stone-200"
                    aria-label="Chọn chế độ hiển thị bài viết"
                  >
                    {visibilityOf(visibility).icon} {visibilityOf(visibility).label}
                    <ChevronDown className="h-3 w-3" />
                  </button>
                </PopoverTrigger>
                <PopoverContent className="w-72 p-2" align="start">
                  <p className="px-1 pb-1 text-xs font-semibold text-muted-foreground">Ai có thể thấy bài viết?</p>
                  {VISIBILITY_OPTIONS.map((v) => (
                    <button
                      key={v.key}
                      onClick={() => { setVisibility(v.key); setVisOpen(false) }}
                      className={`flex w-full items-start gap-2.5 rounded-lg p-2 text-left transition ${visibility === v.key ? 'bg-emerald-50' : 'hover:bg-muted'}`}
                      aria-label={`Chế độ ${v.label}`}
                    >
                      <span className="mt-0.5 text-lg leading-none">{v.icon}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-semibold">{v.label}</span>
                        <span className="block text-xs text-muted-foreground">{v.desc}</span>
                      </span>
                      {visibility === v.key && <Check className="h-4 w-4 text-emerald-600" />}
                    </button>
                  ))}
                </PopoverContent>
              </Popover>
            </div>
            {me.role === 'admin' && (
              <label className="ml-auto flex items-center gap-2 text-xs font-medium text-amber-700">
                <Megaphone className="h-4 w-4" /> Thông báo BGĐ
                <Switch checked={announce} onCheckedChange={setAnnounce} aria-label="Đăng làm thông báo Ban Giám đốc" />
              </label>
            )}
          </div>

          {/* Vùng soạn (có nền màu) */}
          <div className="rounded-lg" style={bg ? { backgroundImage: bg } : undefined}>
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={`${me.fullName} ơi, bạn đang nghĩ gì?`}
              rows={bg ? 5 : 3}
              className={`resize-none border-0 ${bg ? 'bg-transparent text-center text-xl font-bold text-white placeholder:text-white/70 focus-visible:ring-0' : ''}`}
            />
            {images.length > 0 && (
              <div className={`grid gap-1 p-2 ${images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
                {images.map((img, i) => (
                  <div key={i} className="relative">
                    {isGradMedia(img) ? <GradMedia value={img} className="h-32 w-full rounded-md" /> : <img src={img} alt={`Ảnh ${i + 1}`} className="h-32 w-full rounded-md bg-stone-100 object-contain" />}
                    <button className="absolute right-1 top-1 rounded-full bg-black/60 p-1 text-white" onClick={() => setImages((xs) => xs.filter((_, j) => j !== i))} aria-label="Bỏ ảnh"><X className="h-3 w-3" /></button>
                  </div>
                ))}
              </div>
            )}
            {videoUrl && (
              <div className="relative p-2">
                <video src={videoUrl} controls className="max-h-56 w-full rounded-md" />
                <button className="absolute right-3 top-3 rounded-full bg-black/60 p-1 text-white" onClick={() => setVideoUrl(null)} aria-label="Bỏ video"><X className="h-3 w-3" /></button>
              </div>
            )}
          </div>

          {/* Chọn nền màu */}
          {!hasMedia && (
            <div className="flex items-center gap-2">
              <Palette className="h-4 w-4 text-muted-foreground" />
              <div className="flex flex-1 gap-1.5 overflow-x-auto">
                <button onClick={() => setBg(null)} className={`h-7 w-7 shrink-0 rounded-md border text-[10px] ${bg === null ? 'border-emerald-600' : 'border-input'}`} aria-label="Không dùng nền">Aa</button>
                {POST_BACKGROUNDS.map((g) => (
                  <button key={g} onClick={() => setBg(g)} aria-label="Chọn phông nền" className={`h-7 w-7 shrink-0 rounded-md border-2 ${bg === g ? 'border-emerald-600' : 'border-transparent'}`} style={{ backgroundImage: g }} />
                ))}
              </div>
            </div>
          )}

          {/* Mention chips */}
          {mentions.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {mentions.map((m) => (
                <span key={m.id} className="flex items-center gap-1 rounded-full bg-sky-100 px-2 py-0.5 text-xs font-medium text-sky-700">
                  @{m.fullName}
                  <button onClick={() => setMentions((ms) => ms.filter((x) => x.id !== m.id))} aria-label={`Bỏ nhắc ${m.fullName}`}><X className="h-3 w-3" /></button>
                </span>
              ))}
            </div>
          )}
          {showLocation && (
            <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Bạn đang ở đâu? (VD: Văn phòng Vexon, Quận 1)" />
          )}
          {file && (
            <div className="flex items-center gap-2 rounded-lg border bg-muted/40 px-3 py-2 text-sm">
              <Paperclip className="h-4 w-4 text-muted-foreground" />
              <span className="flex-1 truncate">{file.name}</span>
              <button onClick={() => setFile(null)} aria-label="Bỏ file đính kèm"><X className="h-4 w-4" /></button>
            </div>
          )}

          {/* Thanh công cụ đính kèm */}
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-2">
            <div className="flex flex-wrap items-center gap-1">
              <label className="flex cursor-pointer items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-emerald-700 hover:bg-emerald-50" aria-label="Gắn ảnh hoặc video">
                <ImageIcon className="h-4 w-4" /> Ảnh/Video
                <input type="file" accept="image/*,video/*" multiple className="hidden" onChange={async (e) => {
                  for (const f of Array.from(e.target.files || [])) {
                    if (f.type.startsWith('video/')) {
                      if (f.size > 1_500_000) { toast({ title: `${f.name} quá lớn`, description: 'Demo giới hạn ~1.5MB/video', variant: 'destructive' }); continue }
                      setVideoUrl(await readFileAsDataURL(f))
                    } else {
                      // Ảnh: CHỈ NÉN dung lượng (giữ nguyên tỉ lệ gốc, không cắt xén) rồi mới đính kèm
                      let url = ''
                      try { url = await compressImage(f) } catch { url = await readFileAsDataURL(f) }
                      setImages((xs) => [...xs, url].slice(0, 6))
                    }
                  }
                }} />
              </label>
              <label className="flex cursor-pointer items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-sky-700 hover:bg-sky-50" aria-label="Gắn file tài liệu">
                <Paperclip className="h-4 w-4" /> File
                <input type="file" className="hidden" onChange={async (e) => {
                  const f = e.target.files?.[0]
                  if (!f) return
                  if (f.size > 1_500_000) { setFile({ url: null, name: f.name }); toast({ title: 'File >1.5MB: chỉ đính kèm tên (demo)' }) }
                  else setFile({ url: await readFileAsDataURL(f), name: f.name })
                }} />
              </label>
              {/* AI viết giùm — sinh bài viết từ ý tưởng, chèn thẳng vào ô soạn */}
              <Popover open={aiOpen} onOpenChange={setAiOpen}>
                <PopoverTrigger asChild>
                  <button className="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-teal-700 hover:bg-teal-50" aria-label="AI viết giùm bài">
                    {aiBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />} AI viết giùm
                  </button>
                </PopoverTrigger>
                <PopoverContent className="w-80 p-3" align="start">
                  <p className="text-sm font-bold text-teal-800">AI viết giùm</p>
                  <p className="mb-2 text-xs text-muted-foreground">Nhập ý tưởng, AI soạn bài tiếng Việt 2-4 câu kèm hashtag.</p>
                  <Input value={aiTopic} onChange={(e) => setAiTopic(e.target.value)} placeholder="VD: team hoàn thành Sprint 24..." aria-label="Ý tưởng bài viết" />
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {AI_IDEAS.map((idea) => (
                      <button key={idea} onClick={() => setAiTopic(idea)} className="rounded-full border border-teal-200 bg-teal-50 px-2 py-0.5 text-[11px] font-medium text-teal-700 hover:bg-teal-100" aria-label={`Chọn ý tưởng: ${idea}`}>
                        {idea}
                      </button>
                    ))}
                  </div>
                  <Button size="sm" className="mt-2.5 w-full bg-teal-600 hover:bg-teal-700" onClick={() => aiWrite(aiTopic)} disabled={aiBusy || !aiTopic.trim()} aria-label="Tạo bài với AI">
                    {aiBusy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Wand2 className="mr-1 h-4 w-4" />} {aiBusy ? 'AI đang viết...' : 'Tạo bài viết'}
                  </Button>
                </PopoverContent>
              </Popover>
              <button className="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-rose-600 hover:bg-rose-50" onClick={() => setShowLocation((v) => !v)}><MapPin className="h-4 w-4" /> Check-in</button>
              <Popover open={mentionOpen} onOpenChange={setMentionOpen}>
                <PopoverTrigger asChild>
                  <button className="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-sky-600 hover:bg-sky-50"><AtSign className="h-4 w-4" /> Nhắc đồng nghiệp</button>
                </PopoverTrigger>
                <PopoverContent className="w-64 p-2" align="start">
                  <p className="mb-1.5 px-1 text-xs font-semibold text-muted-foreground">Chọn đồng nghiệp</p>
                  <ScrollArea className="h-56">
                    {users.map((u) => (
                      <label key={u.id} className="flex cursor-pointer items-center gap-2 rounded-md p-1.5 hover:bg-muted">
                        <Checkbox checked={mentions.some((m) => m.id === u.id)} onCheckedChange={(c) => setMentions((ms) => (c ? [...ms, { id: u.id, fullName: u.fullName }] : ms.filter((m) => m.id !== u.id)))} />
                        <Avatar name={u.fullName} color={u.avatarColor} size={26} />
                        <div className="min-w-0"><p className="truncate text-xs font-medium">{u.fullName}</p><p className="truncate text-[10px] text-muted-foreground">{u.department}</p></div>
                      </label>
                    ))}
                  </ScrollArea>
                </PopoverContent>
              </Popover>
            </div>
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={post} disabled={!canPost || saving} aria-label="Đăng bài viết">
              {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Send className="mr-1 h-4 w-4" />} Đăng bài
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ============ POST CARD ============
// Xuất để trang Hồ sơ tái dùng ĐÚNG cách hiển thị của Bảng tin (đồng bộ cảm xúc/bình luận/menu ⋯)
export function PostCard({ me, post, onReacted, onCommented, onOpenProfile, onEdited, onDeleted, onCommentEdited, onCommentDeleted, context = 'feed', onFlagSaved, onRemoved, onReposted }: {
  me: VxUserInfo
  post: PostT
  onReacted: (id: string, d: { myReaction: string | null; reactions: Record<string, number> }) => void
  onCommented: (postId: string, c: CommentT) => void
  onOpenProfile?: (userId: string) => void
  onEdited?: (id: string, content: string, location: string | null) => void
  onDeleted?: (id: string) => void
  onCommentEdited: (postId: string, commentId: string, content: string, editedAt: string) => void
  onCommentDeleted: (postId: string, commentId: string) => void
  context?: 'feed' | 'saved' | 'archive' // hiển thị trong Bảng tin, mục Đã lưu hay Kho lưu trữ
  onFlagSaved?: (id: string, saved: boolean) => void // báo lên danh sách đang mở
  onRemoved?: (id: string) => void // gỡ bài khỏi danh sách (ẩn/lưu trữ/bỏ lưu...)
  onReposted?: (p: PostT) => void // khi Đăng lại/Chia sẻ lên trang cá nhân tạo bài mới — chen lên đầu bảng tin
}) {
  const [showComments, setShowComments] = useState(false)
  const [pickerOpen, setPickerOpen] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [saved, setSaved] = useState(Boolean(post.myFlag?.saved))
  const [notified, setNotified] = useState(Boolean(post.myFlag?.notified))
  const [editOpen, setEditOpen] = useState(false)
  const [editText, setEditText] = useState('')
  const [editLoc, setEditLoc] = useState('')
  const [savingEdit, setSavingEdit] = useState(false)
  const [shareOpen, setShareOpen] = useState(false)
  const [myRepostId, setMyRepostId] = useState<string | null>(post.myRepostId ?? null)
  const [repostBusy, setRepostBusy] = useState(false)
  // AI tóm tắt bài dài — 1 chạm rút gọn bài viết thành 1-2 câu
  const [aiSum, setAiSum] = useState<string | null>(null)
  const [aiSumBusy, setAiSumBusy] = useState(false)
  const { toast } = useToast()

  const aiSummarize = async () => {
    setAiSumBusy(true)
    try {
      const res = await fetch('/api/tiai/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system: 'Bạn tóm tắt bài viết mạng xã hội tiếng Việt thành 1-2 câu gọn dễ đọc, KHÔNG dùng emoji, không giải thích gì thêm.',
          prompt: post.content,
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'AI bận')
      setAiSum(d.text)
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'AI chưa trả lời được', variant: 'destructive' })
    } finally { setAiSumBusy(false) }
  }

  const react = async (type: string) => {
    setPickerOpen(false)
    const target = post.myReaction === type ? null : type
    // optimistic
    const r = { ...post.reactions }
    if (post.myReaction) r[post.myReaction] = Math.max(0, (r[post.myReaction] || 1) - 1)
    if (target) r[target] = (r[target] || 0) + 1
    onReacted(post.id, { myReaction: target, reactions: r })
    const res = await fetch(`/api/vx/posts/${post.id}/like`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type }) })
    if (res.ok) onReacted(post.id, await res.json())
  }

  const myR = REACTIONS.find((r) => r.type === post.myReaction)
  const topReactions = REACTIONS.filter((r) => post.reactions[r.type] > 0).slice(0, 3)
  const totalReactions = Object.values(post.reactions).reduce((a, b) => a + b, 0)
  const isMine = post.author.id === me.id

  // Menu ⋯ kiểu Facebook: Lưu, Chỉnh sửa, Xoá, Bật thông báo, Kho lưu trữ, Ẩn, Báo cáo — LƯU THẬT VÀO DB
  const menuBtn = 'flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-left text-sm font-medium text-stone-700 transition-colors hover:bg-muted'

  const toggleFlag = async (field: 'saved' | 'notified') => {
    const next = !(field === 'saved' ? saved : notified)
    if (field === 'saved') setSaved(next)
    else setNotified(next)
    setMenuOpen(false)
    try {
      const res = await fetch(`/api/vx/posts/${post.id}/flag`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ [field]: next }) })
      if (!res.ok) throw new Error()
      if (field === 'saved') {
        onFlagSaved?.(post.id, next)
        toast({ title: next ? 'Đã lưu bài viết, xem ở nút "Đã lưu" phía trên' : 'Đã bỏ lưu bài viết' })
        if (context === 'saved' && !next) onRemoved?.(post.id)
      } else {
        toast({ title: next ? 'Đã bật thông báo cho bài viết này' : 'Đã tắt thông báo cho bài viết này' })
      }
    } catch {
      if (field === 'saved') setSaved(!next)
      else setNotified(!next)
      toast({ title: 'Không cập nhật được, thử lại nhé', variant: 'destructive' })
    }
  }

  const archivePost = async (unarchive = false) => {
    setMenuOpen(false)
    try {
      const res = await fetch(`/api/vx/posts/${post.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ archive: !unarchive }) })
      if (!res.ok) throw new Error()
      onRemoved?.(post.id)
      toast({ title: unarchive ? 'Đã đưa bài viết trở lại Bảng tin' : 'Đã chuyển bài viết vào kho lưu trữ' })
    } catch {
      toast({ title: unarchive ? 'Không bỏ lưu trữ được' : 'Không lưu trữ được bài', variant: 'destructive' })
    }
  }

  const hidePost = async () => {
    setMenuOpen(false)
    try {
      const res = await fetch(`/api/vx/posts/${post.id}/flag`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ hidden: true }) })
      if (!res.ok) throw new Error()
      onRemoved?.(post.id)
      toast({ title: 'Đã ẩn bài viết, sẽ ít thấy bài tương tự' })
    } catch {
      toast({ title: 'Không ẩn được bài viết', variant: 'destructive' })
    }
  }

  // ĐĂNG LẠI kiểu TikTok: bấm 1 lần đưa bài lên trang cá nhân (kèm bài gốc), bấm nữa để bỏ
  const toggleRepost = async () => {
    if (repostBusy) return
    setRepostBusy(true)
    try {
      if (myRepostId) {
        const res = await fetch(`/api/vx/posts/${myRepostId}`, { method: 'DELETE' })
        if (!res.ok) throw new Error()
        setMyRepostId(null)
        toast({ title: 'Đã bỏ đăng lại bài viết' })
      } else {
        const res = await fetch('/api/vx/posts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ repostOfId: post.id }) })
        const d = await res.json()
        if (!res.ok) throw new Error(d.error)
        setMyRepostId(d.id)
        onReposted?.(d as PostT)
        toast({ title: 'Đã đăng lại lên trang cá nhân của bạn' })
      }
    } catch {
      toast({ title: myRepostId ? 'Không bỏ đăng lại được' : 'Không đăng lại được bài viết', variant: 'destructive' })
    } finally { setRepostBusy(false) }
  }

  const menu = (
    <PopoverContent className="w-64 p-1.5" align="end">
      {isMine && (
        <button className={menuBtn} onClick={() => { setMenuOpen(false); setEditText(post.content); setEditLoc(post.location || ''); setEditOpen(true) }} aria-label="Chỉnh sửa bài viết">
          <PenLine className="h-4 w-4 text-stone-500" /> Chỉnh sửa bài viết
        </button>
      )}
      {isMine && (
        <button className={`${menuBtn} text-red-600 hover:bg-red-50`} onClick={async () => {
          setMenuOpen(false)
          if (!window.confirm('Xoá bài viết này?')) return
          const res = await fetch(`/api/vx/posts/${post.id}`, { method: 'DELETE' })
          if (res.ok) { toast({ title: 'Bài viết đã được chuyển vào thùng rác' }); onDeleted?.(post.id) }
          else toast({ title: 'Xoá thất bại', variant: 'destructive' })
        }} aria-label="Xoá bài viết">
          <Trash2 className="h-4 w-4" /> Xoá bài viết
        </button>
      )}
      <button className={menuBtn} onClick={() => toggleFlag('saved')} aria-label="Lưu bài viết">
        <Bookmark className={`h-4 w-4 ${saved ? 'fill-emerald-600 text-emerald-600' : 'text-stone-500'}`} /> {saved ? 'Bỏ lưu bài viết' : 'Lưu bài viết'}
      </button>
      <button className={menuBtn} onClick={() => toggleFlag('notified')} aria-label="Bật thông báo bài viết">
        <Bell className={`h-4 w-4 ${notified ? 'fill-amber-400 text-amber-500' : 'text-stone-500'}`} /> {notified ? 'Tắt thông báo cho bài viết này' : 'Bật thông báo cho bài viết này'}
      </button>
      {isMine && context !== 'archive' && (
        <button className={menuBtn} onClick={() => archivePost(false)} aria-label="Chuyển vào kho lưu trữ">
          <Archive className="h-4 w-4 text-stone-500" /> Chuyển vào kho lưu trữ
        </button>
      )}
      {context === 'archive' && (
        <button className={menuBtn} onClick={() => archivePost(true)} aria-label="Bỏ lưu trữ, đăng lại lên Bảng tin">
          <ArchiveRestore className="h-4 w-4 text-emerald-600" /> Bỏ lưu trữ
        </button>
      )}
      {!isMine && (
        <button className={menuBtn} onClick={hidePost} aria-label="Ẩn bài viết">
          <EyeOff className="h-4 w-4 text-stone-500" /> Ẩn bài viết
        </button>
      )}
      {!isMine && (
        <button className={`${menuBtn} text-red-600 hover:bg-red-50`} onClick={() => { setMenuOpen(false); toast({ title: 'Đã gửi báo cáo, Cảm ơn bạn đã cho chúng tôi biết' }) }} aria-label="Báo cáo bài viết">
          <FlagTriangleRight className="h-4 w-4" /> Báo cáo bài viết
        </button>
      )}
    </PopoverContent>
  )

  return (
    <Card className={post.isAnnouncement ? 'border-amber-300 bg-amber-50/60' : ''}>
      <CardContent className="p-4">
        {post.isAnnouncement && (
          <p className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-amber-700"><Megaphone className="h-3.5 w-3.5" /> Thông báo chính thức từ Ban Giám đốc</p>
        )}
        <div className="flex items-center gap-3">
          <button onClick={() => onOpenProfile?.(post.author.id)} aria-label={`Xem hồ sơ ${post.page?.name || post.author.fullName}`} className="rounded-full outline-none ring-offset-2 focus-visible:ring-2 focus-visible:ring-emerald-500">
            {post.page?.avatar ? (
              <img src={post.page.avatar} alt="" className="h-10 w-10 rounded-full border object-cover" />
            ) : post.page?.category === 'Thú cưng' ? (
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-orange-500 text-white"><PawPrint className="h-5 w-5" /></span>
            ) : post.page ? (
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 font-black text-white">{post.page.name.charAt(0)}</span>
            ) : (
              <Avatar name={post.author.fullName} color={post.author.avatarColor} size={40} />
            )}
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold">
              <button className="hover:underline" onClick={() => onOpenProfile?.(post.author.id)}>
                {post.page ? post.page.name : post.author.fullName}
              </button>
              {post.page && <BadgeCheck className="ml-1 inline h-3.5 w-3.5 text-sky-500" />}
              {post.page?.category === 'Thú cưng'
                ? <span className="ml-1 inline-flex items-center gap-0.5 rounded bg-amber-100 px-1.5 py-0.5 text-[9px] font-semibold text-amber-700"><PawPrint className="h-2.5 w-2.5" />Trang thú cưng</span>
                : post.page && <span className="ml-1 rounded bg-stone-100 px-1.5 py-0.5 text-[9px] font-medium text-stone-500">Trang</span>}
              {!post.page && post.author.accountType === 'business' && <Badge className="ml-1.5 inline bg-amber-600 px-1.5 text-[9px] text-white hover:bg-amber-600">DN</Badge>}
              {post.repostOf && (
                <span className="ml-1.5 inline-flex items-center gap-0.5 rounded bg-emerald-50 px-1.5 py-0.5 align-[1px] text-[9px] font-semibold text-emerald-700"><Repeat2 className="h-3 w-3" />Đã đăng lại</span>
              )}
              {post.mentions.length > 0 && <span className="font-normal text-muted-foreground"> cùng với </span>}
              {post.mentions.map((m, i) => <span key={m.id} className="font-medium text-sky-600">{i > 0 && ', '}@{m.fullName}</span>)}
            </p>
            <p className="flex flex-wrap items-center text-xs text-muted-foreground">
              {timeAgo(post.createdAt)}, {visibilityOf(post.visibility).icon}
              <span className="font-medium text-stone-500">{visibilityOf(post.visibility).label}</span>
              <span className="mx-1">·</span>
              <span className="truncate">{post.page ? post.page.name : post.author.department}</span>
            </p>
          </div>
          {/* Menu ⋯ kiểu Facebook — thay 2 nút sửa/xoá rời rạc */}
          <Popover open={menuOpen} onOpenChange={setMenuOpen}>
            <PopoverTrigger asChild>
              <button className="rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground" aria-label="Tùy chọn bài viết">
                <MoreHorizontal className="h-5 w-5" />
              </button>
            </PopoverTrigger>
            {menu}
          </Popover>
        </div>

        {/* Nội dung */}
        {post.background ? (
          <div className="mt-3 flex min-h-44 items-center justify-center rounded-lg p-6" style={{ backgroundImage: post.background }}>
            <p className="text-center text-xl font-bold leading-snug text-white drop-shadow">{post.content}</p>
          </div>
        ) : post.content ? (
          <div className="mt-2.5"><RichContent text={post.content} mentions={post.mentions} /></div>
        ) : null}
        {post.editedAt && <p className="mt-1 text-[11px] italic text-muted-foreground">Đã sửa</p>}

        {/* AI tóm tắt bài dài — chỉ hiện với bài trên 240 ký tự, không phải nền màu */}
        {!post.background && post.content && post.content.length > 240 && (
          <div className="mt-2">
            {aiSum ? (
              <div className="rounded-lg border border-teal-200 bg-teal-50/70 p-2.5 text-xs leading-relaxed text-teal-900">
                <p className="flex items-start gap-1.5"><Wand2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-teal-600" /><span><b>AI tóm tắt:</b> {aiSum}</span></p>
                <button className="mt-1.5 text-[11px] font-medium text-teal-700 hover:underline" onClick={() => setAiSum(null)} aria-label="Ẩn tóm tắt AI">Ẩn tóm tắt</button>
              </div>
            ) : (
              <button onClick={aiSummarize} disabled={aiSumBusy} className="flex items-center gap-1 rounded-full border border-teal-200 bg-white px-2.5 py-1 text-[11px] font-semibold text-teal-700 transition-colors hover:bg-teal-50 disabled:opacity-60" aria-label="AI tóm tắt bài viết dài">
                {aiSumBusy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Wand2 className="h-3 w-3" />} {aiSumBusy ? 'AI đang đọc...' : 'AI tóm tắt bài dài'}
              </button>
            )}
          </div>
        )}
        {post.location && <p className="mt-2 flex items-center gap-1 text-xs text-muted-foreground"><MapPin className="h-3.5 w-3.5 text-rose-500" /> {post.location}</p>}

        {post.images.length > 0 && (
          <div className={`mt-3 grid gap-1 overflow-hidden rounded-lg bg-stone-100 ${post.images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
            {/* Ảnh bài đăng hiển thị FULL đúng tỉ lệ gốc (object-contain) — không cắt xén, chỉ nén dung lượng khi upload */}
            {post.images.map((img, i) => (isGradMedia(img) ? <GradMedia key={i} value={img} className="h-44 w-full" /> : <img key={i} src={img} alt={`Ảnh ${i + 1} của bài viết`} className={`w-full object-contain ${post.images.length === 1 ? 'max-h-[560px]' : 'max-h-64'}`} />))}
          </div>
        )}
        {post.videoUrl && <video src={post.videoUrl} controls className="mt-3 max-h-96 w-full rounded-lg bg-black" />}
        {post.fileName && (
          <a href={post.fileUrl || undefined} download={post.fileUrl ? post.fileName : undefined} className="mt-3 flex items-center gap-3 rounded-lg border bg-muted/40 p-3 hover:bg-muted">
            <div className="flex h-9 w-9 items-center justify-center rounded-md bg-sky-100"><Paperclip className="h-4 w-4 text-sky-700" /></div>
            <div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{post.fileName}</p><p className="text-xs text-muted-foreground">{post.fileUrl ? 'Bấm để tải file đính kèm' : 'Tài liệu đính kèm'}</p></div>
          </a>
        )}

        {/* BÀI GỐC đính kèm khi được Đăng lại (kiểu TikTok) */}
        {post.repostOf && (
          <div className="mt-3 overflow-hidden rounded-xl border bg-muted/30">
            <button className="block w-full text-left outline-none focus-visible:ring-2 focus-visible:ring-emerald-500" onClick={() => onOpenProfile?.(post.repostOf!.author.id)} aria-label={`Xem bài gốc của ${post.repostOf.page?.name || post.repostOf.author.fullName}`}>
              <div className="flex items-center gap-2.5 p-3 pb-2">
                {post.repostOf.page?.avatar ? (
                  <img src={post.repostOf.page.avatar} alt="" className="h-8 w-8 rounded-full border object-cover" />
                ) : post.repostOf.page ? (
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-xs font-black text-white">{post.repostOf.page.name.charAt(0)}</span>
                ) : (
                  <Avatar name={post.repostOf.author.fullName} color={post.repostOf.author.avatarColor} size={32} />
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-semibold">{post.repostOf.page ? post.repostOf.page.name : post.repostOf.author.fullName}</p>
                  <p className="text-[11px] text-muted-foreground">{timeAgo(post.repostOf.createdAt)}</p>
                </div>
              </div>
              {post.repostOf.background ? (
                <div className="mx-3 flex min-h-28 items-center justify-center rounded-lg p-4" style={{ backgroundImage: post.repostOf.background }}>
                  <p className="whitespace-pre-wrap text-center text-sm font-bold text-white drop-shadow">{post.repostOf.content}</p>
                </div>
              ) : post.repostOf.content ? (
                <p className="whitespace-pre-wrap break-words px-3 pb-2 text-sm">{post.repostOf.content}</p>
              ) : null}
              {post.repostOf.images.length > 0 && (
                <div className={`grid gap-0.5 px-3 pb-3 ${post.repostOf.images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
                  {post.repostOf.images.slice(0, 2).map((img, i) => (isGradMedia(img) ? <GradMedia key={i} value={img} className="h-32 w-full" /> : <img key={i} src={img} alt={`Ảnh bài gốc ${i + 1}`} className="max-h-56 w-full bg-stone-100 object-contain" />))}
                </div>
              )}
              {post.repostOf.videoUrl && <video src={post.repostOf.videoUrl} controls className="mx-3 mb-3 max-h-60 w-[calc(100%-24px)] rounded-lg bg-black" />}
            </button>
          </div>
        )}

        {/* Đếm reaction + comment */}
        <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            {topReactions.length > 0 && (
              <>
                <span className="flex -space-x-1">{topReactions.map((r) => <span key={r.type} className="flex h-5 w-5 items-center justify-center rounded-full border bg-white"><ReactionIcon type={r.type} className="h-3.5 w-3.5" /></span>)}</span>
                {totalReactions}
              </>
            )}
          </span>
          <span>
            <button className="hover:underline" onClick={() => setShowComments(true)}>{post.commentCount} bình luận</button>
          </span>
        </div>

        {/* Thanh hành động: Thích, Bình luận, ĐĂNG LẠI (TikTok), Chia sẻ */}
        <div className="mt-1.5 grid grid-cols-4 gap-1 border-t pt-1.5">
          <Popover open={pickerOpen} onOpenChange={setPickerOpen}>
            <PopoverTrigger asChild>
              <button className="flex items-center justify-center gap-1.5 rounded-md py-2 text-sm font-medium transition-colors hover:bg-muted" style={myR ? { color: myR.color } : undefined} aria-label="Thả cảm xúc">
                <span className="text-base leading-none">{myR ? <ReactionIcon type={myR.type} className="h-[18px] w-[18px]" /> : <ThumbsUp className="h-4.5 w-4.5" />}</span>
                {myR ? myR.label : 'Thích'}
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-1.5" side="top" align="start">
              <div className="flex gap-0.5">
                {REACTIONS.map((r) => (
                  <button key={r.type} onClick={() => react(r.type)} title={r.label} className="rounded-full p-1 transition-transform hover:scale-125 hover:bg-muted" aria-label={`Cảm xúc ${r.label}`}><ReactionIcon type={r.type} className="h-7 w-7" /></button>
                ))}
              </div>
            </PopoverContent>
          </Popover>
          <button className="flex items-center justify-center gap-1.5 rounded-md py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted" onClick={() => setShowComments(!showComments)} aria-label="Bình luận">
            <MessageCircle className="h-4 w-4" /> Bình luận
          </button>
          <button
            className={`flex items-center justify-center gap-1.5 rounded-md py-2 text-sm font-medium transition-colors hover:bg-muted ${myRepostId ? 'text-emerald-600' : 'text-muted-foreground'}`}
            onClick={toggleRepost}
            disabled={repostBusy}
            aria-label={myRepostId ? 'Bỏ đăng lại bài viết' : 'Đăng lại bài viết lên trang cá nhân'}
          >
            {repostBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Repeat2 className={`h-4.5 w-4.5 ${myRepostId ? 'fill-emerald-100' : ''}`} />}
            {myRepostId ? 'Đã đăng lại' : 'Đăng lại'}
          </button>
          <button className="flex items-center justify-center gap-1.5 rounded-md py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted" onClick={() => setShareOpen(true)} aria-label="Chia sẻ">
            <Share2 className="h-4 w-4" /> Chia sẻ
          </button>
        </div>

        {/* Hộp chia sẻ kiểu Zalo: liên kết, trang cá nhân, tin nhắn, ứng dụng khác */}
        <ShareSheet
          open={shareOpen}
          onOpenChange={setShareOpen}
          post={{ id: post.id, content: post.content, author: { id: post.author.id, fullName: post.author.fullName } }}
          onCreated={(np) => onReposted?.(np)}
        />

        {showComments && <CommentSection me={me} postId={post.id} postAuthorId={post.author.id} comments={post.comments} onCommented={(c) => onCommented(post.id, c)} onEdited={(cid, content, at) => onCommentEdited(post.id, cid, content, at)} onDeleted={(cid) => onCommentDeleted(post.id, cid)} />}

        {/* Dialog sửa bài viết — tích hợp theo TTO (bài của tôi có nút sửa) */}
        <Dialog open={editOpen} onOpenChange={setEditOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader><DialogTitle className="flex items-center gap-2"><PenLine className="h-4.5 w-4.5 text-sky-600" /> Sửa bài viết</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <Textarea
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                rows={5}
                maxLength={3000}
                placeholder="Nội dung bài viết..."
                aria-label="Sửa nội dung bài viết"
              />
              <Input value={editLoc} onChange={(e) => setEditLoc(e.target.value)} placeholder="Vị trí (không bắt buộc)" aria-label="Sửa vị trí bài viết" />
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setEditOpen(false)}>Huỷ</Button>
                <Button
                  className="bg-emerald-600 hover:bg-emerald-700"
                  disabled={savingEdit || (!editText.trim() && !editLoc.trim() && !post.content && post.images.length === 0)}
                  onClick={async () => {
                    setSavingEdit(true)
                    try {
                      const res = await fetch(`/api/vx/posts/${post.id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ content: editText.trim(), location: editLoc.trim() || null }),
                      })
                      const d = await res.json()
                      if (!res.ok) throw new Error(d.error)
                      onEdited?.(post.id, d.content, d.location)
                      setEditOpen(false)
                      toast({ title: 'Đã lưu bài viết' })
                    } catch (e) {
                      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không sửa được bài', variant: 'destructive' })
                    } finally { setSavingEdit(false) }
                  }}
                >
                  {savingEdit ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Check className="mr-1 h-4 w-4" />} Lưu thay đổi
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}

// ============ HỘP CHIA SẺ (KIỂU ZALO) ============
// 4 lựa chọn: Chia sẻ liên kết, Chia sẻ lên trang cá nhân, Gửi trong tin nhắn, Chia sẻ cho ứng dụng khác
export function ShareSheet({ open, onOpenChange, post, onCreated }: {
  open: boolean
  onOpenChange: (v: boolean) => void
  post: { id: string; content: string; author: { id: string; fullName: string } }
  onCreated?: (p: PostT) => void
}) {
  const { toast } = useToast()
  const [step, setStep] = useState<'menu' | 'caption' | 'picker'>('menu')
  const [caption, setCaption] = useState('')
  const [busy, setBusy] = useState(false)
  const [convs, setConvs] = useState<ConvLite[]>([])
  const [convsLoaded, setConvsLoaded] = useState(false)
  const [convSearch, setConvSearch] = useState('')
  const [url, setUrl] = useState('')

  useEffect(() => {
    if (open) {
      setUrl(`${window.location.origin}/post/${post.id}`)
      setStep('menu')
      setCaption('')
      setConvSearch('')
    }
  }, [open, post.id])

  // Nạp hội thoại cho bước "Gửi trong tin nhắn" (bỏ các hội thoại đã ẩn)
  useEffect(() => {
    if (open && step === 'picker' && !convsLoaded) {
      fetch('/api/vx/conversations')
        .then((r) => r.json())
        .then((d) => setConvs(Array.isArray(d) ? d.filter((c: ConvLite) => !c.hidden) : []))
        .catch(() => setConvs([]))
        .finally(() => setConvsLoaded(true))
    }
  }, [open, step, convsLoaded])

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(url)
      toast({ title: 'Đã sao chép liên kết bài viết' })
    } catch {
      toast({ title: 'Không sao chép được liên kết', variant: 'destructive' })
    }
    onOpenChange(false)
  }

  // Chia sẻ lên trang cá nhân = tạo bài mới trên tường tôi, đính kèm bài gốc (có thể kèm ý kiến)
  const shareToProfile = async () => {
    setBusy(true)
    try {
      const res = await fetch('/api/vx/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: caption.trim(), repostOfId: post.id }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      onCreated?.(d as PostT)
      toast({ title: 'Đã chia sẻ lên trang cá nhân của bạn' })
      onOpenChange(false)
    } catch (e) {
      toast({ title: 'Không chia sẻ được', description: e instanceof Error ? e.message : 'Thử lại nhé', variant: 'destructive' })
    } finally { setBusy(false) }
  }

  // Gửi bài viết vào hội thoại dưới dạng tin nhắn kèm liên kết
  const shareMsg = post.author.fullName ? `Xem bài viết của ${post.author.fullName}: ${url}` : `Xem bài viết: ${url}`
  const sendToConv = async (c: ConvLite) => {
    setBusy(true)
    try {
      const res = await fetch(`/api/vx/conversations/${c.id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: shareMsg }),
      })
      if (!res.ok) throw new Error()
      toast({ title: `Đã gửi tới ${c.name}` })
      onOpenChange(false)
    } catch {
      toast({ title: 'Không gửi được tin nhắn', variant: 'destructive' })
    } finally { setBusy(false) }
  }

  // Chia sẻ cho ứng dụng khác: Web Share API, không hỗ trợ thì sao chép liên kết
  const shareOtherApps = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({ title: 'Vexon', text: post.content ? post.content.slice(0, 80) : 'Xem bài viết này trên Vexon', url })
      } catch { /* người dùng huỷ chia sẻ */ }
      onOpenChange(false)
    } else {
      try {
        await navigator.clipboard.writeText(url)
        toast({ title: 'Thiết bị không hỗ trợ chia sẻ ngoài, đã sao chép liên kết' })
      } catch {
        toast({ title: 'Không chia sẻ được', variant: 'destructive' })
      }
      onOpenChange(false)
    }
  }

  const optBtn = 'flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted/70'
  const iconDot = 'flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-white'
  const filteredConvs = convs.filter((c) => c.name.toLowerCase().includes(convSearch.trim().toLowerCase()))

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="gap-0 overflow-hidden rounded-2xl p-0 sm:max-w-md">
        <DialogHeader className="flex flex-row items-center gap-2 space-y-0 border-b p-3">
          {step !== 'menu' && (
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setStep('menu')} aria-label="Quay lại danh sách chia sẻ"><ChevronLeft className="h-4 w-4" /></Button>
          )}
          <DialogTitle className="text-base font-bold">
            {step === 'menu' ? 'Chia sẻ' : step === 'caption' ? 'Chia sẻ lên trang cá nhân' : 'Gửi trong tin nhắn'}
          </DialogTitle>
        </DialogHeader>

        {step === 'menu' && (
          <div className="max-h-[60vh] overflow-y-auto p-2">
            <p className="mx-1 mb-1 truncate rounded-lg bg-muted/50 px-3 py-2 text-[11px] text-muted-foreground">{url}</p>
            <button className={optBtn} onClick={copyLink} aria-label="Chia sẻ liên kết bài viết">
              <span className={`${iconDot} bg-sky-500`}><Link2 className="h-5 w-5" /></span>
              <span className="flex-1 text-left">Chia sẻ liên kết</span>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
            <button className={optBtn} onClick={() => setStep('caption')} aria-label="Chia sẻ lên trang cá nhân">
              <span className={`${iconDot} bg-gradient-to-br from-emerald-500 to-teal-600`}><CircleUserRound className="h-5 w-5" /></span>
              <span className="flex-1 text-left">Chia sẻ lên trang cá nhân</span>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
            <button className={optBtn} onClick={() => setStep('picker')} aria-label="Gửi bài viết trong tin nhắn">
              <span className={`${iconDot} bg-indigo-500`}><Send className="h-5 w-5" /></span>
              <span className="flex-1 text-left">Gửi trong tin nhắn</span>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
            <button className={optBtn} onClick={shareOtherApps} aria-label="Chia sẻ cho ứng dụng khác">
              <span className={`${iconDot} bg-violet-500`}><Share2 className="h-5 w-5" /></span>
              <span className="flex-1 text-left">Chia sẻ cho ứng dụng khác</span>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
          </div>
        )}

        {step === 'caption' && (
          <div className="space-y-3 p-4">
            <p className="text-xs text-muted-foreground">Bài gốc sẽ được đính kèm trên trang cá nhân của bạn, kèm ý kiến nếu bạn muốn.</p>
            <Textarea value={caption} onChange={(e) => setCaption(e.target.value)} rows={3} maxLength={1000} placeholder="Viết ý kiến của bạn (không bắt buộc)..." aria-label="Ý kiến khi chia sẻ" />
            <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={shareToProfile} disabled={busy} aria-label="Xác nhận chia sẻ lên trang cá nhân">
              {busy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Share2 className="mr-1 h-4 w-4" />} Chia sẻ
            </Button>
          </div>
        )}

        {step === 'picker' && (
          <div className="p-2">
            <div className="relative px-1 pb-2">
              <Search className="absolute left-3.5 top-3.5 h-4 w-4 text-muted-foreground" />
              <Input value={convSearch} onChange={(e) => setConvSearch(e.target.value)} placeholder="Tìm hội thoại..." className="pl-8" aria-label="Tìm hội thoại để gửi bài viết" />
            </div>
            <div className="max-h-[46vh] overflow-y-auto">
              {!convsLoaded ? (
                <div className="space-y-2 p-2">
                  {[1, 2, 3].map((i) => <Skeleton key={i} className="h-12 w-full rounded-xl" />)}
                </div>
              ) : filteredConvs.length === 0 ? (
                <p className="px-4 py-8 text-center text-xs text-muted-foreground">Chưa có hội thoại nào, hãy kết bạn và nhắn tin trước nhé</p>
              ) : (
                filteredConvs.map((c) => (
                  <button key={c.id} className="flex w-full items-center gap-3 rounded-xl p-2 text-left transition-colors hover:bg-muted/70" onClick={() => sendToConv(c)} disabled={busy} aria-label={`Gửi bài viết tới ${c.name}`}>
                    {c.isGroup ? (
                      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white"><Users2 className="h-5 w-5" /></span>
                    ) : (
                      <Avatar name={c.name} color={c.partner?.avatarColor || '#94a3b8'} size={44} />
                    )}
                    <span className="min-w-0 flex-1 truncate text-sm font-semibold">{c.name}</span>
                    <Send className="h-4 w-4 shrink-0 text-emerald-600" />
                  </button>
                ))
              )}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

// ============ BÀI VIẾT ĐÃ LƯU + KHO LƯU TRỮ (KIỂU FACEBOOK) ============
function SavedCollectionsDialog({ me, open, onOpenChange, onOpenProfile }: {
  me: VxUserInfo
  open: boolean
  onOpenChange: (v: boolean) => void
  onOpenProfile?: (userId: string) => void
}) {
  const [sub, setSub] = useState<'saved' | 'archive'>('saved')
  const [list, setList] = useState<PostT[]>([])
  const [loading, setLoading] = useState(false)

  const load = useCallback((which: 'saved' | 'archive') => {
    setLoading(true)
    fetch(`/api/vx/posts?tab=${which}`)
      .then((r) => r.json())
      .then((d) => setList(Array.isArray(d) ? d : []))
      .catch(() => setList([]))
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(() => {
    if (open) load(sub)
  }, [open, sub, load])

  const upd = (id: string, fn: (p: PostT) => PostT) => setList((ps) => ps.map((p) => (p.id === id ? fn(p) : p)))
  const remove = (id: string) => setList((ps) => ps.filter((p) => p.id !== id))

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Bookmark className="h-4.5 w-4.5 text-emerald-600" />
            Bài viết của tôi
          </DialogTitle>
        </DialogHeader>

        {/* Hai mục: Đã lưu, Kho lưu trữ — kiểu Facebook */}
        <div className="flex gap-2">
          <button
            onClick={() => setSub('saved')}
            className={`flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-sm font-medium transition-colors ${sub === 'saved' ? 'bg-emerald-600 text-white shadow' : 'bg-stone-100 text-stone-600 hover:bg-emerald-50'}`}
            aria-label="Bài viết đã lưu"
          >
            <Bookmark className="h-4 w-4" /> Đã lưu
          </button>
          <button
            onClick={() => setSub('archive')}
            className={`flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-sm font-medium transition-colors ${sub === 'archive' ? 'bg-emerald-600 text-white shadow' : 'bg-stone-100 text-stone-600 hover:bg-emerald-50'}`}
            aria-label="Kho lưu trữ"
          >
            <Archive className="h-4 w-4" /> Kho lưu trữ
          </button>
        </div>

        {loading ? (
          <div className="space-y-3 py-4">
            <Skeleton className="h-20 w-full rounded-xl" />
            <Skeleton className="h-20 w-full rounded-xl" />
          </div>
        ) : list.length === 0 ? (
          <p className="rounded-xl border border-dashed bg-white p-8 text-center text-sm text-muted-foreground">
            {sub === 'saved'
              ? 'Chưa có bài viết nào được lưu, bấm ... trên bài rồi chọn "Lưu bài viết".'
              : 'Kho lưu trữ trống, bấm ... trên bài của bạn rồi chọn "Chuyển vào kho lưu trữ".'}
          </p>
        ) : (
          <div className="space-y-4">
            {list.map((p) => (
              <PostCard
                key={p.id}
                me={me}
                post={p}
                context={sub}
                onOpenProfile={onOpenProfile}
                onReacted={(id, d) => upd(id, (pp) => ({ ...pp, myReaction: d.myReaction, reactions: d.reactions }))}
                onEdited={(id, content, location) => upd(id, (pp) => ({ ...pp, content, location, editedAt: new Date().toISOString() }))}
                onDeleted={remove}
                onFlagSaved={(id, savedNow) => { if (sub === 'saved' && !savedNow) remove(id) }}
                onRemoved={remove}
                onCommented={(postId, c) => upd(postId, (pp) => {
                  const comments = c.parentId
                    ? pp.comments.map((root) => (root.id === c.parentId ? { ...root, replies: [...root.replies, c] } : root))
                    : [...pp.comments, c]
                  return { ...pp, comments, commentCount: pp.commentCount + 1 }
                })}
                onCommentEdited={(postId, cid, content, at) => upd(postId, (pp) => ({
                  ...pp,
                  comments: pp.comments.map((root) => (root.id === cid ? { ...root, content, editedAt: at } : { ...root, replies: root.replies.map((r) => (r.id === cid ? { ...r, content, editedAt: at } : r)) })),
                }))}
                onCommentDeleted={(postId, cid) => upd(postId, (pp) => {
                  const strip = (cs: CommentT[]): CommentT[] => cs.filter((c) => c.id !== cid).map((c) => ({ ...c, replies: strip(c.replies) }))
                  const find = (cs: CommentT[]): CommentT | null => {
                    for (const c of cs) { if (c.id === cid) return c; const r = find(c.replies); if (r) return r }
                    return null
                  }
                  const target = find(pp.comments)
                  const removed = target ? 1 + target.replies.length : 1
                  return { ...pp, comments: strip(pp.comments), commentCount: Math.max(0, pp.commentCount - removed) }
                })}
              />
            ))}
          </div>
        )}
        {!loading && list.length > 0 && (
          <p className="text-center text-[11px] text-muted-foreground">{sub === 'saved' ? 'Bài đã lưu được lưu riêng cho tài khoản của bạn' : 'Bài trong kho lưu trữ chỉ bạn nhìn thấy'}</p>
        )}
      </DialogContent>
    </Dialog>
  )
}

// ============ COMMENTS ============
function CommentSection({ me, postId, postAuthorId, comments, onCommented, onEdited, onDeleted }: { me: VxUserInfo; postId: string; postAuthorId: string; comments: CommentT[]; onCommented: (c: CommentT) => void; onEdited: (commentId: string, content: string, editedAt: string) => void; onDeleted: (commentId: string) => void }) {
  const rate = useUsdRate() // tỷ giá sống — thưởng bình luận quy USD
  const { toast } = useToast()
  const [text, setText] = useState('')
  const [replyTo, setReplyTo] = useState<CommentT | null>(null)
  const [stickerOpen, setStickerOpen] = useState(false)
  const [image, setImage] = useState<string | null>(null)
  const [recording, setRecording] = useState<number | null>(null)
  const recRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const send = async (extra?: Partial<{ sticker: string; imageUrl: string; audioDur: number }>) => {
    const payload = { content: text.trim(), parentId: replyTo?.id || null, ...extra }
    if (!payload.content && !payload.sticker && !payload.imageUrl && !payload.audioDur) return
    const res = await fetch(`/api/vx/posts/${postId}/comments`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    if (res.ok) {
      const d = await res.json()
      onCommented(d)
      if (d.reward > 0) {
        toast({ title: `Bình luận +${fmtUsdFromXu(d.reward, rate)} vào ví` })
        window.dispatchEvent(new Event('vx-coins-changed'))
      }
      setText(''); setImage(null); setReplyTo(null)
    }
  }

  const startRec = () => {
    setRecording(0)
    recRef.current = setInterval(() => setRecording((s) => (s === null ? 0 : s + 1)), 1000)
  }
  const stopRec = async (sendIt: boolean) => {
    if (recRef.current) clearInterval(recRef.current)
    const dur = recording || 1
    setRecording(null)
    if (sendIt) await send({ audioDur: Math.max(1, dur) })
  }

  return (
    <div className="mt-3 space-y-3 rounded-xl bg-muted/50 p-3">
      {comments.map((c) => (
        <div key={c.id} className="space-y-2">
          <CommentItem me={me} postId={postId} postAuthorId={postAuthorId} comment={c} onReply={() => setReplyTo(c)} onEdited={onEdited} onDeleted={onDeleted} />
          {c.replies.map((r) => (
            <div key={r.id} className="ml-9 space-y-2 border-l-2 border-muted pl-3">
              <p className="flex items-center gap-1 text-[10px] text-muted-foreground"><CornerDownRight className="h-3 w-3" /> {r.user.fullName} đã trả lời</p>
              <CommentItem me={me} postId={postId} postAuthorId={postAuthorId} comment={r} onReply={() => setReplyTo(c)} onEdited={onEdited} onDeleted={onDeleted} />
            </div>
          ))}
        </div>
      ))}
      {comments.length === 0 && <p className="py-1 text-center text-xs text-muted-foreground">Chưa có bình luận, hãy là người đầu tiên!</p>}

      {/* Ô soạn bình luận */}
      <div className="space-y-1.5">
        {replyTo && (
          <p className="flex items-center gap-1 text-xs text-muted-foreground">
            Đang trả lời <b className="text-foreground">{replyTo.user.fullName}</b>
            <button onClick={() => setReplyTo(null)} aria-label="Bỏ trả lời"><X className="h-3 w-3" /></button>
          </p>
        )}
        {image && (
          <div className="relative w-fit"><img src={image} alt="Ảnh sẽ gửi" className="h-16 rounded-md" /><button className="absolute -right-1.5 -top-1.5 rounded-full bg-black/70 p-0.5 text-white" onClick={() => setImage(null)} aria-label="Bỏ ảnh"><X className="h-3 w-3" /></button></div>
        )}
        <div className="flex items-center gap-1.5">
          <Avatar name={me.fullName} color={me.avatarColor} size={28} />
          {recording === null ? (
            <>
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && send()}
                placeholder="Viết bình luận..."
                className="flex-1 rounded-full border bg-background px-3.5 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-500/40"
                aria-label="Nội dung bình luận"
              />
              <Popover open={stickerOpen} onOpenChange={setStickerOpen}>
                <PopoverTrigger asChild><button className="rounded-full p-2 text-muted-foreground hover:bg-muted" aria-label="Chọn sticker/GIF"><Smile className="h-5 w-5" /></button></PopoverTrigger>
                <PopoverContent className="w-56 p-2" side="top" align="end">
                  <p className="mb-1 text-[10px] font-semibold text-muted-foreground">STICKER / GIF</p>
                  <div className="grid grid-cols-6 gap-1">
                    {STICKERS.map((s) => (
                      <button key={s.key} className="rounded p-0.5 hover:bg-muted hover:scale-110" onClick={() => { setStickerOpen(false); send({ sticker: s.key }) }} aria-label={`Gửi sticker ${s.label}`}>
                        <StickerStamp content={s.key} size={32} className="w-full" />
                      </button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
              <label className="cursor-pointer rounded-full p-2 text-muted-foreground hover:bg-muted" aria-label="Gửi ảnh vào bình luận">
                <ImageIcon className="h-5 w-5" />
                <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                  const f = e.target.files?.[0]
                  if (!f) return
                  if (f.size > 1_500_000) return
                  setImage(await readFileAsDataURL(f))
                }} />
              </label>
              <button className="rounded-full p-2 text-muted-foreground hover:bg-muted" onClick={startRec} aria-label="Gửi icon audio"><Mic className="h-5 w-5" /></button>
              <Button size="icon" className="h-9 w-9 shrink-0 rounded-full bg-emerald-600 hover:bg-emerald-700" onClick={() => send()} disabled={!text.trim() && !image} aria-label="Gửi bình luận"><Send className="h-4 w-4" /></Button>
            </>
          ) : (
            <>
              <span className="flex flex-1 items-center gap-2 text-sm text-red-600"><span className="h-2.5 w-2.5 animate-pulse rounded-full bg-red-500" /> Đang ghi audio... {recording}s</span>
              <Button size="sm" variant="outline" onClick={() => stopRec(false)}>Huỷ</Button>
              <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => stopRec(true)}>Gửi audio</Button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

function CommentItem({ me, postId, postAuthorId, comment, onReply, onEdited, onDeleted }: {
  me: VxUserInfo; postId: string; postAuthorId: string; comment: CommentT; onReply: () => void
  onEdited: (commentId: string, content: string, editedAt: string) => void
  onDeleted: (commentId: string) => void
}) {
  const [playing, setPlaying] = useState(false)
  const [editing, setEditing] = useState(false)
  const [editText, setEditText] = useState(comment.content)
  const [saving, setSaving] = useState(false)
  const { toast } = useToast()

  // Quyền kiểu Facebook: chủ bình luận sửa/xoá, chủ bài viết + Ban Giám đốc xoá
  const canEdit = comment.user.id === me.id && Boolean(comment.content)
  const canDelete = comment.user.id === me.id || postAuthorId === me.id || me.role === 'admin'

  const saveEdit = async () => {
    const content = editText.trim()
    if (!content) return
    setSaving(true)
    try {
      const res = await fetch(`/api/vx/posts/${postId}/comments/${comment.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không sửa được bình luận')
      onEdited(comment.id, d.content, d.editedAt || new Date().toISOString())
      setEditing(false)
      toast({ title: 'Đã sửa bình luận' })
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không sửa được bình luận', variant: 'destructive' })
    } finally { setSaving(false) }
  }

  const remove = async () => {
    if (!window.confirm('Xoá bình luận này?')) return
    try {
      const res = await fetch(`/api/vx/posts/${postId}/comments/${comment.id}`, { method: 'DELETE' })
      const d = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(d.error || 'Không xoá được bình luận')
      onDeleted(comment.id)
      toast({ title: 'Đã xoá bình luận' })
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không xoá được bình luận', variant: 'destructive' })
    }
  }

  return (
    <div className="group/comment flex items-start gap-2">
      <Avatar name={comment.user.fullName} color={comment.user.avatarColor} size={28} />
      <div className="min-w-0 flex-1">
        <div className="inline-block max-w-full rounded-2xl bg-background px-3 py-2 shadow-sm">
          <p className="text-xs font-semibold">{comment.user.fullName}</p>
          {editing ? (
            <div className="mt-1 space-y-1.5">
              <input
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && saveEdit()}
                autoFocus
                className="w-full rounded-full border bg-background px-3 py-1.5 text-sm outline-none focus:ring-2 focus:ring-emerald-500/40"
                aria-label="Sửa nội dung bình luận"
              />
              <div className="flex justify-end gap-1.5">
                <Button size="sm" variant="outline" className="h-7 px-2.5 text-xs" onClick={() => { setEditing(false); setEditText(comment.content) }}>Huỷ</Button>
                <Button size="sm" className="h-7 bg-emerald-600 px-2.5 text-xs hover:bg-emerald-700" onClick={saveEdit} disabled={saving || !editText.trim()}>
                  {saving ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <Check className="mr-1 h-3 w-3" />} Lưu
                </Button>
              </div>
            </div>
          ) : comment.sticker ? (
            <span className="inline-block py-1"><StickerStamp content={comment.sticker} size={56} /></span>
          ) : (
            <>
              {comment.content && <p className="break-words text-sm">{comment.content}</p>}
              {comment.imageUrl && (isGradMedia(comment.imageUrl) ? <GradMedia value={comment.imageUrl} className="mt-1 h-24 w-44 rounded-lg" /> : <img src={comment.imageUrl} alt="Ảnh bình luận" className="mt-1 max-h-40 rounded-lg" />)}
              {comment.audioDur && (
                <button className="mt-1 flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1.5" onClick={() => { setPlaying(true); setTimeout(() => setPlaying(false), 1200) }} aria-label="Phát audio bình luận">
                  {playing ? <Pause className="h-4 w-4 text-emerald-700" /> : <Play className="h-4 w-4 text-emerald-700" />}
                  <span className="flex items-end gap-0.5">{[3, 6, 4, 8, 5, 7, 4].map((h, i) => <span key={i} className={`w-0.5 rounded bg-emerald-600 ${playing ? 'animate-pulse' : ''}`} style={{ height: h * 1.6 }} />)}</span>
                  <span className="text-xs font-medium text-emerald-700">{comment.audioDur}&quot;</span>
                </button>
              )}
            </>
          )}
        </div>
        <p className="mt-0.5 flex items-center gap-2 pl-1 text-[10px] text-muted-foreground">
          {timeAgo(comment.createdAt)}
          {comment.editedAt && <i className="flex items-center gap-0.5"><PenLine className="h-3 w-3" /> Đã sửa</i>}
          <button className="font-medium hover:underline" onClick={onReply}>Trả lời</button>
          {canEdit && !editing && (
            <button className="font-medium opacity-0 transition-opacity hover:underline group-hover/comment:opacity-100" onClick={() => { setEditText(comment.content); setEditing(true) }}>Sửa</button>
          )}
          {canDelete && (
            <button className="font-medium text-red-500 opacity-0 transition-opacity hover:underline group-hover/comment:opacity-100" onClick={remove}>Xoá</button>
          )}
        </p>
      </div>
    </div>
  )
}

// ============ GỢI Ý KẾT BẠN NGẪU NHIÊN (KIỂU FACEBOOK) ============
function FriendSuggestions({ onOpenProfile }: { onOpenProfile?: (userId: string) => void }) {
  const { toast } = useToast()
  const [list, setList] = useState<SuggestionUser[]>([])
  const [hidden, setHidden] = useState<string[]>([])
  const [sent, setSent] = useState<string[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(() => {
    setLoading(true)
    fetch('/api/vx/friends/suggestions?n=8')
      .then((r) => r.json())
      .then((d) => Array.isArray(d) && setList(d))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(() => load(), [load])

  const add = async (u: SuggestionUser) => {
    const res = await fetch('/api/vx/friends', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: u.id }) })
    if (res.ok) {
      setSent((s) => [...s, u.id])
      toast({ title: `Đã gửi lời mời kết bạn tới ${u.fullName}` })
    } else {
      const d = await res.json().catch(() => ({}))
      toast({ title: d.error || 'Không gửi được lời mời', variant: 'destructive' })
      setSent((s) => [...s, u.id])
    }
  }

  const dismiss = (id: string) => setHidden((h) => [...h, id])
  const visible = list.filter((u) => !hidden.includes(u.id))
  if (loading || visible.length === 0) return null

  return (
    <section className="rounded-xl border bg-white p-3.5 shadow-sm">
      <div className="mb-2.5 flex items-center justify-between">
        <p className="flex items-center gap-1.5 text-sm font-bold text-stone-800"><UserPlus className="h-4 w-4 text-emerald-600" /> Gợi ý kết bạn</p>
        <button onClick={load} className="flex items-center gap-1 text-xs text-stone-500 hover:text-emerald-700" aria-label="Làm mới gợi ý"><RefreshCw className="h-3.5 w-3.5" /> Làm mới</button>
      </div>
      <div className="flex gap-3 overflow-x-auto pb-1">
        {visible.map((u) => (
          <div key={u.id} className="w-40 shrink-0 rounded-xl border bg-stone-50 text-center">
            <div className="h-12 rounded-t-xl bg-gradient-to-br from-emerald-400 to-teal-500" />
            <div className="-mt-7 px-2 pb-3">
              <button onClick={() => onOpenProfile?.(u.id)} className="rounded-full" aria-label={`Xem hồ sơ ${u.fullName}`}>
                <Avatar name={u.fullName} color={u.avatarColor} size={52} img={u.avatarImage} ring />
              </button>
              <p className="mt-1.5 truncate text-xs font-semibold text-stone-800">{u.fullName}</p>
              <p className="truncate text-[10px] text-stone-500">{u.reason}</p>
              {sent.includes(u.id) ? (
                <p className="mt-2 rounded-md bg-stone-200 py-1 text-[11px] font-medium text-stone-500">Đã gửi lời mời</p>
              ) : (
                <div className="mt-2 flex gap-1">
                  <Button size="sm" className="h-7 flex-1 bg-emerald-600 px-1 text-[11px] hover:bg-emerald-700" onClick={() => add(u)}><UserPlus className="mr-0.5 h-3 w-3" /> Kết bạn</Button>
                  <Button size="sm" variant="ghost" className="h-7 w-7 px-0 text-stone-400" onClick={() => dismiss(u.id)} aria-label={`Bỏ gợi ý ${u.fullName}`}><X className="h-3 w-3" /></Button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

interface SuggestionUser {
  id: string; username: string; fullName: string; avatarColor: string; avatarImage?: string | null
  department?: string; title?: string; online?: boolean; reason?: string
}
