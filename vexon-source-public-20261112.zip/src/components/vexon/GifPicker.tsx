'use client'

// ============ GIF HUB DÙNG CHUNG — tin nhắn · bình luận · bài viết ============
import { useEffect, useState } from 'react'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Input } from '@/components/ui/input'
import { Loader2, Clapperboard } from 'lucide-react'
import { searchGifs, type GifT } from '@/lib/gif'

export function GifPickerButton({ onPick, className, label = 'Gửi GIF' }: {
  onPick: (gif: GifT) => void
  className?: string
  label?: string
}) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const [gifs, setGifs] = useState<GifT[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!open) return
    let alive = true
    // debounce 350ms khi gõ; setTimeout cũng tránh setState đồng bộ trong effect
    const t = setTimeout(() => {
      setLoading(true)
      searchGifs(q)
        .then((g) => { if (alive) setGifs(g) })
        .catch(() => { if (alive) setGifs([]) })
        .finally(() => { if (alive) setLoading(false) })
    }, q ? 350 : 0)
    return () => { alive = false; clearTimeout(t) }
  }, [open, q])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button className={className || 'rounded-full p-2 text-violet-600 transition hover:bg-violet-50'} aria-label={label} title="GIF hub — gửi GIF vui">
          <Clapperboard className="h-5 w-5" />
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-2.5" side="top" align="start">
        <p className="mb-1.5 text-[10px] font-bold tracking-wide text-muted-foreground">🎞️ GIF HUB — TÌM &amp; GỬI</p>
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm GIF: chúc mừng, like, cười..." className="mb-2 h-8 text-sm" aria-label="Tìm GIF" />
        <div className="h-56 overflow-y-auto">
          {loading ? (
            <p className="flex items-center justify-center gap-2 py-10 text-xs text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Đang tải GIF...</p>
          ) : gifs.length === 0 ? (
            <p className="py-10 text-center text-xs text-muted-foreground">Không tìm thấy GIF nào</p>
          ) : (
            <div className="grid grid-cols-2 gap-1.5">
              {gifs.map((g) => (
                <button
                  key={g.id}
                  onClick={() => { onPick(g); setOpen(false) }}
                  className="overflow-hidden rounded-lg border bg-white transition hover:ring-2 hover:ring-emerald-400"
                  aria-label={`Chọn GIF ${g.title}`}
                >
                  <img src={g.url} alt={g.title} loading="lazy" className="h-28 w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>
        <p className="mt-1.5 text-[9px] text-muted-foreground">GIF hub dùng chung: tin nhắn · bình luận · bài viết</p>
      </PopoverContent>
    </Popover>
  )
}
