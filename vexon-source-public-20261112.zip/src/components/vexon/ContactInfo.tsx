'use client'

// ============ PHẦN LIÊN HỆ — SOLOWORKS BY VEXON ============
// Dùng chung cho footer index, footer Cửa hàng Vexon và footer Tiệm Ảnh AI.
// Trang Liên hệ riêng (sang trọng) nằm ở ContactPage.tsx — footer chỉ là lối vào.

import { Music2, Youtube, Phone, Mail, MapPin, ArrowRight } from 'lucide-react'

export const CONTACT = {
  brand: 'SoloWorks by Vexon',
  tiktok: 'TikTok',
  youtube: 'YouTube',
  zaloPhone: '+84 777 764 004',
  zaloTel: 'tel:+84777764004',
  zaloMe: 'https://zalo.me/84777764004',
  email: 'c-s@email.com',
  address: 'Thôn Yên Hóa, Xã Minh Hóa, Tỉnh Quảng Trị',
  tiktokUrl: 'https://www.tiktok.com/search?q=SoloWorks%20by%20Vexon',
  youtubeUrl: 'https://www.youtube.com/results?search_query=SoloWorks+by+Vexon',
  mapUrl: 'https://www.google.com/maps/search/?api=1&query=Th%C3%B4n+Y%C3%AAn+H%C3%B3a%2C+X%C3%A3+Minh+H%C3%B3a%2C+T%E1%BB%89nh+Qu%E1%BA%A3ng+Tr%E1%BB%8B',
}

/**
 * Khối liên hệ gọn cho footer. Truyền `onOpen` để biến dòng tiêu đề thành nút
 * mở trang Liên hệ riêng (ContactPage) — bấm vào là ra trang sang trọng.
 */
export function ContactInfo({ compact = false, onOpen }: { compact?: boolean; onOpen?: () => void }) {
  return (
    <div className={compact ? 'space-y-1 text-center sm:text-left' : 'space-y-2 text-center sm:text-left'}>
      <p className={`font-bold text-emerald-800 ${compact ? 'text-xs' : 'text-sm'}`}>
        {onOpen ? (
          <button
            onClick={onOpen}
            className="inline-flex items-center gap-1 rounded underline-offset-2 transition hover:underline"
            aria-label="Mở trang Liên hệ, SoloWorks by Vexon"
            title="Mở trang Liên hệ"
          >
            {CONTACT.brand}, Liên hệ <ArrowRight aria-hidden className="inline h-3.5 w-3.5" />
          </button>
        ) : (
          <>{CONTACT.brand}, Liên hệ</>
        )}
      </p>
      <div className={`flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-muted-foreground sm:justify-start ${compact ? 'text-[11px]' : 'text-xs'}`}>
        <span className="flex items-center gap-1" title="TikTok SoloWorks by Vexon">
          <Music2 className="h-3.5 w-3.5 text-stone-700" /> TikTok
        </span>
        <span className="flex items-center gap-1" title="YouTube SoloWorks by Vexon">
          <Youtube className="h-4 w-4 text-red-500" /> YouTube
        </span>
        <a href={CONTACT.zaloTel} className="flex items-center gap-1 transition-colors hover:text-emerald-700">
          <Phone className="h-3.5 w-3.5 text-sky-600" /> Zalo: <b className="font-semibold">{CONTACT.zaloPhone}</b>
        </a>
        <a href={`mailto:${CONTACT.email}`} className="flex items-center gap-1 transition-colors hover:text-emerald-700">
          <Mail className="h-3.5 w-3.5 text-amber-600" /> {CONTACT.email}
        </a>
        <span className="flex items-center gap-1">
          <MapPin className="h-3.5 w-3.5 text-rose-500" /> {CONTACT.address}
        </span>
      </div>
    </div>
  )
}
