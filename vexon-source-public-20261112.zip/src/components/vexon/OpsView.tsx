'use client'

import { useCallback, useMemo, useState } from 'react'
import { fmtXuWithUsd } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import type { VxUserInfo } from './AuthView'
import { Avatar, timeAgo } from './shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'sonner'
import {
  KanbanSquare, MailOpen, Wallet, Boxes, FolderOpen, CalendarClock, Lightbulb,
  ShieldAlert, UserCheck, Plane, Megaphone, Target, Plus, Loader2, Trash2,
  ChevronLeft, ChevronRight, ThumbsUp, CheckCircle2, XCircle, LayoutDashboard, Coins,
  MapPin, Clock,
} from 'lucide-react'

// ============ CẤU HÌNH 12 PHÂN HỆ QUẢN TRỊ ============

type RecordT = {
  id: string; type: string; title: string; description: string | null; status: string; priority: string
  assigneeId: string | null; assignee: { id: string; fullName: string; avatarColor: string } | null
  creator: { id: string; fullName: string; avatarColor: string }
  dueDate: string | null; amount: number | null; category: string | null; location: string | null
  votes: number; voters: string[]; completedAt: string | null; createdAt: string
}

type StatsT = { myTasks: number; pendingLeaves: number; taskDone: number; taskTotal: number; financeIn: number; financeOut: number; balance: number; openIdeas: number; openIncidents: number }

const TABS = [
  { key: 'overview', label: 'Tổng quan', icon: <LayoutDashboard className="h-4 w-4" />, desc: 'Bức tranh toàn cảnh doanh nghiệp' },
  { key: 'task', label: 'Công việc', icon: <KanbanSquare className="h-4 w-4" />, desc: 'Kanban, Gantt, KPI, hoàn thành có thưởng vào ví' },
  { key: 'leave', label: 'Đơn từ', icon: <MailOpen className="h-4 w-4" />, desc: 'Nghỉ phép, OT, Chi phí, duyệt online' },
  { key: 'finance', label: 'Tài chính', icon: <Wallet className="h-4 w-4" />, desc: 'Thu, Chi, Dòng tiền nội bộ' },
  { key: 'asset', label: 'Tài sản', icon: <Boxes className="h-4 w-4" />, desc: 'Cấp phát, Thu hồi, Bảo trì' },
  { key: 'document', label: 'Tài liệu', icon: <FolderOpen className="h-4 w-4" />, desc: 'Kho tri thức, Quy trình, Biểu mẫu' },
  { key: 'meeting', label: 'Cuộc họp', icon: <CalendarClock className="h-4 w-4" />, desc: 'Đặt phòng, Lịch mời, Biên bản' },
  { key: 'idea', label: 'Sáng kiến', icon: <Lightbulb className="h-4 w-4" />, desc: 'Đề xuất, Bình chọn, đăng có thưởng vào ví' },
  { key: 'incident', label: 'Sự cố', icon: <ShieldAlert className="h-4 w-4" />, desc: 'An toàn lao động, Báo cáo sự cố' },
  { key: 'visitor', label: 'Khách', icon: <UserCheck className="h-4 w-4" />, desc: 'Check-in QR, Lịch hẹn đối tác' },
  { key: 'travel', label: 'Công tác phí', icon: <Plane className="h-4 w-4" />, desc: 'Đặt vé, Xe công tác, Quyết toán' },
  { key: 'announce', label: 'Bảng tin', icon: <Megaphone className="h-4 w-4" />, desc: 'Thông báo chính thức Ban Giám đốc' },
] as const

type TabKey = (typeof TABS)[number]['key']

const TASK_COLS = [
  { key: 'todo', label: 'Cần làm', tint: 'bg-stone-100' },
  { key: 'doing', label: 'Đang làm', tint: 'bg-sky-50' },
  { key: 'review', label: 'Chờ duyệt', tint: 'bg-amber-50' },
  { key: 'done', label: 'Hoàn thành', tint: 'bg-emerald-50' },
] as const

const PRIORITY: Record<string, { label: string; cls: string }> = {
  low: { label: 'Thấp', cls: 'bg-stone-100 text-stone-600' },
  normal: { label: 'Bình thường', cls: 'bg-sky-100 text-sky-700' },
  high: { label: 'Cao', cls: 'bg-amber-100 text-amber-700' },
  urgent: { label: 'Khẩn', cls: 'bg-rose-100 text-rose-700' },
}

const STATUS_LABEL: Record<string, { label: string; cls: string }> = {
  open: { label: 'Mở', cls: 'bg-stone-100 text-stone-600' },
  pending: { label: 'Chờ duyệt', cls: 'bg-amber-100 text-amber-700' },
  approved: { label: 'Đã duyệt', cls: 'bg-emerald-100 text-emerald-700' },
  rejected: { label: 'Từ chối', cls: 'bg-rose-100 text-rose-700' },
  todo: { label: 'Cần làm', cls: 'bg-stone-100 text-stone-600' },
  doing: { label: 'Đang làm', cls: 'bg-sky-100 text-sky-700' },
  review: { label: 'Chờ duyệt', cls: 'bg-amber-100 text-amber-700' },
  done: { label: 'Hoàn thành', cls: 'bg-emerald-100 text-emerald-700' },
  backlog: { label: 'Kho dự trù', cls: 'bg-emerald-100 text-emerald-700' },
}

// Cấu hình form tạo mới cho từng phân hệ
const FORM: Record<string, { title: string; category?: string[]; amount?: string; assignee?: boolean; due?: boolean; location?: string }> = {
  task: { title: 'Giao việc mới', assignee: true, due: true },
  leave: { title: 'Nộp đơn từ', category: ['Nghỉ phép', 'Làm ngoài giờ (OT)', 'Công tác', 'Đề xuất chi phí'], due: true },
  finance: { title: 'Ghi sổ thu chi', category: ['thu', 'chi'], amount: 'Số tiền (₫)' },
  asset: { title: 'Cấp phát tài sản', category: ['Laptop', 'Điện thoại', 'Xe', 'Thiết bị', 'Khác'], amount: 'Giá trị (₫)', assignee: true },
  document: { title: 'Thêm tài liệu' },
  meeting: { title: 'Đặt lịch họp', due: true, location: 'Phòng họp', assignee: true },
  idea: { title: 'Đề xuất sáng kiến' },
  incident: { title: 'Báo cáo sự cố', location: 'Địa điểm xảy ra' },
  visitor: { title: 'Đăng ký khách', due: true, location: 'Sảnh / Phòng tiếp' },
  travel: { title: 'Đăng ký công tác', due: true, amount: 'Ngân sách (₫)', location: 'Địa điểm' },
  announce: { title: 'Đăng bảng tin nội bộ' },
  kpi: { title: 'Đặt chỉ tiêu KPI', due: true, amount: 'Giá trị mục tiêu' },
}

const fmtVnd = (n: number) => `${Math.round(n).toLocaleString('vi-VN')}₫`

export default function OpsView({ me, onRefreshUser }: { me: VxUserInfo; onRefreshUser: () => void }) {
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho thưởng hoàn thành công việc
  const [tab, setTab] = useState<TabKey>('overview')
  const [records, setRecords] = useState<RecordT[]>([])
  const [stats, setStats] = useState<StatsT | null>(null)
  const [loading, setLoading] = useState(true)
  const [createOpen, setCreateOpen] = useState(false)
  const [users, setUsers] = useState<{ id: string; fullName: string; avatarColor: string }[]>([])

  const isType = (k: TabKey): k is Exclude<TabKey, 'overview'> => k !== 'overview'

  const load = useCallback(async (t: TabKey) => {
    setLoading(true)
    try {
      const res = await fetch(`/api/vx/ops${isType(t) ? `?type=${t}` : '?type=task'}`)
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      setRecords(d.records || [])
      setStats(d.stats || null)
    } catch {
      toast.error('Không tải được dữ liệu')
    } finally {
      setLoading(false)
    }
  }, [])

  useDeferredLoad(() => { load(tab); fetch('/api/vx/users').then((r) => r.json()).then((d) => Array.isArray(d) && setUsers(d.slice(0, 50))).catch(() => {}) }, [tab, load])

  const patch = async (id: string, payload: Record<string, unknown>, msg?: string) => {
    const res = await fetch(`/api/vx/ops/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    const d = await res.json()
    if (!res.ok) { toast.error(d.error || 'Không cập nhật được'); return }
    if (d.reward > 0) { toast.success(`+${fmtXuWithUsd(d.reward, rate)} vào ví!`); onRefreshUser() }
    else if (msg) toast.success(msg)
    load(tab)
  }

  const remove = async (id: string) => {
    const res = await fetch(`/api/vx/ops/${id}`, { method: 'DELETE' })
    if (!res.ok) { toast.error('Không xóa được (chỉ người tạo / Ban Giám đốc)'); return }
    toast.success('Đã xóa')
    load(tab)
  }

  const canApprove = me.role === 'admin' || me.role === 'manager'

  return (
    <div className="space-y-4">
      {/* Tiêu đề + nút tạo */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-xl font-black text-stone-800"><KanbanSquare className="h-5 w-5 text-emerald-600" /> Quản trị Doanh nghiệp 360</h1>
          <p className="text-sm text-muted-foreground">Bộ 12 phân hệ vận hành, miễn phí 100%, làm việc tốt được thưởng xu</p>
        </div>
        {isType(tab) && (
          <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => setCreateOpen(true)} aria-label={`Thêm ${tab}`}>
            <Plus className="mr-1 h-4 w-4" /> {FORM[tab]?.title || 'Thêm mới'}
          </Button>
        )}
      </div>

      <div className="grid gap-4 lg:grid-cols-[220px_1fr]">
        {/* Sidebar phân hệ */}
        <nav className="flex gap-1 overflow-x-auto rounded-xl border bg-white p-1.5 lg:flex-col lg:overflow-visible" aria-label="Phân hệ quản trị">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                tab === t.key ? 'bg-emerald-600 text-white shadow' : 'text-stone-600 hover:bg-emerald-50 hover:text-emerald-800'
              }`}
              aria-current={tab === t.key ? 'page' : undefined}
            >
              {t.icon}
              <span className="whitespace-nowrap">{t.label}</span>
            </button>
          ))}
        </nav>

        {/* Nội dung */}
        <section className="min-w-0 space-y-4">
          {/* Thống kê tổng quan — luôn hiển thị */}
          {stats && (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <StatCard label="Việc của tôi" value={String(stats.myTasks)} tint="border-sky-200 bg-sky-50 text-sky-700" />
              <StatCard label="Đơn chờ duyệt" value={String(stats.pendingLeaves)} tint="border-amber-200 bg-amber-50 text-amber-700" />
              <StatCard label="Tiến độ việc" value={`${stats.taskDone}/${stats.taskTotal}`} tint="border-emerald-200 bg-emerald-50 text-emerald-700" />
              <StatCard label="Dòng tiền ròng" value={fmtVnd(stats.balance)} tint="border-emerald-200 bg-emerald-50 text-emerald-700" />
            </div>
          )}

          {loading ? (
            <div className="flex items-center justify-center gap-2 rounded-xl border bg-white py-16 text-stone-500"><Loader2 className="h-5 w-5 animate-spin" /> Đang tải...</div>
          ) : tab === 'overview' ? (
            <OverviewBoard stats={stats} go={setTab} />
          ) : tab === 'task' ? (
            <KanbanBoard records={records} me={me} onMove={(id, status) => patch(id, { status })} onDelete={remove} />
          ) : (
            <RecordList tab={tab} records={records} me={me} users={users} canApprove={canApprove} onPatch={patch} onDelete={remove} onOpenCreate={() => setCreateOpen(true)} />
          )}
        </section>
      </div>

      {/* Dialog tạo mới — dùng chung cho mọi phân hệ */}
      <CreateDialog open={createOpen} onOpenChange={setCreateOpen} tab={tab as Exclude<TabKey, 'overview'>} users={users}
        onCreated={(rec, reward) => {
          if (isType(tab)) setRecords((r) => [rec, ...r])
          if (tab === 'overview') load('overview')
          if (reward > 0) { toast.success(`Đăng sáng kiến +${fmtXuWithUsd(reward, rate)}!`); onRefreshUser() } else toast.success('Đã tạo')
        }} />
    </div>
  )
}

// ============ THẺ THỐNG KÊ ============
function StatCard({ label, value, tint }: { label: string; value: string; tint: string }) {
  return (
    <div className={`rounded-xl border p-3 ${tint}`}>
      <p className="text-xs font-medium opacity-80">{label}</p>
      <p className="text-lg font-black tracking-tight">{value}</p>
    </div>
  )
}

// ============ TỔNG QUAN ============
function OverviewBoard({ stats, go }: { stats: StatsT | null; go: (t: TabKey) => void }) {
  if (!stats) return null
  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border bg-gradient-to-br from-emerald-50 to-teal-50 p-4">
          <p className="flex items-center gap-2 font-bold text-emerald-800"><Coins className="h-4 w-4" /> Kinh tế ví nội bộ</p>
          <p className="mt-1 text-xs text-emerald-700">Điểm danh, đăng bài, bình luận, hoàn thành việc, sáng kiến, xem video — mỗi hoạt động đều có thưởng vào ví USD</p>
          <p className="mt-2 text-xs font-semibold text-emerald-800">Toàn bộ công cụ AI & cửa hàng đổi quà dùng chung một ví tiền USD theo tỷ giá thị trường, không tốn tiền ngoài.</p>
        </div>
        <div className="rounded-xl border bg-gradient-to-br from-amber-50 to-orange-50 p-4">
          <p className="font-bold text-amber-800">Tài chính nội bộ</p>
          <p className="mt-1 text-sm">Thu: <b>{fmtVnd(stats.financeIn)}</b>, Chi: <b>{fmtVnd(stats.financeOut)}</b></p>
          <p className="text-sm">Dòng tiền ròng: <b>{fmtVnd(stats.balance)}</b></p>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
        {TABS.filter((t) => t.key !== 'overview').map((t) => (
          <button key={t.key} onClick={() => go(t.key)} className="flex flex-col items-center gap-1.5 rounded-xl border bg-white p-3 text-xs font-medium text-stone-600 transition-colors hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-800">
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>
      <p className="rounded-xl border border-dashed bg-white p-4 text-xs leading-relaxed text-muted-foreground">
        <b className="text-stone-700">Bọc lọc 22 phân hệ chuẩn ERP:</b> Nhân sự &amp; chấm công (Điểm danh), Công việc &amp; Dự án (Kanban), Khách hàng (CRM qua Hồ sơ DN), Tài chính nội bộ, Duyệt quy trình &amp; Ký số (Đơn từ), Kho hàng (Cửa hàng Vexon), Truyền thông nội bộ (Bảng tin + Chat), Tài sản, Tài liệu, BI Dashboard, Đào tạo (Tài liệu), Họp, Nhà cung cấp (Hồ sơ DN), Tích hợp ZNS/Email (EmailLog), Trải nghiệm nhân viên (Thưởng + Sáng kiến), HSE (Sự cố), Khách thăm, Hành chính (Công tác phí), Nhật ký (CoinTx + Audit), ESG (báo cáo dòng tiền).
      </p>
    </div>
  )
}

// ============ KANBAN CÔNG VIỆC ============
function KanbanBoard({ records, me, onMove, onDelete }: { records: RecordT[]; me: VxUserInfo; onMove: (id: string, status: string) => void; onDelete: (id: string) => void }) {
  const byStatus = useMemo(() => {
    const m: Record<string, RecordT[]> = { backlog: [], todo: [], doing: [], review: [], done: [] }
    records.forEach((r) => { (m[r.status] || m.todo).push(r) })
    return m
  }, [records])

  if (records.length === 0) {
    return <p className="rounded-xl border border-dashed bg-white p-10 text-center text-sm text-muted-foreground">Chưa có công việc nào, bấm “Giao việc mới” để bắt đầu.</p>
  }

  return (
    <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
      {TASK_COLS.map((col, ci) => (
        <div key={col.key} className={`rounded-xl border p-2.5 ${col.tint}`}>
          <p className="mb-2 flex items-center justify-between px-1 text-xs font-bold uppercase tracking-wide text-stone-600">
            {col.label}
            <span className="rounded-full bg-white px-2 py-0.5 text-[10px]">{byStatus[col.key].length}</span>
          </p>
          <div className="space-y-2">
            {byStatus[col.key].map((r) => (
              <article key={r.id} className="group rounded-lg border bg-white p-3 shadow-sm">
                <div className="flex items-start justify-between gap-1">
                  <p className="text-sm font-semibold leading-snug">{r.title}</p>
                  {(me.id === r.creator.id || me.role === 'admin') && (
                    <button onClick={() => onDelete(r.id)} className="opacity-0 transition-opacity group-hover:opacity-100" title="Xóa" aria-label={`Xóa ${r.title}`}><Trash2 className="h-3.5 w-3.5 text-rose-500" /></button>
                  )}
                </div>
                {r.description && <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{r.description}</p>}
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <Badge className={`border-0 px-1.5 py-0 text-[10px] ${PRIORITY[r.priority]?.cls}`}>{PRIORITY[r.priority]?.label}</Badge>
                  {r.dueDate && <span className="text-[10px] text-stone-500">⏰ {new Date(r.dueDate).toLocaleDateString('vi-VN')}</span>}
                </div>
                <div className="mt-2 flex items-center justify-between">
                  {r.assignee ? <div className="flex items-center gap-1.5"><Avatar name={r.assignee.fullName} color={r.assignee.avatarColor} size={22} /><span className="max-w-24 truncate text-[11px] text-stone-600">{r.assignee.fullName}</span></div>
                    : <span className="text-[11px] text-stone-400">Chưa gán</span>}
                  <div className="flex gap-1">
                    {ci > 0 && (
                      <button onClick={() => onMove(r.id, ci === 1 ? 'todo' : ci === 2 ? 'doing' : 'review')} className="rounded p-1 hover:bg-stone-100" title="Lùi lại" aria-label="Lùi trạng thái"><ChevronLeft className="h-4 w-4 text-stone-400" /></button>
                    )}
                    {ci < TASK_COLS.length - 1 && (
                      <button onClick={() => onMove(r.id, TASK_COLS[ci + 1].key)} className="rounded bg-emerald-600 p-1 hover:bg-emerald-700" title={TASK_COLS[ci + 1].key === 'done' ? 'Hoàn thành (có thưởng)' : 'Chuyển tiếp'} aria-label="Chuyển trạng thái"><ChevronRight className="h-4 w-4 text-white" /></button>
                    )}
                  </div>
                </div>
              </article>
            ))}
            {byStatus[col.key].length === 0 && <p className="rounded-lg border border-dashed py-4 text-center text-[11px] text-stone-400">Trống</p>}
          </div>
        </div>
      ))}
    </div>
  )
}

// ============ DANH SÁCH CHUNG CHO CÁC PHÂN HỆ CÒN LẠI ============
function RecordList({ tab, records, me, users, canApprove, onPatch, onDelete, onOpenCreate }: {
  tab: Exclude<TabKey, 'overview'>; records: RecordT[]; me: VxUserInfo
  users: { id: string; fullName: string; avatarColor: string }[]
  canApprove: boolean; onPatch: (id: string, payload: Record<string, unknown>, msg?: string) => void
  onDelete: (id: string) => void; onOpenCreate: () => void
}) {
  if (records.length === 0) {
    return (
      <div className="rounded-xl border border-dashed bg-white p-10 text-center">
        <p className="text-sm text-muted-foreground">Chưa có dữ liệu ở phân hệ “{TABS.find((t) => t.key === tab)?.label}”.</p>
        <Button size="sm" className="mt-3 bg-emerald-600 hover:bg-emerald-700" onClick={onOpenCreate}><Plus className="mr-1 h-4 w-4" /> Thêm ngay</Button>
      </div>
    )
  }
  return (
    <div className="space-y-2.5">
      {records.map((r) => {
        const st = STATUS_LABEL[r.status]
        const iVoted = r.voters.includes(me.id)
        return (
          <article key={r.id} className="group rounded-xl border bg-white p-4 shadow-sm">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-semibold leading-snug">{r.title}</p>
                  {st && <Badge className={`border-0 px-2 py-0 text-[10px] ${st.cls}`}>{st.label}</Badge>}
                  {tab === 'finance' && r.category && (
                    <Badge className={`border-0 px-2 py-0 text-[10px] ${r.category === 'thu' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                      {r.category === 'thu' ? 'Thu' : 'Chi'}
                    </Badge>
                  )}
                  {r.priority !== 'normal' && <Badge className={`border-0 px-2 py-0 text-[10px] ${PRIORITY[r.priority]?.cls}`}>{PRIORITY[r.priority]?.label}</Badge>}
                </div>
                {r.description && <p className="mt-1 whitespace-pre-wrap text-sm text-muted-foreground">{r.description}</p>}
                <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-stone-500">
                  <span className="flex items-center gap-1"><Avatar name={r.creator.fullName} color={r.creator.avatarColor} size={18} /> {r.creator.fullName}</span>
                  {r.assignee && <span className="flex items-center gap-1"><UserCheck className="h-3 w-3" /> Giao: <b>{r.assignee.fullName}</b></span>}
                  {r.amount != null && <span className="flex items-center gap-1"><Coins className="h-3 w-3" /> Số tiền: <b>{fmtVnd(r.amount)}</b></span>}
                  {r.category && tab !== 'finance' && <span className="flex items-center gap-1"><Boxes className="h-3 w-3" /> {r.category}</span>}
                  {r.location && <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {r.location}</span>}
                  {r.dueDate && <span className="flex items-center gap-1"><CalendarClock className="h-3 w-3" /> {new Date(r.dueDate).toLocaleString('vi-VN', { dateStyle: 'short', timeStyle: 'short' })}</span>}
                  <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {timeAgo(r.createdAt)}</span>
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-1.5">
                {/* Duyệt / từ chối đơn từ */}
                {tab === 'leave' && r.status === 'pending' && canApprove && (
                  <>
                    <Button size="sm" className="h-8 bg-emerald-600 hover:bg-emerald-700" onClick={() => onPatch(r.id, { status: 'approved' }, 'Đã duyệt đơn')}><CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Duyệt</Button>
                    <Button size="sm" variant="outline" className="h-8 text-rose-600" onClick={() => onPatch(r.id, { status: 'rejected' }, 'Đã từ chối')}><XCircle className="mr-1 h-3.5 w-3.5" /> Từ chối</Button>
                  </>
                )}
                {/* Bình chọn sáng kiến */}
                {tab === 'idea' && (
                  <Button size="sm" variant={iVoted ? 'default' : 'outline'} className={`h-8 ${iVoted ? 'bg-emerald-600 hover:bg-emerald-700' : ''}`} onClick={() => onPatch(r.id, { action: 'vote' })}>
                    <ThumbsUp className="mr-1 h-3.5 w-3.5" /> {r.votes}
                  </Button>
                )}
                {(me.id === r.creator.id || me.role === 'admin') && (
                  <button onClick={() => onDelete(r.id)} className="rounded p-1.5 text-stone-300 hover:bg-rose-50 hover:text-rose-500" title="Xóa" aria-label={`Xóa ${r.title}`}><Trash2 className="h-4 w-4" /></button>
                )}
              </div>
            </div>
          </article>
        )
      })}
    </div>
  )
}

// ============ DIALOG TẠO MỚI CHUNG ============
function CreateDialog({ open, onOpenChange, tab, users, onCreated }: {
  open: boolean; onOpenChange: (v: boolean) => void; tab: Exclude<TabKey, 'overview'>
  users: { id: string; fullName: string; avatarColor: string }[]
  onCreated: (rec: RecordT, reward: number) => void
}) {
  const cfg = FORM[tab] || { title: 'Thêm mới' }
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState('')
  const [amount, setAmount] = useState('')
  const [assigneeId, setAssigneeId] = useState('')
  const [dueDate, setDueDate] = useState('')
  const [location, setLocation] = useState('')
  const [priority, setPriority] = useState('normal')
  const [saving, setSaving] = useState(false)

  const submit = async () => {
    if (!title.trim()) { toast.error('Nhập tiêu đề'); return }
    setSaving(true)
    try {
      const res = await fetch('/api/vx/ops', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: tab, title: title.trim(), description: description.trim() || undefined,
          category: category || undefined, amount: amount ? Number(amount.replace(/[^\d.]/g, '')) : undefined,
          assigneeId: assigneeId || undefined, dueDate: dueDate || undefined,
          location: location.trim() || undefined, priority,
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      onCreated(d.record, d.reward || 0)
      onOpenChange(false)
      setTitle(''); setDescription(''); setCategory(''); setAmount(''); setAssigneeId(''); setDueDate(''); setLocation(''); setPriority('normal')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không tạo được')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
        <DialogHeader><DialogTitle>{cfg.title}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5"><Label htmlFor="ops-title">Tiêu đề</Label><Input id="ops-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Nhập tiêu đề..." /></div>
          <div className="space-y-1.5"><Label htmlFor="ops-desc">Mô tả</Label><Textarea id="ops-desc" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Chi tiết (không bắt buộc)..." rows={3} /></div>
          {cfg.category && (
            <div className="space-y-1.5">
              <Label>Loại</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger aria-label="Chọn loại"><SelectValue placeholder="Chọn loại..." /></SelectTrigger>
                <SelectContent>{cfg.category.map((c) => <SelectItem key={c} value={c}>{c === 'thu' ? 'Thu' : c === 'chi' ? 'Chi' : c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          )}
          {cfg.amount && (
            <div className="space-y-1.5"><Label htmlFor="ops-amount">{cfg.amount}</Label><Input id="ops-amount" inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0" /></div>
          )}
          {cfg.assignee && (
            <div className="space-y-1.5">
              <Label>Giao cho</Label>
              <Select value={assigneeId} onValueChange={setAssigneeId}>
                <SelectTrigger aria-label="Chọn người thực hiện"><SelectValue placeholder="Chọn nhân sự..." /></SelectTrigger>
                <SelectContent>{users.map((u) => <SelectItem key={u.id} value={u.id}>{u.fullName}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          )}
          {cfg.due && (
            <div className="space-y-1.5"><Label htmlFor="ops-due">{tab === 'meeting' || tab === 'visitor' ? 'Thời gian' : 'Hạn chót'}</Label><Input id="ops-due" type="datetime-local" value={dueDate} onChange={(e) => setDueDate(e.target.value)} /></div>
          )}
          {cfg.location && (
            <div className="space-y-1.5"><Label htmlFor="ops-loc">{cfg.location}</Label><Input id="ops-loc" value={location} onChange={(e) => setLocation(e.target.value)} /></div>
          )}
          {tab === 'task' && (
            <div className="space-y-1.5">
              <Label>Ưu tiên</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger aria-label="Chọn mức ưu tiên"><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(PRIORITY).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          )}
          {tab === 'idea' && <p className="rounded-lg bg-amber-50 p-2.5 text-xs text-amber-700">Đăng sáng kiến được thưởng vào ví, ý tưởng hay được toàn công ty bình chọn, Ban quản trị duyệt triển khai.</p>}
          {tab === 'task' && <p className="rounded-lg bg-emerald-50 p-2.5 text-xs text-emerald-700">Người thực hiện chuyển việc sang “Hoàn thành” sẽ được thưởng vào ví tự động.</p>}
          <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={submit} disabled={saving}>
            {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Target className="mr-1 h-4 w-4" />} Tạo mới
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
