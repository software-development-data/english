'use client'

// ============ VEXON AI — TRANG CHATBOT RIÊNG (/chat) ============
// • Link riêng biệt: mở trực tiếp /chat không cần vào app
// • Tổng hợp mọi công cụ: chat đa chủ đề, nhìn ảnh trả lời, vẽ ảnh, tìm kiếm web + tổng hợp dữ liệu
// • Chế độ TỰ ĐỘNG: chỉ cần nhập câu lệnh — hệ thống tự nhận diện và xử lý
// • Một ví tiền USD chung cho cả mạng lưới Vexon: hội thoại miễn phí, vẽ ảnh / nhìn ảnh / tìm web tính tiền vào ví

import { useCallback, useEffect, useRef, useState } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { toast } from 'sonner'
import { useWallet } from '@/lib/tiai/wallet'
import { fmtXuWithUsd } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'
import { BOT_TOOLS, type Tool } from '@/lib/tiai/tools'
import type { GifT } from '@/lib/gif'
import {
  Sparkles, X, Send, Loader2, ImagePlus, ImageIcon, Globe, Volume2, Square,
  History, Plus, Trash2, Menu, Coins, Wand2, ArrowLeft, Zap, Search, Eye,
  Library, Upload, FileText, Home, Palette, PenLine, BarChart3, Lightbulb, Wrench, Link2, Download, TriangleAlert,
  Mic, Sticker, MicOff,
} from 'lucide-react'

interface AMsg { role: 'user' | 'ai'; text: string; image?: string; sources?: { url: string; name: string }[]; audio?: string; docs?: string[] }
interface AConv { id: string; title: string; msgs: AMsg[]; at: number }

const STORE_KEY = 'vexon-chatbot-convs-v1'

interface KDoc { id: string; name: string; kind: string; sizeChars: number; chunks: number }

/** Bộ công cụ AI mà chatbot này tổng hợp — bấm là tự điền câu lệnh mẫu */
const CAPABILITIES = [
  { icon: <Palette className="h-5 w-5 text-emerald-600" />, label: 'Vẽ ảnh AI', prompt: 'Vẽ ảnh: hoàng hôn trên biển có thuyền buồn, phong cách watercolor' },
  { icon: <Search className="h-5 w-5 text-sky-600" />, label: 'Tìm kiếm & tổng hợp', prompt: 'Tìm kiếm: giá vàng hôm nay và nhận định thị trường' },
  { icon: <Eye className="h-5 w-5 text-emerald-600" />, label: 'Nhìn ảnh trả lời', prompt: '', hint: 'Bấm nút ảnh để gắn ảnh rồi hỏi' },
  { icon: <PenLine className="h-5 w-5 text-amber-600" />, label: 'Viết bài, caption', prompt: 'Viết giúp mình bài đăng giới thiệu quán cà phê mới mở, tone gần gũi, có emoji' },
  { icon: <Globe className="h-5 w-5 text-cyan-600" />, label: 'Dịch thuật', prompt: 'Dịch sang tiếng Anh: "Cảm ơn bạn đã tin tưởng Vexon, đơn hàng sẽ giao trong 24 giờ."' },
  { icon: <BarChart3 className="h-5 w-5 text-teal-600" />, label: 'Phân tích & tóm tắt', prompt: 'Tóm tắt giúp mình các cách kiếm tiền vào ví trong Vexon theo gạch đầu dòng' },
  { icon: <Lightbulb className="h-5 w-5 text-yellow-600" />, label: 'Tư vấn ý tưởng', prompt: 'Gợi ý 5 ý tưởng nội dung TikTok cho cửa hàng quần áo local brand' },
  { icon: <Wrench className="h-5 w-5 text-stone-600" />, label: 'Mẹo dùng Vexon', prompt: 'Hướng dẫn mình cách dùng Công cụ AI và Nhóm trong Vexon' },
]

/** Nhận diện chế độ TỰ ĐỘNG từ câu lệnh */
function detectAuto(text: string, hasImage: boolean): 'vision' | 'image' | 'search' | 'chat' {
  const t = text.trim().toLowerCase()
  if (hasImage) return 'vision'
  if (/^(vẽ|ve\b|tạo ảnh|viet hoa|draw|generate image|make an image)/i.test(t) || /^vẽ ảnh/i.test(t)) return 'image'
  if (/(^tìm kiếm|^tim kiem|^tìm |^search |tin tức|tin tuc|giá .* hôm nay|thời tiết|tuổi|kết quả|xem ngay|kiểm tra giá)/i.test(t)) return 'search'
  return 'chat'
}

const AUTO_BADGE: Record<string, { icon: React.ReactNode; label: string; cls: string }> = {
  chat: { icon: <Sparkles className="h-3 w-3" />, label: 'Hội thoại', cls: 'bg-emerald-100 text-emerald-700' },
  image: { icon: <ImageIcon className="h-3 w-3" />, label: 'Vẽ ảnh', cls: 'bg-teal-100 text-teal-700' },
  search: { icon: <Search className="h-3 w-3" />, label: 'Tìm web', cls: 'bg-sky-100 text-sky-700' },
  vision: { icon: <Eye className="h-3 w-3" />, label: 'Nhìn ảnh', cls: 'bg-emerald-100 text-emerald-700' },
}

function loadConvs(): AConv[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = localStorage.getItem(STORE_KEY)
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr.slice(0, 40) : []
  } catch {
    return []
  }
}

/** Thêm tin nhắn AI vào hội thoại đang mở (tạo mới nếu chưa có) — dùng cho thông báo lỗi ví tiền */
function appendAi(convs: AConv[], activeId: string | null, msg: AMsg): AConv[] {
  const id = activeId || `c${Date.now()}`
  const exists = convs.find((c) => c.id === id)
  if (!exists) return [{ id, title: 'Vexon AI', msgs: [msg], at: Date.now() }, ...convs]
  return convs.map((c) => (c.id === id ? { ...c, msgs: [...c.msgs, msg], at: Date.now() } : c))
}

export default function VexonAI() {
  const [me, setMe] = useState<{ fullName: string; username: string } | null>(null)
  const [convs, setConvs] = useState<AConv[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const [mode, setMode] = useState<'auto' | 'chat' | 'image'>('auto')
  const [attach, setAttach] = useState<string | null>(null)
  const [webOn, setWebOn] = useState(false)
  const [showSidebar, setShowSidebar] = useState(false)
  const [speakingId, setSpeakingId] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const audioCacheRef = useRef<Map<string, string>>(new Map())
  const bottomRef = useRef<HTMLDivElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  // Giọng nói kiểu ChatGPT voice: bật chế độ → bấm micro nói → ASR tự điền → AI tự đọc to trả lời
  const [voiceOn, setVoiceOn] = useState(false)
  const [recording, setRecording] = useState(false)
  const [transcribing, setTranscribing] = useState(false)
  const mediaRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])
  // GIF Hub — gửi GIF vui vào hội thoại (nguồn: Giphy + bộ dự phòng, tìm qua /api/vx/gif)
  const [gifOpen, setGifOpen] = useState(false)
  const [gifQ, setGifQ] = useState('')
  const [gifs, setGifs] = useState<GifT[]>([])
  const [gifBusy, setGifBusy] = useState(false)
  // RAG — Tài liệu riêng (kiểu AnythingLLM): tải lên để Vexon AI tự tra khi trả lời
  const [docsOpen, setDocsOpen] = useState(false)
  const [myDocs, setMyDocs] = useState<KDoc[]>([])
  const [docBusy, setDocBusy] = useState(false)
  const [pasteName, setPasteName] = useState('')
  const [pasteText, setPasteText] = useState('')
  const docFileRef = useRef<HTMLInputElement>(null)
  // Ví tiền CHUNG cả mạng lưới — cùng số dư với Công cụ AI & mạng xã hội
  const xu = useWallet((s) => s.xu)
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho Vexon AI
  const freeLeft = useWallet((s) => s.freeLeft)
  const hydrateWallet = useWallet((s) => s.hydrate)
  const charge = useWallet((s) => s.charge)
  const refund = useWallet((s) => s.refund)

  // Đăng nhập (nếu có) → chào tên + đồng bộ ví tiền USD chung của cả mạng lưới
  useEffect(() => {
    fetch('/api/vx/auth')
      .then((r) => r.json())
      .then((d) => d.user && setMe({ fullName: d.user.fullName, username: d.user.username }))
      .catch(() => {})
  }, [])
  useEffect(() => {
    hydrateWallet()
    // Store ví tự nghe 'vx-coins-changed' → mọi thay đổi ở MXH / Công cụ AI
    // đều phản ánh vào đây (không cần listener riêng nữa)
  }, [hydrateWallet])

  useEffect(() => {
    const list = loadConvs()
    setConvs(list)
    if (list.length > 0) setActiveId(list[0].id)
  }, [])

  const active = convs.find((c) => c.id === activeId) || null
  const msgs = active?.msgs || []

  const saveConvs = useCallback((next: AConv[]) => {
    setConvs(next)
    try { localStorage.setItem(STORE_KEY, JSON.stringify(next.slice(0, 40))) } catch { /* đầy bộ nhớ, bỏ qua */ }
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [msgs.length, busy])

  const newConv = () => {
    setActiveId(null)
    setAttach(null)
    setWebOn(false)
    setMode('auto')
    setShowSidebar(false)
  }

  const removeConv = (id: string) => {
    const next = convs.filter((c) => c.id !== id)
    saveConvs(next)
    if (activeId === id) setActiveId(next[0]?.id || null)
  }

  const pickAttach = (f: File | undefined) => {
    if (!f) return
    if (!f.type.startsWith('image/')) return
    if (f.size > 3_500_000) return
    const r = new FileReader()
    r.onload = () => setAttach(String(r.result))
    r.readAsDataURL(f)
  }

  const stopAudio = () => {
    audioRef.current?.pause()
    audioRef.current = null
    setSpeakingId(null)
  }

  // Đọc to 1 đoạn văn bản — cache âm thanh theo nội dung để nghe lại tức thời
  const speakText = useCallback(async (text: string): Promise<void> => {
    const clean = text.slice(0, 1000)
    const cached = audioCacheRef.current.get(clean)
    const src = cached || await (async () => {
      const res = await fetch('/api/tiai/voice', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: clean, voice: 'tongtong', speed: 1 }),
      })
      const d = await res.json()
      if (!res.ok || !d.audio) throw new Error('no audio')
      audioCacheRef.current.set(clean, d.audio as string)
      return d.audio as string
    })()
    const audio = new Audio(src)
    audioRef.current = audio
    audio.onended = () => setSpeakingId(null)
    await audio.play()
  }, [])

  // ── Tài liệu riêng (RAG) ────────────────────────────
  const loadDocs = useCallback(async () => {
    try {
      const r = await fetch('/api/vx/knowledge', { cache: 'no-store' })
      const d = await r.json()
      if (r.ok && Array.isArray(d)) setMyDocs(d)
    } catch { /* bỏ qua */ }
  }, [])

  const openDocs = () => {
    setDocsOpen(true)
    loadDocs()
  }

  const uploadDocFile = async (f: File | undefined) => {
    if (!f) return
    setDocBusy(true)
    try {
      const fd = new FormData()
      fd.append('file', f)
      const r = await fetch('/api/vx/knowledge', { method: 'POST', body: fd })
      const d = await r.json()
      if (!r.ok) throw new Error(d.error)
      toast.success(`Đã học tài liệu “${d.name}” (${d.chunks} đoạn), Vexon AI sẽ tự tra khi trả lời`)
      loadDocs()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không tải được tài liệu')
    } finally {
      setDocBusy(false)
      if (docFileRef.current) docFileRef.current.value = ''
    }
  }

  const uploadDocText = async () => {
    if (pasteText.trim().length < 20) { toast.error('Nội dung quá ngắn, dán nhiều hơn một chút nhé'); return }
    setDocBusy(true)
    try {
      const r = await fetch('/api/vx/knowledge', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: pasteName, text: pasteText }) })
      const d = await r.json()
      if (!r.ok) throw new Error(d.error)
      toast.success(`Đã học tài liệu “${d.name}” (${d.chunks} đoạn)`)
      setPasteName(''); setPasteText('')
      loadDocs()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không lưu được tài liệu')
    } finally { setDocBusy(false) }
  }

  const deleteDoc = async (id: string) => {
    const r = await fetch(`/api/vx/knowledge/${id}`, { method: 'DELETE' })
    if (r.ok) { toast.success('Đã xoá tài liệu'); setMyDocs((ds) => ds.filter((d) => d.id !== id)) }
    else toast.error('Không xoá được')
  }

  const speak = async (idx: number) => {
    const m = msgs[idx]
    if (!m || m.role !== 'ai') return
    if (speakingId === String(idx)) { stopAudio(); return }
    stopAudio()
    setSpeakingId(String(idx))
    try {
      await speakText(m.text)
    } catch {
      setSpeakingId(null)
    }
  }

  // Chế độ Giọng nói: AI tự đọc to câu trả lời vừa tạo (kiểu ChatGPT Voice)
  const autoSpeak = async (text: string) => {
    stopAudio()
    setSpeakingId('auto')
    try {
      await speakText(text)
    } catch {
      setSpeakingId((s) => (s === 'auto' ? null : s))
    }
  }

  // ── Ghi âm micro → ASR tự điền câu lệnh ────────────────────
  const toggleRecord = async () => {
    if (recording) {
      mediaRef.current?.stop()
      return
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mr = new MediaRecorder(stream)
      chunksRef.current = []
      mr.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data) }
      mr.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop())
        setRecording(false)
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' })
        if (blob.size < 2500) { toast.error('Bạn chưa nói gì cả'); return }
        setTranscribing(true)
        try {
          const b64 = await new Promise<string>((resolve) => {
            const r = new FileReader()
            r.onload = () => resolve(String(r.result).split(',')[1] || '')
            r.readAsDataURL(blob)
          })
          const r2 = await fetch('/api/tiai/transcribe', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ audio: b64 }),
          })
          const d2 = await r2.json()
          if (!r2.ok || !d2.text) throw new Error(d2.error || 'Không nghe rõ nội dung')
          setText(String(d2.text))
          toast.success(`Đã nghe: “${String(d2.text).slice(0, 60)}”`, { description: 'Bấm Gửi để hỏi Vexon AI' })
        } catch (e) {
          toast.error(e instanceof Error ? e.message : 'Không nghe được giọng nói, thử lại nhé')
        } finally {
          setTranscribing(false)
        }
      }
      mediaRef.current = mr
      mr.start()
      setRecording(true)
      toast.info('Đang nghe... bấm micro lần nữa để gửi')
    } catch {
      toast.error('Không truy cập được micro — kiểm tra quyền trình duyệt')
    }
  }

  // ── GIF Hub: tìm & gửi GIF vui vào hội thoại ────────────────
  const loadGifs = useCallback((q: string) => {
    setGifBusy(true)
    fetch(`/api/vx/gif?q=${encodeURIComponent(q)}`)
      .then((r) => r.json())
      .then((d) => Array.isArray(d.gifs) && setGifs(d.gifs))
      .catch(() => setGifs([]))
      .finally(() => setGifBusy(false))
  }, [])

  const openGifPicker = () => {
    setGifOpen(true)
    if (gifs.length === 0) loadGifs('')
  }

  const sendGif = (g: GifT) => {
    const convId = activeId || `c${Date.now()}`
    const userMsg: AMsg = { role: 'user', text: `GIF: ${g.title}`, image: g.url }
    const aiMsg: AMsg = { role: 'ai', text: 'GIF vui đấy! Muốn mình viết caption, dịch nội dung hay kể chuyện theo GIF này cứ nhắn nhé!' }
    const exists = convs.find((c) => c.id === convId)
    const nextConvs = exists
      ? convs.map((c) => (c.id === convId ? { ...c, msgs: [...c.msgs, userMsg, aiMsg], at: Date.now() } : c))
      : [{ id: convId, title: `GIF: ${g.title}`.slice(0, 40), msgs: [userMsg, aiMsg], at: Date.now() }, ...convs]
    saveConvs(nextConvs)
    if (!exists) setActiveId(convId)
    setGifOpen(false)
  }

  const send = async (quickQ?: string) => {
    const q = (quickQ ?? text).trim()
    if ((!q && !attach) || busy) return
    stopAudio()

    // Chế độ: tự động nhận diện hoặc dùng chế độ chọn sẵn
    const kind = mode === 'auto' ? detectAuto(q, Boolean(attach)) : attach ? 'vision' : mode === 'image' ? 'image' : webOn ? 'search' : 'chat'

    // Tính tiền qua ví chung: vẽ ảnh / nhìn ảnh / tìm web tính tiền vào ví, hội thoại luôn miễn phí
    const botTool: Tool | null =
      kind === 'image' ? BOT_TOOLS.image : kind === 'vision' ? BOT_TOOLS.vision : kind === 'search' ? BOT_TOOLS.search : null
    if (botTool && !charge(botTool)) {
      saveConvs(
        appendAi(convs, activeId, {
          role: 'ai',
          text: `Cần ${fmtXuWithUsd(botTool.price, rate)} để dùng "${botTool.name}". Hết 2 lượt miễn phí hôm nay rồi, kiếm thêm bằng cách đăng bài, điểm danh, xem video... hoặc nạp qua QR ngân hàng trong Ví tiền!`,
        }),
      )
      return
    }

    const userMsg: AMsg = { role: 'user', text: q || 'Nhìn ảnh này giúp mình', image: attach || undefined }
    const nextMsgs: AMsg[] = [...msgs, userMsg]
    const convId = activeId || `c${Date.now()}`
    const nextConvs: AConv[] = [
      { id: convId, title: (q || 'Ảnh gửi AI').slice(0, 40), msgs: nextMsgs, at: Date.now() },
      ...convs.filter((c) => c.id !== convId),
    ]
    saveConvs(nextConvs)
    setActiveId(convId)
    setText('')
    const sentImage = attach
    setAttach(null)
    setBusy(true)

    try {
      let aiMsg: AMsg
      if (kind === 'image') {
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'image', prompt: q }) })
        const d = await res.json()
        if (!res.ok) { refund(BOT_TOOLS.image); aiMsg = { role: 'ai', text: `Không tạo được ảnh: ${d.error || ''}, đã hoàn tiền nếu bị trừ.` } }
        else aiMsg = { role: 'ai', text: `Ảnh minh họa cho "${q}", bấm giữ để tải về:`, image: d.image }
      } else if (kind === 'vision' && sentImage) {
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'vision', text: q, image: sentImage }) })
        const d = await res.json()
        if (!res.ok) { refund(BOT_TOOLS.vision); aiMsg = { role: 'ai', text: `Không đọc được ảnh: ${d.error || ''}, đã hoàn tiền nếu bị trừ.` } }
        else aiMsg = { role: 'ai', text: d.text }
      } else if (kind === 'search') {
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'search', query: q }) })
        const d = await res.json()
        if (!res.ok) { refund(BOT_TOOLS.search); aiMsg = { role: 'ai', text: `Không tìm được: ${d.error || ''}, đã hoàn tiền nếu bị trừ.` } }
        else aiMsg = { role: 'ai', text: d.text, sources: d.sources || [] }
      } else {
        const history = nextMsgs.slice(-10).map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', content: m.text }))
        const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'chat', messages: history }) })
        const d = await res.json()
        aiMsg = res.ok ? { role: 'ai', text: d.text, docs: d.usedDocs } : { role: 'ai', text: `AI đang bận: ${d.error || ''}` }
      }
      saveConvs(nextConvs.map((c) => (c.id === convId ? { ...c, msgs: [...c.msgs, aiMsg], at: Date.now() } : c)))
      // Chế độ Giọng nói: AI tự đọc to câu trả lời (kể cả tên tài liệu đã tra)
      if (voiceOn && aiMsg.text && !aiMsg.image) void autoSpeak(aiMsg.text)
    } catch {
      if (botTool) refund(botTool)
      saveConvs(nextConvs.map((c) => (c.id === convId ? { ...c, msgs: [...c.msgs, { role: 'ai' as const, text: 'Không kết nối được máy chủ AI, thử lại giúp mình nhé. (Đã hoàn tiền nếu bị trừ)' }] } : c)))
    } finally {
      setBusy(false)
    }
  }

  // Xem trước chế độ tự động đang nhận diện
  const previewKind = mode === 'auto' ? detectAuto(text, Boolean(attach)) : null

  const sidebar = (
    <div className="flex h-full w-72 flex-col border-r border-emerald-100 bg-white">
      <div className="flex items-center justify-between border-b border-emerald-100 p-3">
        <p className="flex items-center gap-1.5 text-sm font-bold text-emerald-800"><History className="h-4 w-4" /> Lịch sử chat</p>
        <button onClick={newConv} className="rounded-lg bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 hover:bg-emerald-100" aria-label="Cuộc trò chuyện mới">+ Mới</button>
      </div>
      <div className="flex-1 overflow-y-auto p-2">
        {convs.length === 0 ? (
          <p className="py-10 text-center text-xs text-stone-400">Chưa có cuộc trò chuyện nào</p>
        ) : (
          convs.map((c) => (
            <div key={c.id} className={`group flex items-center gap-2 rounded-lg px-2.5 py-2 transition ${activeId === c.id ? 'bg-emerald-50' : 'hover:bg-stone-50'}`}>
              <button onClick={() => { setActiveId(c.id); setShowSidebar(false) }} className="min-w-0 flex-1 text-left">
                <p className="truncate text-sm font-medium">{c.title || 'Cuộc trò chuyện'}</p>
                <p className="text-[10px] text-stone-400">{c.msgs.length} tin, {new Date(c.at).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}</p>
              </button>
              <button onClick={() => removeConv(c.id)} className="rounded-lg p-1.5 text-stone-300 transition hover:bg-red-50 hover:text-red-500 group-hover:text-stone-400" aria-label={`Xóa ${c.title}`}>
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))
        )}
      </div>
      <div className="border-t border-emerald-100 p-3 text-[11px] leading-relaxed text-stone-500">
        <p className="font-semibold text-emerald-700">Vexon AI tổng hợp mọi công cụ</p>
        <p>Chat miễn phí, Vẽ ảnh {fmtXuWithUsd(BOT_TOOLS.image.price, rate)}, Nhìn ảnh {fmtXuWithUsd(BOT_TOOLS.vision.price, rate)}, Tìm web {fmtXuWithUsd(BOT_TOOLS.search.price, rate)}, một ví tiền USD chung cả mạng lưới, 2 lượt miễn phí mỗi ngày.</p>
      </div>
    </div>
  )

  return (
    <div className="flex h-screen flex-col bg-stone-50">
      {/* Header riêng của trang chatbot */}
      <header className="sticky top-0 z-40 border-b border-emerald-100 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-14 w-full max-w-6xl items-center justify-between gap-2 px-3 sm:px-5">
          <div className="flex items-center gap-2">
            <a href="/" className="rounded-lg p-2 text-stone-500 transition hover:bg-stone-100 hover:text-stone-800" title="Về Vexon" aria-label="Về Vexon">
              <ArrowLeft className="h-5 w-5" />
            </a>
            {/* Bỏ logo ở trang chat — splash/loading đã có logo; giữ badge AI gọn */}
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 shadow-lg shadow-emerald-600/25">
              <Sparkles className="h-5 w-5 text-white" />
            </span>
            <span className="leading-tight">
              <span className="block text-sm font-extrabold tracking-wide text-emerald-900 sm:text-base">Vexon AI</span>
              <span className="hidden text-[10px] leading-tight text-stone-500 sm:block">Tổng hợp mọi công cụ — nhập lệnh, tự xử lý</span>
            </span>
          </div>
          <div className="flex items-center gap-2">
            {/* Một ví tiền USD CHUNG cả mạng lưới — số dư giống hệt mạng xã hội & Công cụ AI */}
            {me ? (
              <span
                className="flex h-9 items-center gap-1.5 whitespace-nowrap rounded-full border border-amber-300 bg-amber-50 px-3 text-sm font-bold text-amber-700"
                title={freeLeft > 0 ? `Còn ${freeLeft}/2 lượt miễn phí hôm nay` : 'Hết 2 lượt miễn phí, vẽ ảnh / nhìn ảnh / tìm web tính tiền vào ví'}
                aria-label={`Ví tiền chung: ${fmtXuWithUsd(xu, rate)}`}
              >
                <Coins className="h-4 w-4" />
                {fmtXuWithUsd(xu, rate)}
              </span>
            ) : (
              <a
                href="/"
                className="flex h-9 items-center gap-1.5 whitespace-nowrap rounded-full border border-amber-300 bg-amber-50 px-3 text-xs font-bold text-amber-700 transition hover:bg-amber-100"
                title="Đăng nhập Vexon để ví tiền USD chung đồng bộ số dư thật của bạn"
                aria-label="Đăng nhập để dùng ví tiền USD chung"
              >
                <Coins className="h-4 w-4" />
                Đăng nhập, ví tiền USD chung
              </a>
            )}
            <button onClick={() => setShowSidebar((s) => !s)} className="rounded-lg p-2 text-stone-600 hover:bg-emerald-50 lg:hidden" aria-label="Lịch sử trò chuyện">
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex w-full max-w-6xl flex-1 overflow-hidden">
        {/* Sidebar lịch sử — desktop */}
        <aside className="hidden lg:block">{sidebar}</aside>
        {/* Sidebar lịch sử — mobile drawer */}
        {showSidebar && (
          <div className="fixed inset-0 z-50 flex lg:hidden">
            <div className="flex-1 bg-black/40" onClick={() => setShowSidebar(false)} aria-hidden />
            <div className="h-full">{sidebar}</div>
          </div>
        )}

        {/* Khung chat chính */}
        <main className="flex min-w-0 flex-1 flex-col">
          {/* Tin nhắn */}
          <div className="flex-1 space-y-3 overflow-y-auto p-3 sm:p-5">
            {msgs.length === 0 && (
              <div className="mx-auto max-w-2xl space-y-4">
                <div className="rounded-2xl border border-emerald-100 bg-white p-5 shadow-sm">
                  <p className="flex items-center gap-2 text-lg font-bold text-emerald-800"><Sparkles className="h-5 w-5" /> Xin chào {me?.fullName || 'bạn'}!</p>
                  <p className="mt-1.5 text-sm leading-relaxed text-stone-600">
                    Mình là <b>Vexon AI</b>, chatbot tổng hợp mọi công cụ của mạng lưới Vexon. Chỉ cần nhập câu lệnh, mình <b>tự động xử lý</b>:
                    hội thoại mọi chủ đề (miễn phí), <b>vẽ ảnh</b> ({fmtXuWithUsd(BOT_TOOLS.image.price, rate)}), <b>nhìn ảnh trả lời</b> ({fmtXuWithUsd(BOT_TOOLS.vision.price, rate)}), <b>tìm kiếm &amp; tổng hợp dữ liệu web</b> ({fmtXuWithUsd(BOT_TOOLS.search.price, rate)}),
                    viết bài, dịch thuật, phân tích, và <b>đọc to</b> câu trả lời. Mỗi ngày bạn được <b>2 lượt miễn phí</b> áp dụng cho mọi công cụ AI!
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {CAPABILITIES.map((c) => (
                    <button
                      key={c.label}
                      onClick={() => { if (c.prompt) send(c.prompt) }}
                      className="flex flex-col items-start gap-1 rounded-xl border border-emerald-100 bg-white p-3 text-left transition hover:border-emerald-300 hover:shadow-sm"
                    >
                      <span className="text-xl">{c.icon}</span>
                      <span className="text-xs font-bold text-stone-700">{c.label}</span>
                      <span className="text-[10px] leading-snug text-stone-400">{c.hint || c.prompt.slice(0, 46) + '...'}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            {msgs.map((m, i) => (
              <div key={i} className={`mx-auto max-w-3xl ${m.role === 'user' ? 'flex justify-end' : ''}`}>
                <div className={`max-w-[88%] rounded-2xl px-4 py-2.5 text-sm shadow-sm ${m.role === 'user' ? 'bg-gradient-to-br from-emerald-600 to-teal-600 text-white' : 'border bg-white text-stone-700'}`}>
                  {m.image && (
                    <div className="mb-2">
                      <img src={m.image} alt="Ảnh trong hội thoại" className="max-h-56 rounded-xl" />
                      {m.role === 'ai' && (
                        <a href={m.image} download={`vexon-ai-${i}.png`} className="mt-1.5 inline-flex items-center gap-1 rounded-lg bg-emerald-50 px-2 py-1 text-[11px] font-semibold text-emerald-700 hover:bg-emerald-100">
                          <Download className="h-3 w-3" /> Tải ảnh
                        </a>
                      )}
                    </div>
                  )}
                  <p className="whitespace-pre-wrap">{m.text}</p>
                  {m.sources && m.sources.length > 0 && (
                    <div className="mt-2 space-y-0.5 border-t border-stone-100 pt-2">
                      <p className="text-[10px] font-bold uppercase tracking-wide text-stone-400">Nguồn tổng hợp</p>
                      {m.sources.slice(0, 6).map((s, j) => (
                        <a key={j} href={s.url} target="_blank" rel="noreferrer" className="block truncate text-[11px] text-emerald-600 hover:underline"><Link2 className="mr-0.5 inline h-3 w-3" /> {s.name}</a>
                      ))}
                    </div>
                  )}
                  {m.docs && m.docs.length > 0 && (
                    <p className="mt-2 flex flex-wrap items-center gap-1 border-t border-stone-100 pt-2 text-[11px] font-semibold text-emerald-600">
                      <Library className="h-3 w-3" /> Tra theo tài liệu của bạn: {m.docs.join(', ')}
                    </p>
                  )}
                  {m.role === 'ai' && m.text && (
                    <button onClick={() => speak(i)} className="mt-1.5 flex items-center gap-1 rounded-lg px-1.5 py-0.5 text-[11px] font-medium text-emerald-600 transition hover:bg-emerald-50" aria-label="Đọc to câu trả lời">
                      {speakingId === String(i) ? <Square className="h-3 w-3" /> : <Volume2 className="h-3 w-3" />} {speakingId === String(i) ? 'Dừng đọc' : 'Đọc to'}
                    </button>
                  )}
                </div>
              </div>
            ))}
            {busy && (
              <div className="mx-auto flex w-fit items-center gap-1.5 rounded-full border bg-white px-3 py-1.5 text-xs text-emerald-600 shadow-sm">
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> Vexon AI đang tổng hợp & xử lý...
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Ảnh đính kèm */}
          {attach && (
            <div className="mx-auto flex w-full max-w-3xl items-center gap-2 px-3 pb-1">
              <div className="flex flex-1 items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50/70 px-3 py-1.5">
                <img src={attach} alt="Ảnh đính kèm" className="h-10 w-10 rounded-lg object-cover" />
                <p className="flex-1 truncate text-xs text-emerald-700">Đã gắn ảnh, AI sẽ nhìn ảnh và trả lời</p>
                <button onClick={() => setAttach(null)} className="rounded-lg p-1 text-emerald-500 hover:bg-emerald-100" aria-label="Bỏ ảnh"><X className="h-3.5 w-3.5" /></button>
              </div>
            </div>
          )}

          {/* Thanh chế độ */}
          <div className="mx-auto w-full max-w-3xl px-3">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5">
              <button
                onClick={() => { setMode('auto'); setWebOn(false) }}
                className={`flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${mode === 'auto' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow' : 'border bg-white text-stone-600 hover:bg-emerald-50'}`}
                title="Tự động nhận diện câu lệnh: chat, vẽ ảnh, tìm web, nhìn ảnh"
                aria-label="Chế độ tự động"
              >
                <Zap className="h-3.5 w-3.5" /> Tự động {previewKind ? `→ ${AUTO_BADGE[previewKind].label}` : ''}
              </button>
              <button
                onClick={() => { setMode('chat'); setWebOn(false) }}
                className={`flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${mode === 'chat' && !webOn ? 'bg-emerald-600 text-white' : 'border bg-white text-stone-600 hover:bg-emerald-50'}`}
                aria-label="Chế độ hội thoại"
              >
                <Sparkles className="h-3.5 w-3.5" /> Chat
              </button>
              <button
                onClick={() => { setMode('image'); setWebOn(false) }}
                className={`flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${mode === 'image' ? 'bg-teal-600 text-white' : 'border bg-white text-stone-600 hover:bg-teal-50'}`}
                aria-label="Chế độ vẽ ảnh"
              >
                <ImageIcon className="h-3.5 w-3.5" /> Vẽ ảnh
              </button>
              <button
                onClick={() => { setMode('chat'); setWebOn(!webOn) }}
                className={`flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${webOn ? 'bg-sky-600 text-white' : 'border bg-white text-stone-600 hover:bg-sky-50'}`}
                title="Tìm thông tin thực trên web rồi tổng hợp trả lời"
                aria-label="Bật tìm kiếm web"
              >
                <Globe className="h-3.5 w-3.5" /> Web {webOn ? 'BẬT' : ''}
              </button>
              <button
                onClick={() => setVoiceOn((v) => !v)}
                className={`flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${voiceOn ? 'bg-indigo-600 text-white' : 'border bg-white text-stone-600 hover:bg-emerald-50'}`}
                title="Giọng nói: nói vào micro, AI nghe và TỰ ĐỌC TO câu trả lời (kiểu ChatGPT Voice)"
                aria-label="Chế độ giọng nói"
              >
                <Mic className="h-3.5 w-3.5" /> Giọng nói {voiceOn ? 'BẬT' : ''}
              </button>
              <button
                onClick={() => fileRef.current?.click()}
                className="flex shrink-0 items-center gap-1 rounded-full border bg-white px-3 py-1.5 text-[11px] font-bold text-stone-600 transition hover:bg-emerald-50 hover:text-emerald-700"
                title="Gửi ảnh cho AI nhìn và trả lời"
                aria-label="Gắn ảnh cho AI nhìn"
              >
                <ImagePlus className="h-3.5 w-3.5" /> Gắn ảnh
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { pickAttach(e.target.files?.[0]); e.target.value = '' }} />
              </button>
              <button
                onClick={openGifPicker}
                className="flex shrink-0 items-center gap-1 rounded-full border bg-white px-3 py-1.5 text-[11px] font-bold text-stone-600 transition hover:bg-emerald-50 hover:text-emerald-700"
                title="GIF Hub — tìm và gửi GIF vui vào hội thoại"
                aria-label="Gửi GIF"
              >
                <Sticker className="h-3.5 w-3.5" /> GIF
              </button>
              <button
                onClick={openDocs}
                className={`flex shrink-0 items-center gap-1 rounded-full border px-3 py-1.5 text-[11px] font-bold transition ${myDocs.length > 0 ? 'border-emerald-300 bg-emerald-50 text-emerald-700' : 'bg-white text-stone-600 hover:bg-emerald-50 hover:text-emerald-700'}`}
                title="Tải tài liệu lên (PDF, TXT, MD, CSV...), Vexon AI sẽ tự tra tài liệu khi trả lời, kiểu AnythingLLM"
                aria-label="Tài liệu của tôi, kiến thức riêng cho Vexon AI"
              >
                <Library className="h-3.5 w-3.5" /> Tài liệu {myDocs.length > 0 ? `(${myDocs.length})` : ''}
              </button>
              <a href="/" className="ml-auto flex shrink-0 items-center gap-1 rounded-full border bg-white px-3 py-1.5 text-[11px] font-bold text-stone-500 transition hover:bg-stone-100" title="Mở Công cụ AI đầy đủ trong Vexon">
                <Wand2 className="h-3.5 w-3.5" /> Công cụ AI
              </a>
            </div>
          </div>

          {/* Ô nhập câu lệnh */}
          <form className="mx-auto w-full max-w-3xl p-3 pb-20 pt-1 lg:pb-3" onSubmit={(e) => { e.preventDefault(); send() }}>
            <div className="flex items-center gap-2 rounded-2xl border border-emerald-200 bg-white p-2 shadow-sm focus-within:border-emerald-400">
              {voiceOn && (
                <button
                  type="button"
                  onClick={toggleRecord}
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition ${recording ? 'animate-pulse bg-rose-600 text-white' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'}`}
                  title={recording ? 'Bấm lần nữa để kết thúc và chuyển giọng nói thành chữ' : 'Bấm để nói — AI tự nghe và điền câu lệnh'}
                  aria-label={recording ? 'Dừng ghi âm' : 'Bắt đầu nói'}
                >
                  {transcribing ? <Loader2 className="h-5 w-5 animate-spin" /> : recording ? <Square className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                </button>
              )}
              <Input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder={mode === 'image' ? 'Mô tả ảnh muốn vẽ...' : recording ? 'Đang nghe bạn nói...' : 'Nhập câu lệnh, Vexon AI tự động xử lý...'}
                aria-label="Nhập câu lệnh cho Vexon AI"
                className="h-10 border-0 bg-transparent text-sm focus-visible:ring-0"
              />
              {speakingId === 'auto' && (
                <button type="button" onClick={stopAudio} className="flex h-10 shrink-0 items-center gap-1 rounded-xl bg-indigo-50 px-3 text-xs font-bold text-indigo-700 hover:bg-indigo-100" aria-label="Dừng đọc to">
                  <MicOff className="h-4 w-4" /> Dừng đọc
                </button>
              )}
              <Button type="submit" size="icon" className="h-10 w-10 shrink-0 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500" disabled={busy || (!text.trim() && !attach)} aria-label="Gửi câu lệnh">
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <p className="mt-1.5 text-center text-[10px] text-stone-400">Vexon AI tổng hợp Chat · Giọng nói · Vẽ ảnh · Nhìn ảnh · Tìm web · GIF · Tài liệu riêng — chat miễn phí, một ví tiền USD chung cả mạng lưới</p>
          </form>
        </main>
      </div>

      {/* Menu dưới màn hình (mobile) — điều hướng nhanh giữa Vexon AI và các phân hệ chính */}
      <nav
        className="fixed inset-x-0 bottom-0 z-40 border-t border-stone-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden"
        aria-label="Menu dưới Vexon AI"
      >
        <div className="mx-auto flex max-w-md items-stretch justify-around">
          <a href="/" className="flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] font-semibold text-stone-400 transition-colors hover:text-stone-600" aria-label="Mở mạng xã hội Vexon">
            <Home className="h-5 w-5" />
            Trang chủ
          </a>
          <a href="/?view=tools" className="flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] font-semibold text-stone-400 transition-colors hover:text-stone-600" aria-label="Mở Công cụ AI">
            <Wand2 className="h-5 w-5" />
            Công cụ
          </a>
          <a href="/?view=wallet" className="flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] font-semibold text-stone-400 transition-colors hover:text-stone-600" aria-label="Mở Ví tiền">
            <Coins className="h-5 w-5" />
            Ví tiền USD
          </a>
          <span className="flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] font-semibold text-emerald-600" aria-current="page">
            <Sparkles className="h-5 w-5" />
            Vexon AI
          </span>
        </div>
      </nav>

      {/* Dialog Tài liệu riêng (RAG kiểu AnythingLLM) */}
      <Dialog open={docsOpen} onOpenChange={setDocsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Library className="h-5 w-5 text-emerald-600" /> Tài liệu của tôi</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="rounded-lg bg-emerald-50 px-3 py-2 text-xs leading-relaxed text-emerald-800">
              Tải lên PDF, TXT, MD, CSV, JSON (tối đa 8MB) hoặc dán thẳng nội dung. Từ giờ khi chat, <b>Vexon AI tự tra tài liệu này</b> và trả lời theo đúng dữ liệu của bạn, ghi rõ nguồn từng tài liệu.
            </p>
            <button
              onClick={() => docFileRef.current?.click()}
              disabled={docBusy}
              className="flex w-full flex-col items-center gap-1 rounded-xl border-2 border-dashed border-emerald-200 bg-emerald-50/40 py-6 transition hover:border-emerald-400 disabled:opacity-60"
              aria-label="Chọn tệp tài liệu để tải lên"
            >
              {docBusy ? <Loader2 className="h-6 w-6 animate-spin text-emerald-600" /> : <Upload className="h-6 w-6 text-emerald-500" />}
              <span className="text-xs font-bold text-emerald-700">Bấm để chọn tệp tải lên</span>
              <span className="text-[10px] text-emerald-400">PDF, TXT, MD, CSV, JSON, tối đa 12 tài liệu</span>
            </button>
            <input ref={docFileRef} type="file" accept=".pdf,.txt,.md,.csv,.json,.log,.xml,.html,.htm" className="hidden" onChange={(e) => uploadDocFile(e.target.files?.[0])} />
            <details className="rounded-xl border p-3">
              <summary className="cursor-pointer text-xs font-bold text-stone-600">Hoặc dán thẳng nội dung</summary>
              <div className="mt-2 space-y-2">
                <Input value={pasteName} onChange={(e) => setPasteName(e.target.value)} placeholder="Tên tài liệu, ví dụ: Quy định công ty 2026" aria-label="Tên tài liệu" />
                <Textarea value={pasteText} onChange={(e) => setPasteText(e.target.value)} placeholder="Dán nội dung vào đây..." rows={4} aria-label="Nội dung tài liệu" />
                <Button size="sm" className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={uploadDocText} disabled={docBusy}>
                  <FileText className="mr-1 h-4 w-4" /> Lưu làm kiến thức
                </Button>
              </div>
            </details>
            <div className="space-y-1.5">
              <p className="text-xs font-bold text-stone-600">Đã học ({myDocs.length}/12)</p>
              {myDocs.length === 0 ? (
                <p className="rounded-lg border border-dashed p-4 text-center text-xs text-stone-400">Chưa có tài liệu nào</p>
              ) : (
                myDocs.map((d) => (
                  <div key={d.id} className="group flex items-center gap-2 rounded-lg border bg-white px-3 py-2">
                    <FileText className="h-4 w-4 shrink-0 text-emerald-500" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-semibold">{d.name}</p>
                      <p className="text-[10px] text-stone-400">{d.chunks} đoạn, {d.sizeChars.toLocaleString('vi-VN')} ký tự, {d.kind.toUpperCase()}</p>
                    </div>
                    <button onClick={() => deleteDoc(d.id)} className="rounded-lg p-1.5 text-stone-300 transition hover:bg-red-50 hover:text-red-500 group-hover:text-stone-400" aria-label={`Xoá tài liệu ${d.name}`}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog GIF Hub — tìm GIF theo từ khoá rồi gửi thẳng vào hội thoại */}
      <Dialog open={gifOpen} onOpenChange={setGifOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Sticker className="h-5 w-5 text-emerald-600" /> GIF Hub</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); loadGifs(gifQ) }}>
              <Input value={gifQ} onChange={(e) => setGifQ(e.target.value)} placeholder="Tìm GIF: mèo, vỗ tay, party..." aria-label="Tìm GIF" />
              <Button type="submit" size="sm" className="bg-emerald-600 hover:bg-emerald-700" disabled={gifBusy} aria-label="Tìm GIF">
                {gifBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />} Tìm
              </Button>
            </form>
            {gifs.length === 0 && !gifBusy && <p className="rounded-lg border border-dashed p-6 text-center text-xs text-stone-400">Không có GIF, thử từ khoá khác nhé</p>}
            <div className="grid grid-cols-3 gap-2">
              {gifs.map((g) => (
                <button key={g.id} onClick={() => sendGif(g)} className="group overflow-hidden rounded-xl border transition hover:border-emerald-400 hover:shadow" aria-label={`Gửi GIF ${g.title}`}>
                  <img src={g.url} alt={g.title} loading="lazy" className="aspect-square w-full object-cover" />
                  <p className="truncate px-1.5 py-1 text-[10px] text-stone-500">{g.title}</p>
                </button>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
