'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import type { VxUserInfo } from './AuthView'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'
import { BankTopUpButton } from './BankTopUp'
import { fmtUsdFromXu, fmtUsdSigned, fmtUsdNumber, usdToXu } from '@/lib/format'
import { refreshUsdRate, useUsdRateInfo } from '@/lib/use-usd-rate'
import { ArrowDownRight, ArrowUpRight, ArrowLeftRight, Banknote, CalendarCheck, Copy, CreditCard, Eye, EyeOff, Gift, Hourglass, KanbanSquare, Lightbulb, Loader2, MessageCircle, Newspaper, Nfc, PlayCircle, RefreshCw, Send, ShieldCheck, Snowflake, Sparkles, TrendingDown, TrendingUp, Wallet } from 'lucide-react'

/** Chip EMV vàng có viền tiếp xúc như thẻ thật — mỗi chỗ dùng cần gid riêng để id gradient không trùng */
function VxCardChip({ className = 'h-9 w-11 drop-shadow', gid = 'vxChipGold' }: { className?: string; gid?: string }) {
  return (
    <svg viewBox="0 0 48 36" className={className} aria-hidden="true">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#fef9c3" />
          <stop offset="45%" stopColor="#fbbf24" />
          <stop offset="100%" stopColor="#d97706" />
        </linearGradient>
      </defs>
      <rect x="1" y="1" width="46" height="34" rx="7" fill={`url(#${gid})`} stroke="#a16207" strokeWidth="1.4" />
      <g fill="none" stroke="#a16207" strokeWidth="1.3" opacity="0.85">
        <path d="M1 12h12M1 24h12M35 12h12M35 24h12" />
        <rect x="13" y="6" width="22" height="24" rx="5" />
        <path d="M13 18h22M24 6v12M24 30V18" />
      </g>
    </svg>
  )
}

interface Tx { id: string; amount: number; reason: string; createdAt: string }
interface WalletTx {
  id: string
  type: 'deposit' | 'withdraw'
  amountVnd: number
  amountXu: number
  taxVnd: number
  proofCode?: string | null
  bankName?: string | null
  accountNumber?: string | null
  accountHolder?: string | null
  status: 'pending' | 'approved' | 'rejected'
  adminNote?: string | null
  createdAt: string
}
interface WalletData {
  coins: number
  accountType: string
  canClaimBonus: boolean
  nextBonusInMin: number
  txs: Tx[]
  giftsSent: { total: number; coins: number }
  giftsReceived: { total: number; coins: number }
}

const fmtVnd = (n: number) => n.toLocaleString('vi-VN')
/** 16 số → nhóm 4: 9704821243211234 → "9704 8212 4321 1234" */
const groupCardNumber = (n: string) => n.replace(/(\d{4})(?=\d)/g, '$1 ')

// Thẻ Vexon Pay — thẻ ngân hàng riêng của mạng xã hội (quản lý ví tiền USD)
interface SocialCardT {
  id: string
  cardNumber: string
  holder: string
  expMonth: number
  expYear: number
  cvv: string
  product: string
  status: string
  createdAt: string
}

const MIN_TRANSFER_XU = 100 // chặn chuyển lẻ tẻ (~$0,39)

const TX_STATUS: Record<string, { label: string; cls: string }> = {
  pending: { label: 'Chờ duyệt', cls: 'bg-amber-100 text-amber-800 hover:bg-amber-100' },
  approved: { label: 'Đã duyệt', cls: 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100' },
  rejected: { label: 'Từ chối', cls: 'bg-rose-100 text-rose-700 hover:bg-rose-100' },
}

export default function WalletView({ me, onRefreshUser }: { me: VxUserInfo; onRefreshUser: () => void }) {
  const [data, setData] = useState<WalletData | null>(null)
  const [loading, setLoading] = useState(true)
  const [claiming, setClaiming] = useState(false)
  const lastLoad = useRef(0)
  // Nạp/rút qua ngân hàng — mọi giao dịch đều CHỜ Ban Giám đốc duyệt
  const [walletTxs, setWalletTxs] = useState<WalletTx[]>([])
  const [withdrawOpen, setWithdrawOpen] = useState(false)
  const [wXu, setWXu] = useState('')
  const [wBank, setWBank] = useState('')
  const [wAcc, setWAcc] = useState('')
  const [wHolder, setWHolder] = useState('')
  const [withdrawing, setWithdrawing] = useState(false)
  // Thẻ Vexon Pay: mở thẻ / hiện số / đóng băng
  const [card, setCard] = useState<SocialCardT | null>(null)
  const [showNum, setShowNum] = useState(false)
  const [openCardOpen, setOpenCardOpen] = useState(false)
  const [opening, setOpening] = useState(false)
  const [freezing, setFreezing] = useState(false)
  // Chuyển tiền USD: người nhận / số tiền / lời nhắn — form chỉ nằm trong popup mở từ nút trên thanh số dư
  const [tfTo, setTfTo] = useState('')
  const [tfUsd, setTfUsd] = useState('')
  const [tfMsg, setTfMsg] = useState('')
  const [tfBusy, setTfBusy] = useState(false)
  const [tfOpen, setTfOpen] = useState(false) // popup chuyển tiền mở từ nút trên thanh số dư
  // Tỷ giá USD/VND thực tế — AI tự cập nhật theo thị trường (hỏi lại mỗi 10 phút + khi quay lại tab)
  const rateInfo = useUsdRateInfo()
  const rate = rateInfo.rate
  const [rateRefreshing, setRateRefreshing] = useState(false)
  const rateTime = rateInfo.updatedAt ? new Date(rateInfo.updatedAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : null
  const ratePct = rateInfo.changePct !== null
    ? (rateInfo.changePct > 0 ? '+' : '') + rateInfo.changePct.toLocaleString('vi-VN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '%'
    : null

  const load = useCallback(() => {
    lastLoad.current = Date.now()
    fetch('/api/vx/wallet')
      .then((r) => r.json())
      .then((d) => d && d.txs && setData(d))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const loadWalletTxs = useCallback(() => {
    fetch('/api/vx/wallet-tx')
      .then((r) => r.json())
      .then((d) => Array.isArray(d.txs) && setWalletTxs(d.txs))
      .catch(() => {})
  }, [])

  const loadCard = useCallback(() => {
    fetch('/api/vx/social-card')
      .then((r) => r.json())
      .then((d) => setCard(d.card ?? null))
      .catch(() => {})
  }, [])

  useDeferredLoad(() => { load(); loadWalletTxs(); loadCard() }, [load, loadWalletTxs, loadCard])

  // r30: nhập số USD muốn rút — đổi theo tỷ giá sống (giữ state cũ wXu làm chuỗi nhập, giờ chứa USD)
  const withdrawUsd = Number(wXu.replace(',', '.').replace(/[^\d.]/g, '')) || 0
  const withdrawXu = withdrawUsd > 0 ? usdToXu(withdrawUsd, rate) : 0
  const wGrossVnd = Math.round(withdrawUsd * rate)
  const wTaxVnd = Math.round(wGrossVnd * 0.1)
  const wNetVnd = wGrossVnd - wTaxVnd

  const submitWithdraw = async () => {
    if (withdrawUsd < 2) { toast.error('Rút tối thiểu $2,00'); return }
    if (!wBank.trim() || !wAcc.trim() || !wHolder.trim()) { toast.error('Nhập đầy đủ ngân hàng, số tài khoản và chủ tài khoản'); return }
    setWithdrawing(true)
    try {
      const res = await fetch('/api/vx/wallet-tx', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'withdraw', amountUsd: withdrawUsd, bankName: wBank, accountNumber: wAcc, accountHolder: wHolder }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không gửi được yêu cầu rút')
      toast.success(`Đã gửi yêu cầu rút $${fmtUsdNumber(withdrawUsd)}`, { description: `Nhận ${d.tx.netVnd.toLocaleString('vi-VN')}đ (sau thuế 10%) — chờ Ban Giám đốc duyệt` })
      setWithdrawOpen(false)
      setWXu('')
      onRefreshUser()
      load()
      loadWalletTxs()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không gửi được yêu cầu rút')
    } finally { setWithdrawing(false) }
  }

  // Ví tiền CHUNG — khi Công cụ AI / Vexon AI tiêu xu nội bộ hoặc kiếm xu ở nơi khác,
  // thẻ số dư ở đây cũng nhảy số theo ngay (không còn 2 ví lệch nhau)
  useEffect(() => {
    const onCoins = (e: Event) => {
      const coins = (e as CustomEvent<{ coins?: number }>).detail?.coins
      if (typeof coins === 'number') setData((d) => (d && d.coins !== coins ? { ...d, coins } : d))
      if (Date.now() - lastLoad.current > 2000) load()
    }
    window.addEventListener('vx-coins-changed', onCoins)
    return () => window.removeEventListener('vx-coins-changed', onCoins)
  }, [load])

  const claim = async () => {
    setClaiming(true)
    const res = await fetch('/api/vx/wallet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'daily_bonus' }),
    })
    const d = await res.json()
    setClaiming(false)
    if (res.ok) {
      toast.success(`${fmtUsdFromXu(50, rate)}! Số dư: ${fmtUsdFromXu(d.coins, rate)}`)
      onRefreshUser()
      load()
    } else toast.error(d.error || 'Không nhận được thưởng')
  }

  // Mở thẻ Vexon Pay — thẻ ngân hàng riêng của mạng xã hội, miễn phí
  const openCard = async () => {
    setOpening(true)
    try {
      const res = await fetch('/api/vx/social-card', { method: 'POST' })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không mở được thẻ')
      setCard(d.card)
      setOpenCardOpen(false)
      toast.success('Mở thẻ Vexon Pay thành công! Thẻ đã liên kết ví tiền của bạn.')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không mở được thẻ')
    } finally { setOpening(false) }
  }

  // Đóng băng / mở băng thẻ khi nghi ngờ mất thẻ
  const toggleFreeze = async () => {
    if (!card) return
    setFreezing(true)
    try {
      const action = card.status === 'frozen' ? 'unfreeze' : 'freeze'
      const res = await fetch('/api/vx/social-card', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không cập nhật được thẻ')
      setCard(d.card)
      toast.success(action === 'freeze' ? 'Đã đóng băng thẻ — mọi giao dịch qua thẻ bị tạm dừng' : 'Đã mở băng thẻ, thẻ hoạt động bình thường trở lại')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không cập nhật được thẻ')
    } finally { setFreezing(false) }
  }

  const copyCardNumber = async () => {
    if (!card) return
    try {
      await navigator.clipboard.writeText(card.cardNumber)
      toast.success('Đã sao chép số thẻ Vexon Pay')
    } catch { toast.error('Không sao chép được số thẻ') }
  }

  // Số tiền đang nhập ở form chuyển (USD → xu theo tỷ giá hiện tại)
  const tfUsdNum = Number(tfUsd.replace(',', '.').replace(/[^\d.]/g, '')) || 0
  const tfXu = tfUsdNum > 0 ? usdToXu(tfUsdNum, rate) : 0

  // CHUYỂN TIỀN USD cho người dùng khác — 0 phí, đến ngay
  const submitTransfer = async () => {
    const to = tfTo.trim().replace(/^@/, '')
    if (!to) { toast.error('Nhập username người nhận (VD: @hongnhung)'); return }
    if (tfUsdNum <= 0) { toast.error('Nhập số tiền USD muốn chuyển'); return }
    if (tfXu < MIN_TRANSFER_XU) { toast.error(`Tối thiểu ${fmtUsdFromXu(MIN_TRANSFER_XU, rate)} mỗi lần chuyển`); return }
    setTfBusy(true)
    try {
      const res = await fetch('/api/vx/transfers', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ toUsername: to, amountUsd: tfUsdNum, message: tfMsg.trim() || undefined }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không chuyển được tiền')
      toast.success(d.message || 'Đã chuyển tiền thành công')
      setTfTo(''); setTfUsd(''); setTfMsg('')
      setTfOpen(false) // chuyển xong tự đóng popup
      load(); onRefreshUser()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không chuyển được tiền')
    } finally { setTfBusy(false) }
  }

  return (
    <div className="space-y-5">
      {/* Số dư — VÍ TIỀN USD quy theo TỶ GIÁ THẬT (live) */}
      <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-700 via-teal-600 to-emerald-500 p-6 text-white shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="flex items-center gap-1.5 text-sm font-medium text-emerald-50"><Wallet className="h-4 w-4" /> Số dư ví tiền Vexon (USD)</p>
            <p className="mt-1 text-5xl font-black tracking-tight">{loading ? <span className="inline-block h-10 w-40 animate-pulse rounded-lg bg-white/30 align-middle" /> : fmtUsdFromXu(data?.coins ?? me.coins ?? 0, rate)}</p>
            <p className="mt-1 text-xs text-emerald-50/90">Ví tiền USD dùng chung cho cả mạng lưới Vexon — đổi theo tỷ giá thị trường thực tế</p>
            {/* Tỷ giá SỐNG — AI tự bám thị trường: mũi tên tăng/giảm + % thay đổi + giờ cập nhật, nút xoay tròn hỏi lại ngay */}
            <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
              <span className="inline-flex items-center gap-1 rounded-full bg-white/15 px-2.5 py-1 text-xs font-bold text-white">
                {rateInfo.trend === 'up' ? <TrendingUp className="h-3.5 w-3.5 text-lime-200" /> : rateInfo.trend === 'down' ? <TrendingDown className="h-3.5 w-3.5 text-rose-200" /> : <ArrowLeftRight className="h-3.5 w-3.5" />}
                1$ = {rate.toLocaleString('vi-VN')}đ
                {ratePct && <span className={`rounded-full px-1.5 py-0.5 text-[10px] font-black ${rateInfo.trend === 'up' ? 'bg-lime-300/20 text-lime-100' : rateInfo.trend === 'down' ? 'bg-rose-300/20 text-rose-100' : 'bg-white/15 text-emerald-50'}`}>{ratePct}</span>}
              </span>
              <span className="inline-flex items-center gap-1 rounded-full bg-white/10 px-2 py-1 text-[10px] text-emerald-50">
                <Sparkles className="h-3 w-3 text-lime-200" /> AI tự cập nhật theo thị trường{rateTime ? ` · ${rateTime}` : ''}
              </span>
              <button
                onClick={async () => { setRateRefreshing(true); try { await refreshUsdRate() } finally { setTimeout(() => setRateRefreshing(false), 600) } }}
                className="rounded-full bg-white/10 p-1 text-emerald-50 transition hover:bg-white/20"
                aria-label="Làm mới tỷ giá USD ngay"
                title="Hỏi lại thị trường ngay"
              >
                <RefreshCw className={`h-3 w-3 ${rateRefreshing ? 'animate-spin' : ''}`} />
              </button>
            </div>
            {data && !data.canClaimBonus && <p className="mt-1 text-xs text-emerald-50">Điểm danh tiếp sau {data.nextBonusInMin} phút</p>}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <BankTopUpButton
              username={me.username}
              onSubmitted={() => {
                // Yêu cầu nạp CHỜ DUYỆT đã tạo — số dư chỉ tăng sau khi Ban Giám đốc duyệt
                loadWalletTxs()
              }}
              className="h-11 gap-2 rounded-xl bg-stone-900 px-4 font-bold text-white hover:bg-stone-800"
              label="Nạp tiền qua QR ngân hàng"
            />
            <Button
              className="h-11 gap-2 rounded-xl bg-white px-4 font-bold text-emerald-700 hover:bg-emerald-50"
              onClick={() => setWithdrawOpen(true)}
              aria-label="Rút tiền về tài khoản ngân hàng"
            >
              <Banknote className="h-5 w-5" /> Rút tiền
            </Button>
            <Button
              className="h-11 gap-2 rounded-xl bg-white px-4 font-bold text-emerald-700 hover:bg-emerald-50"
              onClick={() => setTfOpen(true)}
              aria-label="Chuyển tiền cho người dùng Vexon khác"
            >
              <ArrowLeftRight className="h-5 w-5" /> Chuyển tiền
            </Button>
            <Button size="lg" className="bg-white text-lg font-black text-emerald-700 hover:bg-emerald-50" onClick={claim} disabled={claiming || (data ? !data.canClaimBonus : false)}>
              {claiming ? <Loader2 className="mr-1 h-5 w-5 animate-spin" /> : <Sparkles className="mr-1 h-5 w-5" />}
              {data?.canClaimBonus ? `Nhận +${fmtUsdFromXu(50, rate)}` : 'Đã nhận hôm nay'}
            </Button>
          </div>
        </div>
      </div>

      {/* THẺ VEXON PAY — thẻ ngân hàng riêng của mạng xã hội để quản lý ví tiền */}
      {card ? (
        <div className="space-y-2.5">
          <div className="relative max-w-md overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-950 via-emerald-800 to-teal-900 p-5 text-white shadow-xl">
            {/* Bố trí lại pattern (r28): BỎ lớp logo lặp toàn mặt gây rối — chỉ còn 1 watermark góc dưới phải + vệt sáng chéo nhẹ kiểu thẻ thật */}
            <div aria-hidden className="pointer-events-none absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.04] to-white/[0.10]" />
            <img aria-hidden src="/vexon-logo.png" alt="" className="pointer-events-none absolute -bottom-10 -right-10 h-44 w-44 rotate-12 opacity-[0.10]" />
            {card.status === 'frozen' && <div className="pointer-events-none absolute inset-0 z-10 bg-stone-950/60" />}
            <div className="relative flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <img src="/vexon-logo.png" alt="Logo Vexon Pay" className="h-8 w-8" />
                  <p className="text-[13px] font-black uppercase tracking-[0.2em] text-emerald-100">Vexon Pay</p>
                </div>
                <p className="mt-0.5 text-[10px] text-emerald-200/80">{card.product}</p>
              </div>
              <div className="text-right">
                <p className="text-[9px] uppercase tracking-wider text-emerald-200/70">Số dư khả dụng</p>
                <p className="text-lg font-black">{fmtUsdFromXu(data?.coins ?? me.coins ?? 0, rate)}</p>
              </div>
            </div>
            <div className="relative mt-4 flex items-center gap-3">
              <VxCardChip className="h-9 w-11 drop-shadow" gid="vxChipGoldMain" />
              <Nfc className="h-6 w-6 text-emerald-200/80" />
              {card.status === 'frozen' && (
                <Badge className="bg-stone-200 text-stone-800 hover:bg-stone-200"><Snowflake className="mr-1 h-3 w-3" /> Đã đóng băng</Badge>
              )}
            </div>
            <div className="relative mt-3 flex items-center gap-2">
              <p className="font-mono text-xl font-bold tracking-[0.16em]">
                {showNum ? groupCardNumber(card.cardNumber) : `9704  ••••  ••••  ${card.cardNumber.slice(-4)}`}
              </p>
              <button
                onClick={() => setShowNum((v) => !v)}
                className="rounded-lg bg-white/10 p-1.5 text-emerald-100 transition hover:bg-white/20"
                aria-label={showNum ? 'Ẩn chi tiết thẻ' : 'Hiện chi tiết thẻ'}
                title={showNum ? 'Ẩn chi tiết thẻ' : 'Hiện chi tiết thẻ'}
              >
                {showNum ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <div className="relative mt-3 flex flex-wrap items-end justify-between gap-3 text-[11px]">
              <div>
                <p className="text-[9px] uppercase tracking-wider text-emerald-200/70">Chủ thẻ</p>
                <p className="font-bold tracking-wide">{card.holder}</p>
              </div>
              <div>
                <p className="text-[9px] uppercase tracking-wider text-emerald-200/70">Hiệu lực đến</p>
                <p className="font-bold">{String(card.expMonth).padStart(2, '0')}/{String(card.expYear).slice(-2)}</p>
              </div>
              <div>
                <p className="text-[9px] uppercase tracking-wider text-emerald-200/70">CVV</p>
                <p className="font-bold">{showNum ? card.cvv : '•••'}</p>
              </div>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button size="sm" variant="outline" className="border-emerald-300 text-emerald-700 hover:bg-emerald-50" onClick={toggleFreeze} disabled={freezing}>
              {freezing ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <Snowflake className="mr-1 h-3.5 w-3.5" />}
              {card.status === 'frozen' ? 'Mở băng thẻ' : 'Đóng băng thẻ'}
            </Button>
            <Button size="sm" variant="outline" className="border-emerald-300 text-emerald-700 hover:bg-emerald-50" onClick={copyCardNumber}>
              <Copy className="mr-1 h-3.5 w-3.5" /> Sao chép số thẻ
            </Button>
            <p className="text-[11px] text-stone-500">Mở ngày {new Date(card.createdAt).toLocaleDateString('vi-VN')} · thẻ liên kết trực tiếp ví tiền USD của bạn</p>
          </div>
        </div>
      ) : (
        <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-emerald-200 bg-gradient-to-r from-emerald-50 to-teal-50 p-4">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 text-white shadow"><CreditCard className="h-6 w-6" /></span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold text-emerald-900">Thẻ Vexon Pay — thẻ ngân hàng riêng của mạng xã hội</p>
            <p className="mt-0.5 text-xs text-emerald-700/90">Mở thẻ để quản lý ví tiền USD của bạn: theo dõi số dư, nạp/rút, đóng băng ngay khi mất thẻ. Miễn phí mở thẻ, không phí thường niên.</p>
          </div>
          <Button className="bg-emerald-600 font-semibold hover:bg-emerald-700" onClick={() => setOpenCardOpen(true)}>
            <CreditCard className="mr-1 h-4 w-4" /> Mở thẻ ngay
          </Button>
        </div>
      )}

      {/* r29: đã gỡ khối “Chuyển tiền USD cho nhau” (form + lịch sử riêng) vì dư — nút “Chuyển tiền” trên thanh
          số dư mở popup là đủ; lịch sử chuyển/nhận xem ở “Lịch sử giao dịch ví tiền” dưới trang (API tự ghi 2 phía) */}
      {/* Cách kiếm tiền — một ví tiền USD chung cho toàn nền tảng */}
      <div className="rounded-xl border bg-white p-4 shadow-sm">
        <p className="font-bold">Nhiệm vụ kiếm tiền mỗi ngày</p>
        <p className="mt-0.5 text-xs text-stone-500">Một ví tiền USD dùng chung cho cả mạng lưới Vexon: mạng xã hội, Công cụ AI và Chatbot AI cùng một số dư duy nhất, không có ví riêng. Kiếm tiền bằng cách tham gia mạng xã hội!</p>
        <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: <CalendarCheck className="h-4 w-4 text-lime-600" />, label: 'Điểm danh công việc', desc: 'Check-in chấm công', val: `+${fmtUsdFromXu(10, rate)}` },
            { icon: <Newspaper className="h-4 w-4 text-sky-600" />, label: 'Đăng bài bảng tin', desc: 'tối đa 8 bài/ngày', val: `+${fmtUsdFromXu(5, rate)}` },
            { icon: <MessageCircle className="h-4 w-4 text-cyan-600" />, label: 'Bình luận', desc: 'tối đa 20 lần/ngày', val: `+${fmtUsdFromXu(2, rate)}` },
            { icon: <PlayCircle className="h-4 w-4 text-rose-600" />, label: 'Xem video', desc: 'mỗi video 1 lần/ngày', val: `+${fmtUsdFromXu(5, rate)}` },
            { icon: <KanbanSquare className="h-4 w-4 text-emerald-600" />, label: 'Hoàn thành công việc', desc: 'Kanban Quản trị 360', val: `+${fmtUsdFromXu(20, rate)}` },
            { icon: <Lightbulb className="h-4 w-4 text-amber-600" />, label: 'Đăng sáng kiến', desc: 'đề xuất cải tiến', val: `+${fmtUsdFromXu(10, rate)}` },
            { icon: <Sparkles className="h-4 w-4 text-emerald-600" />, label: 'Điểm danh hàng ngày', desc: `nút “Nhận +${fmtUsdFromXu(50, rate)}” trên đây`, val: `+${fmtUsdFromXu(50, rate)}` },
            { icon: <Gift className="h-4 w-4 text-teal-600" />, label: 'Nhận quà khi livestream', desc: 'host nhận 100% giá trị', val: '100%' },
          ].map((t) => (
            <div key={t.label} className="rounded-lg border bg-stone-50 p-2.5">
              <p className="flex items-center gap-1.5 text-xs font-bold">{t.icon} {t.label}</p>
              <p className="mt-0.5 text-[11px] text-stone-500">{t.desc}</p>
              <p className="mt-1 text-sm font-black text-emerald-700">{t.val}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Nạp & rút qua ngân hàng — mọi giao dịch đều chờ Ban Giám đốc duyệt */}
      <div className="rounded-xl border bg-white shadow-sm">
        <div className="flex items-center justify-between border-b px-4 py-3">
          <p className="flex items-center gap-1.5 text-sm font-bold"><Banknote className="h-4 w-4 text-emerald-600" /> Nạp &amp; rút tiền qua ngân hàng</p>
          <p className="flex items-center gap-1 text-[11px] text-stone-500"><ShieldCheck className="h-3.5 w-3.5 text-emerald-600" /> Nạp/rút theo tỷ giá thị trường · Thuế rút 10%</p>
        </div>
        <div className="divide-y">
          {walletTxs.length === 0 && <p className="p-6 text-center text-sm text-stone-500">Chưa có giao dịch nạp/rút nào.</p>}
          {walletTxs.map((t) => {
            const st = TX_STATUS[t.status] || TX_STATUS.pending
            return (
              <div key={t.id} className="flex flex-wrap items-center gap-2 px-4 py-2.5">
                <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${t.type === 'deposit' ? 'bg-emerald-100' : 'bg-rose-100'}`}>
                  {t.type === 'deposit' ? <ArrowDownRight className="h-4.5 w-4.5 text-emerald-600" /> : <ArrowUpRight className="h-4.5 w-4.5 text-rose-500" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold">{t.type === 'deposit' ? `Nạp ${fmtUsdFromXu(t.amountXu, rate)} (chuyển ${fmtVnd(t.amountVnd)}đ)` : `Rút ${fmtUsdFromXu(t.amountXu, rate)} → nhận ${fmtVnd(t.amountVnd)}đ${t.taxVnd ? ` (thuế ${fmtVnd(t.taxVnd)}đ)` : ''}`}</p>
                  <p className="truncate text-[11px] text-stone-400">
                    {new Date(t.createdAt).toLocaleString('vi-VN')}
                    {t.proofCode && ` · mã ${t.proofCode}`}
                    {t.bankName && ` · ${t.bankName} ${t.accountNumber || ''}`}
                    {t.adminNote && ` · Ghi chú: ${t.adminNote}`}
                  </p>
                </div>
                <Badge className={st.cls}>{st.label}</Badge>
              </div>
            )
          })}
        </div>
      </div>

      {/* Thống kê quà */}
      {data && (
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="flex items-center gap-3 rounded-xl border bg-white p-4 shadow-sm">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-rose-100"><ArrowUpRight className="h-5 w-5 text-rose-600" /></div>
            <div><p className="text-sm font-bold">Quà đã tặng</p><p className="text-xs text-stone-500">{data.giftsSent.total} lần, {fmtUsdFromXu(data.giftsSent.coins, rate)}</p></div>
          </div>
          <div className="flex items-center gap-3 rounded-xl border bg-white p-4 shadow-sm">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100"><ArrowDownRight className="h-5 w-5 text-emerald-600" /></div>
            <div><p className="text-sm font-bold">Quà nhận được</p><p className="text-xs text-stone-500">{data.giftsReceived.total} lần, {fmtUsdFromXu(data.giftsReceived.coins, rate)}</p></div>
          </div>
        </div>
      )}

      {/* Lịch sử */}
      <div className="rounded-xl border bg-white shadow-sm">
        <p className="border-b px-4 py-3 text-sm font-bold">Lịch sử giao dịch ví tiền</p>
        <div className="divide-y">
          {data?.txs.length === 0 && <p className="p-8 text-center text-sm text-stone-500">Chưa có giao dịch nào. Bấm <b>Nhận +{fmtUsdFromXu(50, rate)}</b> ngay!</p>}
          {data?.txs.map((t) => (
            <div key={t.id} className="flex items-center justify-between gap-3 px-4 py-2.5">
              <div className="flex items-center gap-2.5">
                {t.amount >= 0 ? <TrendingUp className="h-4 w-4 shrink-0 text-emerald-600" /> : <TrendingDown className="h-4 w-4 shrink-0 text-rose-500" />}
                <div>
                  <p className="text-sm">{t.reason}</p>
                  <p className="text-[11px] text-stone-400">{new Date(t.createdAt).toLocaleString('vi-VN')}</p>
                </div>
              </div>
              <Badge className={t.amount >= 0 ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100' : 'bg-rose-100 text-rose-800 hover:bg-rose-100'}>
                {fmtUsdSigned(t.amount, rate)}
              </Badge>
            </div>
          ))}
        </div>
      </div>
      {/* Dialog mở thẻ Vexon Pay */}
      <Dialog open={openCardOpen} onOpenChange={setOpenCardOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><CreditCard className="h-5 w-5 text-emerald-600" /> Mở thẻ Vexon Pay</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-emerald-950 via-emerald-800 to-teal-900 p-4 text-white">
              {/* Đồng bộ bố trí mới: vệt sáng chéo + 1 watermark góc dưới phải (bỏ logo lặp) */}
              <div aria-hidden className="pointer-events-none absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.04] to-white/[0.10]" />
              <img aria-hidden src="/vexon-logo.png" alt="" className="pointer-events-none absolute -bottom-8 -right-8 h-32 w-32 rotate-12 opacity-[0.10]" />
              <div className="relative flex items-center gap-2">
                <img src="/vexon-logo.png" alt="" className="h-6 w-6" />
                <p className="text-[11px] font-black uppercase tracking-[0.2em] text-emerald-100">Vexon Pay</p>
              </div>
              <div className="relative mt-2 flex items-center gap-2">
                <VxCardChip className="h-7 w-9" gid="vxChipGoldDlg" />
                <p className="font-mono text-base tracking-[0.16em]">9704  ••••  ••••  ••••</p>
              </div>
              <p className="relative mt-2 text-[10px] uppercase tracking-wider text-emerald-200/80">Chủ thẻ: {(me.fullName || '').toUpperCase()}</p>
            </div>
            <ul className="space-y-1 text-xs text-stone-600">
              <li className="flex items-start gap-1.5"><ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" /> Thẻ ngân hàng riêng của mạng xã hội — liên kết trực tiếp ví tiền USD của bạn</li>
              <li className="flex items-start gap-1.5"><Snowflake className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" /> Đóng băng tức thì khi nghi ngờ mất thẻ, mở băng bất cứ lúc nào</li>
              <li className="flex items-start gap-1.5"><Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" /> Miễn phí mở thẻ, không phí thường niên</li>
            </ul>
            <Button className="h-11 w-full gap-2 bg-emerald-600 font-semibold hover:bg-emerald-700" onClick={openCard} disabled={opening}>
              {opening ? <><Loader2 className="h-4 w-4 animate-spin" /> Đang mở thẻ...</> : <><CreditCard className="h-4 w-4" /> Xác nhận mở thẻ</>}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog chuyển tiền — mở từ nút “Chuyển tiền” trên thanh số dư (điểm vào duy nhất của form chuyển tiền từ r29) */}
      <Dialog open={tfOpen} onOpenChange={setTfOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><ArrowLeftRight className="h-5 w-5 text-emerald-600" /> Chuyển tiền cho người dùng Vexon</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="flex items-center gap-1.5 rounded-lg bg-emerald-50 px-3 py-2 text-[11px] font-medium text-emerald-800"><ShieldCheck className="h-3.5 w-3.5 shrink-0 text-emerald-600" /> 0 phí · đến ngay · tối thiểu {fmtUsdFromXu(MIN_TRANSFER_XU, rate)}</p>
            <div className="space-y-1">
              <Label htmlFor="tfd-to">Người nhận (@username)</Label>
              <Input id="tfd-to" value={tfTo} onChange={(e) => setTfTo(e.target.value)} placeholder="VD: @hongnhung" aria-label="Username người nhận" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="tfd-usd">Số tiền (USD)</Label>
              <Input id="tfd-usd" value={tfUsd} onChange={(e) => setTfUsd(e.target.value)} placeholder="VD: 5,00" inputMode="decimal" aria-label="Số tiền USD muốn chuyển" />
              {tfXu > 0 && <p className="text-[11px] text-emerald-700">≈ {Math.round(tfUsdNum * rate).toLocaleString('vi-VN')}đ (tỷ giá {rate.toLocaleString('vi-VN')}đ/$)</p>}
            </div>
            <div className="space-y-1">
              <Label htmlFor="tfd-msg">Lời nhắn (tuỳ chọn)</Label>
              <Input id="tfd-msg" value={tfMsg} onChange={(e) => setTfMsg(e.target.value)} placeholder="VD: Trả tiền cà phê nè" aria-label="Lời nhắn kèm chuyển tiền" />
            </div>
            <Button className="h-11 w-full gap-2 bg-emerald-600 font-semibold hover:bg-emerald-700" onClick={submitTransfer} disabled={tfBusy || !tfTo.trim() || tfXu < MIN_TRANSFER_XU} aria-label="Gửi tiền">
              {tfBusy ? <><Loader2 className="h-4 w-4 animate-spin" /> Đang chuyển...</> : <><Send className="h-4 w-4" /> Gửi tiền{tfUsdNum > 0 ? ` $${fmtUsdNumber(tfUsdNum)}` : ''}</>}
            </Button>
            <p className="text-[11px] leading-relaxed text-stone-500">Tiền chuyển vào ví tiền người nhận ngay lập tức, không thể hoàn tác — kiểm tra kỹ username trước khi gửi. Người nhận nhận thông báo kèm lời nhắn; lịch sử chuyển / nhận xem ở mục “Lịch sử giao dịch ví tiền” dưới trang.</p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog rút tiền — chịu thuế 10%, chờ Ban Giám đốc duyệt mới chuyển tiền */}
      <Dialog open={withdrawOpen} onOpenChange={setWithdrawOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Banknote className="h-5 w-5 text-emerald-600" /> Rút tiền về tài khoản ngân hàng</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label htmlFor="wd-usd">Số tiền muốn rút — đơn vị USD, tối thiểu $2,00</Label>
              <Input id="wd-usd" value={wXu} onChange={(e) => setWXu(e.target.value)} placeholder="VD: 2,00" inputMode="decimal" aria-label="Số tiền USD muốn rút" />
              {withdrawUsd > 0 && <p className="text-[11px] text-emerald-700">≈ {wGrossVnd.toLocaleString('vi-VN')}đ nhận về ngân hàng (tỷ giá {rate.toLocaleString('vi-VN')}đ/$)</p>}
            </div>
            <div className="grid grid-cols-3 gap-2 rounded-xl border border-amber-200 bg-amber-50/70 p-3 text-center text-xs">
              <div><p className="font-bold text-stone-700">${fmtUsdNumber(withdrawUsd)}<span className="block text-[10px] font-medium text-stone-400">≈ {wGrossVnd.toLocaleString('vi-VN')}đ</span></p><p className="text-[10px] text-stone-500">Giá trị rút</p></div>
              <div><p className="font-bold text-rose-600">-${fmtUsdNumber(withdrawUsd * 0.1)}</p><p className="text-[10px] text-stone-500">Thuế rút 10%</p></div>
              <div><p className="font-bold text-emerald-700">${fmtUsdNumber(withdrawUsd * 0.9)}<span className="block text-[10px] font-medium text-stone-400">≈ {wNetVnd.toLocaleString('vi-VN')}đ</span></p><p className="text-[10px] text-stone-500">Nhận thực tế</p></div>
            </div>
            <p className="rounded-lg bg-stone-50 px-3 py-2 text-[11px] leading-relaxed text-stone-500">
              Rút đổi theo tỷ giá thị trường tại thời điểm gửi (1$ = {rate.toLocaleString('vi-VN')}đ), chịu thuế 10%. Số dư bị trừ ngay để giữ chỗ; nếu Ban Giám đốc từ chối sẽ hoàn 100% vào ví.
            </p>
            <div className="space-y-1">
              <Label htmlFor="wd-bank">Ngân hàng nhận</Label>
              <Input id="wd-bank" value={wBank} onChange={(e) => setWBank(e.target.value)} placeholder="VD: Techcombank" aria-label="Ngân hàng nhận tiền" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="wd-acc">Số tài khoản</Label>
              <Input id="wd-acc" value={wAcc} onChange={(e) => setWAcc(e.target.value)} placeholder="VD: 19036666666" inputMode="numeric" aria-label="Số tài khoản nhận tiền" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="wd-holder">Chủ tài khoản</Label>
              <Input id="wd-holder" value={wHolder} onChange={(e) => setWHolder(e.target.value)} placeholder="VD: NGUYEN VAN A" aria-label="Chủ tài khoản nhận tiền" />
            </div>
            <Button className="h-11 w-full gap-2 bg-emerald-600 font-semibold hover:bg-emerald-700" disabled={withdrawing || withdrawUsd < 2 || !wBank.trim() || !wAcc.trim() || !wHolder.trim()} onClick={submitWithdraw} aria-label="Gửi yêu cầu rút tiền">
              {withdrawing ? <><Loader2 className="h-4 w-4 animate-spin" /> Đang gửi...</> : <><Hourglass className="h-4 w-4" /> Gửi yêu cầu rút {withdrawUsd > 0 ? `$${fmtUsdNumber(withdrawUsd)}` : ''}</>}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
