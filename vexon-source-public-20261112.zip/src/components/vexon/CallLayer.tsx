'use client'

// ============ LỚP CUỘC GỌI TOÀN CỤC (WebRTC thật) ============
// Mount 1 lần trong VexonApp: nghe cuộc gọi đến từ bất kỳ tab nào, hiện chuông + modal gọi 1-1
// Audio/Video thật qua RTCPeerConnection (STUN Google), signaling qua vexon-socket cổng 3003

import { useEffect, useRef, useState } from 'react'
import type { VxUserInfo } from '@/components/vexon/AuthView'
import { Avatar } from '@/components/vexon/shared'
import { useToast } from '@/hooks/use-toast'
import { getSocket } from '@/lib/vx-socket'
import { useCallStore, type IncomingCall } from '@/lib/vx-call-store'
import { openUserMedia, mediaErrorMessage, newPeerConnection, stopStream, fmtCallTime } from '@/lib/vx-call'
import MeetingRoom from '@/components/vexon/MeetingRoom'
import { Mic, MicOff, Video, VideoOff, Phone, PhoneOff, Loader2 } from 'lucide-react'

type SignalData =
  | { type: 'offer'; sdp: { type: string; sdp?: string } }
  | { type: 'answer'; sdp: { type: string; sdp?: string } }
  | { type: 'ice'; candidate: RTCIceCandidateInit | null }

const RING_TIMEOUT = 45_000

export default function CallLayer({ me }: { me: VxUserInfo }) {
  const { outgoing, incoming, meeting, setIncoming, clearOutgoing, closeMeeting } = useCallStore()
  const [accepted, setAccepted] = useState<IncomingCall | null>(null)
  const ringRef = useRef<HTMLAudioElement>(null)
  const { toast } = useToast()

  // Đăng ký nhận cuộc gọi + nghe invite
  useEffect(() => {
    const s = getSocket()
    const reg = () => s.emit('call:register', me.id)
    if (s.connected) reg()
    s.on('connect', reg)

    const onInvite = (p: { to: string; callId: string; kind: 'voice' | 'video'; conversationId: string; from: { userId: string; userName: string; avatarColor: string } }) => {
      const st = useCallStore.getState()
      // đang gọi/đang họp → từ chối lễ phép (bận)
      if (st.outgoing || st.meeting || st.incoming) {
        s.emit('call:reject', { to: p.from.userId, callId: p.callId, reason: 'busy' })
        return
      }
      setIncoming({ callId: p.callId, conversationId: p.conversationId, kind: p.kind, from: p.from })
    }
    // người gọi huỷ trước khi trả lời → gỡ chuông ngay
    const onEndWhileRinging = (p: { to: string; callId: string }) => {
      const st = useCallStore.getState()
      if (st.incoming?.callId === p.callId) setIncoming(null)
    }
    s.on('call:invite', onInvite)
    s.on('call:end', onEndWhileRinging)
    return () => {
      s.off('connect', reg)
      s.off('call:invite', onInvite)
      s.off('call:end', onEndWhileRinging)
    }
  }, [me.id, setIncoming])

  // Chuông cuộc gọi đến (chỉ kêu khi người dùng đã tương tác với trang)
  useEffect(() => {
    const a = ringRef.current
    if (!a) return
    if (incoming) {
      a.currentTime = 0
      a.play().catch(() => {})
    } else {
      a.pause()
    }
  }, [incoming])

  const acceptIncoming = async (c: IncomingCall) => {
    setIncoming(null)
    setAccepted(c)
  }

  const declineIncoming = (c: IncomingCall) => {
    const s = getSocket()
    s.emit('call:reject', { to: c.from.userId, callId: c.callId, reason: 'declined' })
    setIncoming(null)
  }

  return (
    <>
      <audio ref={ringRef} src="/test-nhac.wav" loop preload="auto" className="hidden" aria-hidden />
      {/* Chuông cuộc gọi đến */}
      {incoming && (
        <div className="fixed inset-0 z-[78] flex items-center justify-center bg-black/80 p-4" role="dialog" aria-label="Cuộc gọi đến">
          <div className="w-full max-w-sm rounded-2xl bg-gradient-to-b from-stone-800 to-stone-900 p-6 text-center text-white shadow-2xl">
            <p className="text-xs font-semibold uppercase tracking-widest text-emerald-400">{incoming.kind === 'video' ? 'Cuộc gọi video đến' : 'Cuộc gọi thoại đến'}</p>
            <div className="relative mx-auto mt-5 mb-4 w-fit">
              <Avatar name={incoming.from.userName} color={incoming.from.avatarColor} size={92} />
              <span className="absolute inset-0 -z-10 animate-ping rounded-full bg-emerald-500/30" />
            </div>
            <p className="text-lg font-bold">{incoming.from.userName}</p>
            <p className="mt-1 text-sm text-stone-400">Đang đổ chuông...</p>
            <div className="mt-6 flex items-center justify-center gap-4">
              <button className="rounded-full bg-red-600 p-4 hover:bg-red-500" onClick={() => declineIncoming(incoming)} aria-label="Từ chối cuộc gọi">
                <PhoneOff className="h-6 w-6" />
              </button>
              <button className="rounded-full bg-emerald-600 p-4 hover:bg-emerald-500" onClick={() => acceptIncoming(incoming)} aria-label="Nhận cuộc gọi">
                {incoming.kind === 'video' ? <Video className="h-6 w-6" /> : <Phone className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Cuộc gọi đi (người gọi) */}
      {outgoing && (
        <CallSessionModal
          key={outgoing.callId}
          me={me}
          role="caller"
          callId={outgoing.callId}
          conversationId={outgoing.conversationId}
          kind={outgoing.kind}
          peer={outgoing.peer}
          onDone={(sec) => {
            fetch('/api/vx/calls', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ conversationId: outgoing.conversationId, kind: outgoing.kind, duration: sec }),
            }).catch(() => {})
            clearOutgoing()
          }}
        />
      )}
      {/* Cuộc gọi đến đã nhận (người nhận) — không ghi log để tránh trùng */}
      {accepted && (
        <CallSessionModal
          key={accepted.callId}
          me={me}
          role="callee"
          callId={accepted.callId}
          conversationId={accepted.conversationId}
          kind={accepted.kind}
          peer={{ userId: accepted.from.userId, userName: accepted.from.userName, avatarColor: accepted.from.avatarColor }}
          onDone={() => setAccepted(null)}
        />
      )}
      {/* Phòng họp nhóm kiểu Zoom */}
      {meeting && (
        <MeetingRoom
          session={meeting}
          me={me}
          onDone={(sec) => {
            // chỉ trưởng nhóm ghi lịch sử cuộc họp vào hội thoại
            if (meeting.isHost) {
              fetch('/api/vx/calls', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ conversationId: meeting.conversationId, kind: 'meeting', duration: sec }),
              }).catch(() => {})
            }
            closeMeeting()
          }}
        />
      )}
    </>
  )
}

// ============ PHIÊN GỌI 1-1 (WebRTC) ============
function CallSessionModal({ me, role, callId, conversationId, kind, peer, onDone }: {
  me: VxUserInfo
  role: 'caller' | 'callee'
  callId: string
  conversationId: string
  kind: 'voice' | 'video'
  peer: { userId: string; userName: string; avatarColor: string }
  onDone: (sec: number) => void
}) {
  const [phase, setPhase] = useState<'ringing' | 'connecting' | 'live'>('ringing')
  const [sec, setSec] = useState(0)
  const [muted, setMuted] = useState(false)
  const [camOff, setCamOff] = useState(false)
  const [waitingCam, setWaitingCam] = useState(kind === 'video')
  const { toast } = useToast()

  const localRef = useRef<MediaStream | null>(null)
  const peerRef = useRef<RTCPeerConnection | null>(null)
  const remoteRef = useRef<MediaStream | null>(null)
  const remoteVideoRef = useRef<HTMLVideoElement>(null)
  const remoteAudioRef = useRef<HTMLAudioElement>(null)
  const localVideoRef = useRef<HTMLVideoElement>(null)
  const pendingSignals = useRef<SignalData[]>([])
  const peerReadyRef = useRef(false)
  const endedRef = useRef(false)
  const secRef = useRef(0)

  const emitSignal = (data: SignalData) => {
    getSocket().emit('call:signal', { to: peer.userId, callId, data })
  }

  const finish = (withSec: number, emit = true) => {
    if (endedRef.current) return
    endedRef.current = true
    const s = getSocket()
    s.off('call:signal')
    s.off('call:accept')
    s.off('call:reject')
    s.off('call:end')
    if (emit) s.emit('call:end', { to: peer.userId, callId })
    peerRef.current?.close()
    peerRef.current = null
    stopStream(localRef.current)
    localRef.current = null
    stopStream(remoteRef.current)
    remoteRef.current = null
    onDone(withSec)
  }

  // Dựng peer connection sau khi có media + tín hiệu sẵn sàng
  const setupPeer = async () => {
    if (peerReadyRef.current || !localRef.current) return
    peerReadyRef.current = true
    const pc = newPeerConnection()
    peerRef.current = pc
    for (const t of localRef.current.getTracks()) pc.addTrack(t, localRef.current)
    pc.onicecandidate = (ev) => {
      if (ev.candidate) emitSignal({ type: 'ice', candidate: ev.candidate.toJSON() })
    }
    pc.ontrack = (ev) => {
      remoteRef.current = ev.streams[0] || null
      const el = kind === 'video' ? remoteVideoRef.current : remoteAudioRef.current
      if (el && remoteRef.current) el.srcObject = remoteRef.current
    }
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected') setPhase('live')
      if (pc.connectionState === 'failed') {
        toast({ title: 'Kết nối cuộc gọi bị lỗi mạng', variant: 'destructive' })
        finish(secRef.current)
      }
    }
    // xử lý các tín hiệu chờ sẵn
    const q = pendingSignals.current
    pendingSignals.current = []
    for (const data of q) await applySignal(pc, data)
  }

  const applySignal = async (pc: RTCPeerConnection, data: SignalData) => {
    try {
      if (data.type === 'offer') {
        await pc.setRemoteDescription(new RTCSessionDescription(data.sdp as RTCSessionDescriptionInit))
        const answer = await pc.createAnswer()
        await pc.setLocalDescription(answer)
        emitSignal({ type: 'answer', sdp: { type: pc.localDescription!.type, sdp: pc.localDescription!.sdp || undefined } })
      } else if (data.type === 'answer') {
        if (pc.signalingState !== 'stable') {
          await pc.setRemoteDescription(new RTCSessionDescription(data.sdp as RTCSessionDescriptionInit))
        }
      } else if (data.type === 'ice' && data.candidate) {
        await pc.addIceCandidate(new RTCIceCandidate(data.candidate))
      }
    } catch {
      // bỏ qua tín hiệu lỗi (ICE trễ sau khi đóng)
    }
  }

  // ===== Khởi động phiên =====
  useEffect(() => {
    const s = getSocket()
    let mediaP: Promise<MediaStream | null> | null = null

    const onSignal = (p: { to: string; callId: string; data: SignalData }) => {
      if (p.callId !== callId) return
      if (!peerReadyRef.current) {
        pendingSignals.current.push(p.data)
        return
      }
      const pc = peerRef.current
      if (pc) applySignal(pc, p.data)
    }
    const onAccept = async () => {
      if (role !== 'caller' || endedRef.current) return
      setPhase('connecting')
      try {
        if (!localRef.current && mediaP) await mediaP
        await setupPeer()
        const pc = peerRef.current
        if (!pc) {
          toast({ title: 'Không mở được micro/camera để gọi', variant: 'destructive' })
          finish(0)
          return
        }
        const offer = await pc.createOffer()
        await pc.setLocalDescription(offer)
        emitSignal({ type: 'offer', sdp: { type: pc.localDescription!.type, sdp: pc.localDescription!.sdp || undefined } })
      } catch (err) {
        toast({ title: mediaErrorMessage(err), variant: 'destructive' })
        finish(0)
      }
    }
    const onReject = (p: { to: string; callId: string; reason?: string }) => {
      if (p.callId !== callId) return
      if (p.reason === 'busy') toast({ title: 'Người nhận đang bận cuộc gọi khác' })
      else toast({ title: 'Người nhận từ chối cuộc gọi' })
      finish(0, false)
    }
    const onEnd = (p: { to: string; callId: string }) => {
      if (p.callId !== callId) return
      finish(secRef.current, false)
    }

    s.on('call:signal', onSignal)
    s.on('call:accept', onAccept)
    s.on('call:reject', onReject)
    s.on('call:end', onEnd)

    // Xin quyền micro/camera NGAY khi bắt đầu (gọi đi phát chuông song song)
    mediaP = openUserMedia(kind)
      .then((stream) => {
        if (endedRef.current) {
          stopStream(stream)
          return null
        }
        localRef.current = stream
        const lv = localVideoRef.current
        if (lv) lv.srcObject = stream
        setWaitingCam(false)
        return stream
      })
      .catch((err) => {
        if (!endedRef.current) {
          toast({ title: mediaErrorMessage(err), variant: 'destructive' })
          finish(0)
        }
        return null
      })

    if (role === 'caller') {
      s.emit('call:invite', {
        to: peer.userId,
        callId,
        kind,
        conversationId,
        from: { userId: me.id, userName: me.fullName, avatarColor: me.avatarColor },
      })
      const t = setTimeout(() => {
        if (!endedRef.current && phaseRef.current !== 'live') {
          toast({ title: 'Không trả lời, tự động kết thúc' })
          finish(0, true)
        }
      }, RING_TIMEOUT)
      return () => clearTimeout(t)
    }

    return () => {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Người nhận bấm nhận → xin media → báo accept → chờ offer
  const doAccept = async () => {
    setPhase('connecting')
    try {
      const stream = await openUserMedia(kind)
      localRef.current = stream
      const lv = localVideoRef.current
      if (lv) lv.srcObject = stream
      setWaitingCam(false)
      getSocket().emit('call:accept', { to: peer.userId, callId })
      await setupPeer() // peer sẵn sàng để nhận offer (đang chờ trong pendingSignals)
      const pc = peerRef.current
      const q = pendingSignals.current
      if (pc && q.length > 0) {
        pendingSignals.current = []
        for (const data of q) await applySignal(pc, data)
      }
    } catch (err) {
      toast({ title: mediaErrorMessage(err), variant: 'destructive' })
      getSocket().emit('call:reject', { to: peer.userId, callId, reason: 'media' })
      finish(0, false)
    }
  }

  // Đồng hồ đếm giờ
  useEffect(() => {
    if (phase !== 'live') return
    const iv = setInterval(() => {
      secRef.current += 1
      setSec(secRef.current)
    }, 1000)
    return () => clearInterval(iv)
  }, [phase])

  const phaseRef = useRef(phase)
  useEffect(() => {
    phaseRef.current = phase
  }, [phase])

  const toggleMute = () => {
    const t = localRef.current?.getAudioTracks()[0]
    setMuted((m) => {
      const next = !m
      if (t) t.enabled = !next
      return next
    })
  }
  const toggleCam = () => {
    const t = localRef.current?.getVideoTracks()[0]
    setCamOff((c) => {
      const next = !c
      if (t) t.enabled = !next
      return next
    })
  }

  const statusText =
    phase === 'ringing'
      ? role === 'caller'
        ? 'Đang đổ chuông...'
        : 'Đã nhận, đang kết nối...'
      : phase === 'connecting'
        ? 'Đang kết nối...'
        : `Đã kết nối, ${fmtCallTime(sec)}`

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/90 p-4" role="dialog" aria-label={`Cuộc gọi ${kind === 'video' ? 'video' : 'thoại'} với ${peer.userName}`}>
      <div className="relative w-full max-w-sm overflow-hidden rounded-2xl bg-gradient-to-b from-stone-800 to-stone-900 p-5 text-center text-white shadow-2xl">
        {kind === 'video' && (
          <div className="relative mb-4 aspect-video overflow-hidden rounded-xl bg-stone-950">
            <video ref={remoteVideoRef} autoPlay playsInline className="h-full w-full object-cover" aria-label="Hình ảnh của người gọi" />
            {!waitingCam && localRef.current && (
              <video ref={localVideoRef} autoPlay playsInline muted className="absolute bottom-2 right-2 h-20 w-28 rounded-lg border border-white/20 object-cover" style={{ transform: 'scaleX(-1)' }} aria-label="Camera của tôi" />
            )}
            {(phase === 'ringing' || waitingCam) && (
              <div className="absolute inset-0 flex items-center justify-center bg-stone-950/80"><Loader2 className="h-7 w-7 animate-spin text-emerald-500" /></div>
            )}
            <span className="absolute bottom-2 left-2 rounded bg-black/60 px-2 py-0.5 text-[10px]">{phase === 'live' ? peer.userName : 'Đang chờ...'}</span>
          </div>
        )}
        {kind === 'voice' && (
          <div className="mb-4 flex justify-center">
            <div className="relative">
              <Avatar name={peer.userName} color={peer.avatarColor} size={92} />
              {phase === 'live' && <span className="absolute inset-0 -z-10 animate-ping rounded-full bg-emerald-500/30" />}
            </div>
          </div>
        )}
        <audio ref={remoteAudioRef} autoPlay className="hidden" aria-hidden />
        {kind !== 'video' && <video ref={localVideoRef} autoPlay playsInline muted className="hidden" aria-hidden />}
        <p className="text-lg font-bold">{peer.userName}</p>
        <p className="mt-1 text-sm text-stone-400">{statusText}</p>

        <div className="mt-6 flex items-center justify-center gap-3">
          <button
            className={`rounded-full p-3.5 transition-colors ${muted ? 'bg-white text-stone-900' : 'bg-white/10 hover:bg-white/20'}`}
            onClick={toggleMute}
            aria-label={muted ? 'Bật mic' : 'Tắt mic'}
            disabled={!localRef.current}
          >
            {muted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
          </button>
          {kind === 'video' && (
            <button
              className={`rounded-full p-3.5 transition-colors ${camOff ? 'bg-white text-stone-900' : 'bg-white/10 hover:bg-white/20'}`}
              onClick={toggleCam}
              aria-label={camOff ? 'Bật camera' : 'Tắt camera'}
              disabled={!localRef.current}
            >
              {camOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
            </button>
          )}
          <button className="rounded-full bg-red-600 p-3.5 hover:bg-red-500" onClick={() => finish(secRef.current)} aria-label="Kết thúc cuộc gọi">
            <PhoneOff className="h-5 w-5" />
          </button>
        </div>
        <p className="mt-4 text-[10px] text-stone-500">Cuộc gọi WebRTC trực tiếp, kết thúc sẽ lưu lịch sử vào hội thoại</p>
      </div>
    </div>
  )
}
