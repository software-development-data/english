'use client'

import { useCallback, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import type { VxUserInfo } from './AuthView'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'sonner'
import { Briefcase, Search, MapPin, Wallet, Loader2, Send, Users, CalendarClock, FileText, Building2, CheckCircle2 } from 'lucide-react'

interface Job {
  id: string
  title: string
  location: string
  workType: string
  salaryMin: number
  salaryMax: number
  experience: string
  description: string
  requirements: string[]
  benefits: string[]
  createdAt: string
  company: { id: string; name: string; industry: string; size: string; ratingAvg: number; ratingCount: number; address: string | null; owner: { avatarColor: string } }
  applicantCount: number
  myStatus: string | null
}

interface Application {
  id: string
  status: string
  statusVi: string
  interviewAt: string | null
  note: string | null
  job: { id: string; title: string; company: { name: string } }
}

interface Applicant {
  id: string
  coverNote: string | null
  cv: { headline?: string; skills?: string[]; phone?: string } | null
  status: string
  statusVi: string
  interviewAt: string | null
  note: string | null
  user: { id: string; fullName: string; avatarColor: string; title: string; department: string }
}

const WORK_TYPES: Record<string, string> = { all: 'Tất cả hình thức', full_time: 'Toàn thời gian', part_time: 'Bán thời gian', remote: 'Remote', contract: 'Hợp đồng' }
const PIPELINE = ['applied', 'screening', 'interview', 'trial', 'offered', 'rejected']
const PIPELINE_VI: Record<string, string> = { applied: 'Ứng tuyển', screening: 'Sàng lọc', interview: 'Phỏng vấn', trial: 'Thử việc', offered: 'Trúng tuyển', rejected: 'Loại' }
const NEXT_STATUS: Record<string, string> = { applied: 'screening', screening: 'interview', interview: 'trial', trial: 'offered' }

const fmtVnd = (n: number) => `${(n / 1_000_000).toFixed(n % 1_000_000 === 0 ? 0 : 1).replace('.', ',')}tr`

export default function JobsView({ me, onMessage }: { me: VxUserInfo; onMessage: (userId: string) => void }) {
  const isBusiness = me.accountType === 'business'
  const [jobs, setJobs] = useState<Job[]>([])
  const [myJobs, setMyJobs] = useState<Job[]>([])
  const [myApps, setMyApps] = useState<Application[]>([])
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState('')
  const [workType, setWorkType] = useState('all')
  const [tab, setTab] = useState<'find' | 'applied' | 'recruiter' | 'cv'>(isBusiness ? 'recruiter' : 'find')
  const [detail, setDetail] = useState<Job | null>(null)
  const [applyOpen, setApplyOpen] = useState(false)
  const [coverNote, setCoverNote] = useState('')
  const [applicants, setApplicants] = useState<Applicant[] | null>(null)
  const [applicantsJob, setApplicantsJob] = useState<Job | null>(null)
  const [posting, setPosting] = useState(false)
  const [cvSaving, setCvSaving] = useState(false)
  const [cv, setCv] = useState<{ headline: string; phone: string; skills: string; desiredSalary: string; desiredLocation: string }>({ headline: '', phone: '', skills: '', desiredSalary: '', desiredLocation: '' })

  const load = useCallback(() => {
    const params = new URLSearchParams()
    if (q) params.set('q', q)
    if (workType !== 'all') params.set('workType', workType)
    fetch(`/api/vx/jobs?${params}`)
      .then((r) => r.json())
      .then((d) => Array.isArray(d.jobs) && setJobs(d.jobs))
      .catch(() => {})
      .finally(() => setLoading(false))
    fetch('/api/vx/applications?mine=1').then((r) => r.json()).then((d) => Array.isArray(d.applications) && setMyApps(d.applications)).catch(() => {})
    if (isBusiness) fetch('/api/vx/jobs?mine=1').then((r) => r.json()).then((d) => Array.isArray(d.myJobs) && setMyJobs(d.myJobs)).catch(() => {})
    fetch('/api/vx/candidate').then((r) => r.json()).then((d) => {
      if (d.cv) setCv({ headline: d.cv.headline || '', phone: d.cv.phone || '', skills: (d.cv.skills || []).join(', '), desiredSalary: d.cv.desiredSalary ? String(d.cv.desiredSalary) : '', desiredLocation: d.cv.desiredLocation || '' })
    }).catch(() => {})
  }, [q, workType, isBusiness])

  useDeferredLoad(() => load(), [load])

  const apply = async () => {
    if (!detail) return
    const res = await fetch(`/api/vx/jobs/${detail.id}/apply`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ coverNote }),
    })
    const d = await res.json()
    if (res.ok) {
      toast.success('Đã ứng tuyển! Nhà tuyển dụng sẽ xem CV của bạn.')
      setApplyOpen(false)
      setDetail(null)
      load()
    } else toast.error(d.error || 'Không ứng tuyển được')
  }

  const saveCv = async () => {
    setCvSaving(true)
    const res = await fetch('/api/vx/candidate', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        headline: cv.headline,
        phone: cv.phone,
        skills: cv.skills.split(',').map((s) => s.trim()).filter(Boolean),
        desiredSalary: Number(cv.desiredSalary) || null,
        desiredLocation: cv.desiredLocation,
      }),
    })
    setCvSaving(false)
    if (res.ok) toast.success('Đã lưu CV số của bạn')
    else toast.error('Không lưu được CV')
  }

  const postJob = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    const res = await fetch('/api/vx/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: fd.get('title'),
        location: fd.get('location'),
        workType: fd.get('workType'),
        salaryMin: Number(fd.get('salaryMin')) * 1_000_000,
        salaryMax: Number(fd.get('salaryMax')) * 1_000_000,
        experience: fd.get('experience'),
        description: fd.get('description'),
        requirements: String(fd.get('requirements') || '').split('\n').map((s) => s.trim()).filter(Boolean),
        benefits: String(fd.get('benefits') || '').split('\n').map((s) => s.trim()).filter(Boolean),
      }),
    })
    const d = await res.json()
    if (res.ok) {
      toast.success('Đã đăng tin tuyển dụng!')
      setPosting(false)
      load()
    } else toast.error(d.error || 'Không đăng được tin')
  }

  const viewApplicants = async (job: Job) => {
    setApplicantsJob(job)
    const res = await fetch(`/api/vx/applications?jobId=${job.id}`)
    const d = await res.json()
    setApplicants(Array.isArray(d.applications) ? d.applications : [])
  }

  const advance = async (a: Applicant, status: string) => {
    const interviewAt = status === 'interview' ? prompt('Giờ phỏng vấn (VD: 2026-11-10 14:00):', new Date(Date.now() + 172800000).toISOString().slice(0, 16)) : null
    if (status === 'interview' && !interviewAt) return
    const res = await fetch('/api/vx/applications', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ applicationId: a.id, status, interviewAt: interviewAt ? new Date(interviewAt).toISOString() : undefined }),
    })
    if (res.ok) {
      toast.success(`Đã chuyển hồ sơ sang "${PIPELINE_VI[status]}"`)
      if (applicantsJob) viewApplicants(applicantsJob)
    } else toast.error('Không cập nhật được')
  }

  const statusBadge = (s: string) => {
    const map: Record<string, string> = { applied: 'bg-slate-200 text-slate-800', screening: 'bg-sky-100 text-sky-800', interview: 'bg-emerald-100 text-emerald-800', trial: 'bg-amber-100 text-amber-800', offered: 'bg-emerald-100 text-emerald-800', rejected: 'bg-rose-100 text-rose-800' }
    return <Badge className={`${map[s] || 'bg-stone-100'} border-0`}>{PIPELINE_VI[s] || s}</Badge>
  }

  const TABS: { key: 'find' | 'applied' | 'recruiter' | 'cv'; label: string; icon: React.ReactNode }[] = [
    { key: 'find', label: 'Tìm việc', icon: <Search className="h-4 w-4" /> },
    { key: 'applied', label: `Hồ sơ đã nộp (${myApps.length})`, icon: <FileText className="h-4 w-4" /> },
    ...(isBusiness ? [{ key: 'recruiter' as const, label: 'Tuyển dụng', icon: <Users className="h-4 w-4" /> }] : []),
    { key: 'cv', label: 'CV của tôi', icon: <FileText className="h-4 w-4" /> },
  ]

  return (
    <div className="space-y-5">
      <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-teal-600 to-emerald-700 p-5 text-white shadow-lg">
        <h1 className="flex items-center gap-2 text-xl font-black"><Briefcase className="h-6 w-6" /> Cổng Tuyển dụng & Tìm việc làm</h1>
        <p className="mt-1 text-sm text-teal-100">Ứng tuyển 1-click bằng CV số. Nhà tuyển dụng quản lý phễu qua các bước: Ứng tuyển, Phỏng vấn, Thử việc, Trúng tuyển</p>
      </div>

      <div className="flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)} className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold ${tab === t.key ? 'bg-teal-600 text-white shadow' : 'bg-white text-stone-600 hover:bg-teal-50'}`}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* TÌM VIỆC */}
      {tab === 'find' && (
        <>
          <div className="flex flex-wrap items-center gap-3 rounded-xl border bg-white p-3 shadow-sm">
            <div className="relative min-w-64 flex-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-stone-400" />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm theo chức danh, công ty, địa điểm..." className="pl-9" aria-label="Tìm việc" />
            </div>
            <Select value={workType} onValueChange={setWorkType}>
              <SelectTrigger className="w-48" aria-label="Hình thức làm việc"><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(WORK_TYPES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
              </SelectContent>
            </Select>
            <span className="text-xs text-stone-500">{jobs.length} vị trí đang mở</span>
          </div>
          <div className="space-y-3">
            {jobs.map((j) => (
              <div key={j.id} className="rounded-xl border bg-white p-4 shadow-sm transition-shadow hover:shadow-md">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl font-black text-white" style={{ backgroundColor: j.company.owner.avatarColor }}>
                      {j.company.name[0]}
                    </div>
                    <div>
                      <button className="text-left font-bold hover:text-teal-700" onClick={() => setDetail(j)}>{j.title}</button>
                      <p className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-stone-500">
                        <span className="flex items-center gap-1"><Building2 className="h-3 w-3" />{j.company.name}, Đánh giá {j.company.ratingAvg} ({j.company.ratingCount})</span>
                        <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{j.location}</span>
                        <span className="flex items-center gap-1"><Users className="h-3 w-3" />{j.applicantCount} ứng viên</span>
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-emerald-700">{j.salaryMin > 0 ? `${fmtVnd(j.salaryMin)} - ${fmtVnd(j.salaryMax)}` : 'Thương lượng'}</p>
                    <Badge variant="secondary" className="mt-1">{WORK_TYPES[j.workType]}</Badge>
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between gap-2">
                  <p className="line-clamp-1 text-xs text-stone-600">{j.description}</p>
                  {j.myStatus ? statusBadge(j.myStatus) : <Button size="sm" className="bg-teal-600 hover:bg-teal-700" onClick={() => { setDetail(j); setApplyOpen(true) }}><Send className="mr-1 h-3.5 w-3.5" />Ứng tuyển</Button>}
                </div>
              </div>
            ))}
            {!loading && jobs.length === 0 && <div className="rounded-xl border border-dashed p-10 text-center text-sm text-stone-500">Không tìm thấy vị trí phù hợp.</div>}
          </div>
        </>
      )}

      {/* HỒ SƠ ĐÃ NỘP */}
      {tab === 'applied' && (
        <div className="space-y-3">
          {myApps.length === 0 && <div className="rounded-xl border border-dashed p-10 text-center text-sm text-stone-500">Bạn chưa ứng tuyển vị trí nào. Vào tab <b>Tìm việc</b> ngay!</div>}
          {myApps.map((a) => (
            <div key={a.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border bg-white p-4 shadow-sm">
              <div>
                <p className="font-bold">{a.job.title}</p>
                <p className="text-xs text-stone-500">{a.job.company.name}</p>
                {a.interviewAt && <p className="mt-1 flex items-center gap-1 text-xs font-semibold text-emerald-700"><CalendarClock className="h-3.5 w-3.5" />Lịch phỏng vấn: {new Date(a.interviewAt).toLocaleString('vi-VN')}</p>}
                {a.note && <p className="mt-0.5 text-xs italic text-stone-500">Ghi chú NTD: {a.note}</p>}
              </div>
              {statusBadge(a.status)}
            </div>
          ))}
        </div>
      )}

      {/* NHÀ TUYỂN DỤNG */}
      {tab === 'recruiter' && (
        <div className="space-y-4">
          <Button className="bg-teal-600 hover:bg-teal-700" onClick={() => setPosting(true)}>+ Đăng tin tuyển dụng</Button>
          <div className="space-y-3">
            {myJobs.map((j) => (
              <div key={j.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border bg-white p-4 shadow-sm">
                <div>
                  <p className="font-bold">{j.title}</p>
                  <p className="text-xs text-stone-500">{j.location}, {j.applicantCount} ứng viên, {j.salaryMin > 0 ? `${fmtVnd(j.salaryMin)}-${fmtVnd(j.salaryMax)}` : 'Thương lượng'}</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => viewApplicants(j)}><Users className="mr-1 h-3.5 w-3.5" />Ứng viên ({j.applicantCount})</Button>
                </div>
              </div>
            ))}
            {myJobs.length === 0 && <div className="rounded-xl border border-dashed p-10 text-center text-sm text-stone-500">Chưa có tin tuyển dụng nào. Đăng tin đầu tiên!</div>}
          </div>
        </div>
      )}

      {/* CV CỦA TÔI */}
      {tab === 'cv' && (
        <div className="mx-auto max-w-2xl space-y-4 rounded-xl border bg-white p-5 shadow-sm">
          <p className="font-bold">Hồ sơ Ứng viên & CV số</p>
          <p className="text-xs text-stone-500">CV này sẽ đính kèm tự động khi bạn ứng tuyển 1-click.</p>
          <div className="space-y-2"><Label>Headline nghề nghiệp</Label><Input value={cv.headline} onChange={(e) => setCv({ ...cv, headline: e.target.value })} placeholder="VD: Sales B2B 2 năm kinh nghiệm..." /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2"><Label>Số điện thoại</Label><Input value={cv.phone} onChange={(e) => setCv({ ...cv, phone: e.target.value })} placeholder="09xx xxx xxx" /></div>
            <div className="space-y-2"><Label>Mức lương mong muốn (₫/tháng)</Label><Input value={cv.desiredSalary} onChange={(e) => setCv({ ...cv, desiredSalary: e.target.value })} placeholder="15000000" /></div>
          </div>
          <div className="space-y-2"><Label>Kỹ năng (cách nhau bởi dấu phẩy)</Label><Input value={cv.skills} onChange={(e) => setCv({ ...cv, skills: e.target.value })} placeholder="Telesales, Đàm phán, CRM, Excel" /></div>
          <div className="space-y-2"><Label>Địa điểm mong muốn</Label><Input value={cv.desiredLocation} onChange={(e) => setCv({ ...cv, desiredLocation: e.target.value })} placeholder="TP.HCM / Remote..." /></div>
          <Button className="bg-teal-600 hover:bg-teal-700" onClick={saveCv} disabled={cvSaving}>{cvSaving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <CheckCircle2 className="mr-1 h-4 w-4" />}Lưu CV</Button>
        </div>
      )}

      {/* Dialog chi tiết job */}
      <Dialog open={!!detail && !applyOpen} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="sm:max-w-2xl">
          {detail && (
            <>
              <DialogHeader>
                <DialogTitle>{detail.title}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 text-sm">
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">{WORK_TYPES[detail.workType]}</Badge>
                  <Badge variant="secondary"><MapPin className="mr-1 inline h-3 w-3" />{detail.location}</Badge>
                  <Badge variant="secondary"><Wallet className="mr-1 inline h-3 w-3" />{detail.salaryMin > 0 ? `${fmtVnd(detail.salaryMin)} - ${fmtVnd(detail.salaryMax)}` : 'Thương lượng'}</Badge>
                  <Badge variant="secondary">{detail.experience}</Badge>
                </div>
                <p className="whitespace-pre-wrap leading-relaxed">{detail.description}</p>
                {detail.requirements.length > 0 && (
                  <div>
                    <p className="font-semibold">Yêu cầu:</p>
                    <ul className="list-disc space-y-1 pl-5">{detail.requirements.map((r) => <li key={r}>{r}</li>)}</ul>
                  </div>
                )}
                {detail.benefits.length > 0 && (
                  <div>
                    <p className="font-semibold">Quyền lợi:</p>
                    <ul className="list-disc space-y-1 pl-5">{detail.benefits.map((b) => <li key={b}>{b}</li>)}</ul>
                  </div>
                )}
                <div className="flex items-center justify-between border-t pt-3">
                  <p className="text-xs text-stone-500">Đăng bởi <b>{detail.company.name}</b>, Đánh giá {detail.company.ratingAvg}</p>
                  {!detail.myStatus && me.accountType !== 'business' && <Button className="bg-teal-600 hover:bg-teal-700" onClick={() => setApplyOpen(true)}><Send className="mr-1 h-4 w-4" />Ứng tuyển ngay</Button>}
                  {detail.myStatus && statusBadge(detail.myStatus)}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Dialog ứng tuyển */}
      <Dialog open={applyOpen} onOpenChange={setApplyOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle>Ứng tuyển: {detail?.title}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-stone-600">CV số của bạn sẽ được gửi kèm. Hãy kiểm tra tab <b>CV của tôi</b> trước khi nộp.</p>
            <Textarea value={coverNote} onChange={(e) => setCoverNote(e.target.value)} placeholder="Lời nhắn tới nhà tuyển dụng (giới thiệu ngắn về bản thân)..." rows={4} aria-label="Lời nhắn" />
            <Button className="w-full bg-teal-600 hover:bg-teal-700" onClick={apply}><Send className="mr-1 h-4 w-4" />Nộp hồ sơ ứng tuyển</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog đăng tin */}
      <Dialog open={posting} onOpenChange={setPosting}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader><DialogTitle>Đăng tin tuyển dụng mới</DialogTitle></DialogHeader>
          <form className="space-y-3" onSubmit={postJob}>
            <div className="space-y-1"><Label>Chức danh *</Label><Input name="title" required placeholder="VD: Nhân viên kinh doanh B2B" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Địa điểm</Label><Input name="location" placeholder="Quận 1, TP.HCM" /></div>
              <div className="space-y-1"><Label>Hình thức</Label>
                <Select name="workType" defaultValue="full_time">
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(WORK_TYPES).filter(([k]) => k !== 'all').map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1"><Label>Lương từ (triệu)</Label><Input name="salaryMin" type="number" min={0} placeholder="12" /></div>
              <div className="space-y-1"><Label>Lương đến (triệu)</Label><Input name="salaryMax" type="number" min={0} placeholder="30" /></div>
              <div className="space-y-1"><Label>Kinh nghiệm</Label><Input name="experience" placeholder="2+ năm" /></div>
            </div>
            <div className="space-y-1"><Label>Mô tả công việc *</Label><Textarea name="description" required rows={3} /></div>
            <div className="space-y-1"><Label>Yêu cầu (mỗi dòng 1 ý)</Label><Textarea name="requirements" rows={3} /></div>
            <div className="space-y-1"><Label>Quyền lợi (mỗi dòng 1 ý)</Label><Textarea name="benefits" rows={3} /></div>
            <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700">Đăng tin</Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog ứng viên */}
      <Dialog open={!!applicantsJob} onOpenChange={(o) => !o && setApplicantsJob(null)}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader><DialogTitle>Ứng viên: {applicantsJob?.title}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            {applicants?.length === 0 && <p className="py-6 text-center text-sm text-stone-500">Chưa có ứng viên nào ứng tuyển.</p>}
            {applicants?.map((a) => (
              <div key={a.id} className="rounded-xl border p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="flex min-w-0 flex-wrap items-center gap-x-1.5 font-bold">{a.user.fullName} <span className="flex items-center gap-0.5 text-xs font-normal text-stone-500"><Briefcase className="h-3 w-3" /> {a.user.title}</span></p>
                    {a.cv?.headline && <p className="text-xs text-stone-600">{a.cv.headline}</p>}
                    {a.cv?.phone && <p className="text-xs text-stone-500">{a.cv.phone}</p>}
                    {a.cv?.skills && a.cv.skills.length > 0 && (
                      <div className="mt-1 flex flex-wrap gap-1">{a.cv.skills.slice(0, 6).map((s) => <Badge key={s} variant="secondary" className="text-[10px]">{s}</Badge>)}</div>
                    )}
                    {a.coverNote && <p className="mt-2 rounded-lg bg-stone-50 p-2 text-xs italic">&ldquo;{a.coverNote}&rdquo;</p>}
                    {a.interviewAt && <p className="mt-1 flex items-center gap-1 text-xs font-semibold text-emerald-700"><CalendarClock className="h-3.5 w-3.5" />PV: {new Date(a.interviewAt).toLocaleString('vi-VN')}</p>}
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    {statusBadge(a.status)}
                    <Button size="sm" variant="outline" onClick={() => onMessage(a.user.id)}>Nhắn tin</Button>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-1.5 border-t pt-2">
                  {NEXT_STATUS[a.status] && <Button size="sm" className="h-7 bg-emerald-600 text-xs hover:bg-emerald-700" onClick={() => advance(a, NEXT_STATUS[a.status])}>{PIPELINE_VI[NEXT_STATUS[a.status]]}</Button>}
                  {a.status !== 'rejected' && a.status !== 'offered' && <Button size="sm" variant="outline" className="h-7 text-xs text-rose-600" onClick={() => advance(a, 'rejected')}>Loại</Button>}
                </div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
