'use client'

import { useCallback, useState } from 'react'
import type { VxUserInfo } from '@/components/vexon/AuthView'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { Avatar } from '@/components/vexon/shared'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useToast } from '@/hooks/use-toast'
import { FileSearch, Upload, Loader2, Table2, Braces, Trash2, Hash, Type } from 'lucide-react'

interface ColStat {
  name: string
  type: 'number' | 'text'
  min?: number
  max?: number
  avg?: number
  sum?: number
  distinct?: number
  top?: { v: string; c: number }[]
}

interface AnalysisRecord {
  id: string
  name: string
  kind: 'csv' | 'json'
  size: number
  rows: number
  columns: number
  createdAt: string
  summary: { columns: ColStat[]; preview: string[][] }
}

const fmtSize = (n: number) => (n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1048576).toFixed(2)} MB`)
const fmtTime = (s: string) => new Date(s).toLocaleString('vi-VN', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })

export default function AnalysisView({ me }: { me: VxUserInfo }) {
  return (
    <div className="space-y-6">
      <UploadCard />
      <HistoryList me={me} />
    </div>
  )
}

// ===== Tải file lên & phân tích =====
function UploadCard() {
  const [result, setResult] = useState<AnalysisRecord | null>(null)
  const [busy, setBusy] = useState(false)
  const [dragOver, setDragOver] = useState(false)
  const { toast } = useToast()

  const analyze = useCallback(async (name: string, content: string, size: number) => {
    setBusy(true)
    try {
      const res = await fetch('/api/vx/analysis', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, content, size }) })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Không phân tích được file')
      setResult(data)
      toast({ title: 'Phân tích hoàn tất', description: `${data.name}, ${data.rows} dòng, ${data.columns} cột` })
    } catch (e) {
      toast({ title: 'Lỗi phân tích', description: e instanceof Error ? e.message : 'Thử lại nhé', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }, [toast])

  const handleFile = useCallback(async (file: File) => {
    if (file.size > 2_000_000) {
      toast({ title: 'File quá lớn', description: 'Bản demo hỗ trợ tối đa ~2MB', variant: 'destructive' })
      return
    }
    const content = await file.text()
    await analyze(file.name, content, file.size)
  }, [analyze, toast])

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <FileSearch className="h-5 w-5 text-emerald-600" />
          Phân tích file dữ liệu
        </CardTitle>
        <p className="text-sm text-muted-foreground">Tải lên file CSV hoặc JSON (báo cáo, danh sách, dữ liệu bán hàng...), hệ thống tự đọc cấu trúc, thống kê từng cột và xem trước dữ liệu.</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <label
          className={`flex min-h-36 cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-6 text-center transition-colors ${dragOver ? 'border-emerald-500 bg-emerald-50' : 'border-stone-300 bg-muted/30 hover:border-emerald-400 hover:bg-emerald-50/50'}`}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => { e.preventDefault(); setDragOver(false); const f = e.dataTransfer.files?.[0]; if (f) handleFile(f) }}
        >
          <input type="file" accept=".csv,.json,.txt,text/csv,application/json" className="sr-only" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f) }} />
          {busy ? (
            <><Loader2 className="h-8 w-8 animate-spin text-emerald-600" /><p className="text-sm font-medium">Đang phân tích...</p></>
          ) : (
            <>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100"><Upload className="h-5 w-5 text-emerald-700" /></div>
              <p className="text-sm font-semibold">Kéo thả file vào đây hoặc bấm để chọn</p>
              <p className="text-xs text-muted-foreground">Hỗ trợ .csv, .json, .txt, tối đa ~2MB</p>
            </>
          )}
        </label>

        {result && <ResultDetail r={result} />}
      </CardContent>
    </Card>
  )
}

// ===== Kết quả phân tích chi tiết =====
function ResultDetail({ r }: { r: AnalysisRecord }) {
  return (
    <div className="space-y-3 rounded-xl border bg-muted/20 p-4">
      <div className="flex flex-wrap items-center gap-2">
        {r.kind === 'json' ? <Braces className="h-4 w-4 text-emerald-600" /> : <Table2 className="h-4 w-4 text-sky-600" />}
        <p className="text-sm font-bold">{r.name}</p>
        <Badge variant="secondary" className="uppercase">{r.kind}</Badge>
        <Badge variant="outline">{fmtSize(r.size)}</Badge>
        <Badge variant="outline" className="bg-emerald-50 text-emerald-700">{r.rows} dòng</Badge>
        <Badge variant="outline" className="bg-sky-50 text-sky-700">{r.columns} cột</Badge>
      </div>

      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {r.summary.columns.map((c) => (
          <div key={c.name} className="rounded-lg border bg-white p-2.5 text-xs">
            <p className="mb-1 flex items-center gap-1 font-semibold">
              {c.type === 'number' ? <Hash className="h-3 w-3 text-emerald-600" /> : <Type className="h-3 w-3 text-amber-600" />}
              <span className="truncate">{c.name}</span>
            </p>
            {c.type === 'number' ? (
              <ul className="space-y-0.5 text-muted-foreground">
                <li>Tổng: <b className="text-foreground">{(c.sum ?? 0).toLocaleString('vi-VN')}</b></li>
                <li>Trung bình: <b className="text-foreground">{(c.avg ?? 0).toLocaleString('vi-VN')}</b></li>
                <li>Min, Max: {(c.min ?? 0).toLocaleString('vi-VN')} tới {(c.max ?? 0).toLocaleString('vi-VN')}</li>
              </ul>
            ) : (
              <ul className="space-y-0.5 text-muted-foreground">
                <li>{c.distinct ?? 0} giá trị khác nhau</li>
                {(c.top ?? []).map((t) => (
                  <li key={t.v} className="truncate">• {t.v} <b className="text-foreground">×{t.c}</b></li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </div>

      {r.summary.preview.length > 0 && (
        <div className="max-h-64 overflow-auto rounded-lg border">
          <Table>
            <TableHeader className="sticky top-0 bg-white">
              <TableRow>
                {r.summary.columns.map((c) => <TableHead key={c.name} className="whitespace-nowrap">{c.name}</TableHead>)}
              </TableRow>
            </TableHeader>
            <TableBody>
              {r.summary.preview.map((row, i) => (
                <TableRow key={i}>
                  {row.map((cell, j) => <TableCell key={j} className="max-w-48 truncate text-xs">{cell}</TableCell>)}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  )
}

// ===== Lịch sử phân tích =====
function HistoryList({ me }: { me: VxUserInfo }) {
  const [list, setList] = useState<AnalysisRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [openId, setOpenId] = useState<string | null>(null)
  const { toast } = useToast()

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/vx/analysis')
      const data = await res.json()
      if (Array.isArray(data)) setList(data)
    } catch { /* bỏ qua */ } finally { setLoading(false) }
  }, [])
  useDeferredLoad(load, [load])

  const remove = async (id: string) => {
    await fetch(`/api/vx/analysis?id=${id}`, { method: 'DELETE' })
    setList((l) => l.filter((x) => x.id !== id))
    toast({ title: 'Đã xoá khỏi lịch sử' })
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Table2 className="h-5 w-5 text-emerald-600" />
          Lịch sử phân tích của tôi
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="flex items-center gap-2 py-6 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Đang tải...</p>
        ) : list.length === 0 ? (
          <p className="rounded-xl border border-dashed p-6 text-center text-sm text-muted-foreground">Chưa phân tích file nào, hãy tải file CSV/JSON đầu tiên của bạn lên nhé!</p>
        ) : (
          <div className="space-y-2">
            {list.map((f) => (
              <div key={f.id} className="rounded-xl border p-3">
                <div className="flex items-center gap-3">
                  <Avatar name={f.kind === 'json' ? '{}' : 'CS'} color={f.kind === 'json' ? '#8b5cf6' : '#06b6d4'} size={38} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{f.name}</p>
                    <p className="text-xs text-muted-foreground">{fmtTime(f.createdAt)}, {f.rows} dòng, {f.columns} cột, {fmtSize(f.size)}</p>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => setOpenId(openId === f.id ? null : f.id)}>
                    {openId === f.id ? 'Ẩn chi tiết' : 'Xem chi tiết'}
                  </Button>
                  <Button size="sm" variant="ghost" className="text-red-600 hover:text-red-700" onClick={() => remove(f.id)} aria-label={`Xoá ${f.name}`}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                {openId === f.id && <div className="mt-3"><ResultDetail r={f} /></div>}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
