'use client'

import { useCallback, useEffect, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import type { VxUserInfo } from './AuthView'
import { Avatar, GradMedia, isGradMedia } from './shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { toast } from 'sonner'
import { Building2, Search, Star, Bot, Loader2, Plus, Trash2, Globe, MapPin, Users, Briefcase, ShieldCheck, Layers, Target, FileText, Image as ImageIcon, Handshake, Check } from 'lucide-react'

interface Company {
  id: string
  name: string
  industry: string
  size: string
  website: string | null
  address: string | null
  foundedYear: number | null
  about: string | null
  vision: string | null
  services: string[]
  ratingAvg: number
  ratingCount: number
  botEnabled: boolean
  botName: string
  owner: { fullName: string; avatarColor: string; online: boolean }
  portfolioCount: number
  jobCount: number
  reviewCount: number
  memberCount?: number
}

interface PortfolioItem { id: string; title: string; category: string; kind: string; media: string | null; year: number | null; description: string | null }
interface Review { id: string; rating: number; comment: string; createdAt: string; author: { id: string; fullName: string; avatarColor: string } }
interface JobLite { id: string; title: string; location: string; salaryMin: number; salaryMax: number; workType: string }
interface MemberUser { id: string; fullName: string; avatarColor: string; avatarImage?: string | null; title?: string; online?: boolean; role?: string | null }
// Chức vụ trong doanh nghiệp — Giám đốc, Phó giám đốc, Trưởng phòng có quyền duyệt + thêm thành viên
const VX_ROLES = ['Giám đốc', 'Phó giám đốc', 'Trưởng phòng', 'Nhân viên']
const LEADERSHIP_ROLES = ['Giám đốc', 'Phó giám đốc', 'Trưởng phòng']
const HIGH_ROLES = ['Giám đốc', 'Phó giám đốc']
const ROLE_STYLES: Record<string, string> = {
  'Giám đốc': 'bg-amber-100 text-amber-800',
  'Phó giám đốc': 'bg-orange-100 text-orange-700',
  'Trưởng phòng': 'bg-sky-100 text-sky-700',
  'Nhân viên': 'bg-stone-100 text-stone-600',
}
function RoleBadge({ role }: { role?: string | null }) {
  const r = role || 'Nhân viên'
  return <span className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] font-bold ${ROLE_STYLES[r] || 'bg-stone-100 text-stone-600'}`}>{r.toUpperCase()}</span>
}
interface FullCompany extends Company {
  portfolio: PortfolioItem[]
  reviews: Review[]
  jobs: JobLite[]
  botGreeting: string
  botRules: { keywords: string[]; reply: string }[]
  botFallback: string
  ownerId: string
  taxId: string | null
  // Thành viên doanh nghiệp: danh sách chính thức + trạng thái gia nhập của tôi
  members?: MemberUser[]
  memberCount?: number
  myMembership?: { id: string; status: 'pending' | 'active' | 'rejected' } | null
}

const fmtVnd = (n: number) => `${(n / 1_000_000).toFixed(n % 1_000_000 === 0 ? 0 : 1).replace('.', ',')}tr`

function Stars({ value }: { value: number }) {
  return (
    <span className="text-amber-500">
      {[1, 2, 3, 4, 5].map((i) => <Star key={i} className={`inline h-3.5 w-3.5 ${i <= Math.round(value) ? 'fill-amber-400 text-amber-400' : 'text-stone-300'}`} />)}
    </span>
  )
}

export default function CompaniesView({ me, onMessage }: { me: VxUserInfo; onMessage: (userId: string) => void }) {
  const isBusiness = me.accountType === 'business'
  const [companies, setCompanies] = useState<Company[]>([])
  const [industries, setIndustries] = useState<string[]>([])
  const [q, setQ] = useState('')
  const [loading, setLoading] = useState(true)
  const [detail, setDetail] = useState<FullCompany | null>(null)
  const [editing, setEditing] = useState(false)
  const [myCompany, setMyCompany] = useState<FullCompany | null>(null)
  const [botOn, setBotOn] = useState(true)
  const [rules, setRules] = useState<{ keywords: string; reply: string }[]>([])
  const [saving, setSaving] = useState(false)
  const [reviewRating, setReviewRating] = useState(5)
  const [reviewText, setReviewText] = useState('')
  const [joinBusy, setJoinBusy] = useState(false)
  const [memberBusy, setMemberBusy] = useState<string | null>(null)
  // Chủ công ty / thành viên cấp quản lý: toàn bộ dòng thành viên (đơn chờ duyệt + thành viên chính thức)
  const [companyMembers, setCompanyMembers] = useState<{ id: string; userId?: string; status: string; role?: string; createdAt: string; user: MemberUser }[]>([])
  // Bảng quản lý thành viên: hiện cho chủ công ty HOẶC thành viên có chức vụ Giám đốc/Phó giám đốc/Trưởng phòng
  const [panelCompanyId, setPanelCompanyId] = useState<string | null>(null)
  const [panelCompanyName, setPanelCompanyName] = useState('')
  const [panelIsOwner, setPanelIsOwner] = useState(false)
  const [panelRole, setPanelRole] = useState<string>('')
  const canApprovePanel = Boolean(panelCompanyId) && (panelIsOwner || LEADERSHIP_ROLES.includes(panelRole))
  const canManagePanel = Boolean(panelCompanyId) && (panelIsOwner || HIGH_ROLES.includes(panelRole))
  // Dialog thêm thành viên trực tiếp (giám đốc/phó giám đốc/trưởng phòng mời người dùng vào công ty)
  const [addOpen, setAddOpen] = useState(false)
  const [userQuery, setUserQuery] = useState('')
  const [userResults, setUserResults] = useState<{ id: string; username: string; fullName: string; avatarColor: string; avatarImage: string | null; bio: string | null; accountType: string }[]>([])
  const [searching, setSearching] = useState(false)
  const [addBusy, setAddBusy] = useState<string | null>(null)

  const load = useCallback(() => {
    fetch(`/api/vx/companies?q=${encodeURIComponent(q)}`)
      .then((r) => r.json())
      .then((d) => {
        if (Array.isArray(d.companies)) setCompanies(d.companies)
        if (Array.isArray(d.industries)) setIndustries(d.industries)
      })
      .catch(() => {})
      .finally(() => setLoading(false))
    if (isBusiness) {
      fetch('/api/vx/companies?mine=1')
        .then((r) => r.json())
        .then((d) => {
          if (d.myCompany) {
            const c = d.myCompany
            setMyCompany({ ...c, services: c.services ? JSON.parse(c.services) : [], botRules: c.botRules ? JSON.parse(c.botRules) : [], ratingAvg: c.ratingAvg, ratingCount: c.ratingCount, reviews: [], portfolio: c.portfolio, jobs: [], portfolioCount: c.portfolio.length, jobCount: c._count.jobs, reviewCount: c._count.reviews, owner: { fullName: me.fullName, avatarColor: me.avatarColor, online: true } })
            setBotOn(c.botEnabled)
            setRules(c.botRules ? (JSON.parse(c.botRules) as { keywords: string[]; reply: string }[]).map((r) => ({ keywords: r.keywords.join(', '), reply: r.reply })) : [])
            setCompanyMembers(Array.isArray(c.members) ? c.members : [])
            // Chủ công ty: mở bảng quản lý thành viên với quyền đầy đủ (coi như Giám đốc)
            setPanelCompanyId(c.id)
            setPanelCompanyName(c.name)
            setPanelIsOwner(true)
            setPanelRole('Giám đốc')
          } else {
            setPanelCompanyId(null)
            setPanelIsOwner(false)
          }
        })
        .catch(() => {})
    }
    // Thành viên cấp quản lý (không phải chủ công ty): có quyền duyệt/thêm thành viên theo chức vụ
    fetch('/api/vx/companies/members?self=1')
      .then((r) => r.json())
      .then((d) => {
        const ms = d.membership
        if (ms?.status === 'active' && ms.company) {
          const role = String(ms.role || 'Nhân viên')
          const isOwnerOfIt = ms.company.ownerId === me.id
          if (isOwnerOfIt || LEADERSHIP_ROLES.includes(role)) {
            setPanelCompanyId(ms.company.id)
            setPanelCompanyName(ms.company.name)
            setPanelIsOwner(isOwnerOfIt)
            setPanelRole(isOwnerOfIt ? 'Giám đốc' : role)
            fetch(`/api/vx/companies/members?companyId=${ms.company.id}`)
              .then((r) => r.json())
              .then((d2) => { if (Array.isArray(d2.members)) setCompanyMembers(d2.members) })
              .catch(() => {})
          }
        } else if (!isBusiness) {
          setPanelCompanyId(null)
          setPanelIsOwner(false)
        }
      })
      .catch(() => {})
  }, [q, isBusiness, me.id, me.fullName, me.avatarColor])

  useDeferredLoad(() => load(), [load])

  const openDetail = async (id: string) => {
    const res = await fetch(`/api/vx/companies/${id}`)
    const d = await res.json()
    if (d.company) setDetail(d.company)
  }

  // GIA NHẬP DOANH NGHIỆP: xin gia nhập / huỷ / rời khỏi — chủ công ty duyệt mới thành chính thức
  const joinAction = async (companyId: string, action: 'join' | 'cancel' | 'leave') => {
    setJoinBusy(true)
    try {
      const res = await fetch('/api/vx/companies/join', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ companyId, action }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success(d.message || 'Đã xử lý')
      await openDetail(companyId)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không xử lý được')
    } finally { setJoinBusy(false) }
  }

  // GIÁM ĐỐC / PHÓ GIÁM ĐỐC / TRƯỞNG PHÒNG / CHỦ CÔNG TY: duyệt · từ chối · xoá · gán chức vụ
  const memberAction = async (memberId: string, action: 'approve' | 'reject' | 'remove' | 'set-role', role?: string) => {
    setMemberBusy(memberId)
    try {
      const res = await fetch('/api/vx/companies/members', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memberId, action, role }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success(d.message || 'Đã xử lý')
      load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không xử lý được')
    } finally { setMemberBusy(null) }
  }

  // THÊM THÀNH VIÊN TRỰC TIẾP: giám đốc/phó giám đốc/trưởng phòng mời người dùng vào công ty (thành viên chính thức ngay)
  const addMember = async (userId: string) => {
    if (!panelCompanyId) return
    setAddBusy(userId)
    try {
      const res = await fetch('/api/vx/companies/members', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ companyId: panelCompanyId, userId }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success(d.message || 'Đã thêm thành viên')
      setUserQuery('')
      setUserResults([])
      setAddOpen(false)
      load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không thêm được')
    } finally { setAddBusy(null) }
  }

  // Tìm người dùng để thêm vào công ty (debounce 350ms)
  useEffect(() => {
    if (!addOpen || !userQuery.trim()) { setUserResults([]); return }
    setSearching(true)
    const t = setTimeout(() => {
      fetch(`/api/vx/users/search?q=${encodeURIComponent(userQuery.trim())}&limit=8`)
        .then((r) => r.json())
        .then((d) => setUserResults(Array.isArray(d.users) ? d.users : []))
        .catch(() => {})
        .finally(() => setSearching(false))
    }, 350)
    return () => clearTimeout(t)
  }, [userQuery, addOpen])

  const saveProfile = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setSaving(true)
    const fd = new FormData(e.currentTarget)
    const res = await fetch('/api/vx/companies', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: fd.get('name'), industry: fd.get('industry'), size: fd.get('size'),
        website: fd.get('website'), address: fd.get('address'),
        foundedYear: Number(fd.get('foundedYear')) || null, taxId: fd.get('taxId'),
        about: fd.get('about'), vision: fd.get('vision'),
        services: String(fd.get('services') || '').split(',').map((s) => s.trim()).filter(Boolean),
        botEnabled: botOn,
        botName: fd.get('botName'), botGreeting: fd.get('botGreeting'), botFallback: fd.get('botFallback'),
        botRules: rules.map((r) => ({ keywords: r.keywords.split(',').map((k) => k.trim()).filter(Boolean), reply: r.reply })),
      }),
    })
    setSaving(false)
    const d = await res.json()
    if (res.ok) {
      toast.success('Đã lưu hồ sơ năng lực công ty!')
      setEditing(false)
      load()
    } else toast.error(d.error || 'Không lưu được')
  }

  const addPortfolio = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!myCompany) return
    const fd = new FormData(e.currentTarget)
    const res = await fetch(`/api/vx/companies/${myCompany.id}/portfolio`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: fd.get('title'), category: fd.get('category'), year: Number(fd.get('year')) || null, description: fd.get('description'), media: fd.get('media') ? `grad:${fd.get('media')}` : null, kind: fd.get('kind') }),
    })
    if (res.ok) {
      toast.success('Đã thêm hạng mục hồ sơ năng lực')
      ;(e.target as HTMLFormElement).reset()
      load()
    } else toast.error('Không thêm được')
  }

  const removePortfolio = async (itemId: string) => {
    if (!myCompany) return
    const res = await fetch(`/api/vx/companies/${myCompany.id}/portfolio?itemId=${itemId}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Đã xoá'); load() }
  }

  const submitReview = async (companyId: string) => {
    const res = await fetch(`/api/vx/companies/${companyId}/reviews`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rating: reviewRating, comment: reviewText }),
    })
    const d = await res.json()
    if (res.ok) {
      toast.success('Cảm ơn bạn đã đánh giá!')
      setReviewText('')
      openDetail(companyId)
      load()
    } else toast.error(d.error || 'Không gửi được đánh giá')
  }

  return (
    <div className="space-y-5">
      <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 p-5 text-white shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="flex items-center gap-2 text-xl font-black"><Building2 className="h-6 w-6" /> Hồ sơ Năng lực Doanh nghiệp</h1>
            <p className="mt-1 text-sm text-amber-100">Danh bạ B2B, Portfolio công trình, Chấm điểm uy tín, Bot riêng cho từng công ty</p>
          </div>
          {isBusiness && <Button className="bg-white font-bold text-orange-700 hover:bg-orange-50" onClick={() => setEditing(true)}>{myCompany ? 'Sửa hồ sơ công ty' : '+ Tạo hồ sơ công ty'}</Button>}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 rounded-xl border bg-white p-3 shadow-sm">
        <div className="relative min-w-64 flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-stone-400" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm doanh nghiệp theo tên, lĩnh vực..." className="pl-9" aria-label="Tìm doanh nghiệp" />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {industries.map((i) => (
            <Badge key={i} variant="secondary" className="cursor-pointer hover:bg-amber-100" onClick={() => setQ(i)}>{i}</Badge>
          ))}
        </div>
        <span className="ml-auto text-xs text-stone-500">{loading ? <Loader2 className="inline h-3.5 w-3.5 animate-spin" /> : `${companies.length} doanh nghiệp`}</span>
      </div>

      {/* ===== THÀNH VIÊN CÔNG TY (chủ doanh nghiệp hoặc Giám đốc/Phó giám đốc/Trưởng phòng quản lý) ===== */}
      {panelCompanyId && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-4 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="flex items-center gap-2 text-sm font-bold text-emerald-800"><Users className="h-4 w-4" /> Thành viên {panelCompanyName} <span className="rounded bg-emerald-600 px-1.5 py-0.5 text-[10px] font-bold text-white">{companyMembers.filter((m) => m.status === 'active').length} chính thức</span></p>
            {canApprovePanel && (
              <Button size="sm" className="h-8 bg-emerald-600 hover:bg-emerald-700" onClick={() => { setUserQuery(''); setUserResults([]); setAddOpen(true) }} aria-label="Thêm thành viên vào công ty"><Plus className="mr-1 h-3.5 w-3.5" /> Thêm thành viên</Button>
            )}
          </div>
          <p className="mt-0.5 text-xs text-emerald-700/90">
            Đơn xin gia nhập được <b>Giám đốc, Phó giám đốc hoặc Trưởng phòng duyệt</b> — hoặc giám đốc thêm thẳng thành viên mới. Quyền lợi: x2 thưởng điểm danh hàng ngày, badge nhân viên, ưu đãi công cụ AI.
          </p>
          {companyMembers.length === 0 && <p className="mt-3 text-xs text-stone-500">Chưa có thành viên nào — bấm “Thêm thành viên” để mời người dùng vào công ty.</p>}
          <div className="mt-3 space-y-2">
            {companyMembers.map((m) => (
              <div key={m.id} className="flex flex-wrap items-center gap-2.5 rounded-lg border bg-white p-2.5">
                <Avatar name={m.user.fullName} color={m.user.avatarColor} size={34} img={m.user.avatarImage} online={m.user.online} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{m.user.fullName} <span className="text-xs font-normal text-stone-500">{m.user.title ? `, ${m.user.title}` : ''}</span></p>
                  <p className="text-[11px] text-stone-500">{m.status === 'pending' ? 'Xin gia nhập lúc' : 'Thành viên từ'} {new Date(m.createdAt).toLocaleString('vi-VN')}</p>
                </div>
                {m.status === 'pending' ? (
                  <>
                    <RoleBadge role="Nhân viên" />
                    <span className="rounded bg-sky-100 px-2 py-0.5 text-[10px] font-bold text-sky-700">CHỜ DUYỆT</span>
                    {canApprovePanel && (
                      <>
                        <Button size="sm" className="h-7 bg-emerald-600 hover:bg-emerald-700" disabled={memberBusy === m.id} onClick={() => memberAction(m.id, 'approve')} aria-label={`Duyệt thành viên ${m.user.fullName}`}><Check className="mr-1 h-3 w-3" /> Duyệt</Button>
                        <Button size="sm" variant="outline" className="h-7 border-rose-300 text-rose-600 hover:bg-rose-50" disabled={memberBusy === m.id} onClick={() => memberAction(m.id, 'reject')} aria-label={`Từ chối ${m.user.fullName}`}><Trash2 className="mr-1 h-3 w-3" /> Từ chối</Button>
                      </>
                    )}
                  </>
                ) : m.status === 'active' ? (
                  <>
                    <RoleBadge role={m.role} />
                    <span className="rounded bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700">CHÍNH THỨC</span>
                    {canManagePanel && (
                      <Select value={m.role || 'Nhân viên'} onValueChange={(v) => memberAction(m.id, 'set-role', v)}>
                        <SelectTrigger className="h-7 w-[120px] text-xs" aria-label={`Chức vụ của ${m.user.fullName}`}><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {(panelIsOwner ? VX_ROLES : VX_ROLES.filter((r) => r !== 'Giám đốc')).map((r) => (
                            <SelectItem key={r} value={r}>{r}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                    {canManagePanel && m.userId !== me.id && (
                      <Button size="sm" variant="outline" className="h-7 border-rose-300 text-rose-600 hover:bg-rose-50" disabled={memberBusy === m.id} onClick={() => memberAction(m.id, 'remove')} aria-label={`Xoá thành viên ${m.user.fullName}`}><Trash2 className="mr-1 h-3 w-3" /> Xoá</Button>
                    )}
                  </>
                ) : null}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid gap-3 md:grid-cols-2">
        {companies.map((c) => (
          <div key={c.id} className="rounded-xl border bg-white p-4 shadow-sm transition-shadow hover:shadow-md">
            <div className="flex items-start gap-3">
              <Avatar name={c.name} color={c.owner.avatarColor} size={48} />
              <div className="min-w-0 flex-1">
                <button className="text-left font-bold hover:text-orange-700" onClick={() => openDetail(c.id)}>{c.name}</button>
                <p className="text-xs text-stone-500">{c.industry}, {c.size} người, TC:{c.foundedYear}</p>
                <p className="mt-0.5 text-xs"><Stars value={c.ratingAvg} /> <b>{c.ratingAvg}</b> ({c.reviewCount} đánh giá)</p>
              </div>
              {c.botEnabled && <Badge className="bg-slate-800 text-[10px] text-white"><Bot className="mr-1 inline h-3 w-3" />{c.botName}</Badge>}
            </div>
            {c.about ? <p className="mt-2 line-clamp-2 text-xs text-stone-600">{c.about}</p> : null}
            <div className="mt-3 flex flex-wrap items-center gap-3 border-t pt-3 text-xs text-stone-500">
              <span className="flex items-center gap-1"><Layers className="h-3 w-3" /> {c.portfolioCount} portfolio</span>
              <span className="flex items-center gap-1"><Briefcase className="h-3 w-3" /> {c.jobCount} tin tuyển dụng</span>
              {!!c.memberCount && <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {c.memberCount} thành viên</span>}
              {c.website && <span className="flex items-center gap-1 text-sky-600"><Globe className="h-3 w-3" />Website</span>}
              <Button size="sm" variant="outline" className="ml-auto h-7 text-xs" onClick={() => openDetail(c.id)}>Xem hồ sơ</Button>
            </div>
          </div>
        ))}
      </div>

      {/* ===== Dialog chi tiết công ty ===== */}
      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="sm:max-w-3xl">
          {detail && (
            <div className="space-y-4">
              <DialogHeader>
                <DialogTitle className="flex flex-wrap items-center gap-2 text-left text-xl">
                  {detail.name}
                  {detail.botEnabled && <Badge className="bg-slate-800 text-[10px] text-white"><Bot className="mr-1 inline h-3 w-3" />{detail.botName} hoạt động</Badge>}
                </DialogTitle>
              </DialogHeader>
              <div className="flex flex-wrap gap-2 text-xs">
                <Badge variant="secondary">{detail.industry}</Badge>
                <Badge variant="secondary">{detail.size} người</Badge>
                {detail.foundedYear && <Badge variant="secondary">Thành lập {detail.foundedYear}</Badge>}
                {detail.taxId && <Badge variant="secondary"><ShieldCheck className="mr-1 inline h-3 w-3" />MST {detail.taxId}</Badge>}
                {detail.address && <Badge variant="secondary"><MapPin className="mr-1 inline h-3 w-3" />{detail.address}</Badge>}
                {detail.website && <a href={detail.website} target="_blank" className="text-sky-600 underline">{detail.website}</a>}
              </div>
              <p className="flex items-center gap-2 text-sm"><Stars value={detail.ratingAvg} /> <b>{detail.ratingAvg}/5</b>, {detail.ratingCount} đánh giá uy tín</p>
              {detail.about && <p className="text-sm leading-relaxed">{detail.about}</p>}
              {detail.vision && <p className="flex items-start gap-1.5 rounded-lg bg-amber-50 p-3 text-sm italic text-amber-900"><Target className="mt-0.5 h-4 w-4 shrink-0" /> Tầm nhìn: {detail.vision}</p>}
              {detail.services.length > 0 && (
                <div className="flex flex-wrap gap-1.5">{detail.services.map((s) => <Badge key={s} className="bg-orange-100 text-orange-800 hover:bg-orange-100">{s}</Badge>)}</div>
              )}

              {/* Portfolio */}
              <div>
                <p className="mb-2 font-bold">Hồ sơ năng lực số ({detail.portfolio.length})</p>
                <div className="grid gap-2 sm:grid-cols-2">
                  {detail.portfolio.map((p) => (
                    <div key={p.id} className="overflow-hidden rounded-lg border">
                      {p.media && isGradMedia(p.media) ? <GradMedia value={p.media} className="h-24 w-full" /> : <div className="flex h-24 items-center justify-center bg-stone-100 text-stone-400">{p.kind === 'doc' ? <FileText className="h-8 w-8" /> : <ImageIcon className="h-8 w-8" />}</div>}
                      <div className="p-2.5">
                        <p className="text-sm font-semibold">{p.title}</p>
                        <p className="text-[11px] text-stone-500">{p.category}{p.year ? `, ${p.year}` : ''}</p>
                        {p.description && <p className="mt-1 line-clamp-2 text-[11px] text-stone-600">{p.description}</p>}
                      </div>
                    </div>
                  ))}
                  {detail.portfolio.length === 0 && <p className="col-span-2 py-4 text-center text-xs text-stone-500">Chưa cập nhật portfolio.</p>}
                </div>
              </div>

              {/* Jobs */}
              {detail.jobs.length > 0 && (
                <div>
                  <p className="mb-2 font-bold">Đang tuyển ({detail.jobs.length})</p>
                  <div className="space-y-1.5">
                    {detail.jobs.map((j) => (
                      <div key={j.id} className="flex items-center justify-between rounded-lg border p-2.5 text-sm">
                        <span className="flex min-w-0 items-center gap-1.5"><b className="truncate">{j.title}</b> <span className="flex shrink-0 items-center gap-0.5 text-xs text-stone-500"><MapPin className="h-3 w-3" /> {j.location}</span></span>
                        <span className="text-xs font-semibold text-emerald-700">{j.salaryMin > 0 ? `${fmtVnd(j.salaryMin)}-${fmtVnd(j.salaryMax)}` : 'TL'}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Reviews */}
              <div>
                <p className="mb-2 font-bold">Đánh giá từ đối tác ({detail.reviews.length})</p>
                <div className="space-y-2">
                  {detail.reviews.map((r) => (
                    <div key={r.id} className="flex items-start gap-2.5 rounded-lg border p-2.5">
                      <Avatar name={r.author.fullName} color={r.author.avatarColor} size={28} />
                      <div className="flex-1">
                        <p className="text-xs font-semibold">{r.author.fullName} <Stars value={r.rating} /></p>
                        <p className="text-xs text-stone-600">{r.comment}</p>
                      </div>
                    </div>
                  ))}
                </div>
                {detail.ownerId !== me.id && (
                  <div className="mt-3 rounded-lg border border-dashed p-3">
                    <p className="mb-2 text-xs font-semibold">Đánh giá uy tín công ty này:</p>
                    <div className="flex items-center gap-1">{[1, 2, 3, 4, 5].map((i) => <button key={i} onClick={() => setReviewRating(i)} aria-label={`${i} sao`}><Star className={`h-5 w-5 ${i <= reviewRating ? 'fill-amber-400 text-amber-400' : 'text-stone-300'}`} /></button>)}</div>
                    <Textarea value={reviewText} onChange={(e) => setReviewText(e.target.value)} placeholder="Chia sẻ trải nghiệm hợp tác..." rows={2} className="mt-2" aria-label="Nội dung đánh giá" />
                    <Button size="sm" className="mt-2 bg-orange-600 hover:bg-orange-700" onClick={() => submitReview(detail.id)}>Gửi đánh giá</Button>
                  </div>
                )}
              </div>

              {/* THÀNH VIÊN DOANH NGHIỆP: danh sách chính thức + nút xin gia nhập */}
              <div>
                <p className="mb-2 font-bold">Thành viên công ty ({detail.members?.length ?? 0})</p>
                {(detail.members?.length ?? 0) > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {detail.members!.map((m) => (
                      <div key={m.id} className="flex items-center gap-2 rounded-full border bg-white px-2.5 py-1">
                        <Avatar name={m.fullName} color={m.avatarColor} size={22} img={m.avatarImage} />
                        <span className="text-xs font-medium">{m.fullName}</span>
                        <RoleBadge role={m.role} />
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-stone-500">Chưa có thành viên chính thức nào.</p>
                )}
                {/* Nút gia nhập cho tài khoản cá nhân (không phải chủ công ty) — quyền lợi: x2 thưởng điểm danh, badge nhân viên */}
                {detail.ownerId !== me.id && !isBusiness && (
                  <div className="mt-2.5 flex flex-wrap items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 p-2.5">
                    <Handshake className="h-4 w-4 shrink-0 text-emerald-600" />
                    {detail.myMembership?.status === 'active' ? (
                      <>
                        <p className="min-w-0 flex-1 text-xs font-semibold text-emerald-800">Bạn là thành viên chính thức của {detail.name} — đang hưởng x2 thưởng điểm danh hàng ngày và badge nhân viên.</p>
                        <Button size="sm" variant="outline" className="h-7 border-rose-300 text-rose-600 hover:bg-rose-50" disabled={joinBusy} onClick={() => joinAction(detail.id, 'leave')}>Rời doanh nghiệp</Button>
                      </>
                    ) : detail.myMembership?.status === 'pending' ? (
                      <>
                        <p className="min-w-0 flex-1 text-xs text-emerald-800">Đã gửi yêu cầu gia nhập, Giám đốc hoặc các chức vụ quản lý của công ty đang xét duyệt. Duyệt xong bạn sẽ hưởng quyền lợi: x2 thưởng điểm danh, badge nhân viên.</p>
                        <Button size="sm" variant="outline" className="h-7" disabled={joinBusy} onClick={() => joinAction(detail.id, 'cancel')}>Huỷ yêu cầu</Button>
                      </>
                    ) : (
                      <>
                        <p className="min-w-0 flex-1 text-xs text-emerald-800">Gia nhập để hưởng quyền lợi công ty: <b>x2 thưởng điểm danh hàng ngày</b>, badge "Nhân viên {detail.name}" trên hồ sơ, ưu đãi công cụ AI.</p>
                        <Button size="sm" className="h-7 bg-emerald-600 hover:bg-emerald-700" disabled={joinBusy} onClick={() => joinAction(detail.id, 'join')} aria-label={`Xin gia nhập ${detail.name}`}>
                          {joinBusy ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <Users className="mr-1 h-3 w-3" />} Xin gia nhập doanh nghiệp
                        </Button>
                      </>
                    )}
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between border-t pt-3">
                <p className="text-xs text-stone-500">Người đại diện: <b>{detail.owner.fullName}</b></p>
                <Button size="sm" className="bg-slate-800 hover:bg-slate-700" onClick={() => { onMessage(detail.ownerId); setDetail(null) }}>
                  <Bot className="mr-1 h-4 w-4" /> Nhắn tin (bot trả lời)
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ===== Dialog tạo/sửa hồ sơ công ty + bot ===== */}
      <Dialog open={editing} onOpenChange={setEditing}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader><DialogTitle>{myCompany ? 'Cập nhật hồ sơ năng lực' : 'Tạo hồ sơ doanh nghiệp'}</DialogTitle></DialogHeader>
          <form className="space-y-3" onSubmit={saveProfile}>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Tên công ty *</Label><Input name="name" required defaultValue={myCompany?.name || me.companyName || ''} /></div>
              <div className="space-y-1"><Label>Lĩnh vực</Label><Input name="industry" defaultValue={myCompany?.industry || 'Xây dựng'} /></div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1"><Label>Quy mô</Label><Input name="size" defaultValue={myCompany?.size || '10-50'} /></div>
              <div className="space-y-1"><Label>Thành lập</Label><Input name="foundedYear" type="number" defaultValue={myCompany?.foundedYear || ''} /></div>
              <div className="space-y-1"><Label>Mã số thuế</Label><Input name="taxId" defaultValue={myCompany?.taxId || ''} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Website</Label><Input name="website" defaultValue={myCompany?.website || ''} /></div>
              <div className="space-y-1"><Label>Địa chỉ</Label><Input name="address" defaultValue={myCompany?.address || ''} /></div>
            </div>
            <div className="space-y-1"><Label>Giới thiệu</Label><Textarea name="about" rows={2} defaultValue={myCompany?.about || ''} /></div>
            <div className="space-y-1"><Label>Tầm nhìn</Label><Textarea name="vision" rows={2} defaultValue={myCompany?.vision || ''} /></div>
            <div className="space-y-1"><Label>Dịch vụ/lĩnh vực (cách nhau bởi dấu phẩy)</Label><Input name="services" defaultValue={(myCompany?.services || []).join(', ')} /></div>

            {/* Portfolio nhanh */}
            {myCompany && myCompany.portfolio.length > 0 && (
              <div className="rounded-lg border p-3">
                <p className="mb-2 text-xs font-bold">Portfolio hiện có ({myCompany.portfolio.length})</p>
                <div className="space-y-1.5">
                  {myCompany.portfolio.map((p) => (
                    <div key={p.id} className="flex items-center justify-between rounded border px-2 py-1 text-xs">
                      <span className="truncate">{p.title}</span>
                      <button type="button" onClick={() => removePortfolio(p.id)} aria-label={`Xoá ${p.title}`}><Trash2 className="h-3.5 w-3.5 text-rose-500" /></button>
                    </div>
                  ))}
                </div>
                <form className="mt-2 flex flex-wrap items-end gap-2 border-t pt-2" onSubmit={addPortfolio}>
                  <Input name="title" placeholder="Tên hạng mục" className="min-w-40 flex-1" required aria-label="Tiêu đề hạng mục" />
                  <Input name="category" placeholder="Loại (Công trình...)" className="w-36" aria-label="Loại hạng mục" />
                  <Input name="media" placeholder="Màu #hex|#hex + nhãn" className="w-44" aria-label="Hình minh hoạ gradient" />
                  <Input name="year" type="number" placeholder="Năm" className="w-20" aria-label="Năm" />
                  <Button type="submit" size="sm" variant="outline"><Plus className="h-3.5 w-3.5" /></Button>
                </form>
              </div>
            )}

            {/* BOT */}
            <div className="rounded-lg border-2 border-slate-800 bg-slate-900 p-3 text-stone-200">
              <div className="mb-2 flex items-center justify-between">
                <p className="flex items-center gap-1.5 text-sm font-bold text-white"><Bot className="h-4 w-4" /> Bot riêng của công ty</p>
                <div className="flex items-center gap-2 text-xs"><span>{botOn ? 'Đang bật' : 'Tắt'}</span><Switch checked={botOn} onCheckedChange={setBotOn} aria-label="Bật bot" /></div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Input name="botName" defaultValue={myCompany?.botName || 'Trợ lý ảo'} placeholder="Tên bot" className="border-slate-700 bg-slate-800 text-white" aria-label="Tên bot" />
                <Input name="botGreeting" defaultValue={myCompany?.botGreeting || ''} placeholder="Lời chào mở đầu" className="border-slate-700 bg-slate-800 text-white" aria-label="Lời chào bot" />
              </div>
              <p className="mb-1 mt-2 text-xs text-stone-400">Kịch bản trả lời theo từ khoá (khách nhắn tin sẽ được bot tự trả lời):</p>
              {rules.map((r, i) => (
                <div key={i} className="mb-1.5 flex items-center gap-1.5">
                  <Input value={r.keywords} onChange={(e) => setRules(rules.map((x, j) => (j === i ? { ...x, keywords: e.target.value } : x)))} placeholder="Từ khoá: giá, báo giá..." className="border-slate-700 bg-slate-800 text-white" aria-label="Từ khoá bot" />
                  <Input value={r.reply} onChange={(e) => setRules(rules.map((x, j) => (j === i ? { ...x, reply: e.target.value } : x)))} placeholder="Nội dung trả lời..." className="flex-1 border-slate-700 bg-slate-800 text-white" aria-label="Trả lời bot" />
                  <button type="button" onClick={() => setRules(rules.filter((_, j) => j !== i))} aria-label="Xoá kịch bản"><Trash2 className="h-4 w-4 text-rose-400" /></button>
                </div>
              ))}
              <Button type="button" size="sm" variant="outline" className="mt-1 border-slate-600 text-stone-200 hover:bg-slate-800" onClick={() => setRules([...rules, { keywords: '', reply: '' }])}><Plus className="mr-1 h-3.5 w-3.5" />Thêm kịch bản</Button>
              <Textarea name="botFallback" defaultValue={myCompany?.botFallback || ''} placeholder="Trả lời khi không khớp từ khoá nào..." rows={2} className="mt-2 border-slate-700 bg-slate-800 text-white" aria-label="Trả lời mặc định bot" />
            </div>

            <Button type="submit" className="w-full bg-orange-600 hover:bg-orange-700" disabled={saving}>{saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : null}Lưu hồ sơ công ty</Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* ===== Dialog THÊM THÀNH VIÊN trực tiếp (Giám đốc / Phó giám đốc / Trưởng phòng / chủ công ty) ===== */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
          <DialogHeader><DialogTitle>Thêm thành viên vào {panelCompanyName}</DialogTitle></DialogHeader>
          <p className="text-xs text-stone-500">Tìm người dùng theo tên hoặc email — người được thêm sẽ là thành viên chính thức ngay (không cần xin gia nhập), mặc định chức vụ “Nhân viên”.</p>
          <Input value={userQuery} onChange={(e) => setUserQuery(e.target.value)} placeholder="Tên hoặc email người cần thêm..." aria-label="Tìm người dùng để thêm vào công ty" />
          <div className="max-h-72 space-y-2 overflow-y-auto">
            {searching && <p className="flex items-center gap-1.5 text-xs text-stone-500"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Đang tìm...</p>}
            {!searching && userQuery.trim() && userResults.length === 0 && <p className="text-xs text-stone-500">Không tìm thấy ai với từ khoá này.</p>}
            {userResults.map((u) => (
              <div key={u.id} className="flex items-center gap-2.5 rounded-lg border bg-white p-2.5">
                <Avatar name={u.fullName} color={u.avatarColor} size={34} img={u.avatarImage} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{u.fullName}{u.accountType === 'business' && <span className="ml-1 text-[10px] font-bold text-amber-700">[Doanh nghiệp]</span>}</p>
                  <p className="truncate text-[11px] text-stone-500">@{u.username}{u.bio ? `, ${u.bio}` : ''}</p>
                </div>
                <Button size="sm" className="h-7 bg-emerald-600 hover:bg-emerald-700" disabled={addBusy === u.id || u.accountType === 'business'} onClick={() => addMember(u.id)} aria-label={`Thêm ${u.fullName} vào công ty`}>
                  {addBusy === u.id ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <Plus className="mr-1 h-3 w-3" />} Thêm
                </Button>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
