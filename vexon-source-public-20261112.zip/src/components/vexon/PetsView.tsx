'use client'

// ============ THÚ CƯNG — trang cá nhân riêng kiểu FANPAGE cho bé ============
// Mini mạng xã hội riêng cho thú cưng (tính năng PHỤ của Vexon — MXH công ty):
// tạo trang bé, ảnh bìa/đại diện, người theo dõi (follow), đăng bài cho bé,
// thả tim + bình luận. Chỉ dùng icon lucide, tông amber ấm cho bé + emerald thương hiệu.

import { useCallback, useEffect, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { compressImage } from '@/lib/image-compress'
import { Avatar, timeAgo } from './shared'
import type { VxUserInfo } from './AuthView'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { PawPrint, Heart, MessageCircle, Plus, Camera, Images, Trash2, Pencil, X, Loader2, Cake, Info, UserRound, UsersRound, Check, Send } from 'lucide-react'

type PetOwner = { id: string; fullName: string; avatarColor: string; avatarImage?: string | null }

interface PetT {
  id: string
  name: string
  species: string
  breed?: string | null
  gender?: string | null
  birthday?: string | null
  bio?: string | null
  avatarColor: string
  avatarImage?: string | null
  coverImage?: string | null
  createdAt: string
  owner: PetOwner
  followers: number
  postCount: number
  isFollowing: boolean
  isOwner: boolean
}

interface PetCommentT {
  id: string
  content: string
  createdAt: string
  user: PetOwner
}

interface PetPostT {
  id: string
  content: string
  images: string[]
  createdAt: string
  author: PetOwner
  petName: string
  likes: number
  myLike: boolean
  comments: PetCommentT[]
}

interface PetProfileT {
  pet: PetT
  posts: PetPostT[]
}

const SPECIES = ['Chó', 'Mèo', 'Chim', 'Cá', 'Thỏ', 'Khác']

const emptyForm = { name: '', species: 'Chó', breed: '', gender: '', birthday: '', bio: '', avatarImage: '' as string | '' | null, coverImage: '' as string | '' | null }

export default function PetsView({ me, onOpenProfile }: { me: VxUserInfo; onOpenProfile: (id: string) => void }) {
  const [pets, setPets] = useState<PetT[]>([])
  const [loading, setLoading] = useState(true)
  const [createOpen, setCreateOpen] = useState(false)
  const [form, setForm] = useState({ ...emptyForm })
  const [saving, setSaving] = useState(false)
  const [avatarRef, setAvatarRef] = useState<HTMLInputElement | null>(null)
  const [coverRef, setCoverRef] = useState<HTMLInputElement | null>(null)

  // ---- Trang cá nhân bé (fanpage) ----
  const [profile, setProfile] = useState<PetProfileT | null>(null)
  const [profileLoading, setProfileLoading] = useState(false)
  const [editOpen, setEditOpen] = useState(false)

  const load = useCallback(() => {
    fetch('/api/vx/pets')
      .then((r) => r.json())
      .then((d) => Array.isArray(d) && setPets(d))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(() => { load() }, [load])

  const openPet = useCallback((id: string) => {
    setProfileLoading(true)
    fetch(`/api/vx/pets/${id}`)
      .then((r) => r.json())
      .then((d) => { if (d.pet) setProfile(d); else toast.error(d.error || 'Không tải được trang bé') })
      .catch(() => toast.error('Không tải được trang bé'))
      .finally(() => setProfileLoading(false))
  }, [])

  const readAsDataURL = (f: File) => new Promise<string>((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result))
    r.onerror = reject
    r.readAsDataURL(f)
  })

  const pickImage = async (file: File | undefined, kind: 'avatarImage' | 'coverImage') => {
    if (!file) return
    if (file.size > 6_000_000) { toast.error('Ảnh quá lớn (tối đa ~6MB trước khi nén)'); return }
    try {
      const url = await compressImage(file, kind === 'avatarImage' ? 512 : 1280)
      setForm((f) => ({ ...f, [kind]: url }))
    } catch { toast.error('Không đọc được ảnh') }
  }

  const submitPet = async () => {
    if (!form.name.trim()) { toast.error('Nhập tên bé nào!'); return }
    setSaving(true)
    try {
      const res = await fetch('/api/vx/pets', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name.trim(), species: form.species, breed: form.breed, gender: form.gender || null,
          birthday: form.birthday, bio: form.bio,
          avatarImage: form.avatarImage || null, coverImage: form.coverImage || null,
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không tạo được trang bé')
      toast.success(`Đã lập trang cá nhân cho bé ${form.name.trim()}`)
      setCreateOpen(false)
      setForm({ ...emptyForm })
      load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không tạo được trang bé')
    } finally { setSaving(false) }
  }

  const saveEdit = async () => {
    if (!profile) return
    if (!form.name.trim()) { toast.error('Nhập tên bé nào!'); return }
    setSaving(true)
    try {
      const res = await fetch(`/api/vx/pets/${profile.pet.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name.trim(), species: form.species, breed: form.breed, gender: form.gender || null,
          birthday: form.birthday, bio: form.bio,
          avatarImage: form.avatarImage || null, coverImage: form.coverImage || null,
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không lưu được thông tin bé')
      toast.success('Đã cập nhật thông tin bé')
      setEditOpen(false)
      load()
      openPet(profile.pet.id)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không lưu được thông tin bé')
    } finally { setSaving(false) }
  }

  const deletePet = async (pet: PetT) => {
    if (!window.confirm(`Xoá trang cá nhân của bé ${pet.name}? Toàn bộ bài viết, tim và người theo dõi sẽ mất.`)) return
    try {
      const res = await fetch(`/api/vx/pets/${pet.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error()
      toast.success(`Đã xoá trang của bé ${pet.name}`)
      setProfile(null)
      load()
    } catch { toast.error('Không xoá được trang bé') }
  }

  const toggleFollow = async (pet: PetT) => {
    try {
      const res = await fetch(`/api/vx/pets/${pet.id}/follow`, { method: 'POST' })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      const apply = (p: PetT) => (p.id === pet.id ? { ...p, isFollowing: d.isFollowing, followers: p.followers + (d.isFollowing ? 1 : -1) } : p)
      setPets((ps) => ps.map(apply))
      setProfile((pf) => (pf && pf.pet.id === pet.id ? { ...pf, pet: { ...pf.pet, isFollowing: d.isFollowing, followers: pf.pet.followers + (d.isFollowing ? 1 : -1) } } : pf))
      toast.success(d.isFollowing ? `Đã theo dõi bé ${pet.name}` : `Đã bỏ theo dõi bé ${pet.name}`)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không theo dõi được bé')
    }
  }

  const openEdit = (pet: PetT) => {
    setForm({
      name: pet.name, species: pet.species, breed: pet.breed || '', gender: pet.gender || '',
      birthday: pet.birthday ? new Date(pet.birthday).toISOString().slice(0, 10) : '', bio: pet.bio || '',
      avatarImage: pet.avatarImage || '', coverImage: pet.coverImage || '',
    })
    setEditOpen(true)
  }

  const myPets = pets.filter((p) => p.isOwner)
  const otherPets = pets.filter((p) => !p.isOwner)

  return (
    <div className="space-y-4">
      {profile ? (
        /* ---- TRANG CÁ NHÂN CỦA BÉ (kiểu fanpage) ---- */
        <PetProfile
          profile={profile}
          profileLoading={profileLoading}
          me={me}
          onBack={() => { setProfile(null); load() }}
          onEdit={() => openEdit(profile.pet)}
          onFollow={() => toggleFollow(profile.pet)}
          onRefreshProfile={() => openPet(profile.pet.id)}
          onOpenProfile={onOpenProfile}
        />
      ) : (
        <>
          {/* Đầu trang: giới thiệu + nút thêm bé */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-white p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-100 text-amber-600"><PawPrint className="h-6 w-6" /></span>
              <div>
                <p className="text-sm font-bold text-stone-800">Thú cưng của Vexon</p>
                <p className="text-xs text-stone-500">Mỗi bé có trang cá nhân riêng như một fanpage — người theo dõi, bài viết, tim và bình luận của riêng bé.</p>
              </div>
            </div>
            <Button className="gap-1.5 bg-emerald-600 hover:bg-emerald-700" onClick={() => { setForm({ ...emptyForm }); setCreateOpen(true) }} aria-label="Thêm bé mới">
              <Plus className="h-4 w-4" /> Thêm bé của tôi
            </Button>
          </div>

          {loading ? (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {[0, 1, 2].map((i) => <Skeleton key={i} className="h-44 rounded-2xl" />)}
            </div>
          ) : (
            <>
              {myPets.length > 0 && (
                <section>
                  <p className="mb-2 flex items-center gap-1.5 text-sm font-bold"><PawPrint className="h-4 w-4 text-amber-600" /> Bé của tôi ({myPets.length})</p>
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    {myPets.map((p) => <PetCard key={p.id} pet={p} onOpen={() => openPet(p.id)} onEdit={() => openEdit(p)} onDelete={() => deletePet(p)} />)}
                  </div>
                </section>
              )}
              <section>
                <p className="mb-2 flex items-center gap-1.5 text-sm font-bold"><UsersRound className="h-4 w-4 text-emerald-600" /> Khám phá bé khác ({otherPets.length})</p>
                {otherPets.length ? (
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    {otherPets.map((p) => (
                      <PetCard key={p.id} pet={p} onOpen={() => openPet(p.id)} onFollow={() => toggleFollow(p)} />
                    ))}
                  </div>
                ) : (
                  <p className="rounded-xl border border-dashed bg-white p-6 text-center text-sm text-muted-foreground">Chưa có bé nào khác — đồng nghiệp nào có boss/chó/cảnh trong nhà thì thêm cho cả công ty cùng chiêm ngưỡng nhé!</p>
                )}
              </section>
              {pets.length === 0 && (
                <p className="rounded-xl border border-dashed bg-white p-10 text-center text-sm text-muted-foreground">
                  Chưa có bé nào cả! Bấm <b>Thêm bé của tôi</b> để lập trang cá nhân đầu tiên cho boss nhà mình.
                </p>
              )}
            </>
          )}
        </>
      )}

      {/* Dialog tạo bé mới */}
      <PetFormDialog
        open={createOpen}
        title="Thêm bé mới"
        form={form}
        setForm={setForm}
        setAvatarRef={setAvatarRef}
        setCoverRef={setCoverRef}
        saving={saving}
        onClose={() => setCreateOpen(false)}
        onSubmit={submitPet}
      />

      {/* Dialog sửa thông tin bé */}
      <PetFormDialog
        open={editOpen}
        title="Sửa thông tin bé"
        form={form}
        setForm={setForm}
        setAvatarRef={setAvatarRef}
        setCoverRef={setCoverRef}
        saving={saving}
        onClose={() => setEditOpen(false)}
        onSubmit={saveEdit}
      />
    </div>
  )
}

// ---- Thẻ thú cưng trong lưới ----
function PetCard({ pet, onOpen, onEdit, onDelete, onFollow }: { pet: PetT; onOpen: () => void; onEdit?: () => void; onDelete?: () => void; onFollow?: () => void }) {
  return (
    <div className="overflow-hidden rounded-2xl border bg-white shadow-sm transition hover:shadow-md">
      <button onClick={onOpen} className="block w-full text-left" aria-label={`Xem trang cá nhân của ${pet.name}`}>
        <div className="h-20 bg-gradient-to-r from-amber-400 via-orange-400 to-rose-400">
          {pet.coverImage && <img src={pet.coverImage} alt={`Ảnh bìa của ${pet.name}`} className="h-full w-full object-cover" />}
        </div>
        <div className="-mt-6 px-3 pb-3">
          <div className="flex items-end gap-2">
            <span className="rounded-full border-2 border-white bg-white">
              <Avatar name={pet.name} color={pet.avatarColor} size={48} img={pet.avatarImage} />
            </span>
            <div className="min-w-0 pb-1">
              <p className="truncate text-sm font-bold text-stone-800">{pet.name}</p>
              <p className="truncate text-[11px] text-stone-500">{pet.species}{pet.breed ? ` · ${pet.breed}` : ''}{pet.gender ? ` · ${pet.gender}` : ''}</p>
            </div>
          </div>
          {pet.bio && <p className="mt-1.5 line-clamp-2 text-xs text-stone-600">{pet.bio}</p>}
          <p className="mt-1.5 flex items-center gap-2 text-[11px] text-stone-500">
            <span className="flex items-center gap-1"><Heart className="h-3 w-3 text-rose-500" /> {pet.followers} người theo dõi</span>
            <span className="flex items-center gap-1"><Images className="h-3 w-3 text-stone-400" /> {pet.postCount} bài</span>
          </p>
        </div>
      </button>
      <div className="flex gap-1.5 border-t px-3 py-2">
        {pet.isOwner ? (
          <>
            <Button size="sm" variant="outline" className="h-7 flex-1 gap-1 text-[11px]" onClick={onEdit} aria-label={`Sửa thông tin của ${pet.name}`}>
              <Pencil className="h-3 w-3" /> Sửa thông tin
            </Button>
            <Button size="sm" variant="outline" className="h-7 w-7 px-0 text-rose-600 hover:bg-rose-50" onClick={onDelete} aria-label={`Xoá trang của ${pet.name}`} title="Xoá trang bé">
              <Trash2 className="h-3 w-3" />
            </Button>
          </>
        ) : (
          <>
            <Button size="sm" className="h-7 flex-1 gap-1 bg-emerald-600 text-[11px] hover:bg-emerald-700" onClick={onFollow} aria-label={`${pet.isFollowing ? 'Bỏ theo dõi' : 'Theo dõi'} ${pet.name}`}>
              {pet.isFollowing ? <><Check className="h-3 w-3" /> Đang theo dõi</> : <><Plus className="h-3 w-3" /> Theo dõi</>}
            </Button>
            <Button size="sm" variant="outline" className="h-7 flex-1 gap-1 text-[11px]" onClick={onOpen} aria-label={`Xem trang của ${pet.name}`}>
              <PawPrint className="h-3 w-3" /> Xem trang
            </Button>
          </>
        )}
      </div>
    </div>
  )
}

// ---- Dialog tạo/sửa thông tin bé ----
function PetFormDialog({ open, title, form, setForm, setAvatarRef, setCoverRef, saving, onClose, onSubmit }: {
  open: boolean
  title: string
  form: typeof emptyForm
  setForm: React.Dispatch<React.SetStateAction<typeof emptyForm>>
  setAvatarRef: (r: HTMLInputElement | null) => void
  setCoverRef: (r: HTMLInputElement | null) => void
  saving: boolean
  onClose: () => void
  onSubmit: () => void
}) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><PawPrint className="h-4.5 w-4.5 text-amber-600" /> {title}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1"><Label htmlFor="pet-name">Tên bé</Label><Input id="pet-name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="VD: Mực, Bông, Milu..." maxLength={40} /></div>
            <div className="space-y-1"><Label htmlFor="pet-species">Loài</Label>
              <Select value={form.species} onValueChange={(v) => setForm((f) => ({ ...f, species: v }))}>
                <SelectTrigger id="pet-species" aria-label="Chọn loài"><SelectValue /></SelectTrigger>
                <SelectContent>{SPECIES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1"><Label htmlFor="pet-breed">Giống loài</Label><Input id="pet-breed" value={form.breed} onChange={(e) => setForm((f) => ({ ...f, breed: e.target.value }))} placeholder="VD: Corgi, Alaskan..." maxLength={60} /></div>
            <div className="space-y-1"><Label htmlFor="pet-gender">Giới tính</Label>
              <Select value={form.gender || undefined} onValueChange={(v) => setForm((f) => ({ ...f, gender: v }))}>
                <SelectTrigger id="pet-gender" aria-label="Chọn giới tính bé"><SelectValue placeholder="Chọn" /></SelectTrigger>
                <SelectContent>{['Đực', 'Cái'].map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1"><Label htmlFor="pet-birthday">Ngày sinh</Label><Input id="pet-birthday" type="date" value={form.birthday} onChange={(e) => setForm((f) => ({ ...f, birthday: e.target.value }))} /></div>
          <div className="space-y-1"><Label htmlFor="pet-bio">Giới thiệu về bé</Label><Textarea id="pet-bio" value={form.bio} onChange={(e) => setForm((f) => ({ ...f, bio: e.target.value }))} rows={2} maxLength={300} placeholder="Bé thích ăn gì, chơi gì...?" /></div>
          <div className="flex gap-2">
            <label className="flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-medium text-stone-600 transition hover:bg-amber-50">
              <Camera className="h-3.5 w-3.5 text-amber-600" /> {form.avatarImage ? 'Đổi ảnh đại diện' : 'Ảnh đại diện'}
              <input ref={setAvatarRef} type="file" accept="image/*" className="hidden" onChange={(e) => { pickImageHandler(e, setForm, 'avatarImage'); e.target.value = '' }} />
            </label>
            <label className="flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-medium text-stone-600 transition hover:bg-amber-50">
              <Images className="h-3.5 w-3.5 text-teal-600" /> {form.coverImage ? 'Đổi ảnh bìa' : 'Ảnh bìa'}
              <input ref={setCoverRef} type="file" accept="image/*" className="hidden" onChange={(e) => { pickImageHandler(e, setForm, 'coverImage'); e.target.value = '' }} />
            </label>
          </div>
          <Button className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={saving || !form.name.trim()} onClick={onSubmit} aria-label="Lưu trang thú cưng">
            {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <PawPrint className="mr-1 h-4 w-4" />} Lưu trang cho bé
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

const pickImageHandler = async (e: React.ChangeEvent<HTMLInputElement>, setForm: React.Dispatch<React.SetStateAction<typeof emptyForm>>, kind: 'avatarImage' | 'coverImage') => {
  const file = e.target.files?.[0]
  if (!file) return
  if (file.size > 6_000_000) { toast.error('Ảnh quá lớn (tối đa ~6MB trước khi nén)'); return }
  try {
    const url = await compressImage(file, kind === 'avatarImage' ? 512 : 1280)
    setForm((f) => ({ ...f, [kind]: url }))
  } catch { toast.error('Không đọc được ảnh') }
}

// ---- TRANG CÁ NHÂN CỦA BÉ (kiểu fanpage) ----
function PetProfile({ profile, profileLoading, me, onBack, onEdit, onFollow, onRefreshProfile, onOpenProfile }: {
  profile: PetProfileT | null
  profileLoading: boolean
  me: VxUserInfo
  onBack: () => void
  onEdit: () => void
  onFollow: () => void
  onRefreshProfile: () => void
  onOpenProfile: (id: string) => void
}) {
  const [postText, setPostText] = useState('')
  const [postImgs, setPostImgs] = useState<string[]>([])
  const [posting, setPosting] = useState(false)
  const [imgRef, setImgRef] = useState<HTMLInputElement | null>(null)

  if (profileLoading || !profile) {
    return <div className="space-y-3"><Skeleton className="h-40 rounded-2xl" /><Skeleton className="h-64 rounded-2xl" /></div>
  }
  const { pet, posts } = profile
  const isOwner = pet.isOwner

  const submitPost = async () => {
    if (!postText.trim() && postImgs.length === 0) return
    setPosting(true)
    try {
      const res = await fetch(`/api/vx/pets/${pet.id}/posts`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: postText.trim(), images: postImgs }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không đăng được bài cho bé')
      toast.success(`Đã đăng lên trang của bé ${pet.name}`)
      setPostText(''); setPostImgs([])
      onRefreshProfile()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không đăng được bài cho bé')
    } finally { setPosting(false) }
  }

  const ageLine = pet.birthday ? ` · ${Math.max(0, Math.floor((Date.now() - new Date(pet.birthday).getTime()) / 31_557_600_000))} tuổi` : ''

  return (
    <div className="space-y-4">
      <button onClick={onBack} className="flex items-center gap-1 text-xs font-medium text-stone-500 hover:text-emerald-700" aria-label="Về danh sách thú cưng">
        <X className="h-3.5 w-3.5" /> Về danh sách bé
      </button>

      {/* Bìa + hồ sơ fanpage của bé */}
      <div className="overflow-hidden rounded-2xl border bg-white shadow-sm">
        <div className="relative h-36 bg-gradient-to-r from-amber-400 via-orange-400 to-rose-400 sm:h-44">
          {pet.coverImage && <img src={pet.coverImage} alt={`Ảnh bìa của ${pet.name}`} className="h-full w-full object-cover" />}
        </div>
        <div className="px-5 pb-5">
          <div className="-mt-12 flex flex-wrap items-end justify-between gap-3">
            <span className="rounded-full border-4 border-white bg-white shadow-sm">
              <Avatar name={pet.name} color={pet.avatarColor} size={92} img={pet.avatarImage} />
            </span>
            <div className="flex flex-wrap gap-2">
              {isOwner ? (
                <>
                  <Button variant="outline" onClick={onEdit} aria-label={`Sửa thông tin của ${pet.name}`}><Pencil className="mr-1 h-4 w-4" />Sửa thông tin bé</Button>
                </>
              ) : (
                <Button className={pet.isFollowing ? 'gap-1.5 bg-stone-200 text-stone-700 hover:bg-stone-300' : 'gap-1.5 bg-emerald-600 hover:bg-emerald-700'} onClick={onFollow} aria-label={`${pet.isFollowing ? 'Bỏ theo dõi' : 'Theo dõi'} ${pet.name}`}>
                  {pet.isFollowing ? <><Check className="mr-1 h-4 w-4" /> Đang theo dõi</> : <><Plus className="mr-1 h-4 w-4" /> Theo dõi bé</>}
                </Button>
              )}
            </div>
          </div>
          <div className="mt-3">
            <h1 className="flex flex-wrap items-center gap-2 text-2xl font-black">
              {pet.name}
              <Badge className="bg-amber-500 text-white hover:bg-amber-500"><PawPrint className="mr-1 inline h-3.5 w-3.5" />{pet.species}</Badge>
            </h1>
            <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-stone-500">
              {pet.breed && <span>{pet.breed}</span>}
              {pet.gender && <span className="flex items-center gap-1"><UserRound className="h-3.5 w-3.5" /> {pet.gender}</span>}
              {pet.birthday && <span className="flex items-center gap-1"><Cake className="h-3.5 w-3.5 text-rose-400" /> {new Date(pet.birthday).toLocaleDateString('vi-VN')}{ageLine}</span>}
              <span className="flex items-center gap-1"><Heart className="h-3.5 w-3.5 text-rose-500" /> {pet.followers} người theo dõi</span>
              <span className="flex items-center gap-1"><Images className="h-3.5 w-3.5 text-stone-400" /> {pet.postCount} bài viết</span>
            </p>
            <p className="mt-1.5 text-xs text-stone-500">
              Chủ trang:{' '}
              <button className="font-semibold text-emerald-700 hover:underline" onClick={() => onOpenProfile(pet.owner.id)} aria-label={`Xem trang cá nhân của ${pet.owner.fullName}`}>
                {pet.owner.fullName}
              </button>
            </p>
            {pet.bio && <p className="mt-2 rounded-lg bg-amber-50 p-2.5 text-sm text-stone-700">{pet.bio}</p>}
          </div>
        </div>
      </div>

      {/* Khung soạn bài cho bé (chỉ chủ) */}
      {isOwner && (
        <div className="rounded-2xl border bg-white p-3 shadow-sm">
          <div className="flex items-center gap-2.5">
            <Avatar name={pet.name} color={pet.avatarColor} size={40} img={pet.avatarImage} />
            <Textarea value={postText} onChange={(e) => setPostText(e.target.value)} rows={2} maxLength={1000} placeholder={`Đăng giúp bé ${pet.name} điều thú vị hôm nay...`} aria-label={`Soạn bài cho ${pet.name}`} className="flex-1 resize-none" />
          </div>
          {postImgs.length > 0 && (
            <div className="mt-2 grid grid-cols-3 gap-1.5">
              {postImgs.map((src, i) => (
                <div key={i} className="relative">
                  <img src={src} alt={`Ảnh ${i + 1}`} className="h-20 w-full rounded-lg border object-cover" />
                  <button onClick={() => setPostImgs((arr) => arr.filter((_, j) => j !== i))} className="absolute right-1 top-1 rounded-full bg-black/60 p-1 text-white" aria-label={`Bỏ ảnh ${i + 1}`}><X className="h-3 w-3" /></button>
                </div>
              ))}
            </div>
          )}
          <div className="mt-2 flex items-center justify-between gap-2 border-t pt-2">
            <label className="flex cursor-pointer items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-amber-700 transition hover:bg-amber-50" aria-label="Gắn ảnh cho bài của bé">
              <Images className="h-4 w-4" /> Ảnh của bé
              <input ref={setImgRef} type="file" accept="image/*" multiple className="hidden" onChange={async (e) => {
                const files = Array.from(e.target.files || []).slice(0, 6)
                for (const f of files) {
                  if (f.size > 6_000_000) { toast.error(`${f.name} quá lớn`); continue }
                  try {
                    const url = await compressImage(f, 1280)
                    setPostImgs((prev) => [...prev, url].slice(0, 6))
                  } catch { /* bỏ qua */ }
                }
                e.target.value = ''
              }} />
            </label>
            <Button className="bg-emerald-600 hover:bg-emerald-700" disabled={posting || (!postText.trim() && postImgs.length === 0)} onClick={submitPost} aria-label="Đăng bài cho bé">
              {posting ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Send className="mr-1 h-4 w-4" />} Đăng cho bé
            </Button>
          </div>
        </div>
      )}

      {/* Dòng thời gian của bé */}
      <div className="space-y-3">
        {posts.length === 0 && (
          <p className="rounded-xl border border-dashed bg-white p-10 text-center text-sm text-muted-foreground">
            Trang của bé {pet.name} chưa có bài viết nào {isOwner ? '— đăng bài đầu tiên cho bé nhé!' : '— ghé lại sau nhé!'}
          </p>
        )}
        {posts.map((post) => (
          <PetPostCard key={post.id} post={post} pet={pet} me={me} onChanged={onRefreshProfile} />
        ))}
      </div>
    </div>
  )
}

// ---- Thẻ bài viết của bé: tim + bình luận ----
function PetPostCard({ post, pet, me, onChanged }: { post: PetPostT; pet: PetT; me: VxUserInfo; onChanged: () => void }) {
  const [liked, setLiked] = useState(post.myLike)
  const [likes, setLikes] = useState(post.likes)
  const [comments, setComments] = useState(post.comments)
  const [showComments, setShowComments] = useState(false)
  const [commentText, setCommentText] = useState('')
  const [sending, setSending] = useState(false)

  const toggleLike = async () => {
    try {
      const res = await fetch(`/api/vx/pet-posts/${post.id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'like' }) })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      setLikes(d.likes); setLiked(d.myLike)
    } catch { toast.error('Không thả tim được') }
  }

  const sendComment = async () => {
    if (!commentText.trim()) return
    setSending(true)
    try {
      const res = await fetch(`/api/vx/pet-posts/${post.id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'comment', content: commentText.trim() }) })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      setComments((cs) => [...cs, d.comment])
      setCommentText('')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không gửi được bình luận')
    } finally { setSending(false) }
  }

  const deletePost = async () => {
    if (!window.confirm('Xoá bài viết này của bé?')) return
    try {
      const res = await fetch(`/api/vx/pet-posts/${post.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error()
      toast.success('Đã xoá bài viết')
      onChanged()
    } catch { toast.error('Không xoá được bài viết') }
  }

  return (
    <div className="rounded-2xl border bg-white shadow-sm">
      <div className="flex items-center gap-2.5 p-3">
        <span className="rounded-full border-2 border-amber-100"><Avatar name={pet.name} color={pet.avatarColor} size={40} img={pet.avatarImage} /></span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold">
            {pet.name} <span className="font-normal text-stone-400">· trang thú cưng</span>
          </p>
          <p className="text-[11px] text-stone-500">{timeAgo(post.createdAt)}{post.author.id !== pet.owner.id ? ` · đăng bởi ${post.author.fullName}` : ''}</p>
        </div>
        {pet.isOwner && (
          <button onClick={deletePost} className="rounded-full p-1.5 text-stone-400 transition hover:bg-rose-50 hover:text-rose-600" title="Xoá bài" aria-label="Xoá bài viết của bé">
            <Trash2 className="h-4 w-4" />
          </button>
        )}
      </div>
      {post.content && <p className="whitespace-pre-wrap px-3 pb-2 text-sm text-stone-800">{post.content}</p>}
      {post.images.length > 0 && (
        <div className={`grid gap-1 px-3 pb-2 ${post.images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
          {post.images.map((src, i) => (
            <img key={i} src={src} alt={`Ảnh ${i + 1} của ${pet.name}`} className="w-full rounded-lg border object-cover" style={{ maxHeight: 320 }} />
          ))}
        </div>
      )}
      <div className="flex items-center gap-1 border-t px-2 py-1.5">
        <button onClick={toggleLike} className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-1.5 text-sm font-medium transition ${liked ? 'text-rose-600' : 'text-stone-500 hover:bg-stone-50'}`} aria-label={liked ? 'Bỏ tim' : 'Thả tim'}>
          <Heart className={`h-4 w-4 ${liked ? 'fill-rose-600' : ''}`} /> {likes > 0 ? likes : 'Thả tim'}
        </button>
        <button onClick={() => setShowComments((v) => !v)} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg py-1.5 text-sm font-medium text-stone-500 transition hover:bg-stone-50" aria-label="Xem bình luận">
          <MessageCircle className="h-4 w-4" /> {comments.length > 0 ? `${comments.length} bình luận` : 'Bình luận'}
        </button>
      </div>
      {showComments && (
        <div className="space-y-2 border-t bg-stone-50 p-3">
          {comments.map((c) => (
            <div key={c.id} className="flex items-start gap-2">
              <Avatar name={c.user.fullName} color={c.user.avatarColor} size={28} img={c.user.avatarImage} />
              <div className="min-w-0 flex-1 rounded-xl bg-white px-2.5 py-1.5 shadow-sm">
                <p className="text-xs font-semibold text-stone-700">{c.user.fullName}</p>
                <p className="whitespace-pre-wrap text-[13px] text-stone-700">{c.content}</p>
              </div>
            </div>
          ))}
          {comments.length === 0 && <p className="text-center text-xs text-stone-400">Chưa có bình luận — khen bé một câu nào!</p>}
          <div className="flex items-center gap-2 pt-1">
            <Avatar name="Tôi" color={me.avatarColor} size={28} img={me.avatarImage} />
            <Input value={commentText} onChange={(e) => setCommentText(e.target.value)} placeholder={`Khen bé ${pet.name} một câu...`} maxLength={500} className="h-9 flex-1 rounded-full" aria-label="Bình luận bài viết của bé" onKeyDown={(e) => { if (e.key === 'Enter' && !e.nativeEvent.isComposing) sendComment() }} />
            <Button size="sm" className="h-9 rounded-full bg-emerald-600 hover:bg-emerald-700" disabled={sending || !commentText.trim()} onClick={sendComment} aria-label="Gửi bình luận">
              {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
