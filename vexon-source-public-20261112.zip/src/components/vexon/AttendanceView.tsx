'use client'

import { useCallback, useState } from 'react'
import type { VxUserInfo } from '@/components/vexon/AuthView'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useToast } from '@/hooks/use-toast'
import { CalendarCheck, LogIn, LogOut, Clock, Loader2, Users, AlertCircle } from 'lucide-react'

interface AttendanceRecord {
  id: string
  workDate: string
  checkIn: string | null
  checkOut: string | null
  status: string
  lateMinutes: number
}

interface TodayBoardUser {
  id: string
  fullName: string
  username: string
  role: string
  avatarColor: string
  today: AttendanceRecord | null
  monthStats: { present: number; late: number; totalDays: number }
}

const ROLE_LABEL: Record<string, string> = { admin: 'Quản trị', manager: 'Quản lý', employee: 'Nhân viên' }

export default function AttendanceView({ me }: { me: VxUserInfo }) {
  return (
    <div className="space-y-6">
      <SelfAttendance me={me} />
      {['admin', 'manager'].includes(me.role) && <CompanyBoard me={me} />}
    </div>
  )
}

// ===== Điểm danh cá nhân =====
function SelfAttendance({ me }: { me: VxUserInfo }) {
  const [today, setToday] = useState<AttendanceRecord | null>(null)
  const [history, setHistory] = useState<AttendanceRecord[]>([])
  const [date, setDate] = useState('')
  const [busy, setBusy] = useState(false)
  const { toast } = useToast()

  const load = useCallback(() => {
    fetch('/api/vx/attendance?scope=me')
      .then((r) => r.json())
      .then((d) => {
        if (d.today !== undefined) setToday(d.today)
        if (Array.isArray(d.history)) setHistory(d.history)
        if (d.date) setDate(d.date)
      })
      .catch(() => {})
  }, [])

  useDeferredLoad(load, [load])

  const act = async (action: 'checkin' | 'checkout') => {
    setBusy(true)
    try {
      const res = await fetch('/api/vx/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: data.message })
      load()
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không điểm danh được', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  const monthRecords = history.filter((h) => h.workDate.startsWith(date.slice(0, 7)))
  const lateCount = monthRecords.filter((h) => h.status === 'late').length

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <h2 className="flex items-center gap-2 font-bold">
        <CalendarCheck className="h-5 w-5 text-emerald-600" />
        Điểm danh của tôi
      </h2>

      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col items-center gap-4 text-center sm:flex-row sm:text-left">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full text-xl font-bold text-white" style={{ backgroundColor: me.avatarColor }}>
              {me.fullName[0]}
            </div>
            <div className="flex-1">
              <p className="font-bold">{me.fullName}</p>
              <p className="text-sm text-muted-foreground">
                Hôm nay: <b className="text-foreground">{date && new Date(date).toLocaleDateString('vi-VN', { weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric' })}</b>
                {', '}Ca làm bắt đầu <b className="text-foreground">08:00</b>
              </p>
            </div>
            <div className="flex gap-2">
              <Button className="bg-emerald-600 hover:bg-emerald-700" disabled={busy || !!today?.checkIn} onClick={() => act('checkin')}>
                {busy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <LogIn className="mr-1 h-4 w-4" />}
                {today?.checkIn ? `Đã vào ${today.checkIn}` : 'Điểm danh vào'}
              </Button>
              <Button variant="outline" disabled={busy || !today?.checkIn || !!today?.checkOut} onClick={() => act('checkout')}>
                <LogOut className="mr-1 h-4 w-4" />
                {today?.checkOut ? `Đã ra ${today.checkOut}` : 'Điểm danh ra'}
              </Button>
            </div>
          </div>
          {today?.status === 'late' && (
            <p className="mt-3 flex items-center justify-center gap-1.5 rounded-lg bg-amber-50 py-2 text-sm text-amber-800 sm:justify-start">
              <AlertCircle className="h-4 w-4" />
              Hôm nay bạn vào muộn {today.lateMinutes} phút so với giờ ca
            </p>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-3 gap-3">
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-emerald-700">{monthRecords.length}</p>
            <p className="text-xs text-muted-foreground">Ngày làm tháng này</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-amber-600">{lateCount}</p>
            <p className="text-xs text-muted-foreground">Lần vào muộn</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold">
              {monthRecords.reduce((total, h) => {
                if (!h.checkIn || !h.checkOut) return total
                const inMin = Number(h.checkIn.slice(0, 2)) * 60 + Number(h.checkIn.slice(3))
                const outMin = Number(h.checkOut.slice(0, 2)) * 60 + Number(h.checkOut.slice(3))
                return total + Math.max(0, Math.round((outMin - inMin) / 30) / 2)
              }, 0)}
            </p>
            <p className="text-xs text-muted-foreground">Giờ làm (ước tính)</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Clock className="h-4 w-4" />
            Lịch sử điểm danh
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ngày</TableHead>
                <TableHead className="text-center">Vào</TableHead>
                <TableHead className="text-center">Ra</TableHead>
                <TableHead className="text-center">Trạng thái</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {history.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="py-8 text-center text-muted-foreground">Chưa có dữ liệu, điểm danh ngay hôm nay!</TableCell>
                </TableRow>
              ) : (
                history.map((h) => (
                  <TableRow key={h.id}>
                    <TableCell className="font-medium">
                      {new Date(h.workDate).toLocaleDateString('vi-VN', { weekday: 'short', day: '2-digit', month: '2-digit' })}
                    </TableCell>
                    <TableCell className="text-center">{h.checkIn || 'Chưa có'}</TableCell>
                    <TableCell className="text-center">{h.checkOut || 'Chưa có'}</TableCell>
                    <TableCell className="text-center">
                      <Badge variant="secondary" className={h.status === 'late' ? 'bg-amber-100 text-amber-800 hover:bg-amber-100' : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100'}>
                        {h.status === 'late' ? `Muộn ${h.lateMinutes}'` : 'Đúng giờ'}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// ===== Bảng chấm công toàn công ty (admin/manager) =====
function CompanyBoard({ me }: { me: VxUserInfo }) {
  const [users, setUsers] = useState<TodayBoardUser[]>([])
  const [date, setDate] = useState('')
  const [loading, setLoading] = useState(true)

  const load = useCallback(() => {
    setLoading(true)
    fetch('/api/vx/attendance?scope=today')
      .then((r) => r.json())
      .then((d) => {
        if (Array.isArray(d.users)) setUsers(d.users)
        if (d.date) setDate(d.date)
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(load, [load])

  return (
    <div className="mx-auto max-w-3xl space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-bold">
          <Users className="h-5 w-5 text-cyan-600" />
          Chấm công công ty {date && <span className="text-sm font-normal text-muted-foreground">({new Date(date).toLocaleDateString('vi-VN')})</span>}
        </h2>
        <Badge variant="secondary" className="bg-cyan-100 text-cyan-800 hover:bg-cyan-100">
          {me.role === 'admin' ? 'Quản trị' : 'Quản lý'}, {users.length} nhân sự
        </Badge>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nhân sự</TableHead>
                <TableHead className="text-center">Vào hôm nay</TableHead>
                <TableHead className="text-center">Ra hôm nay</TableHead>
                <TableHead className="text-center">Tháng này</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={4} className="py-8 text-center text-muted-foreground">Đang tải...</TableCell>
                </TableRow>
              ) : (
                users.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell>
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold text-white" style={{ backgroundColor: u.avatarColor }}>
                          {u.fullName[0]}
                        </div>
                        <div>
                          <p className="text-sm font-semibold">{u.fullName} {u.id && <span className="text-xs text-muted-foreground">({ROLE_LABEL[u.role] || u.role})</span>}</p>
                          <p className="text-xs text-muted-foreground">@{u.username}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      {u.today?.checkIn ? (
                        <Badge variant="secondary" className={u.today.status === 'late' ? 'bg-amber-100 text-amber-800 hover:bg-amber-100' : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100'}>
                          {u.today.checkIn} {u.today.status === 'late' ? `(muộn ${u.today.lateMinutes}')` : ''}
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="bg-red-100 text-red-700 hover:bg-red-100">Chưa vào</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-center">{u.today?.checkOut || 'Chưa có'}</TableCell>
                    <TableCell className="text-center text-xs text-muted-foreground">
                      <span className="font-semibold text-emerald-700">{u.monthStats.present}</span> đúng,{' '}
                      <span className="font-semibold text-amber-600">{u.monthStats.late}</span> muộn
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
