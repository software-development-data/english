'use client'

import type { VxUserInfo } from '@/components/vexon/AuthView'
import { Avatar } from '@/components/vexon/shared'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import {
  Search, X, Clock, UserPlus, MessageCircle, Check, ChevronDown, ChevronRight, ChevronUp,
  SlidersHorizontal, MapPin, Sparkles, CircleDot, Building2, Star, Users, Navigation, MoveVertical, Weight,
  Crosshair, Loader2, RotateCcw, CheckCheck,
  Newspaper, Video, CalendarCheck2, Wallet, Flag, PawPrint,
} from 'lucide-react'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Button } from '@/components/ui/button'
import { PROVINCES_34, CITY_LABEL_ALL } from '@/lib/vx-provinces'
import { fmtUsdFromXu } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'
import { Slider } from '@/components/ui/slider'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useToast } from '@/hooks/use-toast'

type View = 'feed' | 'video' | 'live' | 'messages' | 'groups' | 'friends' | 'attendance' | 'analysis' | 'shop' | 'nearby' | 'jobs' | 'companies' | 'wallet' | 'profile' | 'tools' | 'ops' | 'pages' | 'pets' | 'home'

interface CompanyLite { id: string; name: string; industry: string; size: string; address: string | null; ratingAvg: number; ratingCount: number; jobCount: number }

// LỐI TẮT NHANH ở trang chủ đỉnh cao — 7 phân hệ dùng nhiều nhất (màu emerald/teal chủ đạo + điểm nhấn)
const QUICK_ACTIONS: { key: string; label: string; icon: React.ReactNode; grad: string }[] = [
  { key: 'feed', label: 'Bảng tin', icon: <Newspaper className="h-5 w-5" />, grad: 'from-emerald-500 to-teal-600' },
  { key: 'messages', label: 'Tin nhắn', icon: <MessageCircle className="h-5 w-5" />, grad: 'from-sky-500 to-cyan-600' },
  { key: 'video', label: 'Video', icon: <Video className="h-5 w-5" />, grad: 'from-rose-500 to-pink-600' },
  { key: 'attendance', label: 'Điểm danh', icon: <CalendarCheck2 className="h-5 w-5" />, grad: 'from-teal-500 to-emerald-600' },
  { key: 'wallet', label: 'Ví tiền', icon: <Wallet className="h-5 w-5" />, grad: 'from-amber-500 to-orange-600' },
  { key: 'pages', label: 'Trang', icon: <Flag className="h-5 w-5" />, grad: 'from-violet-500 to-purple-600' },
  { key: 'pets', label: 'Thú cưng', icon: <PawPrint className="h-5 w-5" />, grad: 'from-amber-400 to-orange-500' },
]

interface SearchUser {
  id: string
  username: string
  fullName: string
  avatarColor: string
  avatarImage: string | null
  bio: string | null
  accountType: string
  age: number | null
  province: string | null
  online: boolean
  activity: string
  activityKey: 'online' | 'recent' | 'today' | 'old'
  friendStatus: 'none' | 'accepted' | 'pending_sent' | 'pending_received'
  friendshipId: string | null
  distanceKm?: number | null
}

interface RecentItem {
  id: string
  fullName: string
  avatarColor: string
  avatarImage: string | null
  ts: number
}


const RECENT_KEY = 'vx-recent-searches'

// Số thẻ người hiển thị mặc định trên trang chủ trước khi bấm "Xem thêm" (3 hàng lưới 3 cột)
const HOME_PEOPLE_PREVIEW = 9

// Độ tuổi lọc bằng slider — kéo từ 18 đến tối đa 99 tuổi ([18, 99] = Mọi độ tuổi)
const AGE_MIN = 18
const AGE_MAX = 99
const ageLabelOf = (r: [number, number]) => (r[0] <= AGE_MIN && r[1] >= AGE_MAX ? 'Mọi độ tuổi' : `${r[0]}-${r[1]} tuổi`)

// Chiều cao / cân nặng lọc bằng 2 thanh kéo NẰM CÙNG MỘT HÀNG (140–200 cm, 40–120 kg — kéo đủ biên = mọi chiều cao/cân nặng)
const HEIGHT_MIN = 140
const HEIGHT_MAX = 200
const WEIGHT_MIN = 40
const WEIGHT_MAX = 120
const heightLabelOf = (r: [number, number]) => (r[0] <= HEIGHT_MIN && r[1] >= HEIGHT_MAX ? 'Mọi chiều cao' : `${r[0]}–${r[1]} cm`)
const weightLabelOf = (r: [number, number]) => (r[0] <= WEIGHT_MIN && r[1] >= WEIGHT_MAX ? 'Mọi cân nặng' : `${r[0]}–${r[1]} kg`)

// Khoảng cách hiển thị ngắn gọn (130m, 1.2km, 609km) — ≥10km làm tròn nguyên cho đỡ số lẻ
const distText = (km: number | null | undefined) =>
  km == null ? '' : km < 1 ? `${Math.round(km * 1000)}m` : km < 10 ? `${km}km` : `${Math.round(km)}km`

// Nhãn khoảng cách gọn cho badge/bong bóng kéo (500 m, 1.5 km)
const kmLabel = (km: number) => (km < 1 ? `${Math.round(km * 1000)} m` : `${km} km`)

type FilterKey = 'all' | 'near' | 'online' | 'new'

// Bộ lọc đúng yêu cầu: Tất cả (tổng hợp mọi người) - Gần đây - Online (đang online hoặc offline trong 30 phút) - Mới tham gia
const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'all', label: 'Tất cả' },
  { key: 'near', label: 'Gần đây' },
  { key: 'online', label: 'Online' },
  { key: 'new', label: 'Mới tham gia' },
]

function loadRecent(): RecentItem[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = localStorage.getItem(RECENT_KEY)
    const arr = raw ? (JSON.parse(raw) as RecentItem[]) : []
    return Array.isArray(arr) ? arr.slice(0, 12) : []
  } catch {
    return []
  }
}

export default function HomeView({ me, onGo, onMessage }: { me: VxUserInfo; onGo: (v: View) => void; onMessage?: (userId: string) => void }) {
  const { toast } = useToast()
  // Tỷ giá USD/VND thực tế (live) — chip ví tiền trên hero quy theo giá hiện nay
  const rate = useUsdRate()
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<FilterKey>('all')
  const [ageRange, setAgeRange] = useState<[number, number]>([AGE_MIN, AGE_MAX])
  const [heightRange, setHeightRange] = useState<[number, number]>([HEIGHT_MIN, HEIGHT_MAX])
  const [weightRange, setWeightRange] = useState<[number, number]>([WEIGHT_MIN, WEIGHT_MAX])
  const [province, setProvince] = useState('')
  const [maxKm, setMaxKm] = useState(0) // 0 = mọi khoảng cách
  const [results, setResults] = useState<SearchUser[]>([])
  const [loading, setLoading] = useState(false)
  const [regionOpen, setRegionOpen] = useState(false) // popover chọn khu vực trỏ xuống dưới nút
  const [regionQ, setRegionQ] = useState('')
  // Tìm kiếm gần đây chỉ có ở client — khởi tạo lười sau mount đầu tiên
  const [recent, setRecent] = useState<RecentItem[]>([])
  useEffect(() => {
    const id = requestAnimationFrame(() => { setRecent(loadRecent()) })
    return () => cancelAnimationFrame(id)
  }, [])
  const [companies, setCompanies] = useState<CompanyLite[]>([])
  const [menuOpen, setMenuOpen] = useState(false) // MENU bộ lọc sổ ra phía tay phải (drawer)
  const [searchFocus, setSearchFocus] = useState(false) // Bấm vào ô tìm kiếm mới sổ Tìm kiếm gần đây (kiểu Zalo)
  const inputRef = useRef<HTMLInputElement>(null)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // HERO đỉnh cao: chào hỏi theo giờ + ngày hôm nay (tính sau mount để tránh lệch hydrate)
  const [heroClock, setHeroClock] = useState<{ greeting: string; today: string }>({ greeting: '', today: '' })
  useEffect(() => {
    const h = new Date().getHours()
    const greeting = h < 11 ? 'Chào buổi sáng' : h < 13 ? 'Chào buổi trưa' : h < 18 ? 'Chào buổi chiều' : 'Chào buổi tối'
    const today = new Date().toLocaleDateString('vi-VN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
    setHeroClock({ greeting, today: today.charAt(0).toUpperCase() + today.slice(1) })
  }, [])

  // Đang bật lọc tuổi/chiều cao/cân nặng khác mặc định hay không
  const ageChanged = ageRange[0] > AGE_MIN || ageRange[1] < AGE_MAX
  const heightChanged = heightRange[0] > HEIGHT_MIN || heightRange[1] < HEIGHT_MAX
  const weightChanged = weightRange[0] > WEIGHT_MIN || weightRange[1] < WEIGHT_MAX
  const openMenu = () => setMenuOpen(true)

  const resetFilters = useCallback(() => {
    setFilter('all'); setAgeRange([AGE_MIN, AGE_MAX]); setHeightRange([HEIGHT_MIN, HEIGHT_MAX]); setWeightRange([WEIGHT_MIN, WEIGHT_MAX]); setProvince(''); setMaxKm(0); setQuery('')
  }, [])

  // Tìm kiếm trực tiếp (debounce 220ms — AJAX cập nhật danh sách người phía dưới)
  const runSearch = useCallback((q: string, f: FilterKey, ar: [number, number], pv: string, km: number, hr: [number, number], wr: [number, number]) => {
    const params = new URLSearchParams()
    if (q) params.set('q', q)
    params.set('filter', f)
    if (ar[0] > AGE_MIN) params.set('ageMin', String(ar[0]))
    if (ar[1] < AGE_MAX) params.set('ageMax', String(ar[1]))
    if (hr[0] > HEIGHT_MIN) params.set('hMin', String(hr[0]))
    if (hr[1] < HEIGHT_MAX) params.set('hMax', String(hr[1]))
    if (wr[0] > WEIGHT_MIN) params.set('wMin', String(wr[0]))
    if (wr[1] < WEIGHT_MAX) params.set('wMax', String(wr[1]))
    if (pv) params.set('province', pv)
    if (km > 0) params.set('maxKm', String(km))
    params.set('limit', '40')
    setLoading(true)
    fetch(`/api/vx/users/search?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => setResults(Array.isArray(d.users) ? d.users : []))
      .catch(() => setResults([]))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    if (timerRef.current) clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => runSearch(query, filter, ageRange, province, maxKm, heightRange, weightRange), query ? 220 : 120)
    return () => { if (timerRef.current) clearTimeout(timerRef.current) }
  }, [query, filter, ageRange, province, maxKm, heightRange, weightRange, runSearch])

  // Công ty đã tham gia ứng dụng — dải ngang cuối trang chủ
  useDeferredLoad(() => {
    fetch('/api/vx/companies')
      .then((r) => r.json())
      .then((d) => setCompanies(Array.isArray(d.companies) ? d.companies.slice(0, 10) : []))
      .catch(() => {})
  }, [])

  const saveRecent = useCallback((u: SearchUser | RecentItem) => {
    setRecent((prev) => {
      const item: RecentItem = { id: u.id, fullName: u.fullName, avatarColor: u.avatarColor, avatarImage: u.avatarImage, ts: Date.now() }
      const next = [item, ...prev.filter((x) => x.id !== u.id)].slice(0, 12)
      try { localStorage.setItem(RECENT_KEY, JSON.stringify(next)) } catch {}
      return next
    })
  }, [])

  const removeRecent = useCallback((id: string) => {
    setRecent((prev) => {
      const next = prev.filter((x) => x.id !== id)
      try { localStorage.setItem(RECENT_KEY, JSON.stringify(next)) } catch {}
      return next
    })
  }, [])

  const clearRecent = useCallback(() => {
    setRecent([])
    try { localStorage.removeItem(RECENT_KEY) } catch {}
  }, [])

  const friendAction = useCallback(async (u: SearchUser, refresh: () => void) => {
    if (u.friendStatus === 'accepted') { onMessage?.(u.id); return }
    if (u.friendStatus === 'pending_received' && u.friendshipId) {
      const res = await fetch('/api/vx/friends', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'accept', friendshipId: u.friendshipId }) })
      if (res.ok) {
        toast({ title: `Đã chấp nhận lời mời từ ${u.fullName}` })
        refresh()
      }
      return
    }
    if (u.friendStatus === 'none') {
      const res = await fetch('/api/vx/friends', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'request', userId: u.id }) })
      if (res.ok) {
        toast({ title: `Đã gửi lời mời kết bạn tới ${u.fullName}` })
        setResults((rs) => rs.map((x) => (x.id === u.id ? { ...x, friendStatus: 'pending_sent' as const } : x)))
      } else {
        const d = await res.json().catch(() => ({}))
        toast({ title: d.error || 'Không gửi được lời mời', variant: 'destructive' })
      }
    }
  }, [onMessage, toast])

  const refreshNow = useCallback(() => runSearch(query, filter, ageRange, province, maxKm, heightRange, weightRange), [runSearch, query, filter, ageRange, province, maxKm, heightRange, weightRange])

  // Định vị GPS — cập nhật vị trí thật rồi bỏ lọc tỉnh (khoảng cách tính từ GPS)
  const useMyLocation = useCallback(() => {
    if (!('geolocation' in navigator)) {
      toast({ title: 'Trình duyệt không hỗ trợ định vị', variant: 'destructive' })
      return
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        fetch('/api/vx/nearby', {
          method: 'PATCH', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
        }).then(() => {
          toast({ title: 'Đã lấy vị trí thực của bạn, lọc khoảng cách theo GPS' })
          setRegionOpen(false)
        }).catch(() => {})
      },
      () => toast({ title: 'Không lấy được GPS, thử lại hoặc chọn tỉnh thành', variant: 'destructive' }),
      { enableHighAccuracy: true, timeout: 10000 },
    )
  }, [toast])

  // Thả thanh khoảng cách mà chưa có GPS đã lưu — nhắc bật định vị ngay để lọc theo m/km
  const onKmCommit = useCallback((km: number) => {
    if (km <= 0) return
    fetch('/api/vx/nearby')
      .then((r) => r.json())
      .then((d) => {
        if (!d.me?.hasLocation) {
          toast({ title: 'Bật định vị để lọc theo khoảng cách m/km' })
          useMyLocation()
        }
      })
      .catch(() => {})
  }, [toast, useMyLocation])

  const filtersActive = query.trim().length > 0 || filter !== 'all' || ageChanged || heightChanged || weightChanged || province !== '' || maxKm > 0

  // Danh sách người thu gọn còn 9 thẻ khi không lọc — bấm "Xem thêm" mới thấy hết (đang lọc/tìm thì hiện đủ)
  const [showAllPeople, setShowAllPeople] = useState(false)
  const peopleCollapsed = !filtersActive && results.length > HOME_PEOPLE_PREVIEW
  const peopleShown = loading && results.length === 0
    ? Array.from({ length: 6 })
    : peopleCollapsed && !showAllPeople
      ? results.slice(0, HOME_PEOPLE_PREVIEW)
      : results

  // Tiêu đề danh sách người phía dưới — đổi trực tiếp theo bộ lọc đang chọn
  const gridTitle = useMemo(() => {
    if (query.trim()) return { icon: <Search className="h-4 w-4 text-emerald-600" />, text: `Kết quả cho "${query.trim()}"` }
    if (filter === 'near') return { icon: <MapPin className="h-4 w-4 text-rose-500" />, text: 'Người gần đây' }
    if (filter === 'online') return { icon: <CircleDot className="h-4 w-4 text-emerald-500" />, text: 'Người online, hoạt động trong 30 phút' }
    if (filter === 'new') return { icon: <UserPlus className="h-4 w-4 text-amber-500" />, text: 'Mới tham gia' }
    return { icon: <Sparkles className="h-4 w-4 text-amber-500" />, text: 'Tất cả mọi người' }
  }, [query, filter])

  const filterSummary = useMemo(() => {
    const parts: string[] = []
    if (query.trim()) parts.push(`"${query.trim()}"`)
    if (filter !== 'all') parts.push(FILTERS.find((f) => f.key === filter)?.label || '')
    if (ageChanged) parts.push(ageLabelOf(ageRange))
    if (heightChanged) parts.push(heightLabelOf(heightRange))
    if (weightChanged) parts.push(weightLabelOf(weightRange))
    if (maxKm > 0) parts.push(`tối đa ${kmLabel(maxKm)}`)
    if (province) parts.push(province)
    return parts.length ? parts.join(', ') : 'Tất cả mọi người'
  }, [query, filter, ageChanged, ageRange, heightChanged, heightRange, weightChanged, weightRange, maxKm, province])

  const provinceList = useMemo(() => {
    const kw = regionQ.trim().toLowerCase()
    return kw ? PROVINCES_34.filter((p) => p.toLowerCase().includes(kw)) : PROVINCES_34
  }, [regionQ])

  const openProfile = (id: string) => { window.dispatchEvent(new CustomEvent('vx-open-profile', { detail: { userId: id } })) }

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      {/* HERO ĐỈNH CAO — chào hỏi theo giờ + số dư xu + hành động nhanh (nâng cấp giao diện trang chủ) */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-700 via-teal-600 to-cyan-700 p-5 shadow-xl shadow-emerald-900/15">
        {/* Hoạ tiết cao cấp: vòng tròn đồng tâm + chấm bi + quầng sáng mờ */}
        <div className="pointer-events-none absolute -right-16 -top-20 h-56 w-56">
          <span className="absolute inset-0 rounded-full border border-white/15" />
          <span className="absolute inset-6 rounded-full border border-white/15" />
          <span className="absolute inset-12 rounded-full border border-white/10" />
          <span className="absolute inset-[72px] rounded-full bg-white/10" />
        </div>
        <div className="pointer-events-none absolute -bottom-20 -left-10 h-48 w-48 rounded-full bg-teal-300/20 blur-2xl" />
        <div className="pointer-events-none absolute right-28 top-8 h-24 w-24 rounded-full bg-cyan-300/25 blur-xl" />
        <div className="pointer-events-none absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.18) 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
        <div className="relative">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-white/25 bg-white/15 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-white backdrop-blur">
              <Sparkles className="h-3.5 w-3.5" /> {heroClock.today || 'Vexon — Super app công ty'}
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-200/40 bg-amber-400/25 px-3.5 py-1.5 text-sm font-bold text-white backdrop-blur" title={`Số dư ví tiền (USD) của bạn — tỷ giá 1$ = ${rate.toLocaleString('vi-VN')}đ`}>
              <Wallet className="h-4 w-4 text-amber-300" /> {fmtUsdFromXu(me.coins ?? 0, rate)}
            </span>
          </div>
          <h1 className="mt-3 text-2xl font-black leading-tight text-white sm:text-[28px]">
            {heroClock.greeting || 'Chào mừng trở lại'},{' '}
            <span className="bg-gradient-to-r from-amber-200 to-yellow-100 bg-clip-text text-transparent">{me.fullName}</span>!
          </h1>
          <p className="mt-1 text-sm text-white/80">
            <span className="font-semibold text-white">{me.title || 'Nhân viên'} · {me.companyName || me.department || 'Vexon'}</span> — chúc bạn một ngày hiệu quả
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button size="sm" className="border border-white/30 bg-white text-emerald-800 shadow-md hover:bg-emerald-50" onClick={() => onGo('feed')} aria-label="Mở Bảng tin">
              <Newspaper className="mr-1 h-4 w-4" /> Mở Bảng tin
            </Button>
            <Button size="sm" className="border border-white/30 bg-white/15 text-white backdrop-blur hover:bg-white/25" onClick={() => onGo('attendance')} aria-label="Điểm danh">
              <CalendarCheck2 className="mr-1 h-4 w-4" /> Điểm danh
            </Button>
            <Button size="sm" className="border border-white/30 bg-white/15 text-white backdrop-blur hover:bg-white/25" onClick={() => onGo('wallet')} aria-label="Ví tiền">
              <Wallet className="mr-1 h-4 w-4" /> Ví tiền
            </Button>
          </div>
        </div>
      </div>

      {/* LỐI TẮT NHANH — 7 phân hệ dùng nhiều nhất (hàng lẻ tự căn giữa cho cân đối) */}
      <div className="flex flex-wrap justify-center gap-2.5">
        {QUICK_ACTIONS.map((a) => (
          <button key={a.key} onClick={() => onGo(a.key as View)} className="group flex w-[calc(25%-7.5px)] flex-col items-center gap-2 rounded-2xl border border-stone-200/80 bg-white p-3.5 shadow-sm transition-all hover:-translate-y-1 hover:border-emerald-300 hover:shadow-lg hover:shadow-emerald-600/10" aria-label={a.label}>
            <span className={`flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br text-white shadow-md transition-transform group-hover:scale-110 ${a.grad}`}>
              {a.icon}
            </span>
            <span className="text-[11px] font-bold text-stone-700">{a.label}</span>
          </button>
        ))}
      </div>

      {/* Ô tìm kiếm lớn kiểu Zalo: bấm vào mới sổ Tìm kiếm gần đây ngay dưới ô */}
      <div className="sticky top-[60px] z-30 -mx-1 border-b border-stone-200/70 bg-stone-100/95 px-1 pb-2.5 pt-1.5 backdrop-blur">
        <div
          className="relative"
          onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setSearchFocus(false) }}
        >
          <div className="flex items-center gap-2.5 rounded-full border border-stone-200 bg-white px-4 shadow-md shadow-stone-900/5 transition-all focus-within:border-emerald-400 focus-within:ring-2 focus-within:ring-emerald-100">
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
              <Search className="h-4 w-4" />
            </span>
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => setSearchFocus(true)}
              placeholder="Tìm bạn bè khắp Việt Nam..."
              aria-label="Tìm kiếm bạn bè trên Vexon"
              className="h-12 flex-1 bg-transparent text-[15px] outline-none placeholder:text-stone-400"
            />
            {filtersActive && (
              <button onClick={resetFilters} aria-label="Xoá tìm kiếm" className="rounded-full p-1.5 text-stone-400 hover:bg-stone-100 hover:text-stone-600">
                <X className="h-4.5 w-4.5" />
              </button>
            )}
          </div>
          {/* Bảng Tìm kiếm gần đây — chỉ hiện khi đang bấm vào ô tìm kiếm và chưa gõ gì (kiểu Zalo) */}
          {searchFocus && query.trim() === '' && recent.length > 0 && (
            <div className="absolute left-0 right-0 top-[calc(100%+4px)] overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-xl">
              <div className="flex items-center justify-between border-b border-stone-100 px-4 py-2.5">
                <span className="flex items-center gap-1.5 text-[13px] font-bold text-stone-700"><Clock className="h-3.5 w-3.5 text-stone-400" /> Tìm kiếm gần đây</span>
                <button onClick={clearRecent} className="text-xs font-semibold text-emerald-700 hover:underline">Xoá tất cả</button>
              </div>
              {recent.map((r) => (
                <div key={r.id} className="flex items-center gap-3 border-b border-stone-100 px-3 py-2 last:border-0 hover:bg-stone-50">
                  <button
                    onClick={() => { setSearchFocus(false); inputRef.current?.blur(); openProfile(r.id) }}
                    onMouseDown={(e) => e.preventDefault()}
                    className="flex min-w-0 flex-1 items-center gap-2.5 text-left"
                    aria-label={`Xem hồ sơ ${r.fullName} trong tìm kiếm gần đây`}
                  >
                    <Avatar name={r.fullName} color={r.avatarColor} size={36} img={r.avatarImage} />
                    <span className="truncate text-sm font-semibold text-stone-800">{r.fullName}</span>
                  </button>
                  <button
                    onClick={() => removeRecent(r.id)}
                    onMouseDown={(e) => e.preventDefault()}
                    aria-label={`Xoá ${r.fullName} khỏi tìm kiếm gần đây`}
                    className="rounded-full p-1.5 text-stone-400 hover:bg-stone-100 hover:text-stone-600"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Hàng tab nhanh + bộ lọc: 3 tab Gần đây / Online / Mới tham gia bên trái, Khu vực + Bộ lọc bên TAY PHẢI */}
      <div className="flex items-center gap-2">
        {/* 3 tab lọc nhanh — bấm chọn, bấm lần nữa để bỏ lọc xem tất cả mọi người */}
        <div role="tablist" aria-label="Tab lọc nhanh danh sách người" className="flex min-w-0 flex-1 items-center gap-1.5 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {FILTERS.filter((f) => f.key !== 'all').map((f) => {
            const active = filter === f.key
            const Icon = f.key === 'near' ? MapPin : f.key === 'online' ? CircleDot : UserPlus
            return (
              <button
                key={f.key}
                role="tab"
                aria-selected={active}
                onClick={() => setFilter(active ? 'all' : f.key)}
                title={active ? 'Bấm lần nữa để bỏ lọc, xem tất cả mọi người' : `Lọc: ${f.label}`}
                className={`flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-2 text-xs font-bold shadow-sm transition-all ${
                  active
                    ? 'border-transparent bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-600/25'
                    : 'border-stone-200/80 bg-white text-stone-600 hover:border-emerald-300 hover:text-emerald-700'
                }`}
              >
                <Icon className={`h-3.5 w-3.5 shrink-0 ${active ? 'text-white' : f.key === 'near' ? 'text-rose-500' : f.key === 'online' ? 'text-emerald-500' : 'text-amber-500'}`} />
                {f.label}
              </button>
            )
          })}
        </div>

        {/* Nút chọn khu vực — danh sách trỏ xuống ngay dưới nút: Toàn quốc Việt Nam + 34 tỉnh sau sáp nhập + GPS (mobile chỉ còn icon cho gọn) */}
        <Popover open={regionOpen} onOpenChange={(v) => { setRegionOpen(v); if (v) setRegionQ('') }}>
          <PopoverTrigger asChild>
            <button
              className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border shadow-sm transition-colors sm:w-auto sm:gap-1 sm:px-3 ${
                province ? 'border-emerald-300 bg-emerald-50' : 'border-stone-200 bg-white hover:bg-stone-50'
              }`}
              aria-haspopup="listbox"
              aria-label="Chọn khu vực, Toàn quốc Việt Nam hoặc 1 trong 34 tỉnh thành sau sáp nhập"
              title="Chọn khu vực: Toàn quốc Việt Nam hoặc 1 trong 34 tỉnh thành sau sáp nhập 2025"
            >
              <MapPin className="h-4 w-4 shrink-0 text-emerald-600" />
              <span className="hidden max-w-24 truncate text-xs font-bold text-stone-700 sm:inline">{province || CITY_LABEL_ALL}</span>
              <ChevronDown className="hidden h-3.5 w-3.5 shrink-0 text-stone-400 sm:inline" />
            </button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-64 overflow-hidden p-0" aria-label="Danh sách khu vực">
            <div className="flex items-center gap-2 border-b px-3 py-2">
              <Search className="h-3.5 w-3.5 shrink-0 text-stone-400" />
              <input
                value={regionQ}
                onChange={(e) => setRegionQ(e.target.value)}
                placeholder="Tìm tỉnh thành..."
                aria-label="Tìm tỉnh thành"
                className="h-7 flex-1 bg-transparent text-xs outline-none placeholder:text-stone-400"
              />
            </div>
            <div className="max-h-72 overflow-y-auto py-1" role="listbox" aria-label="Chọn khu vực">
              <button
                onClick={useMyLocation}
                className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm font-semibold text-sky-700 transition-colors hover:bg-sky-50"
                role="option"
                aria-selected={false}
              >
                <Crosshair className="h-4 w-4 shrink-0" /> Dùng vị trí của tôi (GPS)
              </button>
              <div className="my-1 border-t border-stone-100" />
              <RegionOption label={CITY_LABEL_ALL} sub="Toàn bộ 34 tỉnh thành" checked={!province} onPick={() => { setProvince(''); setRegionOpen(false) }} />
              {provinceList.map((p) => (
                <RegionOption key={p} label={p} checked={province === p} onPick={() => { setProvince(p); setRegionOpen(false) }} />
              ))}
            </div>
          </PopoverContent>
        </Popover>

        {/* Nút Bộ lọc bên TAY PHẢI — sổ menu phải: hoạt động, độ tuổi, khoảng cách, khu vực (mobile chỉ icon) */}
        <button
          onClick={openMenu}
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border shadow-sm transition-all sm:w-auto sm:gap-1.5 sm:px-3 ${
            menuOpen || filtersActive ? 'border-emerald-300 bg-emerald-50 ring-1 ring-emerald-200' : 'border-stone-200 bg-white hover:border-emerald-200 hover:bg-stone-50'
          }`}
          aria-haspopup="dialog"
          aria-label="Mở menu bộ lọc, hoạt động, độ tuổi, khoảng cách"
          title="Bộ lọc: hoạt động, độ tuổi, khoảng cách, khu vực"
        >
          <span className={`flex h-6 w-6 items-center justify-center rounded-lg ${filtersActive ? 'bg-gradient-to-br from-emerald-500 to-teal-600 text-white' : 'bg-emerald-50 text-emerald-600'}`}>
            <SlidersHorizontal className="h-3.5 w-3.5" />
          </span>
          <span className="hidden text-xs font-bold text-stone-700 sm:inline">Bộ lọc</span>
        </button>
      </div>
      {/* Dòng tóm tắt bộ lọc đang bật + nút bỏ lọc nhanh */}
      {filtersActive && (
        <p className="-mt-1 px-1 text-[11px] font-medium text-stone-500">
          Đang lọc: <span className="font-bold text-emerald-700">{filterSummary}</span>
          <button onClick={resetFilters} className="ml-1.5 font-bold text-emerald-700 hover:underline" aria-label="Bỏ tất cả bộ lọc">Bỏ lọc</button>
        </p>
      )}

      {/* MENU BỘ LỌC — sổ ra phía TAY PHẢI (drawer):
          HOẠT ĐỘNG + ĐỘ TUỔI kéo mượt (kiểu tìm kiếm trong file bố trí cũ) + KHOẢNG CÁCH + KHU VỰC 34 tỉnh */}
      <ExploreDrawer
        open={menuOpen}
        onOpenChange={setMenuOpen}
        filter={filter}
        onFilter={(f) => setFilter(f)}
        ageRange={ageRange}
        onAge={(r) => setAgeRange(r)}
        heightRange={heightRange}
        onHeight={(r) => setHeightRange(r)}
        weightRange={weightRange}
        onWeight={(r) => setWeightRange(r)}
        maxKm={maxKm}
        onMaxKm={(km) => setMaxKm(km)}
        onKmCommit={onKmCommit}
        province={province}
        onProvince={(p) => setProvince(p)}
        onReset={() => { resetFilters() }}
      />

      {/* DANH SÁCH NGƯỜI — cập nhật trực tiếp (AJAX) mỗi khi kéo bộ lọc; thẻ người kiểu lưới khoảng cách + tên */}
      <section aria-label="Danh sách người theo bộ lọc">
        <div className="mb-2 flex items-center justify-between px-1">
          <h2 className="flex items-center gap-2 text-[15px] font-bold text-stone-800">
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-stone-200 bg-white shadow-sm">{gridTitle.icon}</span>
            {gridTitle.text}
          </h2>
          <span className="flex items-center gap-1 rounded-full border border-stone-200 bg-white px-2.5 py-1 text-[11px] font-bold text-stone-500 shadow-sm">
            {loading && <Loader2 className="h-3.5 w-3.5 animate-spin text-emerald-600" />}
            {loading ? 'Đang cập nhật...' : `${results.length} người`}
          </span>
        </div>
        {!loading && results.length === 0 ? (
          <div className="rounded-2xl border border-stone-200 bg-white p-6 text-center shadow-sm">
            <Users className="mx-auto mb-2 h-8 w-8 text-stone-300" />
            <p className="text-sm font-semibold text-stone-600">Chưa có người phù hợp bộ lọc này</p>
            <p className="mt-1 text-xs text-stone-400">Thử bỏ bớt bộ lọc hoặc mở rộng độ tuổi, khoảng cách nhé.</p>
            <Button variant="outline" size="sm" className="mt-3 gap-1.5" onClick={resetFilters}>
              <RotateCcw className="h-3.5 w-3.5" /> Đặt lại bộ lọc
            </Button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
              {peopleShown.map((u, i) => {
                const person = u as SearchUser
                if (!person || !person.id) return <div key={`sk_${i}`} className="h-36 animate-pulse rounded-2xl border border-stone-200 bg-white" />
                return (
                  <UserCard
                    key={person.id}
                    u={person}
                    onOpen={(id) => { saveRecent(person); openProfile(id) }}
                    onMessage={onMessage}
                    onFriend={() => friendAction(person, refreshNow)}
                    onSaveRecent={saveRecent}
                  />
                )
              })}
            </div>
            {peopleCollapsed && (
              <div className="mt-3 flex justify-center">
                <button
                  onClick={() => setShowAllPeople((v) => !v)}
                  className="flex items-center gap-1.5 rounded-full border border-emerald-200 bg-white px-5 py-2 text-xs font-bold text-emerald-700 shadow-sm transition-all hover:border-emerald-300 hover:bg-emerald-50 hover:shadow-md"
                  aria-label={showAllPeople ? 'Thu gọn danh sách mọi người' : `Xem thêm ${results.length - HOME_PEOPLE_PREVIEW} người`}
                >
                  {showAllPeople ? (<><ChevronUp className="h-3.5 w-3.5" /> Thu gọn danh sách</>) : (<>Xem thêm {results.length - HOME_PEOPLE_PREVIEW} người <ChevronDown className="h-3.5 w-3.5" /></>)}
                </button>
              </div>
            )}
          </>
        )}
      </section>

      {/* Radar Người gần đây đã GỞI khỏi Trang chủ (r27): trùng lặp với trang Tìm bạn bè / Người xung quanh đã có sẵn radar */}

      {/* Công ty đã tham gia ứng dụng */}
      {companies.length > 0 && (
        <section aria-label="Công ty đã tham gia ứng dụng">
          <div className="mb-2 flex items-center justify-between px-1">
            <h2 className="flex items-center gap-2 text-[15px] font-bold text-stone-800">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-sm"><Building2 className="h-4 w-4" /></span>
              Công ty đã tham gia ứng dụng
            </h2>
            <button onClick={() => onGo('companies')} className="flex shrink-0 items-center rounded-full bg-emerald-50 px-3 py-1.5 text-[11px] font-bold text-emerald-700 transition-colors hover:bg-emerald-100">
              Xem tất cả <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
          <div className="flex gap-2.5 overflow-x-auto rounded-2xl border border-stone-200/70 bg-gradient-to-br from-white to-stone-50 p-3 shadow-sm">
            {companies.map((c) => (
              <button
                key={c.id}
                onClick={() => onGo('companies')}
                className="flex w-40 shrink-0 flex-col items-start gap-2 rounded-xl border border-stone-200/70 bg-white p-3 text-left transition-all hover:-translate-y-0.5 hover:border-emerald-300 hover:shadow-md"
                aria-label={`Xem công ty ${c.name}`}
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-sm"><Building2 className="h-5 w-5" /></span>
                <span className="w-full">
                  <span className="block truncate text-sm font-bold text-stone-800">{c.name}</span>
                  <span className="block truncate text-[11px] text-stone-400">{c.industry}{c.size ? `, ${c.size}` : ''}</span>
                </span>
                <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-600">
                  <Star className="h-3 w-3 fill-amber-500 text-amber-500" /> {c.ratingAvg.toFixed(1)}
                  <span className="font-normal text-stone-400">({c.ratingCount})</span>
                  {c.jobCount > 0 && <span className="ml-1 font-normal text-emerald-600">{c.jobCount} việc làm</span>}
                </span>
              </button>
            ))}
          </div>
        </section>
      )}
    </div>
  )
}

/** Dòng khu vực trong danh sách trỏ xuống */
function RegionOption({ label, sub, checked, onPick }: { label: string; sub?: string; checked: boolean; onPick: () => void }) {
  return (
    <button
      onClick={onPick}
      className={`flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-sm font-semibold transition-colors hover:bg-emerald-50 ${checked ? 'text-emerald-700' : 'text-stone-600'}`}
      role="option"
      aria-selected={checked}
    >
      <span className="min-w-0">
        <span className="block truncate">{label}</span>
        {sub && <span className="block truncate text-[10px] font-medium text-stone-400">{sub}</span>}
      </span>
      {checked && <Check className="h-4 w-4 shrink-0 text-emerald-600" />}
    </button>
  )
}

/** Ô chọn trong menu lọc sổ ra — dấu check bên phải khi đang chọn */
function MenuOption({ label, checked, onClick }: { label: string; checked: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center justify-between gap-2 px-4 py-2 text-left text-sm font-semibold transition-colors hover:bg-emerald-50 ${checked ? 'text-emerald-700' : 'text-stone-600'}`}
      aria-pressed={checked}
    >
      <span className="truncate">{label}</span>
      {checked && <Check className="h-4 w-4 shrink-0 text-emerald-600" />}
    </button>
  )
}

/**
 * MENU BỘ LỌC — drawer sổ ra phía TAY PHẢI (trượt mượt):
 * HOẠT ĐỘNG (Tất cả/Gần đây/Online/Mới tham gia)
 * + ĐỘ TUỔI kéo 2 thanh Từ tuổi, Đến tuổi (18 đến 99, như phần tìm kiếm trong file bố trí cũ)
 * + CHIỀU CAO & CÂN NẶNG: 2 thanh kéo NẰM CÙNG MỘT HÀNG (trái cm, phải kg)
 * + KHOẢNG CÁCH kéo km + KHU VỰC: Toàn quốc Việt Nam và 34 tỉnh thành sau sáp nhập 2025
 */
function ExploreDrawer({ open, onOpenChange, filter, onFilter, ageRange, onAge, heightRange, onHeight, weightRange, onWeight, maxKm, onMaxKm, onKmCommit, province, onProvince, onReset }: {
  open: boolean
  onOpenChange: (v: boolean) => void
  filter: FilterKey
  onFilter: (f: FilterKey) => void
  ageRange: [number, number]
  onAge: (r: [number, number]) => void
  heightRange: [number, number]
  onHeight: (r: [number, number]) => void
  weightRange: [number, number]
  onWeight: (r: [number, number]) => void
  maxKm: number
  onMaxKm: (km: number) => void
  onKmCommit: (km: number) => void
  province: string
  onProvince: (p: string) => void
  onReset: () => void
}) {
  // Chọn mục hoạt động/khu vực xong tự đóng drawer để xem danh sách cập nhật (slider đang kéo thì không đóng)
  const pick = (fn: () => void) => { fn(); onOpenChange(false) }
  // Bong bóng số km/m hiện khi đang kéo thanh khoảng cách
  const [kmDrag, setKmDrag] = useState(false)

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-[21rem] max-w-[88vw] gap-0 overflow-y-auto p-0">
        <SheetHeader className="border-b pb-3 pr-10">
          <SheetTitle className="flex items-center gap-2 text-base font-black text-stone-800">
            <SlidersHorizontal className="h-5 w-5 text-emerald-600" /> Bộ lọc tìm kiếm
          </SheetTitle>
          <SheetDescription className="text-xs">
            Lọc hoạt động, độ tuổi, chiều cao, cân nặng, khoảng cách, khu vực. Danh sách người phía dưới cập nhật ngay khi bạn kéo.
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 px-1.5 py-2">
          <p className="px-2.5 pb-1 pt-1 text-[11px] font-bold tracking-wide text-stone-400">HOẠT ĐỘNG</p>
          {FILTERS.map((f) => (
            <MenuOption key={f.key} label={f.label} checked={filter === f.key} onClick={() => pick(() => onFilter(f.key))} />
          ))}

          <div className="my-1.5 border-t border-stone-100" />
          <div className="px-2.5 py-2">
            <p className="mb-2 flex items-center justify-between text-[11px] font-bold tracking-wide text-stone-400">
              <span>ĐỘ TUỔI</span>
              <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800">{ageLabelOf(ageRange)}</span>
            </p>
            {/* MỘT THANH KÉO DUY NHẤT — 2 núm trên cùng một track: núm trái = Từ tuổi, núm phải = Đến tuổi, kéo mượt */}
            <Slider
              value={ageRange}
              min={AGE_MIN}
              max={AGE_MAX}
              step={1}
              onValueChange={(v) => {
                const a = v[0] ?? AGE_MIN
                const b = v[1] ?? AGE_MAX
                onAge([Math.min(a, b), Math.max(a, b)])
              }}
              aria-label="Kéo chọn khoảng độ tuổi trên một thanh, từ 18 đến tối đa 99 tuổi"
              className="mx-1 [&_[data-slot=slider-range]]:bg-emerald-500 [&_[data-slot=slider-thumb]]:size-5 [&_[data-slot=slider-thumb]]:cursor-grab [&_[data-slot=slider-thumb]]:border-emerald-600 [&_[data-slot=slider-thumb]]:active:cursor-grabbing [&_[data-slot=slider-track]]:h-2 [&_[data-slot=slider-track]]:bg-stone-200"
            />
            <div className="mt-2.5 grid grid-cols-2 gap-2">
              <span className="rounded-xl border border-stone-200 bg-stone-50/60 px-3 py-2 text-[11px] font-bold text-stone-500">
                Từ tuổi <b className="text-sm text-stone-800">{ageRange[0]}</b>
              </span>
              <span className="rounded-xl border border-stone-200 bg-stone-50/60 px-3 py-2 text-[11px] font-bold text-stone-500">
                Đến tuổi <b className="text-sm text-stone-800">{ageRange[1]}</b>
              </span>
            </div>
            <p className="mt-2 text-[10px] text-stone-400">Một thanh kéo 2 núm, từ {AGE_MIN} tuổi, tối đa {AGE_MAX} tuổi</p>
          </div>

          <div className="border-t border-stone-100" />
          {/* CHIỀU CAO & CÂN NẶNG — 2 thanh kéo NẰM CÙNG MỘT HÀNG: trái chọn khoảng cm, phải chọn khoảng kg (mỗi thanh 2 núm như độ tuổi) */}
          <div className="px-2.5 py-2">
            <p className="mb-2 text-[11px] font-bold tracking-wide text-stone-400">CHIỀU CAO &amp; CÂN NẶNG</p>
            <div className="grid grid-cols-2 gap-2.5">
              {/* Thanh trái: chiều cao (cm) */}
              <div className="rounded-xl border border-stone-200 bg-stone-50/60 p-2">
                <p className="mb-1.5 flex items-center justify-between gap-1 text-[10px] font-bold">
                  <span className="flex items-center gap-1 text-stone-500"><MoveVertical className="h-3 w-3 text-emerald-600" /> CM</span>
                  <span className="rounded-full bg-emerald-100 px-1.5 py-0.5 text-[9px] font-bold text-emerald-800">{heightLabelOf(heightRange)}</span>
                </p>
                <Slider
                  value={heightRange}
                  min={HEIGHT_MIN}
                  max={HEIGHT_MAX}
                  step={1}
                  onValueChange={(v) => {
                    const a = v[0] ?? HEIGHT_MIN
                    const b = v[1] ?? HEIGHT_MAX
                    onHeight([Math.min(a, b), Math.max(a, b)])
                  }}
                  aria-label="Kéo chọn khoảng chiều cao, từ 140 đến 200 cm"
                  className="[&_[data-slot=slider-range]]:bg-emerald-500 [&_[data-slot=slider-thumb]]:size-4 [&_[data-slot=slider-thumb]]:cursor-grab [&_[data-slot=slider-thumb]]:border-emerald-600 [&_[data-slot=slider-thumb]]:active:cursor-grabbing [&_[data-slot=slider-track]]:h-1.5 [&_[data-slot=slider-track]]:bg-stone-200"
                />
                <p className="mt-1.5 text-[10px] font-semibold text-stone-500">Từ <b className="text-sm text-stone-800">{heightRange[0]}</b> đến <b className="text-sm text-stone-800">{heightRange[1]}</b> cm</p>
              </div>
              {/* Thanh phải: cân nặng (kg) */}
              <div className="rounded-xl border border-stone-200 bg-stone-50/60 p-2">
                <p className="mb-1.5 flex items-center justify-between gap-1 text-[10px] font-bold">
                  <span className="flex items-center gap-1 text-stone-500"><Weight className="h-3 w-3 text-teal-600" /> KG</span>
                  <span className="rounded-full bg-teal-100 px-1.5 py-0.5 text-[9px] font-bold text-teal-800">{weightLabelOf(weightRange)}</span>
                </p>
                <Slider
                  value={weightRange}
                  min={WEIGHT_MIN}
                  max={WEIGHT_MAX}
                  step={1}
                  onValueChange={(v) => {
                    const a = v[0] ?? WEIGHT_MIN
                    const b = v[1] ?? WEIGHT_MAX
                    onWeight([Math.min(a, b), Math.max(a, b)])
                  }}
                  aria-label="Kéo chọn khoảng cân nặng, từ 40 đến 120 kg"
                  className="[&_[data-slot=slider-range]]:bg-teal-500 [&_[data-slot=slider-thumb]]:size-4 [&_[data-slot=slider-thumb]]:cursor-grab [&_[data-slot=slider-thumb]]:border-teal-600 [&_[data-slot=slider-thumb]]:active:cursor-grabbing [&_[data-slot=slider-track]]:h-1.5 [&_[data-slot=slider-track]]:bg-stone-200"
                />
                <p className="mt-1.5 text-[10px] font-semibold text-stone-500">Từ <b className="text-sm text-stone-800">{weightRange[0]}</b> đến <b className="text-sm text-stone-800">{weightRange[1]}</b> kg</p>
              </div>
            </div>
            <p className="mt-1.5 text-[10px] text-stone-400">Mỗi thanh kéo 2 núm chọn khoảng; kéo về hết biên là bỏ lọc. Người chưa nhập số đo sẽ không hiện khi bật lọc.</p>
          </div>

          <div className="border-t border-stone-100" />
          <div className="px-2.5 py-2">
            <p className="mb-2 flex items-center justify-between text-[11px] font-bold tracking-wide text-stone-400">
              <span>KHOẢNG CÁCH</span>
              <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${maxKm > 0 ? 'bg-sky-100 text-sky-800' : 'bg-stone-100 text-stone-500'}`}>
                {maxKm > 0 ? `Tối đa ${kmLabel(maxKm)}` : 'Mọi khoảng cách'}
              </span>
            </p>
            {/* Bong bóng số m/km hiện ngay trên núm khi kéo — thấy rõ giá trị đang chọn */}
            <div className="relative px-1">
              {kmDrag && (
                <span
                  className="pointer-events-none absolute -top-7 z-10 -translate-x-1/2 whitespace-nowrap rounded-lg bg-sky-600 px-2 py-0.5 text-[10px] font-black text-white shadow"
                  style={{ left: `${Math.min(Math.max((maxKm / 50) * 100, 9), 91)}%` }}
                >
                  {maxKm === 0 ? 'Mọi khoảng cách' : kmLabel(maxKm)}
                </span>
              )}
              <Slider
                value={[maxKm]}
                min={0}
                max={50}
                step={0.5}
                onValueChange={(v) => { setKmDrag(true); onMaxKm(v[0] ?? 0) }}
                onValueCommit={() => { setKmDrag(false); onKmCommit(maxKm) }}
                aria-label="Kéo chọn khoảng cách tối đa"
                className="[&_[data-slot=slider-range]]:bg-sky-500 [&_[data-slot=slider-thumb]]:size-5 [&_[data-slot=slider-thumb]]:cursor-grab [&_[data-slot=slider-thumb]]:border-sky-600 [&_[data-slot=slider-thumb]]:active:cursor-grabbing [&_[data-slot=slider-track]]:h-2 [&_[data-slot=slider-track]]:bg-stone-200"
              />
              <div className="mt-1.5 flex items-center justify-between text-[10px] font-semibold text-stone-400">
                <span>0</span><span>10 km</span><span>25 km</span><span>50 km</span>
              </div>
            </div>
            <p className="mt-1 text-[10px] text-stone-400">Dùng vị trí GPS đã lưu của bạn, kéo về 0 để bỏ lọc</p>
          </div>

          <div className="border-t border-stone-100" />
          <p className="px-2.5 pb-1 pt-2 text-[11px] font-bold tracking-wide text-stone-400">KHU VỰC (34 TỈNH THÀNH SAU SẮP NHẬP)</p>
          <div className="max-h-72 overflow-y-auto pb-1">
            <MenuOption label={CITY_LABEL_ALL} checked={!province} onClick={() => pick(() => onProvince(''))} />
            {PROVINCES_34.map((p) => (
              <MenuOption key={p} label={p} checked={province === p} onClick={() => pick(() => onProvince(p))} />
            ))}
          </div>
        </div>

        <div className="sticky bottom-0 border-t bg-white p-3">
          <Button variant="outline" className="w-full gap-2" onClick={() => { onReset(); onOpenChange(false) }} aria-label="Đặt lại bộ lọc">
            <RotateCcw className="h-4 w-4" /> Đặt lại bộ lọc
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}

/** Thẻ người kiểu lưới (Trang chủ + kết quả tìm kiếm) — bản gọn: avatar 52 viền gradient, 1 dòng tỉnh · tuổi · khoảng cách, nút căn đáy thẻ */
function UserCard({ u, onOpen, onMessage, onFriend, onSaveRecent }: {
  u: SearchUser
  onOpen: (id: string) => void
  onMessage?: (userId: string) => void
  onFriend: () => void
  onSaveRecent: (u: SearchUser) => void
}) {
  const open = () => { onSaveRecent(u); onOpen(u.id) }
  const statusDot = u.activityKey === 'online'
  // Dấu chấm phân cách chỉ chèn khi có phần đứng trước (tỉnh/tuổi) để không thừa "·" đầu dòng
  const hasMetaBefore = (u.province ? 1 : 0) + (u.age != null ? 1 : 0)
  return (
    <div className="flex flex-col overflow-hidden rounded-2xl border border-stone-200/80 bg-white shadow-sm transition-all hover:-translate-y-0.5 hover:border-emerald-300 hover:shadow-lg hover:shadow-emerald-600/10">
      <button onClick={open} className="flex w-full flex-col items-center gap-1.5 p-3 pb-2" aria-label={`Xem hồ sơ ${u.fullName}`}>
        <span className="rounded-full bg-gradient-to-br from-emerald-400 via-teal-400 to-cyan-400 p-[2px] leading-none">
          <Avatar name={u.fullName} color={u.avatarColor} size={52} online={statusDot} img={u.avatarImage} />
        </span>
        <div className="w-full min-w-0 text-center">
          <p className="truncate text-[13px] font-bold text-stone-800">{u.fullName}</p>
          {/* Một dòng gọn: tỉnh · tuổi · khoảng cách — đủ nhận biết, không rời rạc, không chip placeholder */}
          <p className="flex w-full flex-wrap items-center justify-center gap-x-1 text-[11px] leading-4 text-stone-500">
            {u.province && (
              <span className="flex min-w-0 items-center gap-0.5">
                <MapPin className="h-3 w-3 shrink-0 text-stone-400" />
                <span className="truncate">{u.province}</span>
              </span>
            )}
            {u.province && u.age != null && <span className="text-stone-300">·</span>}
            {u.age != null && <span className="shrink-0 font-semibold text-stone-600">{u.age} tuổi</span>}
            {u.distanceKm != null && hasMetaBefore > 0 && <span className="text-stone-300">·</span>}
            {u.distanceKm != null && (
              <span className="flex shrink-0 items-center gap-0.5 font-bold text-sky-600">
                <Navigation className="h-2.5 w-2.5" /> Cách {distText(u.distanceKm)}
              </span>
            )}
          </p>
          <p className={`mt-0.5 flex w-full items-center justify-center gap-1 truncate text-[11px] ${u.activityKey === 'online' ? 'font-semibold text-emerald-600' : u.activityKey === 'recent' ? 'text-sky-600' : 'text-stone-400'}`}>
            {statusDot && <span className="inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500" />}
            {u.activity}
          </p>
        </div>
      </button>
      {/* Khối nút căn đáy thẻ — mọi thẻ cao bằng nhau dù tên dài ngắn */}
      <div className="mt-auto px-2.5 pb-2.5">
        {u.friendStatus === 'none' && (
          <button onClick={onFriend} className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 py-1.5 text-[11px] font-bold text-white shadow-sm transition-all hover:shadow-md hover:brightness-105" aria-label={`Kết bạn với ${u.fullName}`}>
            <UserPlus className="h-3.5 w-3.5" /> Kết bạn
          </button>
        )}
        {u.friendStatus === 'pending_sent' && (
          <span className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-stone-100 py-1.5 text-[11px] font-semibold text-stone-400">Đã gửi lời mời</span>
        )}
        {u.friendStatus === 'pending_received' && (
          <button onClick={onFriend} className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-amber-500 py-1.5 text-[11px] font-bold text-white shadow-sm transition-colors hover:bg-amber-600" aria-label={`Chấp nhận lời mời từ ${u.fullName}`}>
            <Check className="h-3.5 w-3.5" /> Chấp nhận
          </button>
        )}
        {u.friendStatus === 'accepted' && onMessage && (
          <button onClick={() => onMessage(u.id)} className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-stone-200 bg-white py-1.5 text-[11px] font-bold text-stone-600 transition-colors hover:border-emerald-300 hover:bg-emerald-50/60 hover:text-emerald-700" aria-label={`Nhắn tin cho ${u.fullName}`}>
            <MessageCircle className="h-3.5 w-3.5" /> Nhắn tin
          </button>
        )}
        {u.friendStatus === 'accepted' && !onMessage && (
          <span className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-emerald-50 py-1.5 text-[11px] font-bold text-emerald-700">
            <CheckCheck className="h-3.5 w-3.5" /> Bạn bè
          </span>
        )}
      </div>
    </div>
  )
}
