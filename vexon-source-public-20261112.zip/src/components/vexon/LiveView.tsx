'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { getSocket } from '@/lib/vx-socket'
import { fmtDateTime, fmtUsdFromXu, fmtXuWithUsd } from '@/lib/format'
import { useUsdRate } from '@/lib/use-usd-rate'
import type { VxUserInfo } from '@/components/vexon/AuthView'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { Radio, Heart, Send, Users, Plus, Loader2, LogOut, Info, Gift, Coins, Trophy, Lock, ShieldCheck, Globe, Flame, Hand, Laugh, ChevronLeft } from 'lucide-react'
import { GiftStamp, StampAny } from '@/components/vexon/shared'

interface VxLive {
  id: string
  title: string
  sourceVideoUrl: string
  status: string
  visibility?: string
  isPrivate?: boolean
  peakViewers: number
  startedAt: string
  endedAt?: string | null
  host: { id: string; username: string; fullName: string; role: string; avatarColor: string }
  _count?: { chats: number }
}

interface ChatMsg {
  id: string
  content: string
  createdAt: string
  user: { id: string; fullName: string; avatarColor: string }
}

interface GiftItem { id: string; code: string; name: string; emoji: string; cost: number }
interface GiftLeaderboard { rank: number; user: { id: string; fullName: string; avatarColor: string } | null; totalCoins: number }

export default function LiveView({ me, onRefreshUser }: { me: VxUserInfo; onRefreshUser?: () => void }) {
  const [lives, setLives] = useState<VxLive[]>([])
  const [loading, setLoading] = useState(true)
  const [activeLiveId, setActiveLiveId] = useState<string | null>(null)
  const { toast } = useToast()

  const load = useCallback(() => {
    fetch('/api/vx/lives')
      .then((r) => r.json())
      .then((data) => Array.isArray(data) && setLives(data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(load, [load])

  if (activeLiveId) {
    return <LiveRoom liveId={activeLiveId} me={me} onBack={() => { setActiveLiveId(null); load() }} onRefreshUser={onRefreshUser} />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="flex items-center gap-2 font-bold">
            <Radio className="h-5 w-5 text-rose-600" />
            Livestream
          </h2>
          <p className="text-xs text-muted-foreground">Chọn chế độ <b>Công khai</b> hoặc <b>Bảo mật</b> (người xem phải nhập mật khẩu) khi tạo phòng</p>
        </div>
        <CreateLiveButton me={me} onCreated={(id) => { load(); setActiveLiveId(id) }} />
      </div>

      {loading ? (
        <p className="py-16 text-center text-sm text-muted-foreground">Đang tải...</p>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {lives.map((live) => (
            <Card key={live.id} className="overflow-hidden pt-0 transition-shadow hover:shadow-lg">
              <div className="relative h-40 bg-black">
                <video src={live.sourceVideoUrl} className="h-full w-full object-cover opacity-80" muted preload="metadata" />
                {live.status === 'live' ? (
                  <Badge className="absolute left-2 top-2 animate-pulse bg-rose-600 text-white hover:bg-rose-600">
                    <span className="mr-1 inline-block h-2 w-2 animate-pulse rounded-full bg-white" />
                    LIVE
                  </Badge>
                ) : (
                  <Badge variant="secondary" className="absolute left-2 top-2 bg-stone-700 text-stone-200">Đã kết thúc</Badge>
                )}
                {live.isPrivate && (
                  <Badge className="absolute right-2 top-2 bg-amber-500 text-white hover:bg-amber-500" title="Phòng live bảo mật, cần mật khẩu">
                    <Lock className="mr-1 h-3 w-3" /> Bảo mật
                  </Badge>
                )}
              </div>
              <CardContent className="space-y-2 p-4">
                <p className="line-clamp-2 min-h-[2.5rem] font-semibold">{live.title}</p>
                <p className="text-xs text-muted-foreground">
                  {live.host.fullName}, {fmtDateTime(live.startedAt)}
                </p>
                <Button
                  className={`w-full ${live.status === 'live' ? 'bg-rose-600 hover:bg-rose-700' : ''}`}
                  variant={live.status === 'live' ? 'default' : 'outline'}
                  onClick={() => setActiveLiveId(live.id)}
                >
                  {live.status === 'live' ? 'Vào xem ngay' : 'Xem lại'}
                </Button>
              </CardContent>
            </Card>
          ))}
          {lives.length === 0 && (
            <p className="col-span-full py-16 text-center text-sm text-muted-foreground">Chưa có buổi live nào, tạo buổi live đầu tiên!</p>
          )}
        </div>
      )}
    </div>
  )
}

// ===== Tạo buổi live =====
function CreateLiveButton({ me, onCreated }: { me: VxUserInfo; onCreated: (liveId: string) => void }) {
  const [open, setOpen] = useState(false)
  const [title, setTitle] = useState('')
  const [videoUrl, setVideoUrl] = useState('')
  const [visibility, setVisibility] = useState<'public' | 'private'>('public')
  const [password, setPassword] = useState('')
  const [myVideos, setMyVideos] = useState<{ id: string; caption: string; url: string }[]>([])
  const [saving, setSaving] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    if (!open) return
    fetch('/api/vx/videos')
      .then((r) => r.json())
      .then((data) => Array.isArray(data) && setMyVideos(data.filter((v: { user: { id: string } }) => v.user.id === me.id)))
      .catch(() => {})
  }, [open, me.id])

  const create = async () => {
    if (!title.trim() || !videoUrl) {
      toast({ title: 'Thiếu thông tin', description: 'Nhập tiêu đề và chọn nguồn phát', variant: 'destructive' })
      return
    }
    if (visibility === 'private' && password.trim().length < 4) {
      toast({ title: 'Thiếu mật khẩu', description: 'Live bảo mật cần mật khẩu tối thiểu 4 ký tự', variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/vx/lives', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: title.trim(), sourceVideoUrl: videoUrl, visibility, password }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: visibility === 'private' ? 'Live bảo mật đã bắt đầu' : 'Buổi live đã bắt đầu!' })
      setOpen(false)
      setTitle('')
      setVideoUrl('')
      setPassword('')
      setVisibility('public')
      onCreated(data.id)
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không tạo được', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-rose-600 hover:bg-rose-700">
          <Plus className="mr-1 h-4 w-4" />
          Tạo buổi live
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Bắt đầu phát trực tiếp</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
            <Info className="mt-0.5 h-4 w-4 shrink-0" />
            Sandbox chưa hỗ trợ RTMP/WebRTC nên nguồn phát là video có sẵn (chọn từ video bạn đã đăng). Chat & người xem vẫn realtime 100%.
          </div>
          <div className="space-y-2">
            <Label>Tiêu đề buổi live *</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="VD: Live ra mắt sản phẩm mới" />
          </div>
          <div className="space-y-2">
            <Label>Nguồn phát (video của bạn) *</Label>
            <Select value={videoUrl} onValueChange={setVideoUrl}>
              <SelectTrigger aria-label="Chọn video phát trực tiếp">
                <SelectValue placeholder={myVideos.length === 0 ? 'Bạn chưa có video, hãy đăng ở tab Video' : 'Chọn video'} />
              </SelectTrigger>
              <SelectContent>
                {myVideos.map((v) => (
                  <SelectItem key={v.id} value={v.url}>{v.caption.slice(0, 50)}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {/* Chế độ live: công khai / bảo mật mật khẩu */}
          <div className="space-y-2">
            <Label>Chế độ phòng live</Label>
            <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="Chế độ phòng live">
              <button
                type="button"
                onClick={() => setVisibility('public')}
                className={`flex items-start gap-2 rounded-lg border-2 p-3 text-left transition-colors ${visibility === 'public' ? 'border-rose-500 bg-rose-50' : 'border-stone-200 hover:bg-stone-50'}`}
                aria-pressed={visibility === 'public'}
              >
                <Globe className="mt-0.5 h-4 w-4 text-emerald-600" />
                <span className="text-sm"><b>Công khai</b><br /><span className="text-[11px] text-stone-500">Ai cũng vào xem được</span></span>
              </button>
              <button
                type="button"
                onClick={() => setVisibility('private')}
                className={`flex items-start gap-2 rounded-lg border-2 p-3 text-left transition-colors ${visibility === 'private' ? 'border-amber-500 bg-amber-50' : 'border-stone-200 hover:bg-stone-50'}`}
                aria-pressed={visibility === 'private'}
              >
                <Lock className="mt-0.5 h-4 w-4 text-amber-600" />
                <span className="text-sm"><b>Bảo mật</b><br /><span className="text-[11px] text-stone-500">Phải nhập mật khẩu</span></span>
              </button>
            </div>
            {visibility === 'private' && (
              <div className="space-y-1.5 rounded-lg border border-amber-200 bg-amber-50 p-3">
                <Label htmlFor="live-pw" className="flex items-center gap-1.5 text-amber-900"><ShieldCheck className="h-4 w-4" /> Mật khẩu phòng live *</Label>
                <Input id="live-pw" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Tối thiểu 4 ký tự, ví dụ: hop2026" type="text" autoComplete="off" />
                <p className="text-[11px] text-amber-800">Chỉ chia sẻ mật khẩu cho người bạn muốn mời. Người xem phải nhập đúng mới thấy video, chat & tặng quà.</p>
              </div>
            )}
          </div>
          <Button className="w-full bg-rose-600 hover:bg-rose-700" onClick={create} disabled={saving}>
            {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Radio className="mr-1 h-4 w-4" />}
            Bắt đầu live
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ===== Phòng live =====
function LiveRoom({ liveId, me, onBack, onRefreshUser }: { liveId: string; me: VxUserInfo; onBack: () => void; onRefreshUser?: () => void }) {
  const [live, setLive] = useState<VxLive | null>(null)
  const [chats, setChats] = useState<ChatMsg[]>([])
  const [viewers, setViewers] = useState(0)
  const [input, setInput] = useState('')
  const [reactions, setReactions] = useState<{ id: number; emoji: string }[]>([])
  const [giftOpen, setGiftOpen] = useState(false)
  const [gifts, setGifts] = useState<GiftItem[]>([])
  const [leaderboard, setLeaderboard] = useState<GiftLeaderboard[]>([])
  const [myCoins, setMyCoins] = useState(0)
  const [selGift, setSelGift] = useState<GiftItem | null>(null)
  const rate = useUsdRate() // tỷ giá sống — đồng bộ ví USD cho quà live
  const [giftQty, setGiftQty] = useState(1)
  const [sendingGift, setSendingGift] = useState(false)
  // Phòng live bảo mật: cần mật khẩu mới xem được
  const [locked, setLocked] = useState(false)
  const [lockedHost, setLockedHost] = useState<{ fullName: string; avatarColor: string } | null>(null)
  const [pw, setPw] = useState('')
  const [pwError, setPwError] = useState('')
  const [unlocking, setUnlocking] = useState(false)
  const chatEndRef = useRef<HTMLDivElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const { toast } = useToast()

  const pwQuery = pw ? `?pw=${encodeURIComponent(pw)}` : ''

  const loadGift = useCallback(() => {
    fetch(`/api/vx/lives/${liveId}/gift${pwQuery}`)
      .then((r) => r.json())
      .then((d) => {
        if (Array.isArray(d.gifts)) setGifts(d.gifts)
        if (Array.isArray(d.leaderboard)) setLeaderboard(d.leaderboard)
        if (typeof d.myCoins === 'number') setMyCoins(d.myCoins)
      })
      .catch(() => {})
  }, [liveId, pw])

  // Tải live + chat — phòng bảo mật trả locked -> hiện cổng nhập mật khẩu
  useEffect(() => {
    fetch(`/api/vx/lives/${liveId}${pwQuery}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.locked) {
          setLocked(true)
          setLockedHost(d.host || null)
          return
        }
        setLocked(false)
        setLive((prev) => (prev && prev.id === d.id ? { ...prev, status: d.status } : d))
      })
      .catch(() => {})
    fetch(`/api/vx/lives/${liveId}/chat${pwQuery}`).then((r) => r.json()).then((d) => Array.isArray(d) && setChats(d)).catch(() => {})
  }, [liveId, pw])

  useDeferredLoad(() => loadGift(), [loadGift])

  // Socket realtime
  useEffect(() => {
    const socket = getSocket()
    socket.emit('live:join', { liveId, userId: me.id, userName: me.fullName })

    const onChat = (payload: { chat: ChatMsg }) => setChats((cs) => [...cs, payload.chat])
    const onViewers = (payload: { count: number }) => setViewers(payload.count)
    const onJoin = (payload: { userName: string }) =>
      toast({ title: `${payload.userName} vừa vào xem live` })
    const onReaction = (payload: { emoji: string; userName: string }) => {
      const id = Date.now() + Math.random()
      setReactions((rs) => [...rs, { id, emoji: payload.emoji }])
      setTimeout(() => setReactions((rs) => rs.filter((r) => r.id !== id)), 2500)
    }
    const onEnd = () => {
      toast({ title: 'Buổi live đã kết thúc' })
      setLive((l) => (l ? { ...l, status: 'ended' } : l))
    }

    socket.on('live:chat', onChat)
    socket.on('live:viewers', onViewers)
    socket.on('live:join-notice', onJoin)
    socket.on('live:reaction', onReaction)
    socket.on('live:end', onEnd)

    return () => {
      socket.off('live:chat', onChat)
      socket.off('live:viewers', onViewers)
      socket.off('live:join-notice', onJoin)
      socket.off('live:reaction', onReaction)
      socket.off('live:end', onEnd)
      socket.emit('live:join', { liveId, userId: me.id, userName: me.fullName }) // không có leave riêng, disconnect sẽ gỡ
    }
  }, [liveId])

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [chats])

  const send = async () => {
    if (!input.trim()) return
    const content = input.trim()
    setInput('')
    const res = await fetch(`/api/vx/lives/${liveId}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, pw }),
    })
    const data = await res.json()
    if (!res.ok) {
      toast({ title: 'Lỗi', description: data.error, variant: 'destructive' })
      return
    }
    setChats((cs) => [...cs, data])
    getSocket().emit('live:chat', { liveId, chat: data })
  }

  const react = (emoji: string) => {
    const id = Date.now() + Math.random()
    setReactions((rs) => [...rs, { id, emoji }])
    setTimeout(() => setReactions((rs) => rs.filter((r) => r.id !== id)), 2500)
    getSocket().emit('live:reaction', { liveId, emoji, userName: me.fullName })
  }

  const endLive = async () => {
    const res = await fetch(`/api/vx/lives/${liveId}`, { method: 'PATCH' })
    if (res.ok) {
      getSocket().emit('live:end', { liveId })
      setLive((l) => (l ? { ...l, status: 'ended' } : l))
      toast({ title: 'Đã kết thúc buổi live' })
    }
  }

  // Tặng quà: trừ xu, cộng cho host, hiện animation + tin hệ thống
  const sendGift = async () => {
    if (!selGift) return
    setSendingGift(true)
    try {
      const res = await fetch(`/api/vx/lives/${liveId}/gift`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ giftCode: selGift.code, qty: giftQty, pw }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: `Đã tặng ${selGift.name} x${giftQty}!`, description: `- ${fmtXuWithUsd(selGift.cost * giftQty, rate)}` })
      for (let i = 0; i < Math.min(giftQty, 8); i++) {
        setTimeout(() => {
          const id = Date.now() + Math.random()
          setReactions((rs) => [...rs, { id, emoji: selGift.code }])
          setTimeout(() => setReactions((rs) => rs.filter((r) => r.id !== id)), 2500)
        }, i * 180)
      }
      setSelGift(null)
      setGiftQty(1)
      loadGift()
      onRefreshUser?.()
      // Làm mới chat sau 0.5s để thấy tin hệ thống quà
      setTimeout(() => {
        fetch(`/api/vx/lives/${liveId}/chat${pwQuery}`).then((r) => r.json()).then((d) => Array.isArray(d) && setChats(d)).catch(() => {})
      }, 600)
    } catch (e) {
      toast({ title: 'Không tặng được quà', description: e instanceof Error ? e.message : 'Lỗi', variant: 'destructive' })
    } finally {
      setSendingGift(false)
    }
  }

  if (locked) {
    // Cổng mật khẩu cho phòng live bảo mật
    const unlock = async () => {
      setUnlocking(true)
      setPwError('')
      const res = await fetch(`/api/vx/lives/${liveId}?pw=${encodeURIComponent(pw)}`)
      const d = await res.json()
      setUnlocking(false)
      if (d.locked || !res.ok) {
        setPwError('Mật khẩu không đúng, thử lại nhé!')
        return
      }
      setPw(pw)
      setLocked(false)
    }
    return (
      <div className="mx-auto max-w-md py-10">
        <div className="rounded-2xl border-2 border-amber-200 bg-gradient-to-b from-amber-50 to-white p-8 text-center shadow-lg">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-amber-100">
            <Lock className="h-8 w-8 text-amber-600" />
          </div>
          <h2 className="text-xl font-black">Phòng live bảo mật</h2>
          <p className="mt-1 text-sm text-stone-500">
            {lockedHost ? <span>Chủ phòng: <b>{lockedHost.fullName}</b>, </span> : ''}Nhập mật khẩu để vào xem, chat & tặng quà
          </p>
          <div className="mt-5 space-y-3">
            <Input
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && pw.trim() && unlock()}
              placeholder="Mật khẩu phòng live"
              type="password"
              aria-label="Mật khẩu phòng live"
              autoFocus
            />
            {pwError && <p className="text-sm font-medium text-rose-600">{pwError}</p>}
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1 gap-1" onClick={onBack}><ChevronLeft className="h-4 w-4" /> Thoát</Button>
              <Button className="flex-1 bg-amber-600 hover:bg-amber-700" onClick={unlock} disabled={unlocking || !pw.trim()}>
                {unlocking ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-1 h-4 w-4" />}
                Vào phòng
              </Button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!live) return <p className="py-16 text-center text-sm text-muted-foreground">Đang tải phòng live...</p>

  const isHost = live.host.id === me.id

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-3 flex items-center justify-between">
        <Button variant="outline" size="sm" className="gap-1" onClick={onBack}><ChevronLeft className="h-4 w-4" /> Danh sách live</Button>
        <div className="flex items-center gap-2">
          {live.status === 'live' ? (
            <>
              <Badge className="animate-pulse bg-rose-600 text-white hover:bg-rose-600">
                <span className="mr-1 inline-block h-2 w-2 animate-pulse rounded-full bg-white" />
                LIVE
              </Badge>
              <Badge variant="secondary" className="gap-1 bg-stone-800 text-white hover:bg-stone-800">
                <Users className="h-3 w-3" />
                {viewers} đang xem
              </Badge>
              {isHost && (
                <Button size="sm" variant="destructive" onClick={endLive}>
                  <LogOut className="mr-1 h-4 w-4" />
                  Kết thúc
                </Button>
              )}
            </>
          ) : (
            <Badge variant="secondary" className="bg-stone-700 text-stone-200">Đã kết thúc</Badge>
          )}
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Khung phát */}
        <div className="relative overflow-hidden rounded-2xl bg-black lg:col-span-2">
          <video
            ref={videoRef}
            src={live.sourceVideoUrl}
            className="h-[60vh] w-full object-cover"
            autoPlay
            muted
            loop
            playsInline
          />
          <div className="pointer-events-none absolute left-3 top-3 max-w-[80%]">
            <p className="line-clamp-2 rounded-lg bg-black/60 px-3 py-1.5 text-sm font-semibold text-white backdrop-blur">
              {live.title}
            </p>
          </div>
          <div className="pointer-events-none absolute bottom-3 left-3 flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-full text-sm font-bold text-white" style={{ backgroundColor: live.host.avatarColor }}>
              {live.host.fullName[0]}
            </div>
            <div>
              <p className="text-sm font-bold text-white">{live.host.fullName}</p>
              <p className="text-xs text-stone-300">Chủ phòng live</p>
            </div>
          </div>
          {/* Reaction bay */}
          <div className="pointer-events-none absolute bottom-3 right-3 flex flex-col items-center">
            {reactions.map((r) => (
              <span key={r.id} className="vx-float-up absolute bottom-0"><StampAny value={r.emoji} size={30} className="drop-shadow" /></span>
            ))}
          </div>
          {/* Top người tặng */}
          {leaderboard.length > 0 && (
            <div className="pointer-events-none absolute left-3 top-14 w-44 rounded-lg bg-black/55 p-2 backdrop-blur">
              <p className="mb-1 flex items-center gap-1 text-[10px] font-bold text-amber-300"><Trophy className="h-3 w-3" /> TOP TẶNG QUÀ</p>
              {leaderboard.slice(0, 3).map((l) => (
                <p key={l.rank} className="flex items-center justify-between text-[10px] text-white">
                  <span className="truncate">{l.rank}. {l.user?.fullName || 'Ẩn danh'}</span>
                  <span className="ml-1 shrink-0 max-w-[112px] truncate text-right font-bold text-amber-300" title={fmtUsdFromXu(l.totalCoins, rate)}>{fmtXuWithUsd(l.totalCoins, rate)}</span>
                </p>
              ))}
            </div>
          )}
        </div>

        {/* Chat realtime */}
        <Card className="flex h-[60vh] flex-col">
          <CardHeader className="border-b py-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Users className="h-4 w-4 text-rose-600" />
              Live chat ({chats.length})
            </CardTitle>
          </CardHeader>
          <div className="flex-1 space-y-2.5 overflow-y-auto p-3">
            {chats.length === 0 && <p className="py-6 text-center text-xs text-muted-foreground">Chưa có tin nhắn, chào mọi người nào!</p>}
            {chats.map((c) => (
              <div key={c.id} className="flex items-start gap-2">
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[11px] font-bold text-white" style={{ backgroundColor: c.user.avatarColor }}>
                  {c.user.fullName[0]}
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-muted-foreground">
                    {c.user.fullName} {c.user.id === live.host.id && <Badge className="ml-1 h-4 bg-rose-600 px-1 text-[9px] text-white hover:bg-rose-600">HOST</Badge>}
                  </p>
                  <p className="break-words text-sm">{c.content}</p>
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
          {live.status === 'live' && (
            <>
              <div className="flex justify-center gap-2 border-t py-2">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => react('LOVE')} aria-label="Thả tim">
                  <Heart className="h-5 w-5 text-rose-500" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => react('FIRE')} aria-label="Thả lửa"><Flame className="h-5 w-5 text-orange-500" /></Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => react('CLAP')} aria-label="Thả vỗ tay"><Hand className="h-5 w-5 text-amber-500" /></Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => react('HAHA')} aria-label="Thả cười"><Laugh className="h-5 w-5 text-yellow-500" /></Button>
                {!isHost && (
                  <Button size="sm" className="ml-1 h-8 bg-gradient-to-r from-amber-500 to-rose-500 text-xs font-bold text-white hover:from-amber-600 hover:to-rose-600" onClick={() => { setGiftOpen(true); loadGift() }}>
                    <Gift className="mr-1 h-3.5 w-3.5" /> Quà
                  </Button>
                )}
              </div>
              <div className="flex gap-2 border-t p-3">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && send()}
                  placeholder="Gửi bình luận..."
                  className="h-9"
                />
                <Button size="icon" className="h-9 w-9 shrink-0 bg-rose-600 hover:bg-rose-700" onClick={send} aria-label="Gửi chat">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </>
          )}
          {isHost && (
            <div className="flex items-center justify-between border-t bg-amber-50 px-3 py-2 text-xs">
              <span className="font-semibold text-amber-800"><Coins className="mr-1 inline h-3.5 w-3.5" />Host nhận: {fmtXuWithUsd(leaderboard.reduce((s, l) => s + l.totalCoins, 0), rate)}</span>
              <span className="text-amber-700">{viewers} người xem, peak {live.peakViewers}</span>
            </div>
          )}
        </Card>
      </div>

      {/* ===== Drawer tặng quà ===== */}
      <Dialog open={giftOpen} onOpenChange={setGiftOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2"><Gift className="h-5 w-5 text-rose-600" /> Tặng quà {live?.host.fullName}</span>
              <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100"><Coins className="mr-1 inline h-3.5 w-3.5" />{fmtXuWithUsd(myCoins, rate)}</Badge>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-4 gap-2">
              {gifts.map((g) => (
                <button
                  key={g.code}
                  className={`flex flex-col items-center gap-0.5 rounded-xl border-2 p-2 transition-colors ${selGift?.code === g.code ? 'border-rose-500 bg-rose-50' : 'hover:border-amber-300 hover:bg-amber-50'}`}
                  onClick={() => setSelGift(g)}
                >
                  <GiftStamp code={g.code} size={28} />
                  <span className="text-[11px] font-semibold">{g.name}</span>
                  <Badge variant="secondary" className="text-[10px]">{fmtXuWithUsd(g.cost, rate)}</Badge>
                </button>
              ))}
            </div>
            {selGift && (
              <div className="flex items-center justify-between rounded-lg bg-stone-50 p-3">
                <div className="flex items-center gap-1">
                  <Button size="icon" variant="outline" className="h-8 w-8" onClick={() => setGiftQty(Math.max(1, giftQty - 1))} aria-label="Giảm số lượng">−</Button>
                  <span className="w-10 text-center font-black">x{giftQty}</span>
                  <Button size="icon" variant="outline" className="h-8 w-8" onClick={() => setGiftQty(Math.min(99, giftQty + 1))} aria-label="Tăng số lượng">+</Button>
                </div>
                <p className="text-sm">Tổng: <b className="text-rose-600">{fmtXuWithUsd(selGift.cost * giftQty, rate)}</b></p>
                <Button className="bg-gradient-to-r from-amber-500 to-rose-500 font-bold text-white hover:from-amber-600 hover:to-rose-600" onClick={sendGift} disabled={sendingGift}>
                  {sendingGift ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Gift className="mr-1 h-4 w-4" />}
                  Tặng ngay
                </Button>
              </div>
            )}
            <p className="text-center text-xs text-stone-500">Không đủ tiền? Xem video, điểm danh mỗi ngày để kiếm tiền trong mục <b>Ví tiền</b>!</p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
