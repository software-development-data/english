'use client'

// ============ NẠP TIỀN USD BẰNG QUÉT MÃ QR NGÂN HÀNG — CHỜ ADMIN DUYỆT ============
// Ngân hàng: TECHCOMBANK (BIN 970415), Số tài khoản: 2461388888, Chủ TK: TRAN NGOC SON
// Sinh mã QR chuẩn VietQR / Napas 247 (EMVCo) ngay trên máy — số tiền VND quy từ USD theo TỶ GIÁ SỐNG
// r30: MỌI MỆNH GIÁ NẠP ĐỀU TÍNH BẰNG USD — chọn gói $ hoặc nhập số USD, QR tự quy ra VND theo tỷ giá thị trường
// Dùng chung cho Ví tiền mạng xã hội và Ví tiền Công cụ AI — một ví chung cả mạng lưới
// ⚠️ Bấm "Tôi đã chuyển khoản" CHỈ tạo giao dịch pending — số dư chỉ được cộng SAU khi
//    Ban Giám đốc duyệt ở Cài đặt → Duyệt nạp/rút

import { useEffect, useMemo, useState } from 'react'
import QRCode from 'qrcode'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Banknote, Check, ChevronRight, Coins, Copy, Hourglass, Loader2, QrCode, ScanLine, ShieldCheck } from 'lucide-react'
import { useUsdRate } from '@/lib/use-usd-rate'
import { fmtUsdNumber } from '@/lib/format'

export const BANK = {
  name: 'TECHCOMBANK',
  bin: '970415', // đúng mã BIN Techcombank (trên app hiện “TECHCOMBANK, VietQR, Napas 247”)
  account: '2461388888',
  holder: 'TRAN NGOC SON',
  city: 'QUANG TRI',
}

/** Gói nạp USD (r30): user chọn $X → chuyển khoản VND = X × tỷ giá sống → ví được cộng đúng $X */
export const TOPUP_PACKS = [
  { usd: 0.5, label: 'Gói thử' },
  { usd: 1, label: 'Gói nhỏ' },
  { usd: 2, label: 'Gói vừa' },
  { usd: 5, label: 'Phổ biến' },
  { usd: 10, label: 'Tiết kiệm' },
  { usd: 20, label: 'Siêu tiết kiệm' },
]

const fmtVnd = (n: number) => n.toLocaleString('vi-VN')

// ── Sinh payload chuẩn VietQR (EMVCo) — CRC16-CCITT-FALSE ──
function tlv(id: string, value: string): string {
  return `${id}${String(value.length).padStart(2, '0')}${value}`
}

function crc16(s: string): string {
  let crc = 0xffff
  for (let i = 0; i < s.length; i++) {
    crc ^= s.charCodeAt(i) << 8
    for (let b = 0; b < 8; b++) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0')
}

export function buildVietQrPayload(amount: number, message: string): string {
  // Tag 38 — Merchant Account Information chuẩn Napas 247:
  //   00 = GUID Napas A000000727, 01 = mã dịch vụ chuyển nhanh QRIBFTTA, 02 = BIN + số TK
  const merchant = tlv('00', 'A000000727') + tlv('01', 'QRIBFTTA') + tlv('02', BANK.bin + BANK.account)
  let p = tlv('00', '01') + tlv('01', '12') + tlv('38', merchant)
  p += tlv('52', '5899') // MCC
  p += tlv('53', '704') // VND
  if (amount > 0) p += tlv('54', String(Math.round(amount)))
  p += tlv('58', 'VN')
  p += tlv('59', BANK.holder.slice(0, 25)) // tên chủ TK (không dấu)
  p += tlv('60', BANK.city.slice(0, 15)) // thành phố
  p += tlv('62', tlv('08', message.slice(0, 25))) // nội dung chuyển khoản
  p += '6304'
  return p + crc16(p)
}

function CopyRow({ label, value }: { label: string; value: string }) {
  return (
    <button
      className="flex w-full items-center justify-between gap-2 rounded-lg border bg-white px-3 py-2 text-left transition hover:bg-stone-50"
      onClick={async () => {
        try { await navigator.clipboard.writeText(value); toast.success(`Đã sao chép ${label}`) } catch { toast.error('Không sao chép được') }
      }}
      aria-label={`Sao chép ${label}`}
    >
      <span className="text-xs text-stone-500">{label}</span>
      <span className="flex items-center gap-1.5 text-sm font-bold text-stone-800">
        {value} <Copy className="h-3.5 w-3.5 text-stone-400" />
      </span>
    </button>
  )
}

export function BankTopUpDialog({
  open,
  onOpenChange,
  username,
  onSubmitted,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  username: string
  /** Gọi khi người dùng xác nhận đã chuyển khoản — yêu cầu nạp CHỜ DUYỆT đã tạo (chưa có xu) */
  onSubmitted?: (xu: number, vnd: number) => void
}) {
  const [packIdx, setPackIdx] = useState(0)
  const [customUsd, setCustomUsd] = useState('')
  const [qr, setQr] = useState<string | null>(null)
  const [paid, setPaid] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const rate = useUsdRate() // tỷ giá sống — quy USD → VND cho QR chuyển khoản

  const pack = TOPUP_PACKS[packIdx]
  const custom = Number(customUsd.replace(',', '.').replace(/[^\d.]/g, '')) || 0
  const useCustom = custom >= 0.5
  const usd = useCustom ? custom : pack.usd
  const vnd = Math.round(usd * rate)
  const message = useMemo(() => `NAPXU ${username}`.slice(0, 25), [username])

  // Sinh QR VietQR sau 1 nhịp (tránh setState đồng bộ trong effect) + reset trạng thái khi đóng
  useEffect(() => {
    let alive = true
    const t = setTimeout(() => {
      if (!open) { setQr(null); setPaid(false); return }
      const payload = buildVietQrPayload(vnd, message)
      QRCode.toDataURL(payload, { width: 320, margin: 1, errorCorrectionLevel: 'M' })
        .then((url) => { if (alive) setQr(url) })
        .catch(() => { if (alive) setQr(null) })
    }, 0)
    return () => { alive = false; clearTimeout(t) }
  }, [open, vnd, message])

  const handleClose = (v: boolean) => {
    if (!v) setPaid(false)
    onOpenChange(v)
  }

  // Xác nhận lần 2 → tạo yêu cầu NẠP chờ duyệt (không cộng số dư tức thời)
  const confirm = async () => {
    if (!paid) { setPaid(true); return }
    setSubmitting(true)
    try {
      const res = await fetch('/api/vx/wallet-tx', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'deposit', amountUsd: usd, proofCode: message, bankName: BANK.name, accountNumber: BANK.account, accountHolder: BANK.holder }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Không tạo được yêu cầu nạp')
      toast.success(`Đã ghi nhận yêu cầu nạp +$${fmtUsdNumber(usd)} vào ví (chuyển ${fmtVnd(vnd)}đ)`, { description: 'Chờ Ban Giám đốc đối soát và duyệt — số dư sẽ được cộng sau khi duyệt' })
      onSubmitted?.(d.tx.amountXu, vnd)
      setPaid(false)
      handleClose(false)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không tạo được yêu cầu nạp, thử lại nhé')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><ScanLine className="h-5 w-5 text-emerald-600" /> Nạp tiền qua QR ngân hàng</DialogTitle>
        </DialogHeader>

        {/* Chọn mệnh giá USD */}
        <div>
          <p className="mb-2 text-xs font-semibold text-stone-500">CHỌN SỐ TIỀN NẠP (USD)</p>
          <div className="grid grid-cols-3 gap-2">
            {TOPUP_PACKS.map((p, i) => (
              <button
                key={p.usd}
                onClick={() => { setPackIdx(i); setCustomUsd('') }}
                className={`rounded-xl border p-2.5 text-center transition ${packIdx === i && !useCustom ? 'border-emerald-600 bg-emerald-50 shadow-sm' : 'border-stone-200 bg-white hover:border-emerald-300'}`}
                aria-label={`Nạp $${fmtUsdNumber(p.usd)} vào ví`}
              >
                <p className="text-sm font-extrabold text-stone-800">${fmtUsdNumber(p.usd)}</p>
                <p className="mt-0.5 text-[11px] font-bold text-emerald-700">+${fmtUsdNumber(p.usd)} vào ví</p>
                <p className="text-[9px] font-semibold text-amber-600">{p.label}</p>
              </button>
            ))}
          </div>
          <div className="mt-2 flex items-center gap-2">
            <Input
              value={customUsd}
              onChange={(e) => setCustomUsd(e.target.value)}
              placeholder="Hoặc nhập số USD khác (tối thiểu 0,50)"
              inputMode="decimal"
              className="h-9 text-sm"
              aria-label="Số tiền USD tùy chọn"
            />
          </div>
        </div>

        {/* QR + thông tin chuyển khoản */}
        <div className="rounded-2xl border border-emerald-200 bg-gradient-to-b from-emerald-50/80 to-white p-4">
          <div className="flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-sm font-bold text-stone-800"><Banknote className="h-4 w-4 text-emerald-600" /> {BANK.name}</p>
            <p className="text-xs font-semibold text-stone-500">Chủ TK: {BANK.holder}</p>
          </div>
          <div className="mt-3 flex flex-col items-center gap-2">
            {qr ? (
              <img src={qr} alt={`Mã QR chuyển khoản ${fmtVnd(vnd)}đ, nội dung ${message}`} className="h-48 w-48 rounded-xl border bg-white p-1.5" />
            ) : (
              <div className="flex h-48 w-48 items-center justify-center rounded-xl border bg-white"><Loader2 className="h-6 w-6 animate-spin text-emerald-600" /></div>
            )}
            <p className="flex flex-wrap items-center justify-center gap-1.5 text-2xl font-black text-emerald-700">
              <Coins className="h-5 w-5 text-amber-500" /> ${fmtUsdNumber(usd)} <span className="text-sm font-bold text-stone-500">= chuyển {fmtVnd(vnd)}đ</span>
            </p>
            <p className="text-[10px] text-stone-400">Quy theo tỷ giá thị trường {fmtVnd(rate)}đ/$</p>
            <p className="flex flex-wrap items-center justify-center gap-x-0.5 gap-y-0.5 text-[11px] leading-relaxed text-stone-500">
              <span>Mở app ngân hàng</span>
              <ChevronRight className="h-3 w-3 text-stone-400" />
              <span>quét mã QR</span>
              <ChevronRight className="h-3 w-3 text-stone-400" />
              <span>số tiền &amp; nội dung đã điền sẵn (<b>NAPXU {username}</b>)</span>
            </p>
          </div>
          <div className="mt-3 space-y-1.5">
            <CopyRow label="Số tài khoản" value={BANK.account} />
            <CopyRow label="Số tiền" value={String(vnd)} />
            <CopyRow label="Nội dung" value={message} />
          </div>
        </div>

        <Button className="h-11 w-full gap-2 bg-emerald-600 text-base font-semibold hover:bg-emerald-700" disabled={!qr || submitting || usd < 0.5} onClick={confirm} aria-label="Xác nhận đã chuyển khoản">
          {submitting ? <><Loader2 className="h-5 w-5 animate-spin" /> Đang ghi nhận...</> : paid ? <><Check className="h-5 w-5" /> Xác nhận đã chuyển {fmtVnd(vnd)}đ</> : <><QrCode className="h-5 w-5" /> Tôi đã chuyển khoản</>}
        </Button>

        <p className="flex items-start gap-1.5 rounded-lg bg-amber-50 p-2.5 text-[11px] leading-relaxed text-amber-800">
          <Hourglass className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" />
          Sau khi bấm xác nhận, yêu cầu nạp ở trạng thái <b>Chờ duyệt</b>. Ban Giám đốc đối soát với ngân hàng và duyệt — lúc đó {fmtVnd(vnd)}đ mới đổi thành <b>+${fmtUsdNumber(usd)}</b> vào ví tiền. Theo dõi trạng thái ở mục Ví tiền.
        </p>

        <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-stone-500">
          <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
          Ví tiền USD chung cho cả mạng lưới Vexon — nạp vào dùng được cho Công cụ AI, Vexon AI và mọi phân hệ. Nạp bằng chuyển khoản ngân hàng (VND) quy theo tỷ giá thị trường {fmtVnd(rate)}đ/$; giao dịch được đối soát thủ công bởi Ban Giám đốc để chống lạm phát.
        </p>
      </DialogContent>
    </Dialog>
  )
}

/** Nút mở dialog nạp tiền (dùng ở mọi phân hệ) */
export function BankTopUpButton({
  username,
  onSubmitted,
  className,
  label = 'Nạp tiền qua QR',
}: {
  username: string
  onSubmitted?: (xu: number, vnd: number) => void
  className?: string
  label?: string
}) {
  const [open, setOpen] = useState(false)
  return (
    <>
      <Button onClick={() => setOpen(true)} className={className} aria-label="Nạp tiền bằng quét mã QR ngân hàng">
        <ScanLine className="mr-1 h-4 w-4" /> {label}
      </Button>
      <BankTopUpDialog open={open} onOpenChange={setOpen} username={username} onSubmitted={onSubmitted} />
    </>
  )
}
