'use client'

import {
  Globe, Users2, Lock, ThumbsUp, Heart, Smile, Laugh, Frown, Angry, HeartHandshake, HeartCrack, Hand,
  Sparkles, PartyPopper, Rocket, Lightbulb, Pin, Phone, Clock, Star, Flame, MessageCircle, Ruler,
  ReceiptText, Truck, Wallet, ClipboardList, Target, Palette, Wrench, CalendarDays, Megaphone, CircleHelp, Coffee,
  Construction, UtensilsCrossed, BarChart3, MessagesSquare, Laptop, Leaf, Trophy, Building2, Users,
  Flower2, Cake, Gem, Crown, Medal, Plane, Gift,
  type LucideIcon,
} from 'lucide-react'

// Thành phần + hàm dùng chung cho Vexon (Feed / Chat / ...)

export const REACTIONS = [
  { type: 'LIKE', emoji: 'LIKE', color: '#0866ff', label: 'Thích' },
  { type: 'LOVE', emoji: 'LOVE', color: '#f33e58', label: 'Yêu thích' },
  { type: 'CARE', emoji: 'CARE', color: '#f7b125', label: 'Thương thương' },
  { type: 'HAHA', emoji: 'HAHA', color: '#f7b125', label: 'Haha' },
  { type: 'WOW', emoji: 'WOW', color: '#f7b125', label: 'Wow' },
  { type: 'SAD', emoji: 'SAD', color: '#f7b125', label: 'Buồn' },
  { type: 'ANGRY', emoji: 'ANGRY', color: '#e9710f', label: 'Phẫn nộ' },
] as const

// Icon cảm xúc vẽ SVG (không dùng kí tự emoji — nhìn sắc nét trên mọi thiết bị)
function ReactionFace({ mood, className = 'h-4 w-4' }: { mood: 'care' | 'haha' | 'wow' | 'sad' | 'angry'; className?: string }) {
  const bg = mood === 'angry' ? '#e9710f' : '#f7b125'
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden focusable="false">
      <circle cx="12" cy="12" r="10" fill={bg} />
      {mood === 'care' && (
        <>
          <path d="M9 10.2c.5-.9 1.9-.9 2.4 0-.4 1-1.5 1.6-1.2 1.6s-.8-.6-1.2-1.6z" fill="#e31b23" />
          <path d="M12.6 10.2c.5-.9 1.9-.9 2.4 0-.4 1-1.5 1.6-1.2 1.6s-.8-.6-1.2-1.6z" fill="#e31b23" />
          <path d="M8 14.4c1.1 1.5 2.4 2.2 4 2.2s2.9-.7 4-2.2" stroke="#8a4b00" strokeWidth="1.6" strokeLinecap="round" fill="none" />
          <path d="M17.5 16.2c1.4-1.1 3-.6 3 .8 0 1.2-1.6 2.4-3 3.2-1.4-.8-3-2-3-3.2 0-1.4 1.6-1.9 3-.8z" fill="#e31b23" />
        </>
      )}
      {mood === 'haha' && (
        <>
          <path d="M7.3 9.7c.7-.8 2-.8 2.7 0" stroke="#8a4b00" strokeWidth="1.5" strokeLinecap="round" fill="none" />
          <path d="M14 9.7c.7-.8 2-.8 2.7 0" stroke="#8a4b00" strokeWidth="1.5" strokeLinecap="round" fill="none" />
          <path d="M7.5 13.5h9c0 2.5-2 4.5-4.5 4.5s-4.5-2-4.5-4.5z" fill="#5f2f0c" />
          <path d="M9.6 16.4c1.5.9 3.3.9 4.8 0-.6 1-1.4 1.6-2.4 1.6s-1.8-.6-2.4-1.6z" fill="#ff7285" />
        </>
      )}
      {mood === 'wow' && (
        <>
          <ellipse cx="8.8" cy="10" rx="1.4" ry="1.9" fill="#5f2f0c" />
          <ellipse cx="15.2" cy="10" rx="1.4" ry="1.9" fill="#5f2f0c" />
          <ellipse cx="12" cy="16" rx="2.2" ry="3" fill="#5f2f0c" />
        </>
      )}
      {mood === 'sad' && (
        <>
          <circle cx="8.8" cy="10" r="1.3" fill="#5f2f0c" />
          <circle cx="15.2" cy="10" r="1.3" fill="#5f2f0c" />
          <path d="M8 16.8c1-1.4 2.3-2.1 4-2.1s3 .7 4 2.1" stroke="#8a4b00" strokeWidth="1.6" strokeLinecap="round" fill="none" />
          <path d="M7.2 11.5c.9.4.9 1.9 0 2.4-.9-.5-.9-2 0-2.4z" fill="#57a0ff" />
        </>
      )}
      {mood === 'angry' && (
        <>
          <path d="M6.8 8.2l3 1.4M17.2 8.2l-3 1.4" stroke="#5f2f0c" strokeWidth="1.5" strokeLinecap="round" />
          <circle cx="9" cy="11.4" r="1.2" fill="#5f2f0c" />
          <circle cx="15" cy="11.4" r="1.2" fill="#5f2f0c" />
          <path d="M8.2 16.6c1-1.3 2.2-2 3.8-2s2.8.7 3.8 2" stroke="#5f2f0c" strokeWidth="1.6" strokeLinecap="round" fill="none" />
        </>
      )}
    </svg>
  )
}

export function ReactionIcon({ type, className = 'h-4 w-4' }: { type: string; className?: string }) {
  if (type === 'LOVE') return <Heart className={className} style={{ color: '#f33e58', fill: '#f33e58' }} />
  if (type === 'CARE') return <ReactionFace mood="care" className={className} />
  if (type === 'HAHA') return <ReactionFace mood="haha" className={className} />
  if (type === 'WOW') return <ReactionFace mood="wow" className={className} />
  if (type === 'SAD') return <ReactionFace mood="sad" className={className} />
  if (type === 'ANGRY') return <ReactionFace mood="angry" className={className} />
  return <ThumbsUp className={className} style={{ color: '#0866ff', fill: '#0866ff' }} />
}

// Ảnh cảm xúc tin nhắn → icon SVG: nhận key kiểu reaction (LOVE/LIKE/...) hoặc emoji cũ trong dữ liệu
const LEGACY_REACTION_TYPE: Record<string, string> = {
  '❤️': 'LOVE', '❤': 'LOVE', '👍': 'LIKE', '😆': 'HAHA', '😄': 'HAHA', '😂': 'HAHA',
  '😮': 'WOW', '😢': 'SAD', '😡': 'ANGRY',
}
export function EmojiLikeIcon({ emoji, className = 'h-4 w-4' }: { emoji: string; className?: string }) {
  const type = LEGACY_REACTION_TYPE[emoji] ?? emoji
  return <ReactionIcon type={type} className={className} />
}

export const POST_BACKGROUNDS = [
  'linear-gradient(135deg, #f43f5e 0%, #f97316 100%)',
  'linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)',
  'linear-gradient(135deg, #0ea5e9 0%, #22d3ee 100%)',
  'linear-gradient(135deg, #10b981 0%, #84cc16 100%)',
  'linear-gradient(135deg, #f59e0b 0%, #fde047 100%)',
  'linear-gradient(135deg, #0f172a 0%, #334155 100%)',
  'linear-gradient(135deg, #d946ef 0%, #a855f7 50%, #6366f1 100%)',
  'linear-gradient(135deg, #14b8a6 0%, #0ea5e9 100%)',
]

export const STORY_BGS = [
  '#ec4899,#f97316',
  '#0ea5e9,#22d3ee',
  '#8b5cf6,#d946ef',
  '#10b981,#84cc16',
  '#0f172a,#334155',
  '#f59e0b,#ef4444',
]

// ============ STICKER HÌNH ẢNH VECTOR (thay thế hoàn toàn kí tự emoji) ============
// Sticker là hình vẽ SVG sắc nét trên mọi thiết bị — lưu key trong tin nhắn (content = key)
export interface StickerDef { key: string; label: string; color: string; Icon: LucideIcon }

export const STICKERS: StickerDef[] = [
  { key: 'smile', label: 'Vui vẻ', color: '#f7b125', Icon: Smile },
  { key: 'laugh', label: 'Cười lớn', color: '#f59e0b', Icon: Laugh },
  { key: 'love', label: 'Tim', color: '#f33e58', Icon: Heart },
  { key: 'like', label: 'Thích', color: '#0866ff', Icon: ThumbsUp },
  { key: 'clap', label: 'Vỗ tay', color: '#d97706', Icon: Hand },
  { key: 'care', label: 'Thương thương', color: '#ec4899', Icon: HeartHandshake },
  { key: 'wow', label: 'Ngạc nhiên', color: '#8b5cf6', Icon: Sparkles },
  { key: 'sad', label: 'Buồn', color: '#0ea5e9', Icon: Frown },
  { key: 'cry', label: 'Khóc', color: '#38bdf8', Icon: HeartCrack },
  { key: 'angry', label: 'Giận', color: '#ef4444', Icon: Angry },
  { key: 'star', label: 'Sao', color: '#eab308', Icon: Star },
  { key: 'fire', label: 'Lửa', color: '#f97316', Icon: Flame },
  { key: 'party', label: 'Ăn mừng', color: '#a855f7', Icon: PartyPopper },
  { key: 'rocket', label: 'Bắn tung', color: '#10b981', Icon: Rocket },
  { key: 'idea', label: 'Ý tưởng', color: '#facc15', Icon: Lightbulb },
  { key: 'pin', label: 'Ghim', color: '#ef4444', Icon: Pin },
  { key: 'phone', label: 'Gọi điện', color: '#14b8a6', Icon: Phone },
  { key: 'clock', label: 'Thời gian', color: '#78716c', Icon: Clock },
]

// Dữ liệu cũ lưu emoji trước khi đổi sang hình ảnh — ánh xạ sang sticker vector tương ứng
const LEGACY_EMOJI_STAMP: Record<string, string> = {
  '😀': 'smile', '😄': 'laugh', '😂': 'laugh', '😆': 'laugh', '😅': 'laugh', '🥰': 'care', '😍': 'love',
  '😎': 'smile', '🤝': 'care', '👍': 'like', '💪': 'like', '🙏': 'care', '❤️': 'love', '❤': 'love',
  '🔥': 'fire', '🎉': 'party', '👏': 'clap', '🤔': 'idea', '😭': 'cry', '✅': 'like', '📝': 'pin',
  '🚀': 'rocket', '⭐': 'star', '💡': 'idea', '📞': 'phone', '📌': 'pin', '⏰': 'clock', '😮': 'wow',
  '😢': 'sad', '😡': 'angry',
}

/** Hình sticker vector — nhận key mới hoặc emoji cũ trong dữ liệu (tự ánh xạ sang hình tương ứng) */
export function StickerStamp({ content, size = 64, className = '' }: { content: string; size?: number; className?: string }) {
  const key = STICKERS.find((s) => s.key === content) ? content : LEGACY_EMOJI_STAMP[content]
  const def = STICKERS.find((s) => s.key === key)
  if (!def) return <span className={className} style={{ fontSize: size * 0.8, lineHeight: 1 }}>{content}</span>
  const { Icon, color } = def
  return (
    <span
      className={`inline-flex items-center justify-center rounded-3xl shadow-sm ${className}`}
      style={{ width: size, height: size, backgroundColor: `${color}26`, border: `2px solid ${color}59` }}
      role="img"
      aria-label={`Sticker ${def.label}`}
    >
      <Icon style={{ width: size * 0.52, height: size * 0.52, color }} strokeWidth={2.4} />
    </span>
  )
}

export function stickerLabel(content: string): string {
  const key = STICKERS.find((s) => s.key === content) ? content : LEGACY_EMOJI_STAMP[content]
  return STICKERS.find((s) => s.key === key)?.label || 'Sticker'
}

// ============ BIỂU TƯỢNG CHỦ ĐỀ (nhóm tách luồng) — hình vector, lưu key ============
export const TOPIC_ICON_ITEMS: { key: string; label: string; color: string; Icon: LucideIcon }[] = [
  { key: 'chat', label: 'Trò chuyện', color: '#10b981', Icon: MessageCircle },
  { key: 'design', label: 'Thiết kế', color: '#0ea5e9', Icon: Ruler },
  { key: 'bill', label: 'Hóa đơn', color: '#f59e0b', Icon: ReceiptText },
  { key: 'ship', label: 'Vận chuyển', color: '#f97316', Icon: Truck },
  { key: 'money', label: 'Tài chính', color: '#059669', Icon: Wallet },
  { key: 'list', label: 'Công việc', color: '#38bdf8', Icon: ClipboardList },
  { key: 'goal', label: 'Mục tiêu', color: '#f43f5e', Icon: Target },
  { key: 'art', label: 'Nghệ thuật', color: '#8b5cf6', Icon: Palette },
  { key: 'fix', label: 'Sửa chữa', color: '#d97706', Icon: Wrench },
  { key: 'plan', label: 'Lịch', color: '#6366f1', Icon: CalendarDays },
  { key: 'announce', label: 'Thông báo', color: '#ec4899', Icon: Megaphone },
  { key: 'ask', label: 'Hỏi đáp', color: '#78716c', Icon: CircleHelp },
]

// Dữ liệu cũ lưu emoji cho biểu tượng chủ đề — tự ánh xạ sang hình vector tương ứng
const LEGACY_EMOJI_TOPIC: Record<string, string> = {
  '💬': 'chat', '📐': 'design', '🧾': 'bill', '🚚': 'ship', '💰': 'money', '📋': 'list',
  '🎯': 'goal', '🎨': 'art', '🔧': 'fix', '📅': 'plan', '📢': 'announce', '❓': 'ask',
}

/** Hình biểu tượng chủ đề (dùng trên chip chủ đề + danh sách quản lý) */
export function TopicStamp({ icon, size = 18, className = '' }: { icon: string; size?: number; className?: string }) {
  const key = TOPIC_ICON_ITEMS.find((t) => t.key === icon) ? icon : LEGACY_EMOJI_TOPIC[icon]
  const def = TOPIC_ICON_ITEMS.find((t) => t.key === key)
  if (!def) return <CircleHelp className={className} style={{ width: size, height: size, color: '#78716c' }} aria-label="Chủ đề" />
  return (
    <span
      className={`inline-flex shrink-0 items-center justify-center rounded-lg ${className}`}
      style={{ width: size, height: size, backgroundColor: `${def.color}1f` }}
      role="img"
      aria-label={`Chủ đề ${def.label}`}
    >
      <def.Icon style={{ width: size * 0.62, height: size * 0.62, color: def.color }} strokeWidth={2.4} />
    </span>
  )
}

// ============ BIỂU TƯỢNG NHÓM — hình vector, lưu key (dùng chung Tin nhắn + Nhóm) ============
export const GROUP_ICON_ITEMS: { key: string; label: string; Icon: LucideIcon }[] = [
  { key: 'members', label: 'Nhóm', Icon: Users }, { key: 'message', label: 'Trò chuyện', Icon: MessagesSquare },
  { key: 'building', label: 'Công ty', Icon: Building2 }, { key: 'crane', label: 'Xây dựng', Icon: Construction },
  { key: 'rocket', label: 'Dự án', Icon: Rocket }, { key: 'party', label: 'Sự kiện', Icon: PartyPopper },
  { key: 'football', label: 'Thể thao', Icon: Trophy }, { key: 'food', label: 'Ăn uống', Icon: UtensilsCrossed },
  { key: 'megaphone', label: 'Truyền thông', Icon: Megaphone }, { key: 'laptop', label: 'Công nghệ', Icon: Laptop },
  { key: 'wrench', label: 'Kỹ thuật', Icon: Wrench }, { key: 'chart', label: 'Kinh doanh', Icon: BarChart3 },
  { key: 'leaf', label: 'Cuộc sống', Icon: Leaf },
]

const GROUP_ICON_MAP: Record<string, LucideIcon> = Object.fromEntries(GROUP_ICON_ITEMS.map((g) => [g.key, g.Icon]))

// Dữ liệu cũ lưu emoji nhóm — tự ánh xạ sang hình vector tương ứng
const LEGACY_EMOJI_GROUP: Record<string, string> = {
  '👥': 'members', '🏗️': 'crane', '🏗': 'crane', '💻': 'laptop', '🎉': 'party', '⚽': 'football',
  '☕': 'food', '📢': 'megaphone', '🔧': 'wrench', '📊': 'chart', '🌿': 'leaf', '📚': 'members',
  '🎵': 'party', '🍜': 'food', '🚀': 'rocket',
}

export function groupIconOf(avatar: string | null | undefined): LucideIcon | null {
  if (!avatar) return null
  const key = GROUP_ICON_MAP[avatar] ? avatar : LEGACY_EMOJI_GROUP[avatar]
  return key ? GROUP_ICON_MAP[key] || null : null
}

// ============ QUÀ LIVE — hình vector theo mã quà (không dùng kí tự emoji) ============
const GIFT_ICON_MAP: Record<string, { Icon: LucideIcon; color: string }> = {
  rose: { Icon: Flower2, color: '#f43f5e' },
  coffee: { Icon: Coffee, color: '#a16207' },
  cake: { Icon: Cake, color: '#ec4899' },
  diamond: { Icon: Gem, color: '#0ea5e9' },
  rocket: { Icon: Rocket, color: '#10b981' },
  crown: { Icon: Crown, color: '#eab308' },
  lion: { Icon: Medal, color: '#f97316' },
  plane: { Icon: Plane, color: '#6366f1' },
}

// Dữ liệu cũ lưu emoji quà — ánh xạ sang hình vector tương ứng
const LEGACY_EMOJI_GIFT: Record<string, string> = {
  '🌹': 'rose', '☕': 'coffee', '🎂': 'cake', '💎': 'diamond', '🚀': 'rocket', '👑': 'crown', '🦁': 'lion', '✈️': 'plane', '✈': 'plane',
}

export function GiftStamp({ code, size = 28, className = '' }: { code: string; size?: number; className?: string }) {
  const key = GIFT_ICON_MAP[code] ? code : LEGACY_EMOJI_GIFT[code]
  const def = key ? GIFT_ICON_MAP[key] : undefined
  if (!def) return <Gift className={className} style={{ width: size, height: size, color: '#a855f7' }} aria-label="Quà" />
  return (
    <span
      className={`inline-flex shrink-0 items-center justify-center rounded-full ${className}`}
      style={{ width: size, height: size, backgroundColor: `${def.color}24` }}
      role="img"
      aria-label="Quà live"
    >
      <def.Icon style={{ width: size * 0.58, height: size * 0.58, color: def.color }} strokeWidth={2.4} />
    </span>
  )
}

/** Hình vẽ đa dụng cho reaction/quat live bay trên màn hình: key mới hoặc dữ liệu cũ */
export function StampAny({ value, size = 32, className = '' }: { value: string; size?: number; className?: string }) {
  const t = LEGACY_REACTION_TYPE[value] ?? value
  if (['LIKE', 'LOVE', 'CARE', 'HAHA', 'WOW', 'SAD', 'ANGRY'].includes(t)) {
    return <span className={className}><ReactionIcon type={t} className="h-full w-full" /></span>
  }
  if (value === 'FIRE') return <Flame className={className} style={{ width: size, height: size, color: '#f97316' }} aria-label="Thả lửa" />
  if (value === 'CLAP') return <Hand className={className} style={{ width: size, height: size, color: '#d97706' }} aria-label="Vỗ tay" />
  const giftKey = GIFT_ICON_MAP[value] ? value : LEGACY_EMOJI_GIFT[value]
  if (giftKey) return <GiftStamp code={giftKey} size={size} className={className} />
  const stickerKey = STICKERS.find((s) => s.key === value) ? value : LEGACY_EMOJI_STAMP[value]
  if (stickerKey) return <StickerStamp content={stickerKey} size={size} className={className} />
  return <Sparkles className={className} style={{ width: size, height: size, color: '#8b5cf6' }} />
}

// Chế độ hiển thị bài viết (kiểu Facebook): Công khai / Bạn bè / Riêng tư
export const VISIBILITY_OPTIONS = [
  { key: 'public', label: 'Công khai', desc: 'Ai trên Vexon cũng thấy bài viết', icon: <Globe className="h-3.5 w-3.5" /> },
  { key: 'friends', label: 'Bạn bè', desc: 'Chỉ bạn bè của bạn thấy bài viết', icon: <Users2 className="h-3.5 w-3.5" /> },
  { key: 'private', label: 'Riêng tư', desc: 'Chỉ mình bạn thấy bài viết', icon: <Lock className="h-3.5 w-3.5" /> },
] as const

export type PostVisibility = (typeof VISIBILITY_OPTIONS)[number]['key']

export function visibilityOf(key: string) {
  return VISIBILITY_OPTIONS.find((v) => v.key === key) || VISIBILITY_OPTIONS[0]
}

export function timeAgo(iso: string | Date): string {
  const d = typeof iso === 'string' ? new Date(iso) : iso
  const s = Math.floor((Date.now() - d.getTime()) / 1000)
  if (s < 60) return 'vừa xong'
  const m = Math.floor(s / 60)
  if (m < 60) return `${m} phút trước`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h} giờ trước`
  const dd = Math.floor(h / 24)
  if (dd < 7) return `${dd} ngày trước`
  return d.toLocaleDateString('vi-VN')
}

export function fmtSize(bytes?: number | null): string {
  if (!bytes || bytes <= 0) return ''
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

export function Avatar({ name, color, size = 40, online, ring, img }: { name: string; color: string; size?: number; online?: boolean; ring?: boolean; img?: string | null }) {
  const initials = (name || '?').trim().split(/\s+/).slice(-2).map((w) => w[0]).join('').toUpperCase().slice(0, 2)
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      {img ? (
        <img src={img} alt={name} className={`h-full w-full rounded-full object-cover ${ring ? 'ring-2 ring-emerald-500 ring-offset-2' : ''}`} />
      ) : (
        <div
          className={`flex h-full w-full items-center justify-center rounded-full font-bold text-white ${ring ? 'ring-2 ring-emerald-500 ring-offset-2' : ''}`}
          style={{ backgroundColor: color, fontSize: size * 0.36 }}
        >
          {initials}
        </div>
      )}
      {online !== undefined && online && (
        <span className="absolute bottom-0 right-0 block rounded-full border-2 border-white bg-emerald-500" style={{ width: size * 0.28, height: size * 0.28 }} />
      )}
    </div>
  )
}

// "grad:#a|#b|Nhãn" -> gradient; ngược lại là dataURL ảnh
export function isGradMedia(v: string): boolean {
  return typeof v === 'string' && v.startsWith('grad:')
}

export function GradMedia({ value, className }: { value: string; className?: string }) {
  const [, from = '#94a3b8', to = '#64748b', label = ''] = value.split('|')
  return (
    <div className={`flex items-center justify-center bg-gradient-to-br ${className || ''}`} style={{ backgroundImage: `linear-gradient(135deg, ${from.replace('grad:', '')} 0%, ${to} 100%)` }}>
      <span className="px-3 text-center text-sm font-semibold text-white drop-shadow">{label}</span>
    </div>
  )
}

// Nội dung bài viết: làm nổi @mention xanh
export function RichContent({ text, mentions }: { text: string; mentions: { fullName: string }[] }) {
  const names = mentions.map((m) => m.fullName).filter(Boolean)
  if (names.length === 0 || !text.includes('@')) {
    return <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">{text}</p>
  }
  const escaped = names.map((n) => n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
  const re = new RegExp(`(@(?:${escaped.join('|')}))`, 'g')
  const parts = text.split(re)
  return (
    <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">
      {parts.map((part, i) =>
        part.startsWith('@') && names.includes(part.slice(1)) ? (
          <span key={i} className="font-medium text-sky-600">
            {part}
          </span>
        ) : (
          <span key={i}>{part}</span>
        )
      )}
    </p>
  )
}
