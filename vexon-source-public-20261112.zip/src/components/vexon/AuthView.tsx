'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Video, Users, PlayCircle, CalendarCheck, MessageCircle, Loader2, Sparkles, Building2, MapPin, Coins, Briefcase, LayoutGrid, ArrowRight } from 'lucide-react'

export interface VxUserInfo {
  id: string
  username: string
  fullName: string
  role: string
  avatarColor: string
  avatarImage?: string | null
  coverImage?: string | null
  bio?: string | null
  email?: string | null
  hometown?: string | null
  education?: string | null
  birthday?: string | null
  phone?: string | null
  department?: string
  title?: string
  online?: boolean
  lastSeen?: string
  accountType?: 'personal' | 'business'
  companyName?: string | null
  usernameChanges?: number
  coins?: number
  interests?: string[]
  // Hồ sơ mở rộng + hẹn hò (khôi phục đúng bản 09c)
  ethnicity?: string | null
  citizenId?: string | null
  taxCode?: string | null
  heightCm?: number | null
  weightKg?: number | null
  relationship?: string | null
  smoking?: string | null
  drinking?: string | null
  pets?: string | null
  settings?: { theme?: 'day' | 'night'; effect?: ThemeEffectLite; effectsOn?: boolean; notifSound?: boolean; fontSize?: 'small' | 'medium' | 'large'; showOnline?: boolean; showLastSeen?: boolean; birthdayVisibility?: 'public' | 'friends' | 'private'; fieldVis?: Record<string, 'public' | 'friends' | 'private'> } | null
}

type ThemeEffectLite = 'auto' | 'spring' | 'summer' | 'autumn' | 'winter' | 'rain' | 'off'

const DEMO = [
  { username: 'admin', fullName: 'Nguyễn Văn An', role: 'Doanh nghiệp, Vexon Group', color: '#10b981' },
  { username: 'lan', fullName: 'Trần Ngọc Lan', role: 'Quản lý nhân sự', color: '#ec4899' },
  { username: 'minh', fullName: 'Nguyễn Hoàng Minh', role: 'Nhân viên kinh doanh', color: '#f59e0b' },
  { username: 'hoanglong', fullName: 'Cty XD Hoàng Long', role: 'Tài khoản doanh nghiệp', color: '#b45309' },
  { username: 'techviet', fullName: 'Cty CP TechViet', role: 'Tài khoản doanh nghiệp', color: '#4f46e5' },
]

const FEATURES = [
  { icon: <Video className="h-5 w-5" />, tint: 'bg-emerald-100 text-emerald-600', title: 'Video kiểu TikTok', desc: 'cuộn dọc, tự động phát, like & bình luận, xem video kiếm thêm' },
  { icon: <PlayCircle className="h-5 w-5" />, tint: 'bg-rose-100 text-rose-600', title: 'Livestream + quà tặng', desc: 'phòng live công khai/bảo mật, chat realtime, tặng quà bằng tiền ví' },
  { icon: <MessageCircle className="h-5 w-5" />, tint: 'bg-sky-100 text-sky-600', title: 'Tin nhắn & Nhóm', desc: 'chat 1-1, nhóm kiểu Facebook, bot riêng cho từng công ty' },
  { icon: <MapPin className="h-5 w-5" />, tint: 'bg-sky-100 text-sky-600', title: 'Radar người gần đây', desc: 'định vị GPS thật, lọc gần/xa, gửi chào' },
  { icon: <Building2 className="h-5 w-5" />, tint: 'bg-amber-100 text-amber-700', title: 'Hồ sơ doanh nghiệp', desc: 'profile năng lực, portfolio, đánh giá uy tín' },
  { icon: <Briefcase className="h-5 w-5" />, tint: 'bg-teal-100 text-teal-600', title: 'Tuyển dụng & tìm việc', desc: 'CV số, ứng tuyển 1-click, phễu ứng viên' },
  { icon: <Coins className="h-5 w-5" />, tint: 'bg-yellow-100 text-yellow-700', title: 'Ví tiền', desc: 'số dư USD, mở thẻ Vexon Pay, tặng quà live, thưởng điểm danh' },
  { icon: <CalendarCheck className="h-5 w-5" />, tint: 'bg-lime-100 text-lime-700', title: 'Điểm danh nhân viên', desc: 'check-in/out, cảnh báo muộn, chấm công' },
  { icon: <Users className="h-5 w-5" />, tint: 'bg-cyan-100 text-cyan-700', title: 'Công cụ AI + Cửa hàng', desc: 'công cụ AI tính tiền ví (2 lượt miễn phí/ngày), mua bán COD' },
]

export default function AuthView({ onAuthed }: { onAuthed: (u: VxUserInfo) => void }) {
  const [busy, setBusy] = useState(false)

  const submit = async (payload: Record<string, unknown>) => {
    setBusy(true)
    try {
      const res = await fetch('/api/vx/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (!res.ok) {
        alert(data.error || 'Có lỗi xảy ra')
        return
      }
      onAuthed(data.user)
    } finally {
      setBusy(false)
    }
  }

  const quickLogin = (username: string) => submit({ action: 'login', username, password: 'vexon123' })

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-emerald-50 via-white to-sky-50">
      {/* Thanh trên kiểu index */}
      <header className="border-b border-emerald-100/80 bg-white/70 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2.5">
            {/* Trang đăng nhập giữ logo đầy đủ (các trang khác đã bỏ logo vì splash/loading có sẵn) */}
            <img src="/vexon-logo.png" alt="Logo Vexon" className="h-10 w-10" />
            <div>
              <p className="text-lg font-black leading-tight tracking-tight text-emerald-800">Vexon</p>
              <p className="text-[11px] leading-tight text-muted-foreground">Siêu nền tảng B2B &amp; B2C</p>
            </div>
          </div>
          <span className="flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
            <LayoutGrid className="h-3.5 w-3.5" /> 12 phân hệ trong 1 app
          </span>
        </div>
      </header>

      {/* Hero + Form */}
      <div className="mx-auto grid w-full max-w-5xl flex-1 items-center gap-10 px-4 py-10 lg:grid-cols-2 lg:py-16">
        <div>
          <h1 className="text-3xl font-black leading-tight tracking-tight text-stone-800 sm:text-4xl">
            Một ứng dụng cho <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">cả công ty</span> của bạn
          </h1>
          <p className="mt-3 leading-relaxed text-stone-600">
            Mạng xã hội, video, livestream, tin nhắn nhóm với Chủ đề, tuyển dụng, hồ sơ doanh nghiệp,
            điểm danh, ví tiền USD, công cụ AI và cửa hàng, tất cả trong một.
          </p>
          <ul className="mt-6 space-y-2.5">
            {FEATURES.map((f) => (
              <li key={f.title} className="flex items-center gap-3 rounded-xl border border-stone-100 bg-white/80 p-2.5 shadow-sm">
                <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${f.tint}`}>{f.icon}</span>
                <span className="text-sm text-stone-600"><b className="text-stone-800">{f.title}</b>, {f.desc}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Form */}
        <Card className="border-emerald-100 bg-white/90 shadow-xl backdrop-blur">
          <CardContent className="p-6">
            <Tabs defaultValue="login">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Đăng nhập</TabsTrigger>
                <TabsTrigger value="register">Đăng ký</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form
                  className="space-y-4 pt-2"
                  onSubmit={(e) => {
                    e.preventDefault()
                    const fd = new FormData(e.currentTarget)
                    submit({ action: 'login', username: fd.get('username'), password: fd.get('password') })
                  }}
                >
                  <div className="space-y-2">
                    <Label htmlFor="lg-user">Tên đăng nhập hoặc email</Label>
                    <Input id="lg-user" name="username" placeholder="admin" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lg-pass">Mật khẩu</Label>
                    <Input id="lg-pass" name="password" type="password" placeholder="••••••" required />
                  </div>
                  <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={busy}>
                    {busy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : null}
                    Đăng nhập
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="register">
                <form
                  className="space-y-4 pt-2"
                  onSubmit={(e) => {
                    e.preventDefault()
                    const fd = new FormData(e.currentTarget)
                    submit({
                      action: 'register',
                      fullName: fd.get('fullName'),
                      email: fd.get('email'),
                      password: fd.get('password'),
                    })
                  }}
                >
                  <div className="space-y-2">
                    <Label htmlFor="rg-name">Họ và tên</Label>
                    <Input id="rg-name" name="fullName" placeholder="Nguyễn Văn A" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="rg-email">Email</Label>
                    <Input id="rg-email" name="email" type="email" placeholder="ban@email.com" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="rg-pass">Mật khẩu (tối thiểu 6 ký tự)</Label>
                    <Input id="rg-pass" name="password" type="password" required minLength={6} />
                  </div>
                  <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={busy}>
                    Tạo tài khoản
                  </Button>
                  <p className="text-center text-[11px] leading-relaxed text-stone-500">
                    Tên người dùng được tạo tự động, đổi được <b>1 lần duy nhất</b> trong Hồ sơ.<br />
                    Vào mạng xã hội rồi mới xin gia nhập doanh nghiệp hoặc được công ty thêm vào — tự do, không gò bó.
                  </p>
                </form>
              </TabsContent>
            </Tabs>

            {/* Đăng nhập nhanh demo */}
            <div className="mt-6 rounded-xl border border-emerald-100 bg-emerald-50/60 p-4">
              <p className="mb-3 flex items-center gap-1.5 text-xs font-medium text-emerald-800">
                <Sparkles className="h-3.5 w-3.5 text-amber-500" />
                Đăng nhập nhanh tài khoản demo (mật khẩu: vexon123)
              </p>
              <div className="space-y-2">
                {DEMO.map((d) => (
                  <button
                    key={d.username}
                    onClick={() => quickLogin(d.username)}
                    className="flex w-full items-center gap-3 rounded-lg border border-stone-200 bg-white p-2.5 text-left transition-colors hover:border-emerald-500 hover:bg-emerald-50"
                  >
                    <div className="flex h-9 w-9 items-center justify-center rounded-full text-sm font-bold text-white" style={{ backgroundColor: d.color }}>
                      {d.fullName[0]}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-stone-800">{d.fullName}</p>
                      <p className="text-xs text-stone-500">@{d.username}, {d.role}</p>
                    </div>
                    <span className="inline-flex items-center gap-0.5 text-xs font-semibold text-emerald-600">Vào ngay <ArrowRight className="h-3 w-3" /></span>
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      <p className="pb-6 text-center text-xs text-stone-500">Vexon © 2026, Nâng cấp từ hệ thống PHP gốc sang Next.js</p>
    </div>
  )
}
