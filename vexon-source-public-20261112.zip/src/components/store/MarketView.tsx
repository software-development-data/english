'use client'

// ============ CHỢ VEXON — người dùng thường tự đăng bán (kiểu marketplace) ============

import { useCallback, useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { ImagePlus, Loader2, MapPin, Plus, Search, ShoppingBag, Tag, Trash2, CheckCircle2, RotateCcw } from 'lucide-react'

interface ListingT {
  id: string
  title: string
  price: number
  category: string
  image?: string | null
  description?: string | null
  location?: string | null
  status: string
  createdAt: string
  seller: { id: string; username: string; fullName: string; avatarColor: string; avatarImage?: string | null }
  isMine: boolean
}

const CATS = ['Tất cả', 'Điện tử', 'Thời trang', 'Nhà cửa', 'Đồ ăn', 'Làm đẹp', 'Xe cộ', 'Khác']
const CAT_POST = ['Điện tử', 'Thời trang', 'Nhà cửa', 'Đồ ăn', 'Làm đẹp', 'Xe cộ', 'Khác']

const fmtVnd = (n: number) => `${Math.round(n).toLocaleString('vi-VN')}đ`
const timeAgo = (iso: string) => {
  const m = Math.floor((Date.now() - new Date(iso).getTime()) / 60000)
  if (m < 60) return `${m} phút trước`
  if (m < 1440) return `${Math.floor(m / 60)} giờ trước`
  return `${Math.floor(m / 1440)} ngày trước`
}

/** Ảnh → dataURL nén gọn (max 900px) */
async function fileToDataUrl(file: File): Promise<string> {
  const raw = await new Promise<string>((res, rej) => {
    const r = new FileReader()
    r.onload = () => res(String(r.result))
    r.onerror = () => rej(new Error('Đọc ảnh lỗi'))
    r.readAsDataURL(file)
  })
  return new Promise((res) => {
    const img = new Image()
    img.onload = () => {
      const scale = Math.min(1, 900 / Math.max(img.width, img.height))
      const c = document.createElement('canvas')
      c.width = Math.round(img.width * scale)
      c.height = Math.round(img.height * scale)
      c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height)
      res(c.toDataURL('image/jpeg', 0.72))
    }
    img.onerror = () => res(raw)
    img.src = raw
  })
}

export default function MarketView() {
  const [items, setItems] = useState<ListingT[]>([])
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState('')
  const [cat, setCat] = useState('Tất cả')
  const [showMine, setShowMine] = useState(false)
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const [form, setForm] = useState({ title: '', price: '', category: 'Khác', description: '', location: '', image: '' })
  const fileRef = useRef<HTMLInputElement>(null)

  const load = useCallback(() => {
    fetch('/api/vx/listings', { cache: 'no-store' })
      .then((r) => r.json())
      .then((d) => Array.isArray(d) && setItems(d))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => { load() }, [load])

  const pickImage = async (f: File | undefined) => {
    if (!f) return
    try {
      const dataUrl = await fileToDataUrl(f)
      setForm((s) => ({ ...s, image: dataUrl }))
    } catch { toast.error('Không đọc được ảnh') }
  }

  const post = async () => {
    if (!form.title.trim() || !form.price) { toast.error('Nhập tên sản phẩm và giá bán nhé'); return }
    setBusy(true)
    try {
      const res = await fetch('/api/vx/listings', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, price: Number(form.price.replace(/[^\d]/g, '')) }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      toast.success('Đã đăng bán! Tin của bạn đã lên Chợ Vexon')
      setOpen(false)
      setForm({ title: '', price: '', category: 'Khác', description: '', location: '', image: '' })
      load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Không đăng được tin')
    } finally { setBusy(false) }
  }

  const setStatus = async (id: string, status: string) => {
    const res = await fetch(`/api/vx/listings/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
    if (res.ok) { toast.success(status === 'sold' ? 'Đã đánh dấu ĐÃ BÁN' : 'Đã đăng lại tin'); load() }
    else toast.error('Cập nhật không thành công')
  }

  const remove = async (id: string) => {
    const res = await fetch(`/api/vx/listings/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Đã xoá tin đăng'); load() }
    else toast.error('Xoá không thành công')
  }

  const shown = items.filter(
    (l) =>
      (cat === 'Tất cả' || l.category === cat) &&
      (!showMine || l.isMine) &&
      (!q.trim() || l.title.toLowerCase().includes(q.trim().toLowerCase())),
  )

  return (
    <div className="space-y-4">
      {/* Thanh công cụ */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-52 flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm trên Chợ Vexon..." className="pl-9" aria-label="Tìm tin đăng" />
        </div>
        <Button variant={showMine ? 'default' : 'outline'} size="sm" className={showMine ? 'bg-emerald-600 hover:bg-emerald-700' : ''} onClick={() => setShowMine((s) => !s)} aria-pressed={showMine}>
          <Tag className="h-4 w-4" /> Tin của tôi
        </Button>
        <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4" /> Đăng bán
        </Button>
      </div>

      {/* Danh mục */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {CATS.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold transition ${cat === c ? 'border-emerald-600 bg-emerald-600 text-white shadow' : 'border-stone-200 bg-white text-stone-600 hover:border-emerald-300'}`}
            aria-pressed={cat === c}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Lưới tin đăng */}
      {loading ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">{[...Array(4)].map((_, i) => <div key={i} className="h-56 animate-pulse rounded-2xl bg-stone-200/70" />)}</div>
      ) : shown.length === 0 ? (
        <div className="rounded-2xl border border-dashed bg-white p-10 text-center">
          <ShoppingBag className="mx-auto mb-2 h-10 w-10 text-stone-300" />
          <p className="text-sm font-semibold">Chưa có tin đăng nào</p>
          <p className="mt-1 text-xs text-stone-500">Bấm <b>Đăng bán</b> để rao sản phẩm đầu tiên trên Chợ Vexon!</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {shown.map((l) => (
            <article key={l.id} className="group flex flex-col overflow-hidden rounded-2xl border bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg">
              <div className="relative aspect-square bg-stone-100">
                {l.image ? (
                  <img src={l.image} alt={l.title} className="h-full w-full object-cover" loading="lazy" />
                ) : (
                  <div className="flex h-full items-center justify-center text-stone-300"><ImagePlus className="h-10 w-10" /></div>
                )}
                {l.status === 'sold' && (
                  <span className="absolute inset-0 flex items-center justify-center bg-black/55 text-lg font-black tracking-wide text-white">ĐÃ BÁN</span>
                )}
                <Badge className="absolute left-2 top-2 bg-white/90 text-[10px] text-stone-700 hover:bg-white/90">{l.category}</Badge>
              </div>
              <div className="flex flex-1 flex-col gap-1 p-3">
                <p className="line-clamp-2 text-sm font-semibold leading-snug">{l.title}</p>
                <p className="text-base font-black text-emerald-700">{fmtVnd(l.price)}</p>
                <p className="flex items-center gap-1 text-[11px] text-stone-500">
                  <span className="flex h-4 w-4 items-center justify-center rounded-full text-[8px] font-bold text-white" style={{ background: l.seller.avatarColor }}>
                    {l.seller.fullName.charAt(0)}
                  </span>
                  {l.seller.fullName}
                </p>
                <p className="flex items-center gap-1 text-[10px] text-stone-400">
                  {l.location && <><MapPin className="h-3 w-3" />{l.location} · </>}
                  {timeAgo(l.createdAt)}
                </p>
                {l.isMine && (
                  <div className="mt-auto flex gap-1 pt-2">
                    {l.status === 'sold' ? (
                      <>
                        <Button size="sm" variant="outline" className="h-7 flex-1 gap-1 text-[11px]" onClick={() => setStatus(l.id, 'active')}><RotateCcw className="h-3 w-3" /> Đăng lại</Button>
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-rose-500 hover:text-rose-600" onClick={() => remove(l.id)} aria-label={`Xoá tin ${l.title}`}><Trash2 className="h-3.5 w-3.5" /></Button>
                      </>
                    ) : (
                      <>
                        <Button size="sm" className="h-7 flex-1 gap-1 bg-emerald-600 text-[11px] hover:bg-emerald-700" onClick={() => setStatus(l.id, 'sold')}><CheckCircle2 className="h-3 w-3" /> Đã bán</Button>
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-rose-500 hover:text-rose-600" onClick={() => remove(l.id)} aria-label={`Xoá tin ${l.title}`}><Trash2 className="h-3.5 w-3.5" /></Button>
                      </>
                    )}
                  </div>
                )}
              </div>
            </article>
          ))}
        </div>
      )}

      {/* Dialog đăng bán */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Đăng bán trên Chợ Vexon</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <button
              onClick={() => fileRef.current?.click()}
              className="relative flex aspect-video w-full items-center justify-center overflow-hidden rounded-xl border-2 border-dashed bg-stone-50 transition hover:border-emerald-400"
              aria-label="Chọn ảnh sản phẩm"
            >
              {form.image ? (
                <img src={form.image} alt="Ảnh sản phẩm" className="h-full w-full object-cover" />
              ) : (
                <span className="flex flex-col items-center gap-1 text-stone-400"><ImagePlus className="h-8 w-8" /><span className="text-xs font-semibold">Bấm để thêm ảnh</span></span>
              )}
            </button>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => pickImage(e.target.files?.[0])} />
            <Input value={form.title} onChange={(e) => setForm((s) => ({ ...s, title: e.target.value }))} placeholder="Tên sản phẩm, ví dụ: iPhone 13 128GB zin đẹp" aria-label="Tên sản phẩm" />
            <div className="grid grid-cols-2 gap-2">
              <Input value={form.price} onChange={(e) => setForm((s) => ({ ...s, price: e.target.value }))} placeholder="Giá bán (đ)" inputMode="numeric" aria-label="Giá bán" />
              <select
                value={form.category}
                onChange={(e) => setForm((s) => ({ ...s, category: e.target.value }))}
                className="h-9 rounded-md border border-input bg-transparent px-3 text-sm"
                aria-label="Danh mục"
              >
                {CAT_POST.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <Input value={form.location} onChange={(e) => setForm((s) => ({ ...s, location: e.target.value }))} placeholder="Khu vực (không bắt buộc)" aria-label="Khu vực" />
            <Textarea value={form.description} onChange={(e) => setForm((s) => ({ ...s, description: e.target.value }))} placeholder="Mô tả: tình trạng, bảo hành, lý do bán..." rows={3} aria-label="Mô tả sản phẩm" />
            <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={post} disabled={busy}>
              {busy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <ShoppingBag className="mr-1 h-4 w-4" />}
              Đăng bán ngay
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
