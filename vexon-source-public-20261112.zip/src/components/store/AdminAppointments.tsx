'use client'

import { useCallback, useEffect, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { fmtDateTime, APPT_STATUS } from '@/lib/format'
import { useToast } from '@/hooks/use-toast'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Mail, CalendarClock, MailCheck } from 'lucide-react'

interface EmailLog {
  id: string
  type: string
  status: string
  subject: string
  to: string
  scheduledFor: string
  sentAt?: string | null
}

interface Appointment {
  id: string
  customerName: string
  customerPhone: string
  customerEmail: string
  scheduledAt: string
  status: string
  note?: string | null
  service: { name: string; durationMin: number }
  emails: EmailLog[]
}

const EMAIL_TYPE: Record<string, string> = {
  confirmation: 'Xác nhận',
  reminder: 'Nhắc lịch',
  cancelled: 'Báo huỷ',
}

export default function AdminAppointments({ onChanged }: { onChanged: () => void }) {
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  const load = useCallback(() => {
    setLoading(true)
    fetch('/api/appointments')
      .then((r) => r.json())
      .then((data) => Array.isArray(data) && setAppointments(data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(load, [load])

  const update = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/appointments/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      load()
      onChanged()
      toast({ title: 'Đã cập nhật lịch hẹn', description: status === 'cancelled' ? 'Đã gửi email thông báo huỷ cho khách' : undefined })
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không cập nhật được', variant: 'destructive' })
    }
  }

  const now = Date.now()
  const upcoming = appointments.filter((a) => new Date(a.scheduledAt).getTime() > now && !['cancelled', 'done'].includes(a.status))

  return (
    <div className="space-y-6">
      {/* Sắp tới */}
      <div>
        <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold">
          <CalendarClock className="h-4 w-4 text-emerald-700" />
          Lịch sắp tới ({upcoming.length})
        </h3>
        {upcoming.length === 0 ? (
          <div className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">
            Chưa có lịch hẹn nào sắp tới
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {upcoming.slice(0, 6).map((a) => (
              <div key={a.id} className="rounded-xl border p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{a.customerName}</p>
                    <p className="truncate text-xs text-muted-foreground">{a.service.name}</p>
                  </div>
                  <Badge variant="secondary" className={APPT_STATUS[a.status]?.className}>{APPT_STATUS[a.status]?.label}</Badge>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">
                  {fmtDateTime(a.scheduledAt)} · {a.customerPhone}
                </p>
                <div className="mt-3 flex gap-2">
                  {a.status === 'scheduled' && (
                    <Button size="sm" variant="outline" className="h-8 flex-1" onClick={() => update(a.id, 'confirmed')}>
                      Xác nhận
                    </Button>
                  )}
                  <Button size="sm" variant="outline" className="h-8 flex-1 text-emerald-700" onClick={() => update(a.id, 'done')}>
                    Khách đã đến
                  </Button>
                  <Button size="sm" variant="outline" className="h-8 flex-1 text-red-600" onClick={() => update(a.id, 'cancelled')}>
                    Huỷ
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Tất cả lịch hẹn */}
      <div className="rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Khách hẹn</TableHead>
              <TableHead className="hidden md:table-cell">Dịch vụ</TableHead>
              <TableHead>Thời gian</TableHead>
              <TableHead>Email nhắc</TableHead>
              <TableHead>Trạng thái</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={5} className="py-10 text-center text-muted-foreground">Đang tải...</TableCell>
              </TableRow>
            ) : appointments.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="py-10 text-center text-muted-foreground">Chưa có lịch hẹn nào</TableCell>
              </TableRow>
            ) : (
              appointments.map((a) => {
                const st = APPT_STATUS[a.status] || APPT_STATUS.scheduled
                const reminder = a.emails.find((e) => e.type === 'reminder')
                return (
                  <TableRow key={a.id}>
                    <TableCell>
                      <p className="font-medium">{a.customerName}</p>
                      <p className="text-xs text-muted-foreground">{a.customerPhone} · {a.customerEmail}</p>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">{a.service.name}</TableCell>
                    <TableCell className="whitespace-nowrap">{fmtDateTime(a.scheduledAt)}</TableCell>
                    <TableCell>
                      {reminder ? (
                        <Badge variant="secondary" className={reminder.status === 'sent' ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100' : reminder.status === 'queued' ? 'bg-amber-100 text-amber-800 hover:bg-amber-100' : 'bg-gray-100 text-gray-600 hover:bg-gray-100'}>
                          {reminder.status === 'sent' ? <><MailCheck className="mr-1 h-3 w-3" />Đã gửi</> : reminder.status === 'queued' ? <><Mail className="mr-1 h-3 w-3" />Hẹn gửi</> : 'Đã gỡ'}
                        </Badge>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Select value={a.status} onValueChange={(v) => update(a.id, v)}>
                        <SelectTrigger className="w-32 border-0 p-0 shadow-none focus:ring-0" aria-label="Đổi trạng thái lịch hẹn">
                          <Badge variant="secondary" className={st.className}>{st.label}</Badge>
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(APPT_STATUS).map(([k, v]) => (
                            <SelectItem key={k} value={k}>{v.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

export { EMAIL_TYPE }
