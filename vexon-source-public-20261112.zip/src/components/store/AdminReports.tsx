'use client'

import { useCallback, useEffect, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { fmtVND, fmtDateTime, STOCK_TYPE, APPT_STATUS } from '@/lib/format'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts'
import { TrendingUp, TrendingDown, Wallet, ShoppingCart, Boxes, CalendarCheck, AlertTriangle, PackageSearch, Loader2 } from 'lucide-react'

interface ReportData {
  month: string
  summary: {
    revenue: number
    cogs: number
    grossProfit: number
    orderCount: number
    unitsSold: number
    growth: number | null
    inQty: number
    outQty: number
    stockValue: number
    retailValue: number
    productCount: number
    lowStockCount: number
    appointmentCount: number
    appointmentDone: number
    appointmentCancelled: number
    serviceCount: number
  }
  byDay: { day: string; revenue: number; orders: number }[]
  trend: { month: string; revenue: number }[]
  topProducts: { name: string; quantity: number; revenue: number }[]
  lowStock: { id: string; name: string; sku: string; stock: number; minStock: number }[]
  stockMovements: { id: string; type: string; quantity: number; stockAfter: number; createdAt: string; product: { name: string; sku: string } }[]
  appointments: { id: string; customerName: string; service: string; scheduledAt: string; status: string }[]
}

function fmtShort(n: number) {
  if (n >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(1)}tỷ`
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}tr`
  if (n >= 1_000) return `${Math.round(n / 1000)}k`
  return String(n)
}

export default function AdminReports() {
  const [month, setMonth] = useState(() => {
    const d = new Date()
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
  })
  const [data, setData] = useState<ReportData | null>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(() => {
    setLoading(true)
    fetch(`/api/reports?month=${month}`)
      .then((r) => r.json())
      .then((d) => !d.error && setData(d))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [month])

  useDeferredLoad(load, [load])

  // Danh sách 12 tháng gần nhất để chọn
  const monthOptions = Array.from({ length: 12 }, (_, i) => {
    const d = new Date()
    d.setMonth(d.getMonth() - i)
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
  })

  if (loading || !data) {
    return (
      <div className="flex items-center justify-center gap-3 py-24 text-muted-foreground">
        <Loader2 className="h-6 w-6 animate-spin" />
        <p className="text-sm">Đang tổng hợp báo cáo...</p>
      </div>
    )
  }

  const s = data.summary
  const monthLabel = new Date(`${month}-15`).toLocaleDateString('vi-VN', { month: 'long', year: 'numeric' })

  return (
    <div className="space-y-6">
      {/* Chọn tháng */}
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Báo cáo kinh doanh, {monthLabel}</h3>
        <Select value={month} onValueChange={setMonth}>
          <SelectTrigger className="w-44" aria-label="Chọn tháng báo cáo">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {monthOptions.map((m) => (
              <SelectItem key={m} value={m}>
                Tháng {m.split('-')[1]}/{m.split('-')[0]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Thẻ số liệu chính */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <Wallet className="h-5 w-5 text-emerald-700" />
              {s.growth !== null && (
                <span className={`flex items-center gap-1 text-xs font-medium ${s.growth >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {s.growth >= 0 ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
                  {Math.abs(s.growth).toFixed(0)}%
                </span>
              )}
            </div>
            <p className="mt-2 text-xl font-bold text-emerald-700 sm:text-2xl">{fmtVND(s.revenue)}</p>
            <p className="text-xs text-muted-foreground">Doanh thu (so với tháng trước)</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <TrendingUp className="h-5 w-5 text-teal-700" />
            <p className="mt-2 text-xl font-bold sm:text-2xl">{fmtVND(s.grossProfit)}</p>
            <p className="text-xs text-muted-foreground">Lợi nhuận gộp (vốn {fmtShort(s.cogs)})</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <ShoppingCart className="h-5 w-5 text-orange-600" />
            <p className="mt-2 text-xl font-bold sm:text-2xl">{s.orderCount}</p>
            <p className="text-xs text-muted-foreground">Đơn hàng · {s.unitsSold} sản phẩm bán ra</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <CalendarCheck className="h-5 w-5 text-teal-600" />
            <p className="mt-2 text-xl font-bold sm:text-2xl">{s.appointmentCount}</p>
            <p className="text-xs text-muted-foreground">Lịch hẹn ({s.appointmentDone} hoàn tất)</p>
          </CardContent>
        </Card>
      </div>

      {/* Biểu đồ */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Doanh thu theo ngày trong tháng</CardTitle>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.byDay} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="day" fontSize={10} tickMargin={6} interval={2} />
                <YAxis fontSize={10} tickFormatter={fmtShort} />
                <Tooltip formatter={(v: number) => [fmtVND(v), 'Doanh thu']} labelStyle={{ color: '#111827' }} contentStyle={{ borderRadius: 12, border: '1px solid #e5e7eb' }} />
                <Bar dataKey="revenue" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Xu hướng doanh thu 6 tháng</CardTitle>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.trend} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="month" fontSize={11} tickMargin={6} />
                <YAxis fontSize={10} tickFormatter={fmtShort} />
                <Tooltip formatter={(v: number) => [fmtVND(v), 'Doanh thu']} labelStyle={{ color: '#111827' }} contentStyle={{ borderRadius: 12, border: '1px solid #e5e7eb' }} />
                <Line type="monotone" dataKey="revenue" stroke="#f59e0b" strokeWidth={3} dot={{ r: 4, fill: '#f59e0b' }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Kho + top sản phẩm */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Boxes className="h-5 w-5" />
              Tình hình kho
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Nhập trong tháng</span>
              <span className="font-semibold text-emerald-700">+{s.inQty}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Xuất trong tháng</span>
              <span className="font-semibold text-orange-600">-{s.outQty}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Giá trị tồn kho (giá vốn)</span>
              <span className="font-semibold">{fmtVND(s.stockValue)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Giá trị bán lẻ tồn</span>
              <span className="font-semibold">{fmtVND(s.retailValue)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Số mặt hàng</span>
              <span className="font-semibold">{s.productCount}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Top 5 sản phẩm bán chạy</CardTitle>
          </CardHeader>
          <CardContent>
            {data.topProducts.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                <PackageSearch className="mx-auto mb-2 h-8 w-8" />
                Chưa có doanh số trong tháng này
              </p>
            ) : (
              <div className="space-y-3">
                {data.topProducts.map((p, i) => {
                  const max = data.topProducts[0].revenue || 1
                  return (
                    <div key={p.name} className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium">
                          <span className="mr-2 inline-flex h-5 w-5 items-center justify-center rounded-full bg-emerald-100 text-xs font-bold text-emerald-700">{i + 1}</span>
                          {p.name}
                        </span>
                        <span className="text-muted-foreground">{p.quantity} sp · {fmtVND(p.revenue)}</span>
                      </div>
                      <div className="h-2 overflow-hidden rounded-full bg-muted">
                        <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500" style={{ width: `${(p.revenue / max) * 100}%` }} />
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Cảnh báo tồn kho thấp */}
      {data.lowStock.length > 0 && (
        <Card className="border-amber-300 bg-amber-50/60">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base text-amber-800">
              <AlertTriangle className="h-5 w-5" />
              Cảnh báo: {s.lowStockCount} sản phẩm sắp hết hàng
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {data.lowStock.map((p) => (
                <Badge key={p.id} variant="secondary" className="bg-white text-amber-900 border-amber-300">
                  {p.name}: còn {p.stock} (tối thiểu {p.minStock})
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lịch hẹn trong tháng */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Lịch hẹn trong tháng ({data.appointments.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {data.appointments.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">Chưa có lịch hẹn trong tháng này</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Khách</TableHead>
                  <TableHead className="hidden sm:table-cell">Dịch vụ</TableHead>
                  <TableHead>Thời gian</TableHead>
                  <TableHead>Trạng thái</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.appointments.map((a) => {
                  const st = APPT_STATUS[a.status] || APPT_STATUS.scheduled
                  return (
                    <TableRow key={a.id}>
                      <TableCell className="font-medium">{a.customerName}</TableCell>
                      <TableCell className="hidden sm:table-cell">{a.service}</TableCell>
                      <TableCell className="whitespace-nowrap">{fmtDateTime(a.scheduledAt)}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={st.className}>{st.label}</Badge>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
