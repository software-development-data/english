'use client'

import { useEffect, useState } from 'react'
import { fmtVND } from '@/lib/format'
import { useToast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { CalendarClock, Mail, Phone, User, Clock, CheckCircle2, CalendarDays, Info } from 'lucide-react'

interface Service {
  id: string
  name: string
  durationMin: number
  price: number
}

export default function BookingView({ refreshKey }: { refreshKey: number }) {
  const [services, setServices] = useState<Service[]>([])
  const [serviceId, setServiceId] = useState('')
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [date, setDate] = useState('')
  const [time, setTime] = useState('')
  const [note, setNote] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [success, setSuccess] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    fetch('/api/services')
      .then((r) => r.json())
      .then((data) => Array.isArray(data) && setServices(data))
      .catch(() => {})
  }, [refreshKey])

  const today = new Date().toISOString().slice(0, 10)
  const selected = services.find((s) => s.id === serviceId)

  // Giờ làm việc 8:00 - 19:30, bước 30 phút
  const timeSlots = Array.from({ length: 24 }, (_, i) => {
    const h = 8 + Math.floor(i / 2)
    const m = i % 2 === 0 ? '00' : '30'
    return `${String(h).padStart(2, '0')}:${m}`
  })

  const submit = async () => {
    if (!name.trim() || !phone.trim() || !email.trim() || !serviceId || !date || !time) {
      toast({ title: 'Thiếu thông tin', description: 'Vui lòng điền đầy đủ các trường có dấu *', variant: 'destructive' })
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: name.trim(),
          customerPhone: phone.trim(),
          customerEmail: email.trim(),
          serviceId,
          scheduledAt: new Date(`${date}T${time}:00`).toISOString(),
          note: note.trim(),
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Không đặt được lịch')
      setSuccess(data.id)
      toast({ title: 'Đặt lịch thành công!', description: 'Email xác nhận đã được gửi đến hộp thư của bạn' })
    } catch (e) {
      toast({ title: 'Lỗi đặt lịch', description: e instanceof Error ? e.message : 'Vui lòng thử lại', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  if (success) {
    return (
      <Card className="mx-auto max-w-lg text-center">
        <CardContent className="flex flex-col items-center gap-4 p-10">
          <CheckCircle2 className="h-16 w-16 text-emerald-600" />
          <h2 className="text-2xl font-bold">Đặt lịch thành công!</h2>
          <div className="w-full space-y-2 rounded-xl bg-muted/60 p-4 text-left text-sm">
            <p className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-emerald-700" />
              <span>Email <b>xác nhận lịch</b> đã được gửi ngay</span>
            </p>
            <p className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-amber-600" />
              <span>Email <b>nhắc lịch</b> sẽ tự động gửi trước hẹn 24 giờ</span>
            </p>
            <p className="flex items-center gap-2">
              <CalendarClock className="h-4 w-4 text-muted-foreground" />
              <span>Theo dõi trạng thái trong mục <b>Quản lý → Lịch hẹn</b></span>
            </p>
          </div>
          <Button
            onClick={() => {
              setSuccess(null)
              setName('')
              setPhone('')
              setEmail('')
              setDate('')
              setTime('')
              setNote('')
              setServiceId('')
            }}
          >
            Đặt lịch khác
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      {/* Form đặt lịch */}
      <Card className="lg:col-span-3">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarDays className="h-5 w-5 text-emerald-700" />
            Đặt lịch hẹn tại cửa hàng
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>
              <User className="mr-1 inline h-3.5 w-3.5" />
              Họ và tên *
            </Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nguyễn Văn B" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>
                <Phone className="mr-1 inline h-3.5 w-3.5" />
                Số điện thoại *
              </Label>
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="09xx xxx xxx" inputMode="tel" />
            </div>
            <div className="space-y-2">
              <Label>
                <Mail className="mr-1 inline h-3.5 w-3.5" />
                Email *
              </Label>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ban@email.com" inputMode="email" />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Dịch vụ *</Label>
            <Select value={serviceId} onValueChange={setServiceId}>
              <SelectTrigger aria-label="Chọn dịch vụ">
                <SelectValue placeholder="Chọn dịch vụ muốn sử dụng" />
              </SelectTrigger>
              <SelectContent>
                {services.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.name} ({s.durationMin} phút{s.price > 0 ? ` · ${fmtVND(s.price)}` : ' · Miễn phí'})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Ngày hẹn *</Label>
              <Input type="date" value={date} min={today} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Giờ hẹn *</Label>
              <Select value={time} onValueChange={setTime}>
                <SelectTrigger aria-label="Chọn giờ hẹn">
                  <SelectValue placeholder="Chọn giờ" />
                </SelectTrigger>
                <SelectContent className="max-h-64 overflow-y-auto">
                  {timeSlots.map((t) => (
                    <SelectItem key={t} value={t}>
                      {t}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label>Ghi chú (không bắt buộc)</Label>
            <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Mô tả nhu cầu cụ thể của bạn..." rows={3} />
          </div>
          <Button className="w-full" size="lg" onClick={submit} disabled={submitting}>
            {submitting ? 'Đang xử lý...' : 'Xác nhận đặt lịch'}
          </Button>
        </CardContent>
      </Card>

      {/* Thông tin nhắc lịch */}
      <div className="space-y-6 lg:col-span-2">
        <Card className="border-emerald-200 bg-emerald-50/60">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base text-emerald-800">
              <Info className="h-5 w-5" />
              Nhắc lịch tự động qua Email
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-emerald-900">
            <p className="flex gap-2">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
              Ngay khi đặt lịch thành công, hệ thống gửi email <b>xác nhận</b> chi tiết lịch hẹn.
            </p>
            <p className="flex gap-2">
              <Clock className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
              Trước giờ hẹn <b>24 giờ</b>, hệ thống tự động gửi email <b>nhắc lịch</b>.
            </p>
            <p className="flex gap-2">
              <Mail className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
              Nếu lịch bị huỷ, bạn nhận email <b>thông báo huỷ</b> (email nhắc tự gỡ khỏi hàng đợi).
            </p>
          </CardContent>
        </Card>

        {selected && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Dịch vụ đã chọn</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Dịch vụ</span>
                <span className="font-semibold">{selected.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Thời lượng</span>
                <span>{selected.durationMin} phút</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Chi phí</span>
                <span className="font-bold text-emerald-700">{selected.price > 0 ? fmtVND(selected.price) : 'Miễn phí'}</span>
              </div>
              {date && time && (
                <>
                  <div className="flex justify-between border-t pt-2">
                    <span className="text-muted-foreground">Thời gian</span>
                    <span className="font-semibold">{new Date(`${date}T${time}:00`).toLocaleString('vi-VN', { weekday: 'short', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        )}

        <Card>
          <CardContent className="p-4 text-xs leading-relaxed text-muted-foreground">
            <b className="text-foreground">Giờ mở cửa:</b> 8:00 – 20:00 hằng ngày, kể cả cuối tuần.
            <br />
            <b className="text-foreground">Hotline:</b> 1900-6868 (8:00 – 21:00).
            <br />
            Vui lòng đến sớm 5 phút. Đổi/huỷ lịch miễn phí trước giờ hẹn 2 giờ.
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
