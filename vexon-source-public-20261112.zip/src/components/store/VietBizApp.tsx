'use client'

import { useEffect, useState } from 'react'
import Storefront from '@/components/store/Storefront'
import CartView from '@/components/store/CartView'
import BookingView from '@/components/store/BookingView'
import AdminView from '@/components/store/AdminView'
import MarketView from '@/components/store/MarketView'
import { useCart } from '@/lib/cart-store'
import { ContactInfo } from '@/components/vexon/ContactInfo'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Store, ShoppingCart, CalendarClock, Settings2, ShoppingBag, ArrowLeft, Tags } from 'lucide-react'

type View = 'shop' | 'market' | 'cart' | 'booking' | 'admin'

const NAV: { key: View; label: string; icon: React.ReactNode }[] = [
  { key: 'shop', label: 'Cửa hàng', icon: <Store className="h-4 w-4" /> },
  { key: 'market', label: 'Chợ Vexon', icon: <Tags className="h-4 w-4" /> },
  { key: 'cart', label: 'Giỏ hàng', icon: <ShoppingCart className="h-4 w-4" /> },
  { key: 'booking', label: 'Đặt lịch', icon: <CalendarClock className="h-4 w-4" /> },
  { key: 'admin', label: 'Quản lý', icon: <Settings2 className="h-4 w-4" /> },
]

// Ứng dụng Cửa hàng Vexon (bán hàng + kho + đặt lịch) — thương hiệu thống nhất Vexon
export default function VietBizApp({ onExit, onOpenContact }: { onExit: () => void; onOpenContact?: () => void }) {
  const [view, setView] = useState<View>('shop')
  const [refreshKey, setRefreshKey] = useState(0)
  const items = useCart((s) => s.items)
  const cartCount = items.reduce((s, i) => s + i.quantity, 0)

  const refresh = () => setRefreshKey((k) => k + 1)

  return (
    <div className="flex min-h-screen flex-col bg-stone-50">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-white/95 shadow-sm backdrop-blur supports-[backdrop-filter]:bg-white/80">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onExit} aria-label="Về Vexon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600">
              <ShoppingBag className="h-5 w-5 text-white" />
            </div>
            <div className="text-left">
              <p className="text-base font-bold leading-tight text-emerald-800">Vexon</p>
              <p className="hidden text-[10px] leading-tight text-muted-foreground sm:block">Cửa hàng · Kho · Đặt lịch</p>
            </div>
          </div>

          <nav className="flex items-center gap-1" aria-label="Điều hướng chính">
            {NAV.map((n) => (
              <button
                key={n.key}
                onClick={() => setView(n.key)}
                className={`relative flex items-center gap-1.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors sm:px-3 ${
                  view === n.key ? 'bg-emerald-600 text-white shadow' : 'text-stone-600 hover:bg-emerald-50 hover:text-emerald-800'
                }`}
                aria-current={view === n.key ? 'page' : undefined}
              >
                {n.icon}
                <span className="hidden md:inline">{n.label}</span>
                {n.key === 'cart' && cartCount > 0 && (
                  <Badge className="ml-0.5 h-5 min-w-5 rounded-full bg-orange-500 px-1.5 text-[11px] text-white hover:bg-orange-500">
                    {cartCount}
                  </Badge>
                )}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Nội dung */}
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6">
        {view === 'shop' && <Storefront refreshKey={refreshKey} />}
        {view === 'market' && <MarketView />}
        {view === 'cart' && <CartView onOrdered={refresh} />}
        {view === 'booking' && <BookingView refreshKey={refreshKey} />}
        {view === 'admin' && <AdminView refreshKey={refreshKey} onRefresh={refresh} />}
      </main>

      {/* Footer — luôn nằm đáy trang, kèm phần liên hệ */}
      <footer className="mt-auto border-t bg-white">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-muted-foreground sm:flex-row sm:px-6">
          <p>© 2026 <span className="font-semibold text-emerald-800">Vexon Store</span>, Hệ thống bán hàng tích hợp</p>
          <p>Một sản phẩm của <b className="text-emerald-800">SoloWorks by Vexon</b></p>
        </div>
        <div className="border-t border-dashed">
          <div className="mx-auto max-w-6xl px-4 py-3 sm:px-6">
            <ContactInfo compact onOpen={onOpenContact} />
          </div>
        </div>
      </footer>
    </div>
  )
}
