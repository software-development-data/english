'use client'

import { useCallback, useEffect, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { fmtVND, fmtDateTime, ORDER_STATUS } from '@/lib/format'
import { useToast } from '@/hooks/use-toast'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { ClipboardList, Eye } from 'lucide-react'

interface OrderItem {
  id: string
  name: string
  sku: string
  price: number
  quantity: number
}

interface Order {
  id: string
  code: string
  customerName: string
  customerPhone: string
  customerAddress: string
  paymentMethod: string
  paymentStatus: string
  status: string
  total: number
  note?: string | null
  createdAt: string
  items: OrderItem[]
}

export default function AdminOrders({ onChanged }: { onChanged: () => void }) {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('all')
  const { toast } = useToast()

  const load = useCallback(() => {
    setLoading(true)
    fetch('/api/orders')
      .then((r) => r.json())
      .then((data) => Array.isArray(data) && setOrders(data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(load, [load])

  const update = async (id: string, patch: Record<string, string>) => {
    try {
      const res = await fetch(`/api/orders/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patch),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setOrders((prev) => prev.map((o) => (o.id === id ? data : o)))
      onChanged()
      toast({ title: 'Đã cập nhật đơn hàng', description: `${data.code}` })
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không cập nhật được', variant: 'destructive' })
    }
  }

  const filtered = statusFilter === 'all' ? orders : orders.filter((o) => o.status === statusFilter)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Tổng {filtered.length} đơn hàng
        </p>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48" aria-label="Lọc theo trạng thái">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tất cả trạng thái</SelectItem>
            {Object.entries(ORDER_STATUS).map(([k, v]) => (
              <SelectItem key={k} value={k}>{v.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Mã đơn</TableHead>
              <TableHead>Khách hàng</TableHead>
              <TableHead className="text-right">Tổng tiền</TableHead>
              <TableHead className="hidden md:table-cell">Thanh toán</TableHead>
              <TableHead>Trạng thái</TableHead>
              <TableHead className="hidden sm:table-cell">Thời gian</TableHead>
              <TableHead className="w-16 text-center">Chi tiết</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={7} className="py-10 text-center text-muted-foreground">Đang tải...</TableCell>
              </TableRow>
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="py-10 text-center text-muted-foreground">
                  <ClipboardList className="mx-auto mb-2 h-8 w-8" />
                  Chưa có đơn hàng nào
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((o) => {
                const st = ORDER_STATUS[o.status] || ORDER_STATUS.pending
                return (
                  <TableRow key={o.id}>
                    <TableCell className="font-mono text-xs font-semibold">{o.code}</TableCell>
                    <TableCell>
                      <p className="font-medium">{o.customerName}</p>
                      <p className="text-xs text-muted-foreground">{o.customerPhone}</p>
                    </TableCell>
                    <TableCell className="text-right font-bold text-emerald-700">{fmtVND(o.total)}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="flex flex-col gap-1">
                        <span className="text-xs">{o.paymentMethod === 'COD' ? 'COD' : 'Chuyển khoản'}</span>
                        <Badge variant="secondary" className={o.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100' : 'bg-amber-100 text-amber-800 hover:bg-amber-100'}>
                          {o.paymentStatus === 'paid' ? 'Đã thanh toán' : 'Chưa thanh toán'}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Select value={o.status} onValueChange={(v) => update(o.id, { status: v })}>
                        <SelectTrigger className="w-36 border-0 p-0 shadow-none focus:ring-0" aria-label="Đổi trạng thái">
                          <Badge variant="secondary" className={st.className}>{st.label}</Badge>
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(ORDER_STATUS).map(([k, v]) => (
                            <SelectItem key={k} value={k}>{v.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="hidden whitespace-nowrap sm:table-cell text-muted-foreground">{fmtDateTime(o.createdAt)}</TableCell>
                    <TableCell className="text-center">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Xem chi tiết">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Đơn {o.code}</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-3 text-sm">
                            <div className="rounded-lg bg-muted/60 p-3">
                              <p className="font-semibold">{o.customerName} · {o.customerPhone}</p>
                              <p className="text-muted-foreground">{o.customerAddress}</p>
                              {o.note && <p className="mt-1 text-xs italic text-muted-foreground">Ghi chú: {o.note}</p>}
                            </div>
                            <div className="space-y-2">
                              {o.items.map((it) => (
                                <div key={it.id} className="flex items-center justify-between border-b pb-2 last:border-0">
                                  <div>
                                    <p className="font-medium">{it.name}</p>
                                    <p className="text-xs text-muted-foreground">{it.sku} × {it.quantity}</p>
                                  </div>
                                  <span className="font-medium">{fmtVND(it.price * it.quantity)}</span>
                                </div>
                              ))}
                            </div>
                            <div className="flex justify-between text-base font-bold">
                              <span>Tổng cộng</span>
                              <span className="text-emerald-700">{fmtVND(o.total)}</span>
                            </div>
                            {o.paymentStatus !== 'paid' && (
                              <Button
                                className="w-full bg-emerald-600 hover:bg-emerald-700"
                                onClick={() => update(o.id, { paymentStatus: 'paid' })}
                              >
                                Đánh dấu đã thanh toán
                              </Button>
                            )}
                          </div>
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
