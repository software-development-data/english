'use client'

import { useCallback, useEffect, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { fmtVND } from '@/lib/format'
import AdminProducts from '@/components/store/AdminProducts'
import AdminStock from '@/components/store/AdminStock'
import AdminOrders from '@/components/store/AdminOrders'
import AdminAppointments from '@/components/store/AdminAppointments'
import AdminEmails from '@/components/store/AdminEmails'
import AdminReports from '@/components/store/AdminReports'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent } from '@/components/ui/card'
import { LayoutDashboard, Package, Boxes, ClipboardList, CalendarClock, Mail, BarChart3, Wallet, ShoppingCart, AlertTriangle, CalendarCheck, Loader2 } from 'lucide-react'

interface ReportSummary {
  revenue: number
  orderCount: number
  lowStockCount: number
  appointmentCount: number
}

interface DashStats {
  summary: ReportSummary
}

export default function AdminView({ refreshKey, onRefresh }: { refreshKey: number; onRefresh: () => void }) {
  const [stats, setStats] = useState<DashStats | null>(null)
  const [loading, setLoading] = useState(true)

  const loadStats = useCallback(() => {
    const d = new Date()
    const month = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
    fetch(`/api/reports?month=${month}`)
      .then((r) => r.json())
      .then((data) => !data.error && setStats(data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(loadStats, [loadStats, refreshKey])

  return (
    <div className="space-y-6">
      {/* Dashboard tổng quan */}
      <div>
        <h2 className="mb-3 flex items-center gap-2 font-semibold">
          <LayoutDashboard className="h-5 w-5 text-emerald-700" />
          Tổng quan tháng này
        </h2>
        {loading ? (
          <div className="flex items-center justify-center gap-2 rounded-xl border py-10 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span className="text-sm">Đang tải số liệu...</span>
          </div>
        ) : stats ? (
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Card>
              <CardContent className="p-4">
                <Wallet className="h-5 w-5 text-emerald-700" />
                <p className="mt-2 text-lg font-bold text-emerald-700 sm:text-xl">{fmtVND(stats.summary.revenue)}</p>
                <p className="text-xs text-muted-foreground">Doanh thu</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <ShoppingCart className="h-5 w-5 text-orange-600" />
                <p className="mt-2 text-lg font-bold sm:text-xl">{stats.summary.orderCount}</p>
                <p className="text-xs text-muted-foreground">Đơn hàng</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <CalendarCheck className="h-5 w-5 text-teal-600" />
                <p className="mt-2 text-lg font-bold sm:text-xl">{stats.summary.appointmentCount}</p>
                <p className="text-xs text-muted-foreground">Lịch hẹn</p>
              </CardContent>
            </Card>
            <Card className={stats.summary.lowStockCount > 0 ? 'border-amber-300' : ''}>
              <CardContent className="p-4">
                <AlertTriangle className={`h-5 w-5 ${stats.summary.lowStockCount > 0 ? 'text-amber-600' : 'text-muted-foreground'}`} />
                <p className={`mt-2 text-lg font-bold sm:text-xl ${stats.summary.lowStockCount > 0 ? 'text-amber-700' : ''}`}>{stats.summary.lowStockCount}</p>
                <p className="text-xs text-muted-foreground">Sản phẩm sắp hết</p>
              </CardContent>
            </Card>
          </div>
        ) : null}
      </div>

      {/* Các tab quản lý */}
      <Tabs defaultValue="products">
        <TabsList className="flex h-auto w-full flex-wrap justify-start gap-1 overflow-x-auto">
          <TabsTrigger value="products" className="gap-1.5">
            <Package className="h-4 w-4" />
            <span className="hidden sm:inline">Sản phẩm</span>
          </TabsTrigger>
          <TabsTrigger value="stock" className="gap-1.5">
            <Boxes className="h-4 w-4" />
            <span className="hidden sm:inline">Kho</span>
          </TabsTrigger>
          <TabsTrigger value="orders" className="gap-1.5">
            <ClipboardList className="h-4 w-4" />
            <span className="hidden sm:inline">Đơn hàng</span>
          </TabsTrigger>
          <TabsTrigger value="appointments" className="gap-1.5">
            <CalendarClock className="h-4 w-4" />
            <span className="hidden sm:inline">Lịch hẹn</span>
          </TabsTrigger>
          <TabsTrigger value="emails" className="gap-1.5">
            <Mail className="h-4 w-4" />
            <span className="hidden sm:inline">Email</span>
          </TabsTrigger>
          <TabsTrigger value="reports" className="gap-1.5">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden sm:inline">Báo cáo</span>
          </TabsTrigger>
        </TabsList>
        <TabsContent value="products" className="mt-4">
          <AdminProducts onChanged={onRefresh} />
        </TabsContent>
        <TabsContent value="stock" className="mt-4">
          <AdminStock onChanged={onRefresh} />
        </TabsContent>
        <TabsContent value="orders" className="mt-4">
          <AdminOrders onChanged={onRefresh} />
        </TabsContent>
        <TabsContent value="appointments" className="mt-4">
          <AdminAppointments onChanged={onRefresh} />
        </TabsContent>
        <TabsContent value="emails" className="mt-4">
          <AdminEmails />
        </TabsContent>
        <TabsContent value="reports" className="mt-4">
          <AdminReports />
        </TabsContent>
      </Tabs>
    </div>
  )
}
