'use client'

import { useState } from 'react'
import { useCart } from '@/lib/cart-store'
import { fmtVND } from '@/lib/format'
import { useToast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Badge } from '@/components/ui/badge'
import { Minus, Plus, Trash2, ShoppingCart, Banknote, Landmark, CheckCircle2, ShoppingBasket } from 'lucide-react'

interface OrderResult {
  code: string
  total: number
  paymentMethod: string
}

export default function CartView({ onOrdered }: { onOrdered: () => void }) {
  const { items, setQty, remove, clear, totalAmount } = useCart()
  const { toast } = useToast()

  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [address, setAddress] = useState('')
  const [note, setNote] = useState('')
  const [payment, setPayment] = useState<'COD' | 'BANK'>('COD')
  const [submitting, setSubmitting] = useState(false)
  const [result, setResult] = useState<OrderResult | null>(null)

  const shipping = items.length > 0 ? (totalAmount() >= 500000 ? 0 : 30000) : 0
  const grandTotal = totalAmount() + shipping

  const submitOrder = async () => {
    if (!name.trim() || !phone.trim() || !address.trim()) {
      toast({ title: 'Thiếu thông tin', description: 'Vui lòng điền đầy đủ họ tên, số điện thoại và địa chỉ', variant: 'destructive' })
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: name.trim(),
          customerPhone: phone.trim(),
          customerAddress: address.trim(),
          paymentMethod: payment,
          note: note.trim(),
          items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Không đặt được đơn hàng')
      setResult(data)
      clear()
      onOrdered()
      toast({ title: 'Đặt hàng thành công!', description: `Mã đơn: ${data.code}` })
    } catch (e) {
      toast({ title: 'Lỗi đặt hàng', description: e instanceof Error ? e.message : 'Vui lòng thử lại', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  // ===== Màn hình đặt hàng thành công =====
  if (result) {
    return (
      <Card className="mx-auto max-w-lg text-center">
        <CardContent className="flex flex-col items-center gap-4 p-10">
          <CheckCircle2 className="h-16 w-16 text-emerald-600" />
          <h2 className="text-2xl font-bold">Đặt hàng thành công!</h2>
          <p className="text-muted-foreground">
            Cảm ơn bạn đã mua hàng tại <span className="font-semibold text-foreground">Vexon Store</span>
          </p>
          <div className="w-full space-y-2 rounded-xl bg-muted/60 p-4 text-left text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Mã đơn hàng</span>
              <span className="font-mono font-semibold">{result.code}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Tổng tiền</span>
              <span className="font-bold text-emerald-700">{fmtVND(result.total)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Thanh toán</span>
              <span>{result.paymentMethod === 'COD' ? 'Tiền mặt khi nhận hàng (COD)' : 'Chuyển khoản ngân hàng'}</span>
            </div>
          </div>
          <Button onClick={() => setResult(null)} className="w-full sm:w-auto">
            <ShoppingCart className="mr-2 h-4 w-4" />
            Tiếp tục mua sắm
          </Button>
        </CardContent>
      </Card>
    )
  }

  // ===== Giỏ trống =====
  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center gap-3 py-24 text-center text-muted-foreground">
        <ShoppingBasket className="h-16 w-16" />
        <p className="text-lg">Giỏ hàng của bạn đang trống</p>
        <p className="text-sm">Hãy quay lại trang Cửa hàng và thêm sản phẩm yêu thích nhé!</p>
      </div>
    )
  }

  // ===== Trang giỏ hàng =====
  return (
    <div className="grid gap-6 lg:grid-cols-5">
      {/* Danh sách sản phẩm trong giỏ */}
      <Card className="lg:col-span-3">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            Giỏ hàng ({items.length} sản phẩm)
          </CardTitle>
        </CardHeader>
        <CardContent className="max-h-[480px] space-y-4 overflow-y-auto">
          {items.map((i) => (
            <div key={i.productId} className="flex items-center gap-3 rounded-xl border p-3">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-lg bg-emerald-100">
                <ShoppingBasket className="h-6 w-6 text-emerald-700" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{i.name}</p>
                <p className="text-xs text-muted-foreground">{fmtVND(i.price)} · còn {i.stock}</p>
                <div className="mt-2 flex items-center gap-2">
                  <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => setQty(i.productId, i.quantity - 1)} aria-label="Giảm số lượng">
                    <Minus className="h-3 w-3" />
                  </Button>
                  <span className="w-8 text-center text-sm font-medium">{i.quantity}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-7 w-7"
                    onClick={() => {
                      if (i.quantity >= i.stock) {
                        toast({ title: 'Vượt tồn kho', description: `Chỉ còn ${i.stock} sản phẩm`, variant: 'destructive' })
                      } else {
                        setQty(i.productId, i.quantity + 1)
                      }
                    }}
                    aria-label="Tăng số lượng"
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-2">
                <p className="text-sm font-bold text-emerald-700">{fmtVND(i.price * i.quantity)}</p>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500 hover:text-red-700" onClick={() => remove(i.productId)} aria-label="Xoá khỏi giỏ">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Thông tin giao hàng + thanh toán */}
      <div className="space-y-6 lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Thông tin nhận hàng</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="ho-ten">Họ và tên *</Label>
              <Input id="ho-ten" value={name} onChange={(e) => setName(e.target.value)} placeholder="Nguyễn Văn A" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="so-dien-thoai">Số điện thoại *</Label>
              <Input id="so-dien-thoai" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="09xx xxx xxx" inputMode="tel" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dia-chi">Địa chỉ giao hàng *</Label>
              <Textarea id="dia-chi" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Số nhà, đường, phường/xã, tỉnh/thành phố" rows={2} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ghi-chu">Ghi chú (không bắt buộc)</Label>
              <Input id="ghi-chu" value={note} onChange={(e) => setNote(e.target.value)} placeholder="VD: Giao giờ hành chính" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Phương thức thanh toán</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <RadioGroup value={payment} onValueChange={(v) => setPayment(v as 'COD' | 'BANK')}>
              <Label
                htmlFor="pay-cod"
                className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 transition-colors ${payment === 'COD' ? 'border-emerald-600 bg-emerald-50' : 'hover:bg-muted/50'}`}
              >
                <RadioGroupItem value="COD" id="pay-cod" />
                <Banknote className="h-5 w-5 text-emerald-700" />
                <div className="flex-1">
                  <p className="text-sm font-semibold">Tiền mặt khi nhận hàng</p>
                  <p className="text-xs text-muted-foreground">Thanh toán bằng tiền mặt cho người giao hàng</p>
                </div>
              </Label>
              <Label
                htmlFor="pay-bank"
                className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 transition-colors ${payment === 'BANK' ? 'border-emerald-600 bg-emerald-50' : 'hover:bg-muted/50'}`}
              >
                <RadioGroupItem value="BANK" id="pay-bank" />
                <Landmark className="h-5 w-5 text-emerald-700" />
                <div className="flex-1">
                  <p className="text-sm font-semibold">Chuyển khoản ngân hàng</p>
                  <p className="text-xs text-muted-foreground">Chuyển khoản trước, giao hàng sau</p>
                </div>
              </Label>
            </RadioGroup>

            {payment === 'BANK' && (
              <div className="space-y-1 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm">
                <p className="font-semibold text-emerald-800">Thông tin chuyển khoản</p>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Ngân hàng</span>
                  <span className="font-medium">Vietcombank</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Số tài khoản</span>
                  <span className="font-mono font-medium">0123456789</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Chủ tài khoản</span>
                  <span className="font-medium">VIETBIZ STORE</span>
                </div>
                <p className="pt-1 text-xs text-muted-foreground">Nội dung: Số điện thoại + Họ tên</p>
              </div>
            )}

            <Separator />
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tạm tính</span>
                <span>{fmtVND(totalAmount())}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Phí vận chuyển</span>
                {shipping === 0 ? <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">Miễn phí</Badge> : <span>{fmtVND(shipping)}</span>}
              </div>
              {totalAmount() < 500000 && (
                <p className="text-xs text-muted-foreground">Mua thêm {fmtVND(500000 - totalAmount())} để được miễn phí ship</p>
              )}
              <Separator />
              <div className="flex justify-between text-base font-bold">
                <span>Tổng cộng</span>
                <span className="text-emerald-700">{fmtVND(grandTotal)}</span>
              </div>
            </div>
            <Button className="w-full" size="lg" onClick={submitOrder} disabled={submitting}>
              {submitting ? 'Đang xử lý...' : 'Đặt hàng ngay'}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
