'use client'

import { useEffect, useMemo, useState } from 'react'
import { useCart } from '@/lib/cart-store'
import { fmtVND } from '@/lib/format'
import { useToast } from '@/hooks/use-toast'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Search, ShoppingBasket, PackageX, Shirt, Watch, Sparkles, Smartphone, Footprints, Briefcase } from 'lucide-react'

export interface Product {
  id: string
  name: string
  sku: string
  category: string
  price: number
  cost: number
  stock: number
  minStock: number
  description?: string | null
  image?: string | null
  active: boolean
}

const CATEGORY_STYLE: Record<string, { icon: React.ReactNode; gradient: string }> = {
  'Thời trang': { icon: <Shirt className="h-8 w-8 text-white" />, gradient: 'from-emerald-500 to-teal-600' },
  'Giày dép': { icon: <Footprints className="h-8 w-8 text-white" />, gradient: 'from-orange-500 to-amber-600' },
  'Phụ kiện': { icon: <Watch className="h-8 w-8 text-white" />, gradient: 'from-teal-500 to-pink-600' },
  'Làm đẹp': { icon: <Sparkles className="h-8 w-8 text-white" />, gradient: 'from-rose-500 to-red-500' },
  'Điện tử': { icon: <Smartphone className="h-8 w-8 text-white" />, gradient: 'from-cyan-500 to-teal-600' },
  'Khác': { icon: <Briefcase className="h-8 w-8 text-white" />, gradient: 'from-stone-500 to-stone-700' },
}

export default function Storefront({ refreshKey }: { refreshKey: number }) {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState('')
  const [category, setCategory] = useState('')
  const { add } = useCart()
  const { toast } = useToast()

  useEffect(() => {
    let cancelled = false
    const t = setTimeout(() => {
      setLoading(true)
      fetch('/api/products')
        .then((r) => r.json())
        .then((data) => {
          if (!cancelled && Array.isArray(data)) setProducts(data.filter((p: Product) => p.active))
        })
        .catch(() => {})
        .finally(() => !cancelled && setLoading(false))
    }, 0)
    return () => {
      cancelled = true
      clearTimeout(t)
    }
  }, [refreshKey])

  const categories = useMemo(() => Array.from(new Set(products.map((p) => p.category))), [products])

  const filtered = useMemo(() => {
    const kw = q.trim().toLowerCase()
    return products.filter((p) => {
      const matchQ = !kw || p.name.toLowerCase().includes(kw) || p.sku.toLowerCase().includes(kw)
      const matchC = !category || p.category === category
      return matchQ && matchC
    })
  }, [products, q, category])

  const handleAdd = (p: Product) => {
    if (p.stock <= 0) {
      toast({ title: 'Hết hàng', description: `"${p.name}" tạm hết hàng, vui lòng quay lại sau`, variant: 'destructive' })
      return
    }
    add({ productId: p.id, name: p.name, sku: p.sku, price: p.price, stock: p.stock })
    toast({ title: 'Đã thêm vào giỏ hàng', description: `${p.name}, ${fmtVND(p.price)}` })
  }

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 px-6 py-10 text-white sm:px-10">
        <div className="relative z-10 max-w-xl">
          <h1 className="text-2xl font-bold sm:text-3xl">Chào mừng đến Vexon Store</h1>
          <p className="mt-2 text-emerald-50">
            Hàng nghìn sản phẩm chính hãng, đặt lịch trải nghiệm tại cửa hàng chỉ trong 1 phút.
          </p>
        </div>
        <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-white/10" />
        <div className="absolute -bottom-12 right-24 h-32 w-32 rounded-full bg-white/10" />
      </div>

      {/* Tìm kiếm + lọc danh mục */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Tìm sản phẩm theo tên hoặc mã SKU..."
            className="pl-9"
            aria-label="Tìm kiếm sản phẩm"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant={category === '' ? 'default' : 'outline'} size="sm" onClick={() => setCategory('')}>
            Tất cả
          </Button>
          {categories.map((c) => (
            <Button key={c} variant={category === c ? 'default' : 'outline'} size="sm" onClick={() => setCategory(c)}>
              {c}
            </Button>
          ))}
        </div>
      </div>

      {/* Lưới sản phẩm */}
      {loading ? (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Card key={i}>
              <Skeleton className="h-36 w-full rounded-t-xl" />
              <CardContent className="space-y-2 p-4">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-9 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center gap-3 py-16 text-center text-muted-foreground">
          <PackageX className="h-12 w-12" />
          <p>Không tìm thấy sản phẩm phù hợp</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {filtered.map((p) => {
            const style = CATEGORY_STYLE[p.category] || CATEGORY_STYLE['Khác']
            const low = p.stock > 0 && p.stock <= p.minStock
            return (
              <Card key={p.id} className="group overflow-hidden pt-0 transition-all hover:-translate-y-0.5 hover:shadow-lg">
                <div className={`relative flex h-36 items-center justify-center bg-gradient-to-br ${style.gradient}`}>
                  {p.image ? (
                    <img src={p.image} alt={p.name} className="h-full w-full object-cover" />
                  ) : style.icon}
                  {p.stock <= 0 ? (
                    <Badge variant="secondary" className="absolute right-2 top-2 bg-red-600 text-white">Hết hàng</Badge>
                  ) : low ? (
                    <Badge variant="secondary" className="absolute right-2 top-2 bg-amber-500 text-white">Sắp hết</Badge>
                  ) : null}
                </div>
                <CardContent className="flex h-[calc(100%-9rem)] flex-col p-4">
                  <p className="text-xs text-muted-foreground">{p.sku} · {p.category}</p>
                  <h3 className="mt-1 line-clamp-2 min-h-[2.5rem] text-sm font-semibold leading-5">{p.name}</h3>
                  <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{p.description}</p>
                  <div className="mt-auto space-y-2 pt-3">
                    <p className="text-base font-bold text-emerald-700">{fmtVND(p.price)}</p>
                    <p className="text-xs text-muted-foreground">Còn {p.stock} sản phẩm</p>
                    <Button
                      className="w-full"
                      size="sm"
                      disabled={p.stock <= 0}
                      onClick={() => handleAdd(p)}
                    >
                      <ShoppingBasket className="mr-1 h-4 w-4" />
                      Thêm vào giỏ
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
