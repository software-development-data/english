'use client'

import { useCallback, useEffect, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { fmtDateTime, EMAIL_STATUS } from '@/lib/format'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { MailOpen, Mail } from 'lucide-react'

interface EmailLog {
  id: string
  to: string
  subject: string
  body: string
  type: string
  status: string
  scheduledFor: string
  sentAt?: string | null
  createdAt: string
  appointment: { customerName: string; service: { name: string } }
}

const TYPE_LABEL: Record<string, { label: string; className: string }> = {
  confirmation: { label: 'Xác nhận lịch', className: 'bg-emerald-100 text-emerald-800 border-emerald-200' },
  reminder: { label: 'Nhắc lịch', className: 'bg-amber-100 text-amber-800 border-amber-200' },
  cancelled: { label: 'Báo huỷ', className: 'bg-gray-100 text-gray-600 border-gray-200' },
}

export default function AdminEmails() {
  const [emails, setEmails] = useState<EmailLog[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(() => {
    setLoading(true)
    fetch('/api/emails')
      .then((r) => r.json())
      .then((data) => Array.isArray(data) && setEmails(data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(load, [load])

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Hộp thư mô phỏng, xem nội dung email xác nhận & nhắc lịch đã gửi cho khách</p>
        <Button variant="outline" size="sm" onClick={load}>Làm mới</Button>
      </div>

      {loading ? (
        <p className="py-10 text-center text-sm text-muted-foreground">Đang tải...</p>
      ) : emails.length === 0 ? (
        <div className="flex flex-col items-center gap-2 py-16 text-center text-muted-foreground">
          <MailOpen className="h-10 w-10" />
          <p className="text-sm">Chưa có email nào. Hãy đặt lịch hẹn để xem email xác nhận và nhắc lịch.</p>
        </div>
      ) : (
        <div className="grid max-h-[560px] gap-3 overflow-y-auto pr-1">
          {emails.map((e) => {
            const st = EMAIL_STATUS[e.status] || EMAIL_STATUS.queued
            const tp = TYPE_LABEL[e.type] || TYPE_LABEL.confirmation
            return (
              <Card key={e.id}>
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-100">
                    <Mail className="h-5 w-5 text-emerald-700" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="truncate font-semibold">{e.subject}</p>
                      <Badge variant="secondary" className={tp.className}>{tp.label}</Badge>
                      <Badge variant="secondary" className={st.className}>{st.label}</Badge>
                    </div>
                    <p className="truncate text-xs text-muted-foreground">
                      Tới: {e.to} · {e.status === 'sent' ? `Đã gửi ${e.sentAt ? fmtDateTime(e.sentAt) : ''}` : `Hẹn gửi ${fmtDateTime(e.scheduledFor)}`}
                    </p>
                  </div>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">Xem</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>{e.subject}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-2 text-sm">
                        <p className="text-xs text-muted-foreground">
                          Tới: <b>{e.to}</b> · Khách: <b>{e.appointment.customerName}</b> · Dịch vụ: <b>{e.appointment.service.name}</b>
                        </p>
                        <div className="whitespace-pre-wrap rounded-lg bg-muted/60 p-4 leading-relaxed">{e.body}</div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
