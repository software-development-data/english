'use client'

import { useCallback, useEffect, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { fmtDateTime, STOCK_TYPE } from '@/lib/format'
import { useToast } from '@/hooks/use-toast'
import type { Product } from '@/components/store/Storefront'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { PackagePlus, PackageMinus, History, Boxes } from 'lucide-react'

interface Movement {
  id: string
  productId: string
  type: string
  quantity: number
  stockAfter: number
  note?: string | null
  createdAt: string
  product: { name: string; sku: string }
}

export default function AdminStock({ onChanged }: { onChanged: () => void }) {
  const [products, setProducts] = useState<Product[]>([])
  const [movements, setMovements] = useState<Movement[]>([])
  const [productId, setProductId] = useState('')
  const [type, setType] = useState<'IN' | 'OUT'>('IN')
  const [quantity, setQuantity] = useState('')
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)
  const { toast } = useToast()

  const load = useCallback(() => {
    Promise.all([
      fetch('/api/products').then((r) => r.json()),
      fetch('/api/stock').then((r) => r.json()),
    ])
      .then(([prods, moves]) => {
        if (Array.isArray(prods)) setProducts(prods)
        if (Array.isArray(moves)) setMovements(moves)
      })
      .catch(() => {})
  }, [])

  useDeferredLoad(load, [load])

  const selected = products.find((p) => p.id === productId)
  const totalIn = movements.filter((m) => m.type === 'IN').reduce((s, m) => s + m.quantity, 0)
  const totalOut = movements.filter((m) => m.type === 'OUT').reduce((s, m) => s + m.quantity, 0)

  const submit = async () => {
    if (!productId || !quantity || Number(quantity) <= 0) {
      toast({ title: 'Thiếu thông tin', description: 'Chọn sản phẩm và nhập số lượng > 0', variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/stock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId, type, quantity: Number(quantity), note: note.trim() }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({
        title: type === 'IN' ? 'Nhập kho thành công' : 'Xuất kho thành công',
        description: `${selected?.name}: ${type === 'IN' ? '+' : '-'}${quantity} (còn ${data.stockAfter})`,
      })
      setProductId('')
      setQuantity('')
      setNote('')
      load()
      onChanged()
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không thực hiện được', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      {/* Form nhập / xuất */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Boxes className="h-5 w-5 text-emerald-700" />
              Nhập / Xuất kho
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              <Button variant={type === 'IN' ? 'default' : 'outline'} onClick={() => setType('IN')} className={type === 'IN' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}>
                <PackagePlus className="mr-1 h-4 w-4" />
                Nhập kho
              </Button>
              <Button variant={type === 'OUT' ? 'default' : 'outline'} onClick={() => setType('OUT')} className={type === 'OUT' ? 'bg-orange-600 hover:bg-orange-700' : ''}>
                <PackageMinus className="mr-1 h-4 w-4" />
                Xuất kho
              </Button>
            </div>
            <div className="space-y-2">
              <Label>Sản phẩm *</Label>
              <Select value={productId} onValueChange={setProductId}>
                <SelectTrigger aria-label="Chọn sản phẩm">
                  <SelectValue placeholder="Chọn sản phẩm" />
                </SelectTrigger>
                <SelectContent className="max-h-64 overflow-y-auto">
                  {products.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name}, còn {p.stock}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Số lượng *</Label>
              <Input type="number" min={1} value={quantity} onChange={(e) => setQuantity(e.target.value)} placeholder="VD: 50" />
              {selected && type === 'OUT' && quantity && Number(quantity) > selected.stock && (
                <p className="text-xs text-red-600">Kho chỉ còn {selected.stock}, không thể xuất số lượng này</p>
              )}
            </div>
            <div className="space-y-2">
              <Label>Ghi chú</Label>
              <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder={type === 'IN' ? 'Nhập hàng từ NCC...' : 'Xuất cho đơn...'} />
            </div>
            <Button className="w-full" onClick={submit} disabled={saving}>
              {saving ? 'Đang xử lý...' : type === 'IN' ? 'Xác nhận nhập kho' : 'Xác nhận xuất kho'}
            </Button>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-3">
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-emerald-700">+{totalIn}</p>
              <p className="text-xs text-muted-foreground">Tổng đã nhập</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-orange-600">-{totalOut}</p>
              <p className="text-xs text-muted-foreground">Tổng đã xuất</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Lịch sử kho */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <History className="h-5 w-5" />
            Lịch sử nhập / xuất
          </CardTitle>
        </CardHeader>
        <CardContent className="max-h-[560px] overflow-y-auto p-0">
          <Table>
            <TableHeader className="sticky top-0 bg-background">
              <TableRow>
                <TableHead>Sản phẩm</TableHead>
                <TableHead>Loại</TableHead>
                <TableHead className="text-center">SL</TableHead>
                <TableHead className="text-center">Tồn sau</TableHead>
                <TableHead className="hidden md:table-cell">Ghi chú</TableHead>
                <TableHead className="hidden sm:table-cell">Thời gian</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {movements.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="py-10 text-center text-muted-foreground">Chưa có thao tác kho</TableCell>
                </TableRow>
              ) : (
                movements.map((m) => {
                  const st = STOCK_TYPE[m.type] || STOCK_TYPE.ADJUST
                  return (
                    <TableRow key={m.id}>
                      <TableCell>
                        <p className="font-medium">{m.product.name}</p>
                        <p className="text-xs text-muted-foreground">{m.product.sku}</p>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={st.className}>{st.label}</Badge>
                      </TableCell>
                      <TableCell className={`text-center font-bold ${m.type === 'IN' ? 'text-emerald-700' : 'text-orange-600'}`}>
                        {m.type === 'IN' ? '+' : '-'}{m.quantity}
                      </TableCell>
                      <TableCell className="text-center">{m.stockAfter}</TableCell>
                      <TableCell className="hidden max-w-40 truncate md:table-cell text-muted-foreground">{m.note}</TableCell>
                      <TableCell className="hidden whitespace-nowrap sm:table-cell text-muted-foreground">{fmtDateTime(m.createdAt)}</TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
