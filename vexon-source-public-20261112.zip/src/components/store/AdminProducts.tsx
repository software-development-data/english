'use client'

import { useCallback, useEffect, useState } from 'react'
import { useDeferredLoad } from '@/lib/use-deferred-load'
import { fmtVND } from '@/lib/format'
import { useToast } from '@/hooks/use-toast'
import type { Product } from '@/components/store/Storefront'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog'
import { Plus, Pencil, Trash2, Search, PackageSearch, ImagePlus, Loader2 } from 'lucide-react'
import { compressImage } from '@/lib/image-compress'

const emptyForm = { name: '', sku: '', category: '', price: '', cost: '', stock: '', minStock: '5', description: '', image: '' as string | null }

export default function AdminProducts({ onChanged }: { onChanged: () => void }) {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)
  const { toast } = useToast()

  const load = useCallback(() => {
    setLoading(true)
    fetch('/api/products')
      .then((r) => r.json())
      .then((data) => Array.isArray(data) && setProducts(data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useDeferredLoad(load, [load])

  const openCreate = () => {
    setEditingId(null)
    setForm(emptyForm)
    setDialogOpen(true)
  }

  const openEdit = (p: Product) => {
    setEditingId(p.id)
    setForm({
      name: p.name,
      sku: p.sku,
      category: p.category,
      price: String(p.price),
      cost: String(p.cost ?? ''),
      stock: String(p.stock),
      minStock: String(p.minStock),
      description: p.description || '',
      image: p.image || null,
    })
    setDialogOpen(true)
  }

  const save = async () => {
    if (!form.name.trim() || !form.sku.trim() || !form.price) {
      toast({ title: 'Thiếu thông tin', description: 'Vui lòng nhập ít nhất: tên, mã SKU, giá bán', variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      const payload = {
        name: form.name.trim(),
        sku: form.sku.trim().toUpperCase(),
        category: form.category.trim() || 'Khác',
        price: Number(form.price),
        cost: Number(form.cost || 0),
        stock: Number(form.stock || 0),
        minStock: Number(form.minStock || 5),
        description: form.description.trim(),
        image: form.image || null,
      }
      const res = editingId
        ? await fetch(`/api/products/${editingId}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
        : await fetch('/api/products', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: editingId ? 'Đã cập nhật sản phẩm' : 'Đã thêm sản phẩm mới', description: payload.name })
      setDialogOpen(false)
      load()
      onChanged()
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không lưu được sản phẩm', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  // Đăng ảnh sản phẩm: chọn file → nén → lưu dataUrl vào product.image
  const pickImage = async (file: File | undefined) => {
    if (!file) return
    if (!file.type.startsWith('image/')) { toast({ title: 'Chỉ nhận tệp ảnh', variant: 'destructive' }); return }
    if (file.size > 6_000_000) { toast({ title: 'Ảnh quá lớn', description: 'Tối đa ~6MB trước khi nén', variant: 'destructive' }); return }
    setUploading(true)
    try {
      const dataUrl = await compressImage(file, 1024)
      setForm((f) => ({ ...f, image: dataUrl }))
      toast({ title: 'Đã thêm ảnh sản phẩm' })
    } catch {
      toast({ title: 'Không đọc được ảnh', variant: 'destructive' })
    } finally {
      setUploading(false)
    }
  }

  const del = async (p: Product) => {
    try {
      const res = await fetch(`/api/products/${p.id}`, { method: 'DELETE' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: data.softDeleted ? 'Đã ẩn sản phẩm' : 'Đã xoá sản phẩm', description: data.softDeleted ? 'Sản phẩm đã có đơn hàng nên được ẩn khỏi cửa hàng' : p.name })
      load()
      onChanged()
    } catch (e) {
      toast({ title: 'Lỗi', description: e instanceof Error ? e.message : 'Không xoá được', variant: 'destructive' })
    }
  }

  const filtered = products.filter((p) => {
    const kw = q.trim().toLowerCase()
    return !kw || p.name.toLowerCase().includes(kw) || p.sku.toLowerCase().includes(kw)
  })

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm theo tên / SKU..." className="pl-9" />
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreate}>
              <Plus className="mr-1 h-4 w-4" />
              Thêm sản phẩm
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{editingId ? 'Sửa sản phẩm' : 'Thêm sản phẩm mới'}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2 sm:col-span-2">
                <Label>Tên sản phẩm *</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Áo thun nam..." />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label>Ảnh sản phẩm</Label>
                <div className="flex items-center gap-3">
                  <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-xl border bg-muted">
                    {form.image ? (
                      <img src={form.image} alt="Ảnh sản phẩm" className="h-full w-full object-cover" />
                    ) : (
                      <ImagePlus className="h-7 w-7 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="flex w-fit cursor-pointer items-center gap-1.5 rounded-lg border bg-white px-3 py-2 text-sm font-medium transition-colors hover:bg-emerald-50">
                      {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4 text-emerald-600" />}
                      {form.image ? 'Đổi ảnh' : 'Đăng ảnh'}
                      <input type="file" accept="image/*" className="hidden" onChange={(e) => { pickImage(e.target.files?.[0]); e.target.value = '' }} />
                    </label>
                    {form.image && (
                      <button type="button" className="w-fit text-xs text-red-500 hover:underline" onClick={() => setForm((f) => ({ ...f, image: null }))}>
                        Xoá ảnh
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">Ảnh hiện trên thẻ sản phẩm trong Cửa hàng, nén tự động.</p>
              </div>
              <div className="space-y-2">
                <Label>Mã SKU *</Label>
                <Input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} placeholder="AT-001" />
              </div>
              <div className="space-y-2">
                <Label>Danh mục</Label>
                <Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="Thời trang" />
              </div>
              <div className="space-y-2">
                <Label>Giá bán (₫) *</Label>
                <Input type="number" min={0} value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="199000" />
              </div>
              <div className="space-y-2">
                <Label>Giá vốn (₫)</Label>
                <Input type="number" min={0} value={form.cost} onChange={(e) => setForm({ ...form, cost: e.target.value })} placeholder="95000" />
              </div>
              <div className="space-y-2">
                <Label>Tồn kho</Label>
                <Input type="number" min={0} value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} placeholder="100" />
              </div>
              <div className="space-y-2">
                <Label>Tối thiểu cảnh báo</Label>
                <Input type="number" min={0} value={form.minStock} onChange={(e) => setForm({ ...form, minStock: e.target.value })} />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label>Mô tả</Label>
                <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Mô tả ngắn về sản phẩm..." />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Huỷ</Button>
              <Button onClick={save} disabled={saving}>{saving ? 'Đang lưu...' : 'Lưu sản phẩm'}</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Sản phẩm</TableHead>
              <TableHead className="hidden md:table-cell">Danh mục</TableHead>
              <TableHead className="text-right">Giá bán</TableHead>
              <TableHead className="text-right">Giá vốn</TableHead>
              <TableHead className="text-center">Tồn kho</TableHead>
              <TableHead className="w-20 text-right">Thao tác</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={6} className="py-10 text-center text-muted-foreground">Đang tải...</TableCell>
              </TableRow>
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="py-10 text-center text-muted-foreground">
                  <PackageSearch className="mx-auto mb-2 h-8 w-8" />
                  Không có sản phẩm
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((p) => (
                <TableRow key={p.id} className={p.active ? '' : 'opacity-50'}>
                  <TableCell>
                    <div className="flex items-center gap-2.5">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg border bg-muted">
                        {p.image ? <img src={p.image} alt="" className="h-full w-full object-cover" /> : <PackageSearch className="h-4 w-4 text-muted-foreground" />}
                      </div>
                      <div className="min-w-0">
                        <p className="font-medium">{p.name} {!p.active && <Badge variant="secondary">Đã ẩn</Badge>}</p>
                        <p className="text-xs text-muted-foreground">{p.sku}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="hidden md:table-cell">{p.category}</TableCell>
                  <TableCell className="text-right font-medium">{fmtVND(p.price)}</TableCell>
                  <TableCell className="text-right text-muted-foreground">{fmtVND(p.cost)}</TableCell>
                  <TableCell className="text-center">
                    <Badge variant="secondary" className={p.stock <= p.minStock ? 'bg-red-100 text-red-800 hover:bg-red-100' : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100'}>
                      {p.stock}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(p)} aria-label="Sửa">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:text-red-700" aria-label="Xoá">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Xoá sản phẩm "{p.name}"?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Sản phẩm sẽ bị xoá khỏi hệ thống. Nếu đã phát sinh đơn hàng, sản phẩm chỉ bị ẩn để giữ dữ liệu thống nhất.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Giữ lại</AlertDialogCancel>
                            <AlertDialogAction onClick={() => del(p)} className="bg-red-600 hover:bg-red-700">Xoá</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
