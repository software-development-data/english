"use client"

import * as React from "react"
import * as DialogPrimitive from "@radix-ui/react-dialog"
import { XIcon } from "lucide-react"

import { cn } from "@/lib/utils"

/* Kiểu AJAX: hộp thoại tự bung vừa nội dung, tràn màn hình thì tự thu nhỏ để thấy hết — không cần kéo cuộn.
  - Đo chiều cao tự nhiên (scrollHeight trong hệ toạ độ của hộp thoại, không phụ thuộc zoom đang áp)
  - zoom = availH / naturalH (tối đa 1); nếu phải thu nhỏ sâu hơn 0.35 mới rơi về phương án cuộn dự phòng
  - ResizeObserver + resize: nội dung đổi (tab, dữ liệu ajax) → hộp thoại co giãn mượt theo (transition zoom) */
type DialogFit = { z: number; maxH?: number }

const DIALOG_MIN_ZOOM = 0.35

function useDialogAutoFit<T extends HTMLElement>() {
  const [node, setNode] = React.useState<T | null>(null)
  const [fit, setFit] = React.useState<DialogFit | undefined>(undefined)
  const [supportsZoom, setSupportsZoom] = React.useState(true)

  const useIsoLayoutEffect =
    typeof window === "undefined" ? React.useEffect : React.useLayoutEffect

  useIsoLayoutEffect(() => {
    const ok =
      typeof CSS !== "undefined" &&
      typeof CSS.supports === "function" &&
      CSS.supports("zoom", "0.5")
    if (!ok) setSupportsZoom(false) // Trình duyệt quá cũ: giữ phương án cuộn an toàn
  }, [])

  useIsoLayoutEffect(() => {
    if (!node || !supportsZoom) return
    let raf = 0
    const compute = () => {
      raf = 0
      const cs = getComputedStyle(node)
      const availH = window.innerHeight - 12
      const naturalH =
        node.scrollHeight +
        (parseFloat(cs.borderTopWidth) || 0) +
        (parseFloat(cs.borderBottomWidth) || 0)
      if (naturalH <= 0) return
      const raw = Math.min(1, availH / naturalH)
      const next: DialogFit =
        raw >= DIALOG_MIN_ZOOM
          ? { z: raw }
          : { z: DIALOG_MIN_ZOOM, maxH: Math.floor(availH / DIALOG_MIN_ZOOM) }
      setFit((prev) => {
        if (
          prev &&
          Math.abs(prev.z - next.z) <= 0.004 &&
          prev.maxH === next.maxH
        )
          return prev
        return next
      })
    }
    const schedule = () => {
      if (raf === 0) raf = window.requestAnimationFrame(compute)
    }
    compute()
    const ro = new ResizeObserver(schedule)
    ro.observe(node)
    window.addEventListener("resize", schedule)
    return () => {
      ro.disconnect()
      window.removeEventListener("resize", schedule)
      if (raf !== 0) window.cancelAnimationFrame(raf)
    }
  }, [node, supportsZoom])

  const attach = React.useCallback((el: T | null) => setNode(el), [])
  return { attach, fit, supportsZoom }
}

function mergeRefs<T>(...refs: (React.Ref<T> | undefined | null)[]) {
  return (node: T) => {
    for (const r of refs) {
      if (!r) continue
      if (typeof r === "function") r(node)
      else (r as React.RefObject<T | null>).current = node
    }
  }
}

function Dialog({
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Root>) {
  return <DialogPrimitive.Root data-slot="dialog" {...props} />
}

function DialogTrigger({
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Trigger>) {
  return <DialogPrimitive.Trigger data-slot="dialog-trigger" {...props} />
}

function DialogPortal({
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Portal>) {
  return <DialogPrimitive.Portal data-slot="dialog-portal" {...props} />
}

function DialogClose({
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Close>) {
  return <DialogPrimitive.Close data-slot="dialog-close" {...props} />
}

function DialogOverlay({
  className,
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Overlay>) {
  return (
    <DialogPrimitive.Overlay
      data-slot="dialog-overlay"
      className={cn(
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50 backdrop-blur-[2px]",
        className
      )}
      {...props}
    />
  )
}

function DialogContent({
  className,
  children,
  showCloseButton = true,
  style: theirStyle,
  ref: theirRef,
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Content> & {
  showCloseButton?: boolean
}) {
  const { attach, fit, supportsZoom } = useDialogAutoFit<HTMLDivElement>()
  const fitStyle =
    supportsZoom && fit
      ? { zoom: fit.z, maxHeight: fit.maxH }
      : undefined
  return (
    <DialogPortal data-slot="dialog-portal">
      <DialogOverlay />
      <DialogPrimitive.Content
        data-slot="dialog-content"
        ref={mergeRefs(attach, theirRef)}
        style={{ ...fitStyle, ...theirStyle }}
        className={cn(
          "bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=open]:slide-in-from-bottom-2 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border p-6 shadow-lg duration-300 transition-[zoom] ease-out sm:max-w-lg",
          supportsZoom
            ? fit?.maxH
              ? "overflow-y-auto"
              : ""
            : "max-h-[calc(100dvh-2rem)] overflow-y-auto",
          className
        )}
        {...props}
      >
        {/* Thanh loading AJAX: vệt gradient emerald → teal quét một lần rồi mờ dần khi hộp thoại mở */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-0 top-0 z-20 h-[3px] overflow-hidden rounded-t-[inherit]"
        >
          <div className="vx-ajax-bar h-full w-1/2 bg-gradient-to-r from-transparent via-emerald-400 to-teal-300" />
        </div>
        {children}
        {showCloseButton && (
          <DialogPrimitive.Close
            data-slot="dialog-close"
            className="ring-offset-background focus:ring-ring data-[state=open]:bg-accent data-[state=open]:text-muted-foreground absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4"
          >
            <XIcon />
            <span className="sr-only">Close</span>
          </DialogPrimitive.Close>
        )}
      </DialogPrimitive.Content>
    </DialogPortal>
  )
}

function DialogHeader({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="dialog-header"
      className={cn("flex flex-col gap-2 text-center sm:text-left", className)}
      {...props}
    />
  )
}

function DialogFooter({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="dialog-footer"
      className={cn(
        "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
        className
      )}
      {...props}
    />
  )
}

function DialogTitle({
  className,
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Title>) {
  return (
    <DialogPrimitive.Title
      data-slot="dialog-title"
      className={cn("text-lg leading-none font-semibold", className)}
      {...props}
    />
  )
}

function DialogDescription({
  className,
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Description>) {
  return (
    <DialogPrimitive.Description
      data-slot="dialog-description"
      className={cn("text-muted-foreground text-sm", className)}
      {...props}
    />
  )
}

export {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogOverlay,
  DialogPortal,
  DialogTitle,
  DialogTrigger,
  useDialogAutoFit,
  mergeRefs,
}
