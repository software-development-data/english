/**
 * Danh sách phân hệ của mạng xã hội Vexon — dùng chung cho:
 *  • VexonApp (type View + validate)
 *  • src/app/page.tsx (deep-link ?view=tools, ?view=wallet…)
 * Giữ MỘT nguồn duy nhất để không lệch danh sách.
 */
export const VX_VIEWS = [
  'home',
  'feed',
  'video',
  'live',
  'messages',
  'friends',
  'attendance',
  'analysis',
  'shop',
  'nearby',
  'jobs',
  'companies',
  'wallet',
  'profile',
  'tools',
  'ops',
  'groups',
  'pages',
  'pets',
  'settings',
  'contact',
  'aichat',
] as const

export type VxView = (typeof VX_VIEWS)[number]

/** Chuỗi từ URL → view hợp lệ (sai trả về undefined) */
export function parseVxView(raw?: string | null): VxView | undefined {
  return VX_VIEWS.includes(raw as VxView) ? (raw as VxView) : undefined
}
