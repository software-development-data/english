'use client'

import { useEffect } from 'react'

/**
 * Trì hoãn việc tải dữ liệu 1 tick để tránh gọi setState đồng bộ
 * trong effect body (tuân thủ react-hooks/set-state-in-effect).
 */
export function useDeferredLoad(fn: () => void, deps: unknown[]) {
  useEffect(() => {
    const t = setTimeout(fn, 0)
    return () => clearTimeout(t)
  }, deps)
}

