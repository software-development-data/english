// ===== TỶ GIÁ USD/VND (SERVER) — AI TỰ ĐỘNG BÁM THỊ TRƯỜNG =====
// Nạp tỷ giá thực tế từ NHIỀU nguồn miễn phí theo thứ tự dự phòng (failover):
//   1) open.er-api.com — cập nhật mỗi ngày, nhanh, ổn định
//   2) @fawazahmed0/currency-api qua jsDelivr CDN (Cloudflare) — bản chụp hằng ngày
//   3) floatrates.com — bản chụp hằng ngày
// Cache bộ nhớ 30 PHÚT (thay vì 6h) để giá tăng/giảm được căn chỉnh kịp; nguồn nào xong trước dùng ngay.
// Giá kỳ trước (prev) được giữ lại để client hiển thị chiều tăng/giảm. Không bao giờ quăng lỗi ra ngoài.
import { FALLBACK_USD_VND } from '@/lib/format'

const TTL_MS = 30 * 60 * 1000
const TIMEOUT_MS = 6000

type FxCache = { rate: number; source: string; at: number }
let cache: FxCache | null = null
let prevRate: number | null = null // tỷ giá lần nạp thành công TRƯỚC đó (khác giá hiện tại)
let inflight: Promise<void> | null = null // gộp các request đồng thời

// Mỗi nguồn trả về số VND cho 1 USD hoặc null nếu hỏng
const SOURCES: { name: string; url: string; pick: (d: unknown) => number | null }[] = [
  {
    name: 'er-api',
    url: 'https://open.er-api.com/v6/latest/USD',
    pick: (d) => {
      const r = d as { rates?: Record<string, number> }
      return typeof r?.rates?.VND === 'number' ? r.rates.VND : null
    },
  },
  {
    name: 'jsdelivr',
    url: 'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json',
    pick: (d) => {
      const r = d as { usd?: Record<string, number> }
      return typeof r?.usd?.vnd === 'number' ? r.usd.vnd : null
    },
  },
  {
    name: 'floatrates',
    url: 'https://www.floatrates.com/daily/usd.json',
    pick: (d) => {
      const r = d as { vnd?: { rate?: number } }
      return typeof r?.vnd?.rate === 'number' ? r.vnd.rate : null
    },
  },
]

async function fetchSource(s: { name: string; url: string; pick: (d: unknown) => number | null }): Promise<{ name: string; rate: number } | null> {
  try {
    const res = await fetch(s.url, { signal: AbortSignal.timeout(TIMEOUT_MS), cache: 'no-store' })
    if (!res.ok) return null
    const vnd = s.pick(await res.json())
    return typeof vnd === 'number' && vnd > 1000 && vnd < 200000 ? { name: s.name, rate: Math.round(vnd) } : null
  } catch { return null }
}

/** Tỷ giá đầy đủ: giá hiện tại + giá kỳ trước + thời điểm cập nhật */
export async function getUsdVndInfo(): Promise<{ rate: number; source: 'live' | string; prev: number | null; updatedAt: number }> {
  if (cache && Date.now() - cache.at < TTL_MS) {
    return { rate: cache.rate, source: cache.source, prev: prevRate, updatedAt: cache.at }
  }
  // Dùng chung 1 lượt gọi cho mọi request đồng thời (tránh đập vào nguồn liên tục)
  if (!inflight) {
    inflight = (async () => {
      for (const s of SOURCES) {
        const got = await fetchSource(s)
        if (got) {
          if (cache && cache.rate !== got.rate) prevRate = cache.rate
          else if (!cache) prevRate = null
          cache = { rate: got.rate, source: got.name, at: Date.now() }
          return
        }
      }
      // Toàn bộ nguồn hỏng → dự phòng, nhưng KHÔNG ghi đè prev (giữ chiều cũ để còn so sánh)
      const fbAt = cache ? cache.at : Date.now()
      const fbRate = cache ? cache.rate : FALLBACK_USD_VND
      cache = { rate: fbRate, source: cache ? cache.source + '+fallback' : 'fallback', at: fbAt }
    })().finally(() => { inflight = null })
  }
  await inflight.catch(() => {})
  return { rate: cache?.rate ?? FALLBACK_USD_VND, source: cache?.source ?? 'fallback', prev: prevRate, updatedAt: cache?.at ?? Date.now() }
}

/** Bản gọn giữ nguyên chữ ký cũ cho mọi nơi đang dùng */
export async function getUsdVnd(): Promise<{ rate: number; source: 'live' | 'fallback' }> {
  const info = await getUsdVndInfo()
  return { rate: info.rate, source: info.source === 'fallback' || info.source.includes('fallback') ? 'fallback' : 'live' }
}
