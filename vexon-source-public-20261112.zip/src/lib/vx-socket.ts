'use client'

import { io } from 'socket.io-client'

// Kết nối socket qua gateway (mini-service vexon-socket, cổng 3003)
let socket: ReturnType<typeof io> | null = null

// Dev chạy trực tiếp qua Next (:3000) thì Caddy gateway không nằm giữa → nối thẳng mini-service.
// Production/preview đi qua gateway: giữ nguyên query XTransformPort để gateway chuyển hướng.
function socketUrl(): string {
  if (typeof window === 'undefined') return '/?XTransformPort=3003'
  const { protocol, hostname, port } = window.location
  if (port === '3000') return `${protocol}//${hostname}:3003`
  return '/?XTransformPort=3003'
}

export function getSocket() {
  if (!socket) {
    socket = io(socketUrl(), {
      path: '/',
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 10,
      reconnectionDelay: 1500,
      timeout: 6000,
    })
    // hook debug cho môi trường dev (kiểm tra kết nối từ agent-browser eval)
    if (process.env.NODE_ENV !== 'production') {
      ;(window as unknown as { __vxSock?: unknown }).__vxSock = socket
    }
  }
  return socket
}

export function disconnectSocket() {
  if (socket) {
    socket.disconnect()
    socket = null
  }
}
