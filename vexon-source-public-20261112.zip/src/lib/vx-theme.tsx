'use client'

// ============ GIAO DIỆN NGÀY/ĐÊM + 4 MÙA (Pixe lFx) ============
// Context quản lý theme toàn cục, lưu localStorage + đồng bộ user.settings

import { createContext, useCallback, useContext, useEffect, useState } from 'react'

export type ThemeMode = 'day' | 'night'
export type ThemeEffect = 'auto' | 'spring' | 'summer' | 'autumn' | 'winter' | 'rain' | 'off'

export interface VxThemeState {
  mode: ThemeMode
  effect: ThemeEffect
  effectsOn: boolean
  notifSound: boolean
  fontSize: 'small' | 'medium' | 'large' // cỡ chữ toàn app
}

const DEFAULT_STATE: VxThemeState = { mode: 'day', effect: 'auto', effectsOn: true, notifSound: true, fontSize: 'medium' }
const LS_KEY = 'vx-theme-v1'

interface Ctx extends VxThemeState {
  set: (patch: Partial<VxThemeState>) => void
  geo: { lat: number; lon: number } | null
}

const ThemeCtx = createContext<Ctx>({ ...DEFAULT_STATE, set: () => {}, geo: null })

// Mùa theo tháng (miền Bắc VN: Xuân T2-T4, Hạ T5-T7, Thu T8-T10, Đông T11-T1)
export function seasonOfMonth(d = new Date()): Exclude<ThemeEffect, 'auto' | 'off' | 'rain'> {
  const m = d.getMonth() // 0-11
  if (m >= 1 && m <= 3) return 'spring'
  if (m >= 4 && m <= 6) return 'summer'
  if (m >= 7 && m <= 9) return 'autumn'
  return 'winter'
}

export function readLocalTheme(): VxThemeState {
  if (typeof window === 'undefined') return DEFAULT_STATE
  try {
    const raw = localStorage.getItem(LS_KEY)
    if (!raw) return DEFAULT_STATE
    const s = JSON.parse(raw)
    return {
      mode: s.mode === 'night' ? 'night' : 'day',
      effect: ['auto', 'spring', 'summer', 'autumn', 'winter', 'rain', 'off'].includes(s.effect) ? s.effect : 'auto',
      effectsOn: s.effectsOn !== false,
      notifSound: s.notifSound !== false,
      fontSize: ['small', 'medium', 'large'].includes(s.fontSize) ? s.fontSize : 'medium',
    }
  } catch {
    return DEFAULT_STATE
  }
}

export function VxThemeProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<VxThemeState>(DEFAULT_STATE)
  const [geo, setGeo] = useState<{ lat: number; lon: number } | null>(null)

  // Nạp từ localStorage ngay khi mount
  useDeferredThemeInit(setState)

  // Áp dụng class night lên <html> + cỡ chữ toàn app (thay đổi root font-size)
  useEffect(() => {
    document.documentElement.classList.toggle('night', state.mode === 'night')
    const px = state.fontSize === 'small' ? '14.5px' : state.fontSize === 'large' ? '17.5px' : '16px'
    document.documentElement.style.fontSize = px
  }, [state.mode, state.fontSize])

  // Định vị thật (dùng chung cho thời tiết + người gần đây)
  useDeferredLoad(() => {
    try {
      const cached = localStorage.getItem('vx-geo')
      if (cached) {
        const g = JSON.parse(cached)
        if (g?.lat && Date.now() - (g.ts || 0) < 30 * 60_000) setGeo({ lat: g.lat, lon: g.lon })
      }
      if (!navigator.geolocation) return
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const g = { lat: pos.coords.latitude, lon: pos.coords.longitude, ts: Date.now() }
          localStorage.setItem('vx-geo', JSON.stringify(g))
          setGeo({ lat: g.lat, lon: g.lon })
        },
        () => {},
        { timeout: 8000, maximumAge: 15 * 60_000 },
      )
    } catch { /* bỏ qua */ }
  }, [])

  const set = useCallback((patch: Partial<VxThemeState>) => {
    setState((s) => {
      const next = { ...s, ...patch }
      try { localStorage.setItem(LS_KEY, JSON.stringify(next)) } catch { /* bỏ qua */ }
      // Lưu lên server (bỏ qua lỗi — chưa đăng nhập)
      fetch('/api/vx/profile', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ settings: next }) }).catch(() => {})
      return next
    })
  }, [])

  return <ThemeCtx.Provider value={{ ...state, set, geo }}>{children}</ThemeCtx.Provider>
}

function useDeferredThemeInit(setState: React.Dispatch<React.SetStateAction<VxThemeState>>) {
  useEffect(() => {
    const t = setTimeout(() => setState(readLocalTheme()), 0)
    return () => clearTimeout(t)
  }, [])
}

function useDeferredLoad(fn: () => void, deps: unknown[]) {
  useEffect(() => {
    const t = setTimeout(fn, 0)
    return () => clearTimeout(t)
  }, deps)
}

export function useVxTheme() {
  return useContext(ThemeCtx)
}
