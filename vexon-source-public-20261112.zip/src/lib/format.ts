// Định dạng tiền tệ Việt Nam
export function fmtVND(n: number): string {
  return new Intl.NumberFormat('vi-VN').format(Math.round(n)) + '₫'
}

// ===== VÍ TIỀN VEXON (USD theo TỶ GIÁ THẬT) =====
// Số dư nội bộ lưu bằng "xu" (1 xu = 100đ cố định — đúng tỷ lệ nạp).
// Hiển thị USD quy theo tỷ giá USD/VND THỰC TẾ (live từ /api/vx/fx; dự phòng 25.655đ ngày 11/11/2026).
export const XU_VND = 100
export const FALLBACK_USD_VND = 25655

/** xu → USD số học: 99285 xu × 100đ ÷ 25.655đ = $386,99 */
export function xuToUsd(xu: number, usdVnd: number = FALLBACK_USD_VND): number {
  return (xu * XU_VND) / usdVnd
}

/** USD → xu nội bộ (làm tròn nguyên): $2 × 25.655 ÷ 100 = 513 xu */
export function usdToXu(usd: number, usdVnd: number = FALLBACK_USD_VND): number {
  return Math.round((usd * usdVnd) / XU_VND)
}

/** 99285 xu → "$386,99" (chuẩn vi-VN, 2 số lẻ) */
export function fmtUsdFromXu(xu: number, usdVnd: number = FALLBACK_USD_VND): string {
  const s = Math.abs(xuToUsd(xu, usdVnd)).toLocaleString('vi-VN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  return `${xu < 0 ? '-' : ''}$${s}`
}

/** 50 xu → "+$0,19" / -50 xu → "-$0,19" — dùng cho lịch sử giao dịch */
export function fmtUsdSigned(xu: number, usdVnd: number = FALLBACK_USD_VND): string {
  const s = Math.abs(xuToUsd(xu, usdVnd)).toLocaleString('vi-VN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  return `${xu >= 0 ? '+' : '-'}$${s}`
}

/** số USD thô → "386,99" (không có ký tự $) */
export function fmtUsdNumber(usd: number): string {
  return usd.toLocaleString('vi-VN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}

/** r30: TOÀN TRANG KHÔNG CÒN ĐƠN VỊ "XU" — mọi nơi (Công cụ AI, Live, Cài đặt, Video, Vexon AI...) chỉ hiện USD: 99285 xu → "$386,99" */
export function fmtXuWithUsd(xu: number, usdVnd: number = FALLBACK_USD_VND): string {
  return fmtUsdFromXu(xu, usdVnd)
}

// Định dạng ngày giờ VN
export function fmtDateTime(d: string | Date): string {
  return new Date(d).toLocaleString('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function fmtDate(d: string | Date): string {
  return new Date(d).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' })
}

// Nhãn trạng thái đơn hàng
export const ORDER_STATUS: Record<string, { label: string; className: string }> = {
  pending: { label: 'Chờ xác nhận', className: 'bg-amber-100 text-amber-800 border-amber-200' },
  confirmed: { label: 'Đã xác nhận', className: 'bg-emerald-100 text-emerald-800 border-emerald-200' },
  shipping: { label: 'Đang giao', className: 'bg-teal-100 text-teal-800 border-teal-200' },
  done: { label: 'Hoàn tất', className: 'bg-green-100 text-green-800 border-green-200' },
  cancelled: { label: 'Đã huỷ', className: 'bg-red-100 text-red-800 border-red-200' },
}

// Nhãn trạng thái lịch hẹn
export const APPT_STATUS: Record<string, { label: string; className: string }> = {
  scheduled: { label: 'Chờ đến', className: 'bg-amber-100 text-amber-800 border-amber-200' },
  confirmed: { label: 'Đã xác nhận', className: 'bg-emerald-100 text-emerald-800 border-emerald-200' },
  done: { label: 'Hoàn tất', className: 'bg-green-100 text-green-800 border-green-200' },
  cancelled: { label: 'Đã huỷ', className: 'bg-red-100 text-red-800 border-red-200' },
}

// Nhãn loại thao tác kho
export const STOCK_TYPE: Record<string, { label: string; className: string }> = {
  IN: { label: 'Nhập kho', className: 'bg-emerald-100 text-emerald-800 border-emerald-200' },
  OUT: { label: 'Xuất kho', className: 'bg-orange-100 text-orange-800 border-orange-200' },
  ADJUST: { label: 'Điều chỉnh', className: 'bg-gray-100 text-gray-800 border-gray-200' },
}

// Nhãn trạng thái email
export const EMAIL_STATUS: Record<string, { label: string; className: string }> = {
  queued: { label: 'Đang chờ', className: 'bg-amber-100 text-amber-800 border-amber-200' },
  sent: { label: 'Đã gửi', className: 'bg-emerald-100 text-emerald-800 border-emerald-200' },
  cancelled: { label: 'Đã huỷ', className: 'bg-gray-100 text-gray-600 border-gray-200' },
}
