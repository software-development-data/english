'use client'

import { create } from 'zustand'
import type { Tool } from './tools'

export const FREE_RUNS_PER_DAY = 2

export interface Tx {
  id: string
  at: number
  name: string
  xu: number
  kind: 'spend' | 'topup'
  toolSlug?: string
}

export interface Task {
  id: string
  at: number
  toolSlug: string
  toolName: string
  status: 'success' | 'failed'
  xu: number
  _kept?: boolean
}

interface WalletState {
  xu: number
  /** Lượt miễn phí còn lại hôm nay (tài khoản hoặc thiết bị) */
  freeLeft: number
  /** Đã đồng bộ ví server (đã đăng nhập) hay chưa */
  synced: boolean
  txs: Tx[]
  tasks: Task[]
  /** Nạp trạng thái thật từ server — ví Xu CHUNG với nền tảng Vexon (VxUser.coins) */
  hydrate: () => Promise<void>
  topup: (amount: number, note?: string) => void
  /** Giữ chỗ lượt chạy: dùng lượt miễn phí hoặc trừ Xu. Trả về false nếu không đủ điều kiện chạy */
  charge: (tool: Tool) => boolean
  /** Hoàn Xu khi xử lý thất bại (nếu lượt đó bị trừ Xu) */
  refund: (tool: Tool) => void
  logFailed: (tool: Tool, note?: string) => void
  reset: () => void
}

function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

// ── Hạn mức miễn phí cho KHÁCH (chưa đăng nhập): theo thiết bị ──
const DEVICE_KEY = 'vexon-free-runs-v1'

function deviceFreeLeft(): number {
  if (typeof window === 'undefined') return FREE_RUNS_PER_DAY
  try {
    const today = new Date().toDateString()
    const raw = JSON.parse(localStorage.getItem(DEVICE_KEY) || '{}')
    const used = raw.date === today ? Number(raw.used) || 0 : 0
    return Math.max(0, FREE_RUNS_PER_DAY - used)
  } catch {
    return FREE_RUNS_PER_DAY
  }
}

function consumeDeviceFree() {
  try {
    const today = new Date().toDateString()
    const raw = JSON.parse(localStorage.getItem(DEVICE_KEY) || '{}')
    const used = raw.date === today ? Number(raw.used) || 0 : 0
    localStorage.setItem(DEVICE_KEY, JSON.stringify({ date: today, used: used + 1 }))
  } catch {
    /* bỏ qua */
  }
}

/** Báo cho Vexon shell biết số dư thay đổi để cập nhật chip xu trên header */
function pingShell(coins?: number) {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('vx-coins-changed', { detail: { coins } }))
  }
}

export const useWallet = create<WalletState>()((set, get) => ({
  xu: 0,
  freeLeft: FREE_RUNS_PER_DAY,
  synced: false,
  txs: [],
  tasks: [],

  hydrate: async () => {
    try {
      const r = await fetch('/api/tiai/wallet', { cache: 'no-store' })
      if (r.status === 401) {
        // Khách chưa đăng nhập — ví chung hiển thị 0, dùng hạn mức theo thiết bị
        set({ synced: false, xu: 0, freeLeft: deviceFreeLeft() })
        return
      }
      if (!r.ok) {
        // Lỗi server tạm thời — giữ nguyên số dư hiện tại, chờ lần đồng bộ sau
        return
      }
      const d = await r.json()
      set({
        xu: Number(d.xu) || 0,
        freeLeft: Math.max(0, Number(d.freeLeft) || 0),
        txs: Array.isArray(d.txs) ? d.txs : [],
        tasks: Array.isArray(d.tasks) ? d.tasks : [],
        synced: true,
      })
    } catch {
      /* offline — giữ trạng thái hiện tại */
      set({ synced: false, freeLeft: deviceFreeLeft() })
    }
  },

  topup: (amount, note) => {
    // Nạp Xu giờ CHỜ DUYỆT: không cộng xu lạc quan nữa — server tạo giao dịch pending,
    // xu chỉ tăng sau khi Ban Giám đốc duyệt (chống gian lận "bấm là có xu")
    const amt = Math.max(1, Math.round(amount))
    fetch('/api/tiai/wallet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'topup', amount: amt, note }),
    })
      .then(() => get().hydrate())
      .catch(() => {})
  },

  charge: (tool) => {
    const s = get()
    const useFree = s.freeLeft > 0
    if (!useFree && s.xu < tool.price) return false

    // Cập nhật lạc quan: dùng lượt miễn phí hoặc trừ Xu trước, server đối chiếu ngay sau đó
    const txId = uid()
    set((st) => ({
      freeLeft: useFree ? Math.max(0, st.freeLeft - 1) : st.freeLeft,
      xu: useFree ? st.xu : st.xu - tool.price,
      txs: useFree
        ? st.txs
        : [{ id: txId, at: Date.now(), name: tool.name, xu: tool.price, kind: 'spend' as const, toolSlug: tool.slug }, ...st.txs].slice(0, 200),
      tasks: [{ id: uid(), at: Date.now(), toolSlug: tool.slug, toolName: tool.name, status: 'success' as const, xu: useFree ? 0 : tool.price }, ...st.tasks].slice(0, 200),
    }))
    if (useFree && !s.synced) consumeDeviceFree()
    pingShell()

    fetch('/api/tiai/wallet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'charge', slug: tool.slug }),
    })
      .then(async (r) => {
        const d = await r.json().catch(() => ({}))
        if (!r.ok) {
          // Server từ chối (hết lượt miễn phí + không đủ Xu) — hoàn lại tối ưu
          set((st) => ({
            freeLeft: Math.max(st.freeLeft, 0),
            xu: useFree ? st.xu : st.xu + tool.price,
            txs: useFree ? st.txs : st.txs.filter((t) => t.id !== txId),
            tasks: st.tasks.map((t) =>
              t.toolSlug === tool.slug && t.status === 'success' && !t._kept
                ? { ...t, status: 'failed' as const, xu: 0, _kept: true }
                : t,
            ),
          }))
          pingShell()
        } else {
          // Đồng bộ số thật + hạn mức miễn phí thật từ server
          const patch: Partial<WalletState> = {}
          if (d.coins !== undefined) patch.xu = d.coins
          if (d.freeLeft !== undefined) patch.freeLeft = Math.max(0, Number(d.freeLeft) || 0)
          if (Object.keys(patch).length) {
            set(patch as WalletState)
            pingShell(d.coins)
          }
          // Nếu server tính là miễn phí nhưng client đã trừ Xu (lệch lạc) — sửa lại task
          if (d.free && !useFree) {
            set((st) => ({ tasks: st.tasks.map((t) => (t.toolSlug === tool.slug && t.status === 'success' ? { ...t, xu: 0 } : t)) }))
          }
        }
      })
      .catch(() => {})
    return true
  },

  refund: (tool) => {
    // Hoàn tối ưu: nếu lượt vừa rồi bị trừ Xu thì trả lại client, server hoàn phần thật
    const paidTask = get().tasks.find((t) => t.toolSlug === tool.slug && t.status === 'success' && t.xu > 0 && !t._kept)
    if (paidTask) {
      set((st) => {
        const idx = st.txs.findIndex((t) => t.toolSlug === tool.slug && t.kind === 'spend' && t.xu === tool.price)
        const txs = [...st.txs]
        if (idx !== -1) txs.splice(idx, 1)
        return {
          xu: st.xu + tool.price,
          txs,
          tasks: st.tasks.map((t) => (t.id === paidTask.id ? { ...t, status: 'failed' as const, xu: 0 } : t)),
        }
      })
      pingShell()
    }
    fetch('/api/tiai/wallet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'refund', slug: tool.slug }),
    })
      .then(async (r) => {
        const d = await r.json().catch(() => ({}))
        if (r.ok && d.coins !== undefined) {
          set({ xu: d.coins })
          pingShell(d.coins)
        }
      })
      .catch(() => {})
  },

  logFailed: (tool) => {
    set((s) => ({
      tasks: [{ id: uid(), at: Date.now(), toolSlug: tool.slug, toolName: tool.name, status: 'failed' as const, xu: 0 }, ...s.tasks].slice(0, 200),
    }))
    fetch('/api/tiai/wallet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'failed', slug: tool.slug }),
    }).catch(() => {})
  },

  reset: () => {
    // Không xóa dữ liệu server — chỉ tải lại trạng thái thật
    get().hydrate()
  },
}))

// ── Đồng bộ ví Xu CHUNG theo thời gian thực ──────────────────────
// Mọi nơi kiếm/tiêu Xu (mạng xã hội, Công cụ AI, Vexon AI, nạp QR) đều phát
// sự kiện 'vx-coins-changed' → một số dư duy nhất hiện đúng ở mọi phân hệ:
//  • Có detail.coins (số dư thật vừa lấy từ server) → áp ngay, không cần fetch
//  • Không có detail (mới kiếm Xu trên MXH) → tự kéo số dư thật về (throttle)
let lastEventPull = 0
function pullTruthSoon() {
  const now = Date.now()
  if (now - lastEventPull < 1200) return
  lastEventPull = now
  useWallet.getState().hydrate()
}

if (typeof window !== 'undefined') {
  window.addEventListener('vx-coins-changed', (e) => {
    const coins = (e as CustomEvent<{ coins?: number }>).detail?.coins
    if (typeof coins === 'number') {
      useWallet.setState((s) => (s.xu === coins ? s : { xu: coins, synced: true }))
    } else {
      pullTruthSoon()
    }
  })
  // Quay lại tab → tải số dư mới nhất (tránh giữ số cũ cả buổi)
  window.addEventListener('focus', () => {
    if (useWallet.getState().synced) pullTruthSoon()
  })
}
