'use client'

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(r.result as string)
    r.onerror = () => reject(new Error('Không đọc được tệp'))
    r.readAsDataURL(file)
  })
}

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = () => reject(new Error('Không mở được ảnh — vui lòng thả tệp PNG/JPG/WEBP hợp lệ'))
    img.src = src
  })
}

export async function fileToImage(file: File): Promise<{ img: HTMLImageElement; url: string }> {
  const url = await fileToDataUrl(file)
  const img = await loadImage(url)
  return { img, url }
}

export function makeCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement('canvas')
  c.width = w
  c.height = h
  return c
}

export function canvasToBlob(canvas: HTMLCanvasElement, type = 'image/png', quality = 0.92): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (b) => {
        if (b) resolve(b)
        else reject(new Error('Không tạo được ảnh kết quả'))
      },
      type,
      quality
    )
  })
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 4000)
}

/** Convolution kernel làm nét (unsharp mask dạng kernel 3×3) */
export function sharpenCanvas(src: HTMLCanvasElement, amount = 1): HTMLCanvasElement {
  const w = src.width
  const h = src.height
  const sctx = src.getContext('2d', { willReadFrequently: true })!
  const data = sctx.getImageData(0, 0, w, h)
  const out = makeCanvas(w, h)
  const octx = out.getContext('2d', { willReadFrequently: true })!
  const dst = octx.createImageData(w, h)
  const s = data.data
  const d = dst.data
  // kernel: center 1+4a, cạnh -a
  const k = [0, -amount, 0, -amount, 1 + 4 * amount, -amount, 0, -amount, 0]
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let r = 0, g = 0, b = 0
      for (let ky = -1; ky <= 1; ky++) {
        for (let kx = -1; kx <= 1; kx++) {
          const px = Math.min(w - 1, Math.max(0, x + kx))
          const py = Math.min(h - 1, Math.max(0, y + ky))
          const i = (py * w + px) * 4
          const kv = k[(ky + 1) * 3 + (kx + 1)]
          r += s[i] * kv
          g += s[i + 1] * kv
          b += s[i + 2] * kv
        }
      }
      const o = (y * w + x) * 4
      d[o] = Math.max(0, Math.min(255, r))
      d[o + 1] = Math.max(0, Math.min(255, g))
      d[o + 2] = Math.max(0, Math.min(255, b))
      d[o + 3] = s[o + 3]
    }
  }
  octx.putImageData(dst, 0, 0)
  return out
}

export function upscaleCanvas(src: HTMLCanvasElement, factor: number): HTMLCanvasElement {
  // Bước ×2 lặp để giữ chi tiết, mỗi bước làm nét nhẹ
  let cur = src
  let remaining = factor
  while (remaining > 1.01) {
    const step = Math.min(2, remaining)
    const next = makeCanvas(Math.round(cur.width * step), Math.round(cur.height * step))
    const nctx = next.getContext('2d', { willReadFrequently: true })!
    nctx.imageSmoothingEnabled = true
    nctx.imageSmoothingQuality = 'high'
    nctx.drawImage(cur, 0, 0, next.width, next.height)
    cur = sharpenCanvas(next, 0.6)
    remaining /= step
  }
  return cur
}

/** Xóa nền: flood-fill từ viền, xóa vùng màu gần giống viền */
export function removeBackground(src: HTMLCanvasElement, tolerance = 32): HTMLCanvasElement {
  const w = src.width
  const h = src.height
  const ctx = src.getContext('2d', { willReadFrequently: true })!
  const img = ctx.getImageData(0, 0, w, h)
  const d = img.data
  const visited = new Uint8Array(w * h)
  const stack: number[] = []
  const seedColors: [number, number, number][] = []
  const push = (x: number, y: number) => {
    const p = y * w + x
    if (!visited[p]) {
      visited[p] = 1
      stack.push(p)
      const i = p * 4
      seedColors.push([d[i], d[i + 1], d[i + 2]])
    }
  }
  for (let x = 0; x < w; x++) {
    push(x, 0)
    push(x, h - 1)
  }
  for (let y = 0; y < h; y++) {
    push(0, y)
    push(w - 1, y)
  }
  // Màu nền trung bình từ viền
  let sr = 0, sg = 0, sb = 0
  for (const c of seedColors) {
    sr += c[0]; sg += c[1]; sb += c[2]
  }
  const n = seedColors.length || 1
  sr /= n; sg /= n; sb /= n
  const tol2 = tolerance * tolerance * 3

  const mask = new Uint8Array(w * h)
  const queue = [...stack]
  while (queue.length) {
    const p = queue.pop()!
    const i = p * 4
    const dr = d[i] - sr, dg = d[i + 1] - sg, db = d[i + 2] - sb
    if (dr * dr + dg * dg + db * db > tol2) continue
    mask[p] = 1
    const x = p % w
    const y = (p / w) | 0
    const neighbors = [
      x > 0 ? p - 1 : -1,
      x < w - 1 ? p + 1 : -1,
      y > 0 ? p - w : -1,
      y < h - 1 ? p + w : -1,
    ]
    for (const np of neighbors) {
      if (np >= 0 && !visited[np]) {
        visited[np] = 1
        queue.push(np)
      }
    }
  }
  // Làm mượt mép: nới bán kính 1px alpha dần
  for (let p = 0; p < w * h; p++) {
    if (mask[p]) d[p * 4 + 3] = 0
  }
  const out = makeCanvas(w, h)
  out.getContext('2d')!.putImageData(img, 0, 0)
  return out
}

/** Làm đẹp: làm mịn chọn lọc trên tông da + tăng sáng nhẹ */
export function beautifyCanvas(src: HTMLCanvasElement, strength = 0.5): HTMLCanvasElement {
  const w = src.width
  const h = src.height
  const ctx = src.getContext('2d', { willReadFrequently: true })!
  const img = ctx.getImageData(0, 0, w, h)
  const s = img.data
  // Box blur bán kính 2
  const r = 2
  const blurred = new Uint8ClampedArray(s.length)
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let rr = 0, gg = 0, bb = 0, aa = 0, cnt = 0
      for (let dy = -r; dy <= r; dy++) {
        const py = y + dy
        if (py < 0 || py >= h) continue
        for (let dx = -r; dx <= r; dx++) {
          const px = x + dx
          if (px < 0 || px >= w) continue
          const i = (py * w + px) * 4
          rr += s[i]; gg += s[i + 1]; bb += s[i + 2]; aa += s[i + 3]
          cnt++
        }
      }
      const o = (y * w + x) * 4
      blurred[o] = rr / cnt
      blurred[o + 1] = gg / cnt
      blurred[o + 2] = bb / cnt
      blurred[o + 3] = aa / cnt
    }
  }
  const out = makeCanvas(w, h)
  const octx = out.getContext('2d', { willReadFrequently: true })!
  const res = octx.createImageData(w, h)
  const d = res.data
  for (let p = 0; p < w * h; p++) {
    const i = p * 4
    const R = s[i], G = s[i + 1], B = s[i + 2]
    // heuristics tông da: R > G > B và đủ sáng
    const isSkin = R > 95 && G > 40 && B > 20 && R > G && G > B && R - Math.min(G, B) > 15
    const mix = isSkin ? strength * 0.85 : strength * 0.15
    d[i] = R + (blurred[i] - R) * mix
    d[i + 1] = G + (blurred[i + 1] - G) * mix
    d[i + 2] = B + (blurred[i + 2] - B) * mix
    d[i + 3] = s[i + 3]
    // tăng sáng + đều tông nhẹ
    d[i] = Math.min(255, d[i] * 1.03 + 6)
    d[i + 1] = Math.min(255, d[i + 1] * 1.02 + 4)
    d[i + 2] = Math.min(255, d[i + 2] * 1.01 + 3)
  }
  octx.putImageData(res, 0, 0)
  return out
}

export interface CropOpts {
  ratioW: number
  ratioH: number
  zoom: number
  offsetX: number // -1..1
  offsetY: number // -1..1
}

export function cropCanvas(src: HTMLCanvasElement, opts: CropOpts): HTMLCanvasElement {
  const { ratioW, ratioH, zoom } = opts
  const sw = src.width
  const sh = src.height
  // vùng crop lớn nhất theo tỉ lệ nằm trọn trong ảnh
  let cw = sw
  let ch = (cw * ratioH) / ratioW
  if (ch > sh) {
    ch = sh
    cw = (ch * ratioW) / ratioH
  }
  cw /= zoom
  ch /= zoom
  const maxX = (sw - cw) / 2
  const maxY = (sh - ch) / 2
  const cx = sw / 2 + opts.offsetX * maxX
  const cy = sh / 2 + opts.offsetY * maxY
  const out = makeCanvas(Math.round(cw), Math.round(ch))
  const octx = out.getContext('2d')!
  octx.drawImage(src, cx - cw / 2, cy - ch / 2, cw, ch, 0, 0, out.width, out.height)
  return out
}
