'use client'

import { create } from 'zustand'

export type View =
  | { name: 'home' }
  | { name: 'tools' }
  | { name: 'oss' }
  | { name: 'tool'; slug: string }
  | { name: 'wallet' }
  | { name: 'history' }

interface ViewState {
  view: View
  stack: View[]
  go: (v: View) => void
  back: () => void
}

export const useView = create<ViewState>((set, get) => ({
  view: { name: 'home' },
  stack: [],
  go: (v) => {
    const { view, stack } = get()
    set({ view: v, stack: [...stack, view].slice(-30) })
    if (typeof window !== 'undefined') window.scrollTo({ top: 0 })
  },
  back: () => {
    const { stack } = get()
    if (stack.length === 0) {
      set({ view: { name: 'home' } })
    } else {
      const prev = stack[stack.length - 1]
      set({ view: prev, stack: stack.slice(0, -1) })
    }
    if (typeof window !== 'undefined') window.scrollTo({ top: 0 })
  },
}))
