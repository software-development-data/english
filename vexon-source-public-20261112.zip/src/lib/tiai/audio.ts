'use client'

export async function decodeAudioFile(file: File): Promise<AudioBuffer> {
  const ab = await file.arrayBuffer()
  const AC: typeof AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
  const ctx = new AC()
  const buf = await ctx.decodeAudioData(ab)
  void ctx.close()
  return buf
}

/** Tính đỉnh sóng để vẽ waveform */
export function computePeaks(buffer: AudioBuffer, width = 800): number[] {
  const ch = buffer.getChannelData(0)
  const block = Math.floor(ch.length / width) || 1
  const peaks: number[] = []
  for (let i = 0; i < width; i++) {
    let max = 0
    const start = i * block
    for (let j = 0; j < block; j += Math.max(1, Math.floor(block / 50))) {
      const v = Math.abs(ch[start + j] || 0)
      if (v > max) max = v
    }
    peaks.push(max)
  }
  return peaks
}

/** Encode AudioBuffer thành WAV 16-bit PCM */
export function encodeWav(buffer: AudioBuffer, startSec = 0, endSec?: number): Blob {
  const numCh = Math.min(2, buffer.numberOfChannels)
  const sr = buffer.sampleRate
  const s0 = Math.max(0, Math.floor(startSec * sr))
  const s1 = Math.min(buffer.length, Math.floor((endSec ?? buffer.duration) * sr))
  const n = Math.max(0, s1 - s0)
  const bytesPerSample = 2
  const dataSize = n * numCh * bytesPerSample
  const ab = new ArrayBuffer(44 + dataSize)
  const view = new DataView(ab)
  const wstr = (off: number, str: string) => {
    for (let i = 0; i < str.length; i++) view.setUint8(off + i, str.charCodeAt(i))
  }
  wstr(0, 'RIFF')
  view.setUint32(4, 36 + dataSize, true)
  wstr(8, 'WAVE')
  wstr(12, 'fmt ')
  view.setUint32(16, 16, true)
  view.setUint16(20, 1, true)
  view.setUint16(22, numCh, true)
  view.setUint32(24, sr, true)
  view.setUint32(28, sr * numCh * bytesPerSample, true)
  view.setUint16(32, numCh * bytesPerSample, true)
  view.setUint16(34, 16, true)
  wstr(36, 'data')
  view.setUint32(40, dataSize, true)
  const channels: Float32Array[] = []
  for (let c = 0; c < numCh; c++) channels.push(buffer.getChannelData(c))
  let off = 44
  for (let i = 0; i < n; i++) {
    for (let c = 0; c < numCh; c++) {
      let v = channels[c][s0 + i]
      v = Math.max(-1, Math.min(1, v))
      view.setInt16(off, v < 0 ? v * 0x8000 : v * 0x7fff, true)
      off += 2
    }
  }
  return new Blob([ab], { type: 'audio/wav' })
}

/** Đổi tốc độ bằng resample nội suy tuyến tính */
export function changeSpeed(buffer: AudioBuffer, speed: number): AudioBuffer {
  const AC: typeof AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
  const ctx = new AC()
  const srcSr = buffer.sampleRate
  const nOut = Math.floor(buffer.length / speed)
  const out = ctx.createBuffer(buffer.numberOfChannels, nOut, srcSr)
  for (let c = 0; c < buffer.numberOfChannels; c++) {
    const inp = buffer.getChannelData(c)
    const dst = out.getChannelData(c)
    for (let i = 0; i < nOut; i++) {
      const pos = i * speed
      const i0 = Math.floor(pos)
      const frac = pos - i0
      const a = inp[i0] || 0
      const b = inp[i0 + 1] || 0
      dst[i] = a + (b - a) * frac
    }
  }
  void ctx.close()
  return out
}

export interface SplitResult {
  vocal: Blob
  instrumental: Blob
  sampleRate: number
  duration: number
}

/**
 * Tách lời & nhạc bằng DSP karaoke kinh điển:
 * - Nhạc nền (instrumental) ≈ L − R  (triệt tiêu âm trung tâm = vocal)
 * - Giọng hát (vocal) ≈ (L+R)/2 qua band-pass 180–4000 Hz
 */
export function splitVocals(buffer: AudioBuffer): SplitResult {
  const AC: typeof AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
  const ctx = new AC()
  const sr = buffer.sampleRate
  const n = buffer.length
  const L = buffer.getChannelData(0)
  const R = buffer.numberOfChannels > 1 ? buffer.getChannelData(1) : L
  const mono = new Float32Array(n)
  const side = new Float32Array(n)
  for (let i = 0; i < n; i++) {
    mono[i] = (L[i] + R[i]) / 2
    side[i] = L[i] - R[i]
  }
  // Band-pass 180–4000 Hz cho vocal (butterworth bậc 2 xấp xỉ bằng lọc sai phân)
  const vocal = bandpass(mono, sr, 180, 4000)
  const instrumental = bandpass(side, sr, 20, Math.min(16000, sr / 2 - 100))
  const vBuf = ctx.createBuffer(1, n, sr)
  vBuf.copyToChannel(vocal as Float32Array<ArrayBuffer>, 0)
  const iBuf = ctx.createBuffer(Math.min(2, buffer.numberOfChannels), n, sr)
  if (buffer.numberOfChannels > 1) {
    iBuf.copyToChannel(instrumental as Float32Array<ArrayBuffer>, 0)
    iBuf.copyToChannel(instrumental.map((v) => -v), 1)
  } else {
    iBuf.copyToChannel(instrumental as Float32Array<ArrayBuffer>, 0)
  }
  void ctx.close()
  return {
    vocal: encodeWav(vBuf),
    instrumental: encodeWav(iBuf),
    sampleRate: sr,
    duration: buffer.duration,
  }
}

/** Simple state-variable band-pass (2pole) — đủ dùng cho hiệu ứng */
function bandpass(input: Float32Array, sr: number, lo: number, hi: number): Float32Array {
  return highpass(lowpass(input, hi, sr), lo, sr)
}

function lowpass(input: Float32Array, cutoff: number, sr: number): Float32Array {
  const rc = 1 / (2 * Math.PI * cutoff)
  const dt = 1 / sr
  const alpha = dt / (rc + dt)
  const out = new Float32Array(input.length)
  let prev = 0
  for (let i = 0; i < input.length; i++) {
    prev += alpha * (input[i] - prev)
    out[i] = prev
  }
  return out
}

function highpass(input: Float32Array, cutoff: number, sr: number): Float32Array {
  const rc = 1 / (2 * Math.PI * cutoff)
  const dt = 1 / sr
  const alpha = rc / (rc + dt)
  const out = new Float32Array(input.length)
  let prevIn = input[0] || 0
  let prevOut = 0
  for (let i = 0; i < input.length; i++) {
    const x = input[i]
    prevOut = alpha * (prevOut + x - prevIn)
    prevIn = x
    out[i] = prevOut
  }
  return out
}

export function formatDur(sec: number): string {
  const m = Math.floor(sec / 60)
  const s = Math.floor(sec % 60)
  return `${m}:${s.toString().padStart(2, '0')}`
}
