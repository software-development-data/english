// ─── THƯ VIỆN NGUỒN MỞ AI (gifhub tổng hợp) ──────────────────────
// Danh mục repo mã nguồn mở tuyển chọn cho Vexon AI tư vấn + trang "Nguồn mở AI"
// trong Công cụ AI. Dùng chung cho: OSS hub UI + gợi ý ngữ cảnh trong /api/assistant.

export interface OssRepo {
  name: string
  url: string
  desc: string
  use: string
}

export interface OssGroup {
  key: string
  title: string
  icon: string
  tint: string
  keywords: string[]
  repos: OssRepo[]
}

export const OSS_GROUPS: OssGroup[] = [
  {
    key: 'gen-video',
    title: 'Sinh Video AI & Motion (Text/Image-to-Video)',
    icon: 'video',
    tint: 'from-emerald-600 to-teal-600',
    keywords: ['tạo video', 'sinh video', 'text to video', 'image to video', 'sora', 'video ai', 'b-roll', 'motion', 'quảng cáo video'],
    repos: [
      { name: 'Wan-Video/Wan2.1 · Wan2.2', url: 'https://github.com/Wan-Video/Wan2.1', desc: 'Mô hình tạo video mã nguồn mở chất lượng điện ảnh, sinh chuyển động tự nhiên từ prompt và ảnh đầu vào.', use: 'Sản xuất B-roll, visual effects, cảnh quay chuyển động không gian thực.' },
      { name: 'Tencent/HunyuanVideo', url: 'https://github.com/Tencent/HunyuanVideo', desc: 'Hệ thống sinh video đa phương thức cỡ lớn, hiểu ngữ cảnh văn bản dài, chuyển động nhân vật sắc nét.', use: 'Phim quảng cáo, video ngắn storytelling độ phân giải cao.' },
      { name: 'Lightricks/LTX-Video', url: 'https://github.com/Lightricks/LTX-Video', desc: 'Sinh video thời gian thực siêu tốc hỗ trợ WebGPU, chạy trực tiếp trên card đồ họa cá nhân.', use: 'Preview nhanh ý tưởng chuyển động, dựng storyboard ngay trên web.' },
      { name: 'PKU-YuanGroup/Open-Sora-Plan', url: 'https://github.com/PKU-YuanGroup/Open-Sora-Plan', desc: 'Tái lập mô hình sinh video Sora của OpenAI hoàn toàn mở.', use: 'Tạo video chuyển động chất lượng cao từ văn bản và hình ảnh.' },
      { name: 'modelscope/text-to-video-synthesis', url: 'https://github.com/modelscope/modelscope', desc: 'Thư viện mã nguồn mở cho các mô hình sinh video ngắn từ text.', use: 'Nguyên liệu visual effect và cảnh quay B-roll ngắn.' },
      { name: 'Vchitra/Awesome-Text-to-Video', url: 'https://github.com/Vchitra/Awesome-Text-to-Video', desc: 'Danh sách tổng hợp thuật toán, mô hình, thư viện Text-to-Video tiên tiến nhất.', use: 'Tra cứu và thử nghiệm mô hình sinh video mới.' },
    ],
  },
  {
    key: 'enhance-video',
    title: 'Khôi phục, Khử nhiễu & Làm nét Video',
    icon: 'search',
    tint: 'from-sky-600 to-cyan-600',
    keywords: ['upscale video', 'làm nét video', '4k', '8k', 'khử nhiễu', 'khôi phục video', 'super resolution'],
    repos: [
      { name: 'xinntao/Real-ESRGAN', url: 'https://github.com/xinntao/Real-ESRGAN', desc: 'Nâng độ phân giải (upscale) video/ảnh lên 4K–8K không vỡ hình, không bệt chi tiết.', use: 'Khôi phục video chất lượng thấp, video kiến trúc, quay phim bị mờ.' },
      { name: 'hao2015/VSR-TensorFlow', url: 'https://github.com/hao2015/VSR-TensorFlow', desc: 'Bộ thư viện Video Super-Resolution tối ưu cho chuỗi khung hình.', use: 'Tăng độ nét và khôi phục chi tiết chuyển động giữa các frame.' },
      { name: 'NVIDIA/Video-Super-Resolution', url: 'https://github.com/NVIDIA/Video-Super-Resolution', desc: 'Super Resolution trên GPU NVIDIA, xử lý video real-time.', use: 'Upscale video trực tiếp khi có phần cứng NVIDIA.' },
    ],
  },
  {
    key: 'lipsync',
    title: 'Khớp môi & Lồng tiếng Video (Lipsync)',
    icon: 'voice',
    tint: 'from-rose-600 to-orange-600',
    keywords: ['lipsync', 'khớp môi', 'lồng tiếng', 'phát thanh viên ai', 'avatar nói', 'wav2lip', 'sadtalker'],
    repos: [
      { name: 'OpenTalker/SadTalker', url: 'https://github.com/OpenTalker/SadTalker', desc: 'Tạo cử động khuôn mặt và khớp môi từ 1 ảnh tĩnh + 1 file voiceover.', use: 'Video phát thanh viên AI, nhân vật nói chuyện tự động.' },
      { name: 'Rudrabha/Wav2Lip', url: 'https://github.com/Rudrabha/Wav2Lip', desc: 'Đồng bộ cử động môi chuẩn xác với mọi giọng đọc trên video có sẵn.', use: 'Lồng tiếng đa ngôn ngữ mà môi vẫn khớp hoàn toàn.' },
      { name: 'guangweish/Wav2Lip-HD', url: 'https://github.com/guangweish/Wav2Lip-HD', desc: 'Bản HD của Wav2Lip kết hợp GAN giữ chi tiết khuôn mặt.', use: 'Lipsync nét cao cho video thương mại.' },
    ],
  },
  {
    key: 'edit-video',
    title: 'Dựng phim AI & Tự động cắt ghép (Timeline)',
    icon: 'clip',
    tint: 'from-emerald-600 to-teal-600',
    keywords: ['dựng phim', 'cắt ghép video', 'timeline', 'editor ai', 'cắt khoảng lặng', 'auto cut', 'render', 'subtitle tự động'],
    repos: [
      { name: '0xsline/OpenChatCut', url: 'https://github.com/0xsline/OpenChatCut', desc: 'Trình dựng video AI tự host với timeline đa track, tích hợp Agent Skills & MCP.', use: 'Ra lệnh giọng nói/text để AI tự chọn clip, hiệu ứng, phụ đề và render.' },
      { name: 'OpenReel-Video/OpenReel', url: 'https://github.com/OpenReel-Video/OpenReel', desc: 'Video Editor AI mã nguồn mở kết nối mọi LLM, 275+ công cụ điều khiển AI trên timeline.', use: 'AI tự đổi khung 16:9 → 9:16, cắt bám nhịp, căn màu cinematic, sinh phụ đề.' },
      { name: 'WyattBlue/auto-editor', url: 'https://github.com/WyattBlue/auto-editor', desc: 'CLI tự phân tích âm thanh, phát hiện khoảng lặng và cắt bỏ đoạn thừa.', use: 'Dựng thô siêu tốc cho video nói, vlog, bài giảng, podcast.' },
      { name: 'Zulko/moviepy', url: 'https://github.com/Zulko/moviepy', desc: 'Thư viện Python chỉnh sửa video bằng code: cắt, ghép, chèn chữ, hiệu ứng, âm thanh.', use: 'Script xuất hàng loạt video theo template có sẵn.' },
      { name: 'FFmpeg/FFmpeg', url: 'https://github.com/FFmpeg/FFmpeg', desc: 'Framework xử lý multimedia số 1 thế giới: convert, render, nén, stream.', use: 'Hạ tầng cốt lõi cho mọi pipeline xử lý video tự động.' },
    ],
  },
  {
    key: 'scene-detect',
    title: 'Cắt ghép theo phân cảnh (Scene Detection)',
    icon: 'cut',
    tint: 'from-amber-600 to-yellow-600',
    keywords: ['phát hiện cảnh', 'scene detection', 'chia clip', 'shot list', 'phân tích video', 'gán nhãn video'],
    repos: [
      { name: 'Breakthrough/PySceneDetect', url: 'https://github.com/Breakthrough/PySceneDetect', desc: 'Tự phát hiện điểm chuyển cảnh trong video và cắt thành các clip nhỏ.', use: 'Chia video dài thành nguyên liệu dựng, bóc tách shot list.' },
      { name: 'facebookresearch/pytorchvideo', url: 'https://github.com/facebookresearch/pytorchvideo', desc: 'Thư viện Deep Learning của Meta chuyên phân tích, gán nhãn, hiểu hành vi trong video.', use: 'Phân loại cảnh quay, tìm cú quay theo hành vi nhân vật.' },
    ],
  },
  {
    key: 'short-video',
    title: 'Tự động hóa Video ngắn (Shorts · Reels · TikTok)',
    icon: 'mobile',
    tint: 'from-pink-600 to-rose-600',
    keywords: ['shorts', 'reels', 'tiktok', 'video ngắn', 'voiceover', 'pipeline video'],
    repos: [
      { name: 'MagiclightAI/GitHub-AI-Video-Generator', url: 'https://github.com/MagiclightAI/GitHub-AI-Video-Generator', desc: 'No-code biến repo GitHub, bài blog hoặc kịch bản thành video ngắn tự động.', use: 'Tạo video demo dự án, voiceover đa ngôn ngữ, phụ đề tự động.' },
      { name: 'aivideoquality/Best-AI-Video-Generators', url: 'https://github.com/aivideoquality/Best-AI-Video-Generators', desc: 'Benchmark chất lượng khung hình và độ chuyển động của các mô hình video AI mở.', use: 'So sánh, kiểm thử mô hình trước khi triển khai sản xuất.' },
    ],
  },
  {
    key: 'company-os',
    title: 'Company OS · Điều hành công ty 1 người bằng AI Agent',
    icon: 'org',
    tint: 'from-sky-600 to-blue-600',
    keywords: ['company os', 'command center', 'ai agent', 'điều hành công ty', 'solo founder', 'solopreneur', 'one person company', 'tự động hóa', 'nhân sự ảo', 'tuyển dụng tự động'],
    repos: [
      { name: '1mancompany/OneManCompany', url: 'https://github.com/1mancompany/OneManCompany', desc: 'Hệ điều hành AI agent mở cho phép 1 người điều hành toàn công ty: AI tự lập trình, thiết kế, QA, vận hành.', use: 'Khung vận hành tự động cho công ty solo.' },
      { name: 'Bennettxai/FounderOS', url: 'https://github.com/Bennettxai/FounderOS', desc: 'Trung tâm điều khiển doanh nghiệp mở: chia phòng ban AI (truyền thông, tài chính, nội dung, CSKH) trên 1 dashboard.', use: 'Quản lý giao dịch, chiến dịch và hệ thống agent trong một giao diện.' },
      { name: 'alex-jb/solo-founder-os', url: 'https://github.com/topics/solo-founder', desc: 'Stack 10 AI agent tự tiến hóa: bộ nhớ, tự đánh giá lỗi, cập nhật thư viện kỹ năng.', use: 'Vận hành đa nhiệm cho nhà sáng lập đơn lẻ.' },
      { name: 'Sudhakaran88/solopreneur-skills', url: 'https://github.com/Sudhakaran88/solopreneur-skills', desc: '42 kỹ năng AI Agent cho nhà sáng lập solo, SaaS cá nhân, thương hiệu D2C.', use: 'Tối ưu marketing, tăng trưởng và bán hàng.' },
      { name: 'whawkinsiv/solo-founder-skills', url: 'https://github.com/whawkinsiv/solo-founder-skills', desc: 'Kỹ năng cho Claude Code theo triết lý "bán trước khi xây".', use: 'Chốt 10 khách đầu tiên, bảo mật app, kiểm thử UI.' },
      { name: 'pollymallen/solopreneur-ai-staff', url: 'https://github.com/pollymallen/solopreneur-ai-staff', desc: 'Starter kit biến AI Agent thành đội ngũ nhân sự ảo (AI Staff).', use: 'Dựng "đội ngũ" cho mô hình kinh doanh cá nhân.' },
      { name: 'princepal9120/awesome-solo-founder-oss', url: 'https://github.com/topics/solo-founder', desc: 'Awesome list công cụ mã nguồn mở để solo founder xây, ra mắt, bán hàng, chăm khách.', use: 'Tra cứu nhanh công cụ phù hợp từng giai đoạn.' },
      { name: 'feder-cr/Jobs_Applier_AI_Agent_AIHawk', url: 'https://github.com/feder-cr/Jobs_Applier_AI_Agent_AIHawk', desc: 'Agent tự tìm kiếm đối tác/ứng viên, cào dữ liệu và gửi đơn ứng tuyển tự động.', use: 'Tự động hóa tuyển dụng & outreach.' },
      { name: 'xq002011-cpu/awesome-one-person-company', url: 'https://github.com/xq002011-cpu/awesome-one-person-company', desc: 'Tài nguyên, AI workflows và template kinh doanh cho công ty 1 người.', use: 'Tham khảo quy trình kiếm lợi nhuận đơn lẻ.' },
    ],
  },
  {
    key: 'social-oss',
    title: 'Mạng xã hội Open-Source (FB · Telegram · YouTube · Threads)',
    icon: 'org',
    tint: 'from-emerald-600 to-teal-600',
    keywords: ['mạng xã hội', 'social network', 'facebook clone', 'forum', 'diễn đàn', 'telegram clone', 'nhóm cộng đồng', 'fanpage', 'timeline'],
    repos: [
      { name: 'mastodon/mastodon', url: 'https://github.com/mastodon/mastodon', desc: 'Nền tảng mạng xã hội phi tập trung nổi tiếng nhất: đăng bài, timeline, follower, hashtag.', use: 'Tham khảo kiến trúc feed & tương tác kiểu Threads/Twitter.' },
      { name: 'discourse/discourse', url: 'https://github.com/discourse/discourse', desc: 'Nền tảng thảo luận nhóm & cộng đồng chuyên nghiệp, thông báo thời gian thực, phân quyền thành viên.', use: 'Xây nhóm thảo luận, diễn đàn nội bộ kiểu FB Groups.' },
      { name: 'Chocobozzz/PeerTube', url: 'https://github.com/Chocobozzz/PeerTube', desc: 'Chia sẻ video & livestream phi tập trung dùng P2P (WebTorrent), có kênh cá nhân, bình luận, lượt xem.', use: 'Làm nền tảng video nội bộ kiểu YouTube.' },
      { name: 'element-hq/element-web', url: 'https://github.com/element-hq/element-web', desc: 'Chat nhóm mã hoá end-to-end theo giao thức Matrix: kênh chat, gọi video nhóm, gửi tệp, sticker.', use: 'Tham khảo tin nhắn mã hoá + gọi nhóm bảo mật.' },
      { name: 'mattermost/mattermost', url: 'https://github.com/mattermost/mattermost', desc: 'Nền tảng nhắn tin self-host: room chat, kênh thảo luận, chia sẻ file, thông báo mượt.', use: 'Chat nhóm doanh nghiệp kiểu Slack/Telegram.' },
      { name: 'supabase/user-management', url: 'https://github.com/supabase-community/supabase-threads-clone', desc: 'Mẫu mạng xã hội Threads/Twitter full-stack Next.js + Supabase (Auth, Realtime Feed, Post, Like).', use: 'Mốc tham khảo làm feed realtime nhanh gọn.' },
    ],
  },
  {
    key: 'webrtc-meet',
    title: 'Gọi Video, Họp Nhóm & Ghi Âm (WebRTC · Zoom Clone)',
    icon: 'video',
    tint: 'from-teal-600 to-emerald-600',
    keywords: ['gọi video', 'họp nhóm', 'webRTC', 'zoom', 'call', 'ghi âm cuộc họp', 'chia sẻ màn hình', 'giơ tay', 'meeting', 'họp trực tuyến'],
    repos: [
      { name: 'jitsi/jitsi-meet', url: 'https://github.com/jitsi/jitsi-meet', desc: 'Họp nhóm chuyên nghiệp như Zoom, hỗ trợ hàng trăm người, ghi âm cuộc họp, chia sẻ màn hình, giơ tay phát biểu.', use: 'Tham khảo họp nhóm quy mô lớn cho tính năng Họp nhóm Vexon.' },
      { name: 'livekit/livekit', url: 'https://github.com/livekit/livekit', desc: 'Hạ tầng WebRTC hiệu năng cao: room/meeting nhóm, sẵn tính năng ghi hình/ghi âm (Egress).', use: 'Backend SFU cho cuộc gọi & họp nhóm nhiều người.' },
      { name: 'miroslavpejic85/mirotalk', url: 'https://github.com/miroslavpejic85/mirotalk', desc: 'Giao diện giống Zoom, cài 1-click: họp P2P/SFU, chia sẻ màn hình, chat, ghi âm ghi hình bằng MediaRecorder.', use: 'Giao diện phòng họp + ghi âm buổi họp ngay trên trình duyệt.' },
      { name: 'openvidu/openvidu', url: 'https://github.com/OpenVidu/openvidu', desc: 'Framework tạo ứng dụng video call & họp nhóm, có sẵn API ghi âm/video cuộc gọi (Local Recording).', use: 'Tích hợp nhanh video call có ghi âm vào app.' },
    ],
  },
  {
    key: 'biometrics',
    title: 'Xác thực Sinh trắc học (Khuôn mặt · Vân tay · WebAuthn)',
    icon: 'search',
    tint: 'from-sky-600 to-cyan-600',
    keywords: ['sinh trắc', 'vân tay', 'faceid', 'khuôn mặt', 'webauthn', 'đăng nhập không mật khẩu', 'nhận diện khuôn mặt', 'anti-spoofing'],
    repos: [
      { name: 'duo-labs/webauthn', url: 'https://github.com/duo-labs/py_webauthn', desc: 'Đăng nhập bằng vân tay (TouchID, Windows Hello, Android Biometrics) và FaceID ngay trên web, không cần mật khẩu.', use: 'Bật đăng nhập sinh trắc học cho Vexon.' },
      { name: 'justadudewhohacks/face-api.js', url: 'https://github.com/justadudewhohacks/face-api.js', desc: 'Nhận diện khuôn mặt 100% trên trình duyệt: phát hiện sống (liveness), so khớp khuôn mặt.', use: 'Check-in khuôn mặt, chấm công bằng mặt.' },
      { name: 'exadel-inc/CompreFace', url: 'https://github.com/exadel-inc/CompreFace', desc: 'Hệ thống nhận diện khuôn mặt chạy trên server, API tích hợp dễ, độ chính xác cao.', use: 'So khớp ảnh đại diện & chấm công phía server.' },
    ],
  },
  {
    key: 'payments',
    title: 'Thanh toán & Quản lý Tài khoản (Billing · Payments)',
    icon: 'clip',
    tint: 'from-amber-600 to-yellow-600',
    keywords: ['thanh toán', 'payment', 'billing', 'stripe', 'paypal', 'hóa đơn', 'nạp xu', 'cổng thanh toán', 'subscription', 'gói cước'],
    repos: [
      { name: 'killbill/killbill', url: 'https://github.com/killbill/killbill', desc: 'Hệ thống quản lý tài khoản, đăng ký gói cước và tính phí quy mô doanh nghiệp, mã nguồn mở.', use: 'Gói VIP/nạp Xu định kỳ cho Vexon.' },
      { name: 'invoiceninja/invoiceninja', url: 'https://github.com/invoiceninja/invoiceninja', desc: 'Tạo hóa đơn, thu phí tự động, kết nối hơn 40 cổng thanh toán lớn.', use: 'Xuất hóa đơn cho đơn hàng & gói dịch vụ.' },
      { name: 'stripe-samples', url: 'https://github.com/stripe-samples', desc: 'Bộ mẫu xử lý thanh toán thẻ Visa/MasterCard, mã QR, ví điện tử chuẩn bảo mật.', use: 'Tham khảo luồng nạp Xu qua thẻ/QR an toàn.' },
    ],
  },
  {
    key: 'doc-ai',
    title: 'Tóm tắt & Đọc Tài liệu AI (Document AI · RAG)',
    icon: 'voice',
    tint: 'from-rose-600 to-orange-600',
    keywords: ['tóm tắt pdf', 'đọc tài liệu', 'document ai', 'rag', 'pdf chat', 'hỏi đáp tài liệu', 'ocr', 'trích xuất dữ liệu'],
    repos: [
      { name: 'Mintplex-Labs/anything-llm', url: 'https://github.com/Mintplex-Labs/anything-llm', desc: 'AI đọc, tóm tắt và trích xuất thông tin từ PDF, DOCX, TXT, CSV; đầy đủ RAG và phân quyền.', use: 'Trợ lý hỏi đáp kho tài liệu công ty.' },
      { name: 'QuivrHQ/quivr', url: 'https://github.com/QuivrHQ/quivr', desc: 'Bộ nhớ AI cá nhân/doanh nghiệp: upload PDF, video, audio để tóm tắt và hỏi đáp trực tiếp.', use: 'Second brain cho nhóm làm việc.' },
      { name: 'VikParuchuri/marker', url: 'https://github.com/VikParuchuri/marker', desc: 'Chuyển PDF tài liệu/sách/scan sang Markdown chính xác, giữ công thức toán & bảng biểu.', use: 'Dữ liệu sạch để AI tóm tắt hợp đồng, báo cáo.' },
      { name: 'DS4SD/docling', url: 'https://github.com/DS4SD/docling', desc: 'Bóc tách cấu trúc văn bản phức tạp (PDF, Word, PPTX) thành dữ liệu AI dễ xử lý.', use: 'Pipeline nạp tài liệu vào hệ thống RAG.' },
      { name: 'Unstructured-IO/unstructured', url: 'https://github.com/Unstructured-IO/unstructured', desc: 'Xử lý và tóm tắt dữ liệu thô từ 20+ định dạng (PDF, HTML, DOCX, PPT, email).', use: 'Nạp mọi định dạng tài liệu nội bộ cho AI.' },
    ],
  },
  {
    key: 'ai-music',
    title: 'Tạo Bài Hát & Âm Nhạc AI (AI Music)',
    icon: 'music',
    tint: 'from-violet-600 to-purple-600',
    keywords: ['tạo nhạc', 'tạo bài hát', 'ai music', 'sáng tác', 'beat', 'melody', 'suno', 'nhạc nền video', 'soundtrack'],
    repos: [
      { name: 'gcui-art/suno-api', url: 'https://github.com/gcui-art/suno-api', desc: 'API tạo bài hát hoàn chỉnh: ca từ, lời hát, hòa âm theo phong cách âm nhạc yêu thích.', use: 'Nhạc nền quảng cáo, jingle thương hiệu.' },
      { name: 'facebookresearch/audiocraft', url: 'https://github.com/facebookresearch/audiocraft', desc: 'MusicGen của Meta tự sáng tác đoạn nhạc, melodi và beat chất lượng cao từ mô tả.', use: 'Sinh beat/melody mô tả bằng chữ cho video.' },
      { name: 'Stability-AI/stable-audio-tools', url: 'https://github.com/Stability-AI/stable-audio-tools', desc: 'Tạo âm nhạc, sample beat, riff guitar, hiệu ứng âm thanh chuyên nghiệp từ prompt.', use: 'Sản xuất sound design, âm thanh sự kiện.' },
      { name: 'riffusion/riffusion', url: 'https://github.com/riffusion/riffusion', desc: 'Sinh bản nhạc bằng biến đổi phổ âm thanh (spectrogram), chạy mượt trên trình duyệt.', use: 'Trải nghiệm tạo nhạc ngay trên web.' },
    ],
  },
  {
    key: 'voice-clone',
    title: 'Nhân bản & Thay đổi Giọng nói AI (Voice Cloning)',
    icon: 'voice',
    tint: 'from-pink-600 to-rose-600',
    keywords: ['nhân bản giọng nói', 'voice clone', 'thay giọng', 'voice changer', 'text to speech', 'đọc văn bản', 'giọng đọc ai'],
    repos: [
      { name: 'coqui-ai/TTS', url: 'https://github.com/coqui-ai/TTS', desc: 'Nhân bản giọng nói đa ngôn ngữ chuẩn nhất: chỉ cần mẫu âm thanh 3-5 giây để nhái giọng.', use: 'Giọng đọc AI cho phát thanh viên, quảng cáo.' },
      { name: 'RVC-Project/Retrieval-based-Voice-Conversion-WebUI', url: 'https://github.com/RVC-Project/Retrieval-based-Voice-Conversion-WebUI', desc: 'Voice changer nổi tiếng nhất: hoán đổi giọng nói/giọng hát sang nhân vật khác siêu tự nhiên.', use: 'Thay giọng avatar, giải trí trong live.' },
      { name: 'suno-ai/bark', url: 'https://github.com/suno-ai/bark', desc: 'Tạo giọng nói siêu thực: tiếng cười, thở dài, tiếng nền và cảm xúc tự nhiên.', use: 'Giọng kể chuyện có cảm xúc cho video ngắn.' },
      { name: 'myshell-ai/OpenVoice', url: 'https://github.com/myshell-ai/OpenVoice', desc: 'Nhân bản giọng linh hoạt, tùy chỉnh cảm xúc (vui, buồn, giận) và ngữ điệu.', use: 'Việt hoá giọng đọc có tông riêng.' },
      { name: 'RVC-Boss/GPT-SoVITS', url: 'https://github.com/RVC-Boss/GPT-SoVITS', desc: 'TTS + nhân bản giọng thế hệ mới: 5 giây âm thanh mẫu là clone chuẩn ngữ điệu.', use: 'Lồng tiếng nhanh với ít dữ liệu.' },
    ],
  },
  {
    key: 'image-ai',
    title: 'Chỉnh Sửa Ảnh AI (Xóa nền · Phục chế · Upscale)',
    icon: 'image',
    tint: 'from-emerald-600 to-lime-600',
    keywords: ['xóa nền', 'phục chế ảnh', 'upscale ảnh', 'làm nét mặt', 'tô màu ảnh cũ', 'nén ảnh', 'cắt ảnh', 'image editor'],
    repos: [
      { name: 'danielgatis/rembg', url: 'https://github.com/danielgatis/rembg', desc: 'AI tách nền và tách tóc siêu nét dựa trên mô hình U2-Net.', use: 'Xóa nền ảnh đại diện, ảnh sản phẩm.' },
      { name: 'Sanster/IOPaint', url: 'https://github.com/Sanster/IOPaint', desc: 'Xóa người, xóa logo, xóa chữ thừa trên ảnh và tự dựng lại nền mượt mà.', use: 'Retouch ảnh sự kiện, bài đăng.' },
      { name: 'TencentARC/GFPGAN', url: 'https://github.com/TencentARC/GFPGAN', desc: 'Phục chế ảnh cũ, làm mịn da, khôi phục chi tiết mắt/mũi/miệng.', use: 'Phục chế ảnh kỷ yếu, ảnh gia đình.' },
      { name: 'jantic/DeOldify', url: 'https://github.com/jantic/DeOldify', desc: 'Tô màu tự nhiên cho ảnh đen trắng và ảnh gia đình cũ.', use: 'Đổi màu ảnh lịch sử, album công ty.' },
      { name: 'scaleflex/filerobot-image-editor', url: 'https://github.com/scaleflex/filerobot-image-editor', desc: 'Giao diện sửa ảnh HTML5/React: cắt, xoay, nén, filter, chèn chữ.', use: 'Editor ảnh cho composer đăng bài.' },
      { name: 'fengyuanchen/cropperjs', url: 'https://github.com/fengyuanchen/cropperjs', desc: 'Cắt ảnh theo tỷ lệ chuẩn 3x4, Facebook, TikTok mượt mà.', use: 'Crop avatar/cover đúng khung hiển thị.' },
      { name: 'fengyuanchen/compressorjs', url: 'https://github.com/fengyuanchen/compressorjs', desc: 'Nén ảnh JPG/PNG/WEBP siêu nhẹ ngay trên máy người dùng.', use: 'Giảm dung lượng ảnh upload, giữ tốc app.' },
    ],
  },
  {
    key: 'pdf-utils',
    title: 'Xử lý PDF & Tiện ích File trên Browser',
    icon: 'pdf',
    tint: 'from-red-600 to-rose-600',
    keywords: ['pdf', 'gộp pdf', 'tách pdf', 'ocr ảnh', 'đổi file', 'excel', 'word sang html', 'nén zip', 'qrcode'],
    repos: [
      { name: 'Hopding/pdf-lib', url: 'https://github.com/Hopding/pdf-lib', desc: 'Gộp PDF, tách trang, xoay trang, đặt mật khẩu 100% client-side.', use: 'Công cụ PDF trong Công cụ AI không cần server.' },
      { name: 'mozilla/pdf.js', url: 'https://github.com/mozilla/pdf.js', desc: 'Hiển thị & trích xuất hình ảnh từ trang PDF ra PNG/JPG độ phân giải cao.', use: 'Preview file PDF trong chat/tệp đính kèm.' },
      { name: 'naptha/tesseract.js', url: 'https://github.com/naptha/tesseract.js', desc: 'Nhận diện chữ trong ảnh/PDF bằng WebAssembly trực tiếp trên browser (OCR).', use: 'Trích chữ từ ảnh hóa đơn, scan tài liệu.' },
      { name: 'ffmpegwasm/ffmpeg.wasm', url: 'https://github.com/ffmpegwasm/ffmpeg.wasm', desc: 'FFmpeg trên web: đổi đuôi video MP4/WEBM, nén MP3, xuất GIF.', use: 'Đổi định dạng media ngay trong app.' },
      { name: 'SheetJS/sheetjs', url: 'https://github.com/SheetJS/sheetjs', desc: 'Đọc ghi bảng tính XLSX, CSV, JSON client-side.', use: 'Xuất báo cáo Excel từ dữ liệu app.' },
      { name: 'mwilliamson/mammoth.js', url: 'https://github.com/mwilliamson/mammoth.js', desc: 'Chuyển file Word DOCX sang HTML hoặc văn bản thuần.', use: 'Đăng bài từ file Word giữ định dạng.' },
      { name: 'Stuk/jszip', url: 'https://github.com/Stuk/jszip', desc: 'Nén nhiều ảnh hoặc file PDF thành tệp ZIP tải về ngay trên trình duyệt.', use: 'Tải album ảnh, bộ tài liệu dạng ZIP.' },
    ],
  },
  {
    key: 'chatbot-ai',
    title: 'Chatbot AI · RAG · Hạ tầng LLM',
    icon: 'bot',
    tint: 'from-teal-600 to-sky-600',
    keywords: ['chatbot', 'trợ lý ai', 'rag', 'llm', 'vector database', 'ollama', 'chatgpt clone', 'knowledge base', 'trả lời tự động'],
    repos: [
      { name: 'danny-avila/LibreChat', url: 'https://github.com/danny-avila/LibreChat', desc: 'Giao diện chatbot AI đa mô hình (OpenAI, Claude, Gemini, Ollama), hỗ trợ multimodal, RAG, plugin.', use: 'Tham khảo UI chatbot đa mô hình cho Vexon AI.' },
      { name: 'open-webui/open-webui', url: 'https://github.com/open-webui/open-webui', desc: 'WebUI giống ChatGPT siêu nhẹ, kết nối Ollama, vLLM và API ngoài.', use: 'Khuôn mẫu trang chat riêng /chat.' },
      { name: 'langgenius/dify', url: 'https://github.com/langgenius/dify', desc: 'Nền tảng LLM full-stack với quy trình RAG, Agent & workflow kéo thả.', use: 'Thiết kế luồng trợ lý nghiệp vụ phức tạp.' },
      { name: 'FlowiseAI/Flowise', url: 'https://github.com/FlowiseAI/Flowise', desc: 'Kéo thả xây chatbot AI, Agent & RAG dựa trên LangChain JS.', use: 'Prototype agent không cần code.' },
      { name: 'langchain-ai/langchain', url: 'https://github.com/langchain-ai/langchain', desc: 'Framework kết nối LLM với cơ sở dữ liệu, bộ nhớ chat history và công cụ mở rộng.', use: 'Gắn Vexon AI vào dữ liệu công ty.' },
      { name: 'ollama/ollama', url: 'https://github.com/ollama/ollama', desc: 'Chạy local các mô hình LLM (Llama 3, Mistral, Qwen) trên server riêng.', use: 'Phương án AI on-premise cho dữ liệu nhạy cảm.' },
      { name: 'chroma-core/chroma', url: 'https://github.com/chroma-core/chroma', desc: 'Vector database chuyên lưu trữ bộ nhớ & truy xuất kiến thức cho chatbot RAG.', use: 'Cơ sở tìm kiếm ngữ nghĩa kho kiến thức.' },
    ],
  },
  {
    key: 'onboarding',
    title: 'Tour Hướng Dẫn Sử Dụng (Onboarding)',
    icon: 'guide',
    tint: 'from-indigo-600 to-violet-600',
    keywords: ['tour hướng dẫn', 'onboarding', 'hướng dẫn từng bước', 'driver.js', 'intro.js', 'tutorial', 'làm quen app'],
    repos: [
      { name: 'kamranahmedse/driver.js', url: 'https://github.com/kamranahmedse/driver.js', desc: 'Thư viện JS nhẹ tạo tour hướng dẫn từng bước với popover + highlight cực đẹp.', use: 'Tour lần đầu vào Vexon cho nhân viên mới.' },
      { name: 'usablica/intro.js', url: 'https://github.com/usablica/intro.js', desc: 'Tour onboarding step-by-step nổi tiếng, hỗ trợ bàn phím tốt.', use: 'Giới thiệu nhanh tính năng mới.' },
      { name: 'shipshapecode/shepherd', url: 'https://github.com/shipshapecode/shepherd', desc: 'Tour tương tác linh hoạt cho React, Vue, Svelte và JS thuần.', use: 'Hướng dẫn gắn theo component React.' },
    ],
  },
  {
    key: 'web-audio',
    title: 'Trình Phát Nhạc & Âm Thanh Web',
    icon: 'music',
    tint: 'from-cyan-600 to-teal-600',
    keywords: ['phát nhạc', 'audio player', 'sóng nhạc', 'lyric', 'playlist', 'sound effect', 'wavesurfer', 'howler'],
    repos: [
      { name: 'DIYgod/APlayer', url: 'https://github.com/DIYgod/APlayer', desc: 'Trình phát nhạc HTML5 giao diện hiện đại: lyric LRC, playlist, hiệu ứng mượt.', use: 'Phát nhạc nền trang cá nhân, bài đăng.' },
      { name: 'goldfire/howler.js', url: 'https://github.com/goldfire/howler.js', desc: 'Thư viện âm thanh JS chuẩn: phát đa nền tảng, quản lý sound effects & stream.', use: 'Tiếng thông báo, âm thanh tương tác app.' },
      { name: 'Tonejs/Tone.js', url: 'https://github.com/Tonejs/Tone.js', desc: 'Framework tổng hợp âm thanh chuyên sâu: synth, mixer, hiệu ứng audio.', use: 'Hiệu ứng âm sáng tạo cho mini-app.' },
      { name: 'katspaugh/wavesurfer.js', url: 'https://github.com/katspaugh/wavesurfer.js', desc: 'Hiển thị dạng sóng âm trực quan cho trình phát & tính năng cắt nhạc.', use: 'Waveform tin nhắn thoại, bản ghi họp.' },
    ],
  },
]

export const OSS_KEYWORDS = [
  'github', 'mã nguồn mở', 'open source', 'repo', 'gifhub',
  'dựng video', 'làm video', 'video ai', 'tạo video', 'agent', 'công ty 1 người', 'tự động',
  'mạng xã hội', 'họp nhóm', 'gọi video', 'webRTC', 'zoom', 'sinh trắc', 'vân tay',
  'thanh toán', 'billing', 'tóm tắt pdf', 'document ai', 'rag', 'tạo nhạc', 'ai music',
  'nhân bản giọng nói', 'xóa nền', 'phục chế ảnh', 'pdf', 'ocr', 'chatbot', 'llm', 'onboarding',
  'tour hướng dẫn', 'phát nhạc', 'audio player', 'mastodon', 'jitsi', 'livekit', 'ollama', 'langchain',
]

/** Chọn nhóm repo liên quan nhất cho câu hỏi (dùng trong /api/assistant) */
export function matchOssGroups(question: string): OssGroup[] {
  const q = question.toLowerCase()
  const scored = OSS_GROUPS.map((g) => {
    let score = 0
    for (const k of g.keywords) if (q.includes(k)) score += 3
    for (const r of g.repos) {
      if (q.includes(r.name.toLowerCase().split('/')[0])) score += 2
      const head = r.desc.toLowerCase().slice(0, 60)
      for (const w of q.split(/\s+/)) if (w.length > 4 && head.includes(w)) score += 0.5
    }
    return { g, score }
  })
    .filter((s) => s.score >= 3)
    .sort((a, b) => b.score - a.score)
  return scored.slice(0, 2).map((s) => s.g)
}
