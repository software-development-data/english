'use client'

import { PDFDocument, degrees, PageSizes } from 'pdf-lib'

export async function mergePdfs(files: File[]): Promise<Blob> {
  const out = await PDFDocument.create()
  for (const f of files) {
    const src = await PDFDocument.load(await f.arrayBuffer(), { ignoreEncryption: true })
    const pages = await out.copyPages(src, src.getPageIndices())
    for (const p of pages) out.addPage(p)
  }
  const bytes = await out.save()
  return new Blob([bytes as BlobPart], { type: 'application/pdf' })
}

export async function pageCount(file: File): Promise<number> {
  const doc = await PDFDocument.load(await file.arrayBuffer(), { ignoreEncryption: true })
  return doc.getPageCount()
}

/** ranges: mảng "1-3,5" đã parse thành danh sách page index 0-based */
export function parseRanges(input: string, max: number): number[] {
  const pages = new Set<number>()
  for (const part of input.split(',')) {
    const t = part.trim()
    if (!t) continue
    const m = t.match(/^(\d+)\s*-\s*(\d+)$/)
    if (m) {
      const a = Math.max(1, parseInt(m[1]))
      const b = Math.min(max, parseInt(m[2]))
      for (let i = a; i <= b; i++) pages.add(i - 1)
    } else {
      const v = parseInt(t)
      if (!isNaN(v) && v >= 1 && v <= max) pages.add(v - 1)
    }
  }
  return [...pages].sort((a, b) => a - b)
}

export async function splitPdf(file: File, ranges: number[], perFile: boolean): Promise<Blob[]> {
  const src = await PDFDocument.load(await file.arrayBuffer(), { ignoreEncryption: true })
  const results: Blob[] = []
  if (perFile) {
    for (const idx of ranges) {
      const out = await PDFDocument.create()
      const [p] = await out.copyPages(src, [idx])
      out.addPage(p)
      results.push(new Blob([await out.save() as BlobPart], { type: 'application/pdf' }))
    }
  } else {
    const out = await PDFDocument.create()
    const pages = await out.copyPages(src, ranges)
    for (const p of pages) out.addPage(p)
    results.push(new Blob([await out.save() as BlobPart], { type: 'application/pdf' }))
  }
  return results
}

export async function rotatePdf(file: File, angle: 90 | 180 | 270, pageIndexes: number[] | null): Promise<Blob> {
  const doc = await PDFDocument.load(await file.arrayBuffer(), { ignoreEncryption: true })
  const pages = doc.getPages()
  pages.forEach((p, i) => {
    if (pageIndexes && !pageIndexes.includes(i)) return
    const cur = p.getRotation().angle
    p.setRotation(degrees((cur + angle) % 360))
  })
  return new Blob([await doc.save() as BlobPart], { type: 'application/pdf' })
}

async function fileToEmbeddableDataUrl(f: File): Promise<{ url: string; isPng: boolean }> {
  if (f.type === 'image/png' || f.type === 'image/jpeg') {
    const url = await new Promise<string>((resolve, reject) => {
      const r = new FileReader()
      r.onload = () => resolve(r.result as string)
      r.onerror = () => reject(new Error('Không đọc được ảnh'))
      r.readAsDataURL(f)
    })
    return { url, isPng: f.type === 'image/png' }
  }
  // WEBP & các định dạng khác: vẽ lại qua canvas thành PNG
  const { fileToImage, makeCanvas, canvasToBlob } = await import('./image')
  const { img } = await fileToImage(f)
  const canvas = makeCanvas(img.naturalWidth, img.naturalHeight)
  canvas.getContext('2d')!.drawImage(img, 0, 0)
  const blob = await canvasToBlob(canvas, 'image/png')
  const url = await new Promise<string>((resolve) => {
    const r = new FileReader()
    r.onload = () => resolve(r.result as string)
    r.readAsDataURL(blob)
  })
  return { url, isPng: true }
}

export async function imagesToPdf(files: File[], pageSize: 'fit' | 'a4' | 'letter'): Promise<Blob> {
  const doc = await PDFDocument.create()
  for (const f of files) {
    const { url, isPng } = await fileToEmbeddableDataUrl(f)
    const embedded = isPng ? await doc.embedPng(url) : await doc.embedJpg(url)
    if (pageSize === 'fit') {
      const page = doc.addPage([embedded.width, embedded.height])
      page.drawImage(embedded, { x: 0, y: 0, width: embedded.width, height: embedded.height })
    } else {
      const [pw, ph] = pageSize === 'a4' ? PageSizes.A4 : PageSizes.Letter
      const page = doc.addPage([pw, ph])
      const margin = 0
      const scale = Math.min((pw - margin * 2) / embedded.width, (ph - margin * 2) / embedded.height)
      const w = embedded.width * scale
      const h = embedded.height * scale
      page.drawImage(embedded, { x: (pw - w) / 2, y: (ph - h) / 2, width: w, height: h })
    }
  }
  return new Blob([await doc.save() as BlobPart], { type: 'application/pdf' })
}

// ─── pdf.js render / extract ─────────────────────────────

let pdfjsPromise: Promise<typeof import('pdfjs-dist')> | null = null

async function getPdfjs() {
  if (!pdfjsPromise) {
    pdfjsPromise = import('pdfjs-dist')
    const pdfjs = await pdfjsPromise
    pdfjs.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs'
  }
  return pdfjsPromise
}

export interface RenderedPage {
  pageIndex: number
  canvas: HTMLCanvasElement
}

export async function renderPdfPages(file: File, scale = 2, onProgress?: (i: number, n: number) => void): Promise<RenderedPage[]> {
  const pdfjs = await getPdfjs()
  const data = await file.arrayBuffer()
  const doc = await pdfjs.getDocument({ data }).promise
  const out: RenderedPage[] = []
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i)
    const viewport = page.getViewport({ scale })
    const canvas = document.createElement('canvas')
    canvas.width = Math.floor(viewport.width)
    canvas.height = Math.floor(viewport.height)
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = '#ffffff'
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    await page.render({ canvas, canvasContext: ctx, viewport } as Parameters<typeof page.render>[0]).promise
    out.push({ pageIndex: i, canvas })
    onProgress?.(i, doc.numPages)
  }
  return out
}

export async function extractPdfText(file: File, onProgress?: (i: number, n: number) => void): Promise<{ pages: string[]; numPages: number }> {
  const pdfjs = await getPdfjs()
  const data = await file.arrayBuffer()
  const doc = await pdfjs.getDocument({ data }).promise
  const pages: string[] = []
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i)
    const tc = await page.getTextContent()
    const text = tc.items
      .map((it) => ('str' in it ? it.str : ''))
      .join(' ')
      .replace(/\s+/g, ' ')
      .trim()
    pages.push(text)
    onProgress?.(i, doc.numPages)
  }
  return { pages, numPages: doc.numPages }
}
