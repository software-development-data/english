// Danh sách 34 đơn vị hành chính cấp tỉnh Việt Nam sau sáp nhập (Nghị quyết 202/2025/QH15,
// có hiệu lực từ 01/07/2025). 6 thành phố trực thuộc Trung ương đứng đầu, 28 tỉnh theo sau.
// Nguồn: vanchuyenachau.com.vn, chinhphu.vn — đã rà theo nghị quyết chính thức.
// "ghi chú" cho biết tỉnh/thành nào giữ nguyên hoặc hình thành từ việc hợp nhất nào.

export type VnProvince = {
  name: string
  type: 'city' | 'province'
  note?: string
}

export const VN_PROVINCES_34: VnProvince[] = [
  // 6 thành phố trực thuộc Trung ương
  { name: 'Hà Nội', type: 'city', note: 'Giữ nguyên' },
  { name: 'Hải Phòng', type: 'city', note: 'Hợp nhất Hải Dương + TP Hải Phòng' },
  { name: 'Huế', type: 'city', note: 'Giữ nguyên' },
  { name: 'Đà Nẵng', type: 'city', note: 'Hợp nhất Quảng Nam + TP Đà Nẵng' },
  { name: 'TP. Hồ Chí Minh', type: 'city', note: 'Hợp nhất Bình Dương + TPHCM + Bà Rịa – Vũng Tàu' },
  { name: 'Cần Thơ', type: 'city', note: 'Hợp nhất Sóc Trăng + Hậu Giang + TP Cần Thơ' },
  // 28 tỉnh
  { name: 'Tuyên Quang', type: 'province', note: 'Hợp nhất Hà Giang + Tuyên Quang' },
  { name: 'Cao Bằng', type: 'province', note: 'Giữ nguyên' },
  { name: 'Lai Châu', type: 'province', note: 'Giữ nguyên' },
  { name: 'Lào Cai', type: 'province', note: 'Hợp nhất Lào Cai + Yên Bái' },
  { name: 'Thái Nguyên', type: 'province', note: 'Hợp nhất Bắc Kạn + Thái Nguyên' },
  { name: 'Điện Biên', type: 'province', note: 'Giữ nguyên' },
  { name: 'Lạng Sơn', type: 'province', note: 'Giữ nguyên' },
  { name: 'Sơn La', type: 'province', note: 'Giữ nguyên' },
  { name: 'Phú Thọ', type: 'province', note: 'Hợp nhất Hòa Bình + Vĩnh Phúc + Phú Thọ' },
  { name: 'Bắc Ninh', type: 'province', note: 'Hợp nhất Bắc Giang + Bắc Ninh' },
  { name: 'Quảng Ninh', type: 'province', note: 'Giữ nguyên' },
  { name: 'Hưng Yên', type: 'province', note: 'Hợp nhất Thái Bình + Hưng Yên' },
  { name: 'Ninh Bình', type: 'province', note: 'Hợp nhất Hà Nam + Ninh Bình + Nam Định' },
  { name: 'Thanh Hóa', type: 'province', note: 'Giữ nguyên' },
  { name: 'Nghệ An', type: 'province', note: 'Giữ nguyên' },
  { name: 'Hà Tĩnh', type: 'province', note: 'Giữ nguyên' },
  { name: 'Quảng Trị', type: 'province', note: 'Hợp nhất Quảng Bình + Quảng Trị' },
  { name: 'Quảng Ngãi', type: 'province', note: 'Hợp nhất Quảng Ngãi + Kon Tum' },
  { name: 'Gia Lai', type: 'province', note: 'Hợp nhất Gia Lai + Bình Định' },
  { name: 'Đắk Lắk', type: 'province', note: 'Hợp nhất Phú Yên + Đắk Lắk' },
  { name: 'Khánh Hòa', type: 'province', note: 'Hợp nhất Khánh Hòa + Ninh Thuận' },
  { name: 'Lâm Đồng', type: 'province', note: 'Hợp nhất Đắk Nông + Lâm Đồng + Bình Thuận' },
  { name: 'Đồng Nai', type: 'province', note: 'Hợp nhất Bình Phước + Đồng Nai' },
  { name: 'Tây Ninh', type: 'province', note: 'Hợp nhất Long An + Tây Ninh' },
  { name: 'Đồng Tháp', type: 'province', note: 'Hợp nhất Tiền Giang + Đồng Tháp' },
  { name: 'An Giang', type: 'province', note: 'Hợp nhất Kiên Giang + An Giang' },
  { name: 'Vĩnh Long', type: 'province', note: 'Hợp nhất Bến Tre + Vĩnh Long + Trà Vinh' },
  { name: 'Cà Mau', type: 'province', note: 'Hợp nhất Bạc Liêu + Cà Mau' },
]

export const VN_PROVINCE_NAMES_34: string[] = VN_PROVINCES_34.map((p) => p.name)

// Một số quốc gia phổ biến (cho người ngoài Việt Nam chọn quê quán). Mở rộng thoải mái.
export const COUNTRIES: string[] = [
  'Việt Nam',
  'Hoa Kỳ',
  'Trung Quốc',
  'Hàn Quốc',
  'Nhật Bản',
  'Thái Lan',
  'Singapore',
  'Malaysia',
  'Indonesia',
  'Philippines',
  'Lào',
  'Campuchia',
  'Myanmar',
  'Ấn Độ',
  'Đài Loan',
  'Hồng Kông',
  'Úc',
  'Canada',
  'Anh',
  'Pháp',
  'Đức',
  'Nga',
  'Khác',
]

// 54 dân tộc Việt Nam (theo Tổng cục Thống kê). "Kinh" đầu tiên, các dân tộc thiểu số theo sau.
// Lọc trùng phòng sai số nhập liệu.
const VN_ETHNIC_GROUPS_RAW: string[] = [
  'Kinh',
  'Tày',
  'Thái',
  'Mường',
  'Khmer',
  'Hoa',
  'Nùng',
  'Hmông',
  'Dao',
  'Gia Rai',
  'Ngái',
  'Ê Đê',
  'Ba Na',
  'Sán Chay',
  'Xơ Đăng',
  'Sán Dìu',
  'Hrê',
  'Mnông',
  'Bru - Vân Kiều',
  'Cơ Tu',
  'Thổ',
  'Giáy',
  'Cơ Ho',
  'Chăm',
  'Xtiêng',
  'Hà Nhì',
  'Mạ',
  'Khơ Mú',
  'Co',
  'Tà Ôi',
  'Chơ Ro',
  'Kháng',
  'Xinh Mun',
  'Chu Ru',
  'Lào',
  'Bố Y',
  'La Hủ',
  'La Chí',
  'Phù Lá',
  'La Ha',
  'Pà Thẻn',
  'Giẻ Triêng',
  'Mảng',
  'Cống',
  'Si La',
  'Pu Péo',
  'Brâu',
  'Ơ Đu',
  'Rơ Măm',
  'Lô Lô',
]
export const VN_ETHNIC_GROUPS_54: string[] = Array.from(new Set(VN_ETHNIC_GROUPS_RAW))

// Quan hệ: dùng cho dropdown Tình trạng quan hệ (lưới hẹn hò / hồ sơ)
export const RELATIONSHIP_OPTIONS: string[] = [
  'Độc thân',
  'Đang hẹn hò',
  'Có người yêu',
  'Đã kết hôn',
  'Đã ly hôn',
  'Phức tạp',
]

// Lối sống: thuốc lá / rượu bia
export const SMOKING_OPTIONS: string[] = ['Không', 'Thỉnh thoảng', 'Thường xuyên', 'Đã bỏ']
export const DRINKING_OPTIONS: string[] = ['Không', 'Thỉnh thoảng', 'Thường xuyên', 'Đã bỏ']
