import { db } from '@/lib/db'
import { hashPassword } from '@/lib/vx-auth'

// ============ VEXON BOT — CHATBOX TIN NHẮN ============
// Tài khoản bot hệ thống trong phần Tin nhắn:
//  - Thông báo khi ai đó tặng quà live cho bạn (kiểu chatbot thông báo của Zalo)
//  - Trả lời tự động bằng AI khi bạn nhắn tin cho bot

export const VX_BOT_USERNAME = 'vexonbot'

const WELCOME =
  'Chào mừng bạn đến với Vexon Bot, trợ lý chính thức của Vexon. Mình sẽ thông báo ngay tại đây khi có ai đó tặng quà cho bạn trong Livestream. Bạn cũng có thể nhắn tin bất cứ câu gì, mình sẽ trả lời bằng AI nhé.'

// Đảm bảo bot tồn tại (tạo lazily lần đầu cần)
export async function ensureVexonBot() {
  let bot = await db.vxUser.findUnique({ where: { username: VX_BOT_USERNAME } })
  if (!bot) {
    try {
      bot = await db.vxUser.create({
        data: {
          username: VX_BOT_USERNAME,
          email: 'vexonbot@vexon.app',
          passwordHash: hashPassword(`vexon-bot-no-login-${Date.now()}`),
          fullName: 'Vexon Bot',
          title: 'Trợ lý AI',
          department: 'Vexon AI',
          avatarColor: '#0d9488',
          bio: 'Trợ lý AI chính thức của Vexon: thông báo quà tặng, nhắc việc và trò chuyện cùng bạn mọi lúc.',
        },
      })
    } catch {
      // Race khi 2 request tạo cùng lúc — đọc lại
      bot = await db.vxUser.findUnique({ where: { username: VX_BOT_USERNAME } })
    }
  }
  return bot
}

// Tìm hội thoại 1-1 giữa bot và user, chưa có thì tạo + gửi tin chào mừng
export async function ensureBotConversation(userId: string): Promise<string | null> {
  const bot = await ensureVexonBot()
  if (!bot || bot.id === userId) return null
  const mine = await db.vxConversationMember.findMany({
    where: { userId },
    include: { conversation: { include: { members: true } } },
  })
  const existing = mine.find(
    (m) =>
      !m.conversation.isGroup &&
      m.conversation.members.length === 2 &&
      m.conversation.members.some((mm) => mm.userId === bot.id),
  )
  if (existing) return existing.conversation.id
  const conv = await db.vxConversation.create({
    data: {
      isGroup: false,
      members: { create: [{ userId, role: 'member' }, { userId: bot.id, role: 'member' }] },
    },
  })
  await db.vxMessage.create({
    data: { conversationId: conv.id, senderId: bot.id, content: WELCOME, status: 'delivered' },
  })
  return conv.id
}

// Gửi thông báo từ bot vào chatbox của user (quà tặng, nhắc việc...)
export async function botNotify(userId: string, content: string, type = 'text') {
  try {
    const convId = await ensureBotConversation(userId)
    if (!convId) return
    const bot = await ensureVexonBot()
    if (!bot) return
    await db.vxMessage.create({
      data: { conversationId: convId, senderId: bot.id, content: content.slice(0, 800), type, status: 'delivered' },
    })
  } catch (e) {
    console.error('botNotify', e instanceof Error ? e.message : e)
  }
}

const BOT_SYSTEM = `Bạn là "Vexon Bot" — chatbox chính thức trong khung Tin nhắn của siêu ứng dụng Vexon (mạng xã hội + quản trị doanh nghiệp + Livestream quà tặng + Công cụ AI).
Nhiệm vụ: trò chuyện thân thiện, trả lời câu hỏi, hướng dẫn dùng Vexon (Kiếm Xu: điểm danh +10, đăng bài +5, xem video +5; Nhóm, GIF, Livestream tặng quà, Ví Xu, Công cụ AI, Cài đặt).
Trả lời BẰNG TIẾNG VIỆT, ngắn gọn (dưới 120 từ), không dùng markdown định dạng phức tạp, không dùng ký tự đặc biệt.`

// AI trả lời tin nhắn người dùng gửi cho bot (dùng ZAI SDK)
export async function vexonBotAiReply(content: string): Promise<string | null> {
  try {
    const ZAI = (await import('z-ai-web-dev-sdk')).default
    const zai = await ZAI.create()
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: BOT_SYSTEM },
        { role: 'user', content: String(content).slice(0, 2000) },
      ],
      thinking: { type: 'disabled' },
    })
    const text = completion?.choices?.[0]?.message?.content
    return text ? text.slice(0, 1200) : null
  } catch (e) {
    console.error('vexonBotAiReply', e instanceof Error ? e.message : e)
    return null
  }
}
