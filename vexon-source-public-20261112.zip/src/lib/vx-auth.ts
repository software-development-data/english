import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'crypto'
import { cookies } from 'next/headers'
import { db } from '@/lib/db'

const SECRET = process.env.VX_SECRET || 'vexon-demo-secret-2026'
export const SESSION_COOKIE = 'vx_session'

// ===== Mật khẩu (scrypt) =====
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':')
  if (!salt || !hash) return false
  const test = scryptSync(password, salt, 64)
  const origin = Buffer.from(hash, 'hex')
  return origin.length === test.length && timingSafeEqual(origin, test)
}

// ===== Session cookie (HMAC ký userId) =====
function sign(value: string): string {
  return createHmac('sha256', SECRET).update(value).digest('hex').slice(0, 32)
}

export function createSessionToken(userId: string): string {
  return `${userId}.${sign(userId)}`
}

export function parseSessionToken(token: string | undefined): string | null {
  if (!token) return null
  const [userId, sig] = token.split('.')
  if (!userId || !sig) return null
  return sign(userId) === sig ? userId : null
}

export async function setSessionCookie(userId: string) {
  const jar = await cookies()
  jar.set(SESSION_COOKIE, createSessionToken(userId), {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 30, // 30 ngày
  })
}

export async function clearSessionCookie() {
  const jar = await cookies()
  jar.set(SESSION_COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 })
}

// Lấy user hiện tại từ cookie (dùng trong route handler / server)
export async function getSessionUser() {
  try {
    const jar = await cookies()
    const userId = parseSessionToken(jar.get(SESSION_COOKIE)?.value)
    if (!userId) return null
    return await db.vxUser.findUnique({
      where: { id: userId },
      select: {
        id: true, username: true, email: true, fullName: true, role: true,
        department: true, title: true, avatarColor: true, avatarImage: true, coverImage: true,
        settings: true, bio: true, accountType: true, companyName: true, coins: true,
        usernameChanges: true,
        lastBonusAt: true,
        latitude: true, longitude: true, locationName: true, locationVisible: true, locationUpdatedAt: true,
        interests: true,
        // Hồ sơ chi tiết (mở rộng theo yêu cầu)
        birthday: true, hometown: true, education: true, phone: true,
        heightCm: true, weightKg: true, relationship: true, smoking: true, drinking: true, pets: true,
        ethnicity: true, citizenId: true, taxCode: true,
      },
    })
  } catch (e) {
    console.log('[vx-auth] getSessionUser error:', e instanceof Error ? e.message : e)
    return null
  }
}

// Trả về 401 nếu chưa đăng nhập
export async function requireUser() {
  const user = await getSessionUser()
  if (!user) throw new AuthError('Chưa đăng nhập')
  return user
}

export class AuthError extends Error {}

// Chuẩn hoá thông tin công khai của user
export const publicUser = (u: { id: string; username: string; fullName: string; role: string; department?: string | null; title?: string | null; avatarColor: string; avatarImage?: string | null; coverImage?: string | null; bio?: string | null; hometown?: string | null; education?: string | null; birthday?: Date | string | null; phone?: string | null; email?: string; accountType?: string; companyName?: string | null; usernameChanges?: number; coins?: number; interests?: string | null; settings?: string | null; heightCm?: number | null; weightKg?: number | null; relationship?: string | null; smoking?: string | null; drinking?: string | null; pets?: string | null; gender?: string | null; ethnicity?: string | null; citizenId?: string | null; taxCode?: string | null }) => ({
  id: u.id,
  username: u.username,
  fullName: u.fullName,
  role: u.role,
  // null = chủ profile chủ động ẩn (quyền riêng tư từng mục kiểu FB) — giữ nguyên null; undefined = chưa đặt → nhãn mặc định
  department: u.department === null ? null : (u.department ?? 'Chung'),
  title: u.title === null ? null : (u.title ?? 'Nhân viên'),
  avatarColor: u.avatarColor,
  avatarImage: u.avatarImage ?? null,
  coverImage: u.coverImage ?? null,
  bio: u.bio ?? null,
  hometown: u.hometown ?? null,
  education: u.education ?? null,
  birthday: u.birthday ?? null,
  phone: u.phone ?? null,
  email: u.email ?? null,
  accountType: u.accountType ?? 'personal',
  companyName: u.companyName ?? null,
  // Tên người dùng chỉ đổi được tối đa 1 lần — trả số lần đã đổi để UI khoá sau khi dùng lượt
  usernameChanges: u.usernameChanges ?? 0,
  coins: u.coins ?? 0,
  interests: u.interests ? JSON.parse(u.interests) : [],
  // Hồ sơ hẹn hò + xã giao (mạng xã hội tìm người yêu): null khi chưa đặt hoặc bị ẩn theo quyền riêng tư
  heightCm: u.heightCm ?? null,
  weightKg: u.weightKg ?? null,
  relationship: u.relationship ?? null,
  smoking: u.smoking ?? null,
  drinking: u.drinking ?? null,
  pets: u.pets ?? null,
  gender: u.gender ?? null,
  // Hồ sơ mở rộng: dân tộc, CCCD, mã số thuế — cũng có quyền riêng tư riêng
  ethnicity: u.ethnicity ?? null,
  citizenId: u.citizenId ?? null,
  taxCode: u.taxCode ?? null,
  settings: u.settings ? (() => { try { return JSON.parse(u.settings) } catch { return null } })() : null,
})

// Kiểm tra bot của công ty: trả về câu trả lời nếu người nhận là tài khoản doanh nghiệp bật bot
export async function companyBotReply(receiverId: string, content: string): Promise<{ name: string; reply: string } | null> {
  const company = await db.vxCompany.findUnique({ where: { ownerId: receiverId } })
  if (!company || !company.botEnabled) return null
  const lower = content.toLowerCase()
  try {
    const rules = company.botRules ? (JSON.parse(company.botRules) as { keywords: string[]; reply: string }[]) : []
    for (const rule of rules) {
      if (rule.keywords.some((k) => lower.includes(k.toLowerCase()))) return { name: company.botName, reply: rule.reply }
    }
  } catch {
    /* rules lỗi định dạng -> bỏ qua */
  }
  return { name: company.botName, reply: company.botFallback }
}
