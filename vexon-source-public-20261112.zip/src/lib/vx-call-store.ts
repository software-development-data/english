'use client'

import { create } from 'zustand'

// ============ STORE CUỘC GỌI + HỌP NHÓM (dùng chung toàn app) ============
// CallLayer (global trong VexonApp) đọc store này để hiện modal gọi & chuông cuộc gọi đến,
// MessagesView chỉ cần bấm nút là bắt đầu gọi/họp từ bất kỳ tab nào.

export type CallPeer = { userId: string; userName: string; avatarColor: string }

export type OutgoingCall = {
  callId: string
  conversationId: string
  kind: 'voice' | 'video'
  peer: CallPeer
  peerOnline?: boolean
}

export type IncomingCall = {
  callId: string
  conversationId: string
  kind: 'voice' | 'video'
  from: CallPeer
}

export type MeetingSession = {
  conversationId: string
  name: string
  isGroup: boolean
  isHost: boolean
  avatar?: string | null
  avatarImage?: string | null
  partnerColor?: string
}

type CallStore = {
  outgoing: OutgoingCall | null
  incoming: IncomingCall | null
  meeting: MeetingSession | null
  startCall: (o: OutgoingCall) => void
  clearOutgoing: () => void
  setIncoming: (i: IncomingCall | null) => void
  openMeeting: (m: MeetingSession) => void
  closeMeeting: () => void
}

export const useCallStore = create<CallStore>((set) => ({
  outgoing: null,
  incoming: null,
  meeting: null,
  startCall: (o) => set({ outgoing: o, incoming: null }),
  clearOutgoing: () => set({ outgoing: null }),
  setIncoming: (i) => set({ incoming: i }),
  openMeeting: (m) => set({ meeting: m, outgoing: null, incoming: null }),
  closeMeeting: () => set({ meeting: null }),
}))
