'use client'

// ===== HOOK TỶ GIÁ USD/VND (CLIENT) — AI TỰ ĐỘNG BÁM THỊ TRƯỜNG =====
// Giống tin tức tự cập nhật: mỗi 10 phút hỏi lại /api/vx/fx, quay lại tab/mở lại cửa sổ cũng hỏi luôn.
// Server tự bám nhiều nguồn thị trường (er-api → jsDelivr → floatrates, cache 30 phút) nên giá tăng/giảm
// được căn chỉnh kịp. Lịch sử giá lưu localStorage để tính chiều tăng/giảm (%).
// Trước khi có số live → dùng cache cũ hoặc tỷ giá dự phòng trong format.ts (không hiện nhấp nháy).
import { useEffect, useState } from 'react'
import { FALLBACK_USD_VND } from '@/lib/format'

export type UsdRateInfo = {
  rate: number
  source: string // 'er-api' | 'jsdelivr' | 'floatrates' | 'fallback' | 'cache'
  prev: number | null // giá kỳ trước
  trend: 'up' | 'down' | 'flat'
  changePct: number | null
  updatedAt: number | null
}

const KEY = 'vx-usd-rate' // cache cũ { rate, at } — giữ nguyên để không mất cache người dùng
const HIST_KEY = 'vx-usd-rate-hist' // lịch sử giá [{ r, at }] để tính tăng/giảm
const REFRESH_MS = 10 * 60 * 1000 // hỏi lại mỗi 10 phút
const HIST_MAX = 60

// ----- Bộ nhớ dùng chung mọi nơi gọi hook (chỉ 1 vòng hỏi cho cả app) -----
let info: UsdRateInfo | null = null
let inflight: Promise<void> | null = null
let lastFetchAt = 0
let timer: ReturnType<typeof setInterval> | null = null
const subs = new Set<(i: UsdRateInfo) => void>()

function readCache(): { rate: number; at: number } | null {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return null
    const p = JSON.parse(raw) as { rate: number; at: number }
    return typeof p.rate === 'number' && typeof p.at === 'number' ? p : null
  } catch { return null }
}

function readHist(): { r: number; at: number }[] {
  try {
    const p = JSON.parse(localStorage.getItem(HIST_KEY) || '[]')
    return Array.isArray(p) ? p.filter((x: { r?: unknown; at?: unknown }) => typeof x?.r === 'number' && typeof x?.at === 'number') : []
  } catch { return [] }
}

function pushHist(rate: number, at: number) {
  try {
    const h = readHist()
    h.push({ r: rate, at })
    localStorage.setItem(HIST_KEY, JSON.stringify(h.slice(-HIST_MAX)))
  } catch { /* bỏ qua */ }
}

function initialInfo(): UsdRateInfo {
  if (typeof window !== 'undefined') {
    const cached = readCache()
    if (cached) {
      const hist = readHist()
      const last = hist.length && hist[hist.length - 1].r !== cached.rate ? hist[hist.length - 1].r : null
      return {
        rate: cached.rate,
        source: 'cache',
        prev: last,
        trend: last ? (cached.rate > last ? 'up' : cached.rate < last ? 'down' : 'flat') : 'flat',
        changePct: last && last > 0 ? ((cached.rate - last) / last) * 100 : null,
        updatedAt: cached.at,
      }
    }
  }
  return { rate: FALLBACK_USD_VND, source: 'fallback', prev: null, trend: 'flat', changePct: null, updatedAt: null }
}

function applyInfo(next: UsdRateInfo) {
  info = next
  subs.forEach((fn) => { try { fn(next) } catch { /* bỏ qua */ } })
}

async function refreshInfo(force = false): Promise<void> {
  const now = Date.now()
  if (!force && lastFetchAt && now - lastFetchAt < REFRESH_MS) return
  if (inflight) return inflight
  lastFetchAt = now
  inflight = fetch('/api/vx/fx')
    .then((r) => r.json())
    .then((d) => {
      if (typeof d?.usdVnd !== 'number' || d.usdVnd < 1000) return
      try { localStorage.setItem(KEY, JSON.stringify({ rate: d.usdVnd, at: Date.now() })) } catch { /* bỏ qua */ }
      // Chiều tăng/giảm: so giá mới với giá gần nhất trong lịch sử, chưa có thì dùng prev của server
      const hist = readHist()
      const lastEntry = hist.length > 0 ? hist[hist.length - 1] : null
      const base = lastEntry ? lastEntry.r : (typeof d.prev === 'number' ? d.prev : null)
      let trend: 'up' | 'down' | 'flat' = 'flat'
      let changePct: number | null = null
      if (typeof base === 'number' && base > 0 && base !== d.usdVnd) {
        trend = d.usdVnd > base ? 'up' : 'down'
        changePct = ((d.usdVnd - base) / base) * 100
      }
      if (!lastEntry || lastEntry.r !== d.usdVnd) pushHist(d.usdVnd, Date.now())
      applyInfo({
        rate: d.usdVnd,
        source: typeof d.source === 'string' ? d.source : 'live',
        prev: typeof d.prev === 'number' ? d.prev : (lastEntry?.r ?? null),
        trend,
        changePct,
        updatedAt: typeof d.updatedAt === 'number' ? d.updatedAt : Date.now(),
      })
    })
    .catch(() => { /* mạng lỗi → giữ giá đang hiển thị */ })
    .finally(() => { inflight = null })
  return inflight
}

function ensureLoop() {
  if (!timer) timer = setInterval(() => { if (typeof document === 'undefined' || document.visibilityState === 'visible') void refreshInfo(false) }, REFRESH_MS)
}

function stopLoopIfEmpty() {
  if (!subs.size && timer) { clearInterval(timer); timer = null }
}

/** Thông tin đầy đủ: giá + nguồn + chiều tăng/giảm + thời điểm cập nhật */
export function useUsdRateInfo(): UsdRateInfo {
  const [local, setLocal] = useState<UsdRateInfo>(() => info ?? initialInfo()) // dùng giá sống dùng chung nếu app đã hỏi trước
  useEffect(() => {
    setLocal(info ?? initialInfo())
    const fn = (i: UsdRateInfo) => setLocal(i)
    subs.add(fn)
    ensureLoop()
    void refreshInfo(false) // hỏi luôn 1 lượt khi vào app
    const onVis = () => { if (document.visibilityState === 'visible') void refreshInfo(false) }
    const onFocus = () => { void refreshInfo(false) }
    document.addEventListener('visibilitychange', onVis)
    window.addEventListener('focus', onFocus)
    return () => {
      subs.delete(fn)
      document.removeEventListener('visibilitychange', onVis)
      window.removeEventListener('focus', onFocus)
      stopLoopIfEmpty()
    }
  }, [])
  return local
}

/** Bản gọn giữ nguyên chữ ký cũ cho mọi nơi đang dùng */
export function useUsdRate(): number {
  return useUsdRateInfo().rate
}

/** Bấm nút làm mới ngay — bỏ qua hạn chờ, hỏi lại thị trường luôn */
export async function refreshUsdRate(): Promise<void> {
  return refreshInfo(true)
}
