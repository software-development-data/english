/**
 * 34 đơn vị hành chính cấp tỉnh của Việt Nam sau sắp xếp 2025
 * (Nghị quyết 202/2025/QH15 — hoạt động từ 01/7/2025, nguồn chinhphu.vn).
 * Sắp theo vùng: Bắc Bộ → Trung Bộ → Nam Bộ.
 * 6 thành phố trực thuộc trung ương: Hà Nội, Hải Phòng, Đà Nẵng, TP. Hồ Chí Minh, Cần Thơ, Huế.
 */
export const PROVINCES_34: string[] = [
  // Bắc Bộ
  'Hà Nội',
  'Cao Bằng',
  'Điện Biên',
  'Lai Châu',
  'Lạng Sơn',
  'Sơn La',
  'Tuyên Quang',
  'Lào Cai',
  'Thái Nguyên',
  'Phú Thọ',
  'Bắc Ninh',
  'Hưng Yên',
  'Hải Phòng',
  'Quảng Ninh',
  // Trung Bộ
  'Ninh Bình',
  'Thanh Hóa',
  'Nghệ An',
  'Hà Tĩnh',
  'Quảng Trị',
  'Huế',
  'Đà Nẵng',
  'Quảng Ngãi',
  'Gia Lai',
  'Khánh Hòa',
  'Lâm Đồng',
  'Đắk Lắk',
  // Nam Bộ
  'TP. Hồ Chí Minh',
  'Tây Ninh',
  'Đồng Nai',
  'An Giang',
  'Vĩnh Long',
  'Đồng Tháp',
  'Cần Thơ',
  'Cà Mau',
]

export const CITY_LABEL_ALL = 'Toàn quốc Việt Nam'
