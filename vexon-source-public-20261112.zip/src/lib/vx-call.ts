'use client'

// ============ THƯ VIỆN MEDIA / WEBRTC CHO CUỘC GỌI + HỌP NHÓM VEXON ============
// Chuẩn theo tài liệu khắc phục lỗi gọi điện & ghi âm:
// - Bắt buộc HTTPS hoặc localhost (secure context) mới dùng được getUserMedia
// - Constraint: echoCancellation, noiseSuppression, autoGainControl để chống hú, lọc ồn
// - MediaRecorder phải gom dữ liệu qua ondataavailable (start(timeslice)) tránh trôi luồng

export type CallKind = 'voice' | 'video'

// STUN Google miễn phí giúp vượt NAT cơ bản; mạng NAT đối xứng cần TURN (bản demo chưa có)
export const ICE_SERVERS: RTCIceServer[] = [
  { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
]

const AUDIO_CONSTRAINTS: MediaTrackConstraints = {
  echoCancellation: true,
  noiseSuppression: true,
  autoGainControl: true,
}

export async function openUserMedia(kind: CallKind | 'meeting'): Promise<MediaStream> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
    throw new Error('Trình duyệt không hỗ trợ micro/camera. Cần chạy trên HTTPS hoặc localhost.')
  }
  const constraints: MediaStreamConstraints =
    kind === 'voice'
      ? { audio: AUDIO_CONSTRAINTS, video: false }
      : { audio: AUDIO_CONSTRAINTS, video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' } }
  return await navigator.mediaDevices.getUserMedia(constraints)
}

export function mediaErrorMessage(err: unknown): string {
  const e = err as { name?: string; message?: string }
  if (e?.name === 'NotAllowedError' || e?.name === 'SecurityError') {
    return 'Chưa cấp quyền micro/camera. Bấm biểu tượng ổ khoá trên thanh địa chỉ, bật quyền rồi thử lại.'
  }
  if (e?.name === 'NotFoundError' || e?.name === 'OverconstrainedError') {
    return 'Không tìm thấy thiết bị micro/camera trên máy này.'
  }
  if (e?.name === 'NotReadableError' || e?.name === 'TrackStartError') {
    return 'Micro/camera đang được ứng dụng khác sử dụng.'
  }
  return e?.message || 'Không truy cập được micro/camera.'
}

export function newPeerConnection(): RTCPeerConnection {
  return new RTCPeerConnection({ iceServers: ICE_SERVERS })
}

export function stopStream(stream?: MediaStream | null) {
  stream?.getTracks().forEach((t) => t.stop())
}

// ===== GHI ÂM (MediaRecorder chuẩn) =====
export function pickAudioMime(): string {
  if (typeof MediaRecorder === 'undefined') return ''
  if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) return 'audio/webm;codecs=opus'
  if (MediaRecorder.isTypeSupported('audio/webm')) return 'audio/webm'
  if (MediaRecorder.isTypeSupported('audio/mp4')) return 'audio/mp4'
  return ''
}

export function isRecordingSupported(): boolean {
  return typeof MediaRecorder !== 'undefined' && !!pickAudioMime()
}

// Trả về recorder đã start với timeslice 250ms — dữ liệu gom về qua onChunk, không rò rỉ luồng
export function startAudioRecorder(stream: MediaStream, onChunk: (b: Blob) => void, onErr?: (e: string) => void): MediaRecorder | null {
  const mime = pickAudioMime()
  if (!mime) {
    onErr?.('Trình duyệt không hỗ trợ ghi âm MediaRecorder.')
    return null
  }
  const rec = new MediaRecorder(stream, { mimeType: mime, audioBitsPerSecond: 32000 })
  rec.ondataavailable = (ev: BlobEvent) => {
    if (ev.data && ev.data.size > 0) onChunk(ev.data)
  }
  rec.onerror = () => onErr?.('Ghi âm gặp lỗi, vui lòng thử lại.')
  rec.start(250)
  return rec
}

export function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader()
    r.onload = () => res(String(r.result))
    r.onerror = () => rej(new Error('Đọc dữ liệu ghi âm thất bại'))
    r.readAsDataURL(blob)
  })
}

// Trộn audio của nhiều stream (mình + mọi người) thành 1 luồng để ghi âm cuộc họp
export function mixAudioStreams(streams: MediaStream[]): { ctx: AudioContext; dest: MediaStreamAudioDestinationNode } | null {
  if (typeof AudioContext === 'undefined') return null
  const ctx = new AudioContext()
  const dest = ctx.createMediaStreamDestination()
  for (const st of streams) {
    const track = st.getAudioTracks()[0]
    if (!track) continue
    try {
      ctx.createMediaStreamSource(new MediaStream([track])).connect(dest)
    } catch {
      // stream đã đóng thì bỏ qua
    }
  }
  return { ctx, dest }
}

export function fmtCallTime(sec: number): string {
  const s = Math.max(0, Math.round(sec))
  const mm = String(Math.floor(s / 60)).padStart(2, '0')
  const ss = String(s % 60).padStart(2, '0')
  return `${mm}:${ss}`
}

// Tạo callId dùng chung cho 2 phía
export function newCallId(): string {
  return `call_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`
}
