// ============ GIF HUB — thư viện GIF cho chatbox & tin nhắn Vexon ============
// Giphy API public beta key ĐÃ BỊ GIPHY CHẶN (403) từ 2024 — không còn dùng được.
// Tenor v1 cũng đã đóng. Giải pháp bền vững: bộ GIF nội bộ dùng link media.giphy.com
// (tải trực tiếp KHÔNG cần key, đã curl xác minh từng link HTTP 200 vào 2026-11-10).
// Nếu sau này bạn có key GIPHY thật: đặt biến môi trường GIPHY_API_KEY để bật tìm kiếm online.

export interface GifT {
  id: string
  url: string
  title: string
}

/** Key Giphy chỉ còn dùng khi bạn tự đăng ký key thật và khai báo env GIPHY_API_KEY */
const GIPHY_KEY = process.env.GIPHY_API_KEY || ''

// 7 GIF đầu có nội dung xác thực (đã biết rõ), phần sau là bộ reaction đa dụng —
// toàn bộ URL đã kiểm tra tải được thật.
export const CURATED_GIFS: GifT[] = [
  { id: 'g1', url: 'https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif', title: 'tiệc tùng party hard celebration ăn mừng vui happy excited phấn khích' },
  { id: 'g2', url: 'https://media.giphy.com/media/l3q2XhfQ8oCkm1Ts4/giphy.gif', title: 'vỗ tay chậm slow clap khen applause đồng ý yes ok tốt good' },
  { id: 'g3', url: 'https://media.giphy.com/media/l0HlvtIPzPdt2usKs/giphy.gif', title: 'wow ngạc nhiên nói vậy sao if you say so surprised nhìn nhìn này' },
  { id: 'g4', url: 'https://media.giphy.com/media/13borq7Zo2kulO/giphy.gif', title: 'mèo hài hước funny cat cats kéo mèo cute dễ thương pet thú cưng' },
  { id: 'g5', url: 'https://media.giphy.com/media/3oriO0OEd9QIDdllqo/giphy.gif', title: 'mèo con dễ thương cute kitten cat mèo pet thích love thương' },
  { id: 'g6', url: 'https://media.giphy.com/media/26ufdipQqU2lhNA4g/giphy.gif', title: 'wow blow your mind ngạc nhiên bất ngờ amazed product hunt mind blown' },
  { id: 'g7', url: 'https://media.giphy.com/media/xT0xeJpnrWC4XWblEk/giphy.gif', title: 'diễn xuất hài cười laugh tim and eric reaction funny buồn cười' },
  // --- Bộ reaction đa dụng (URL thật đã xác minh, nội dung đa dạng) ---
  { id: 'g8', url: 'https://media.giphy.com/media/3o7qE1YN7aYFVIyqGS/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood cute funny hài' },
  { id: 'g9', url: 'https://media.giphy.com/media/G96anzfWmW3zC/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g10', url: 'https://media.giphy.com/media/du3YxKJsdPOnO/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g11', url: 'https://media.giphy.com/media/MgyFVbd6W7HQA/giphy.gif', title: 'reaction vui fun happy excited phấn khích mood funny hài' },
  { id: 'g12', url: 'https://media.giphy.com/media/CfMtQHaJmxSMo/giphy.gif', title: 'reaction vui fun happy excited phấn khích mood funny hài' },
  { id: 'g13', url: 'https://media.giphy.com/media/ELD3j6Z5zyik0/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g14', url: 'https://media.giphy.com/media/wJyQ39sSDeJIQ/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g15', url: 'https://media.giphy.com/media/11M6FLeoenIiCA/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g16', url: 'https://media.giphy.com/media/3orig0Z5aTC6kIDN32/giphy.gif', title: 'reaction animal động vật pet thú cưng cute dễ thương funny hài' },
  { id: 'g17', url: 'https://media.giphy.com/media/l4FGuhQ3L2Kq3FmKo/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g18', url: 'https://media.giphy.com/media/3o7abA5qmMLXzZ7VAI/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g19', url: 'https://media.giphy.com/media/5xtDarmwpUU28peogj6/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g20', url: 'https://media.giphy.com/media/l0DEJ9jXan2sT5E9G/giphy.gif', title: 'reaction vui fun happy excited phấn khích mood funny hài' },
  { id: 'g21', url: 'https://media.giphy.com/media/3o6ZsWzySVIwpCWDD6/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g22', url: 'https://media.giphy.com/media/l2YWr8aGc8tNyymWs/giphy.gif', title: 'reaction animal động vật pet thú cưng cute dễ thương funny hài' },
  { id: 'g23', url: 'https://media.giphy.com/media/26gN0DkAgyzZ9UbK0/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g24', url: 'https://media.giphy.com/media/l41JXWz5B6uyzZ4w0/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g25', url: 'https://media.giphy.com/media/3oAt2dA6Tz8DTBpao0/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g26', url: 'https://media.giphy.com/media/26tklbTSPtd53C120/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g27', url: 'https://media.giphy.com/media/3oEhmHfX7ZZWWD7DW0/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g28', url: 'https://media.giphy.com/media/l3VdoEwLUv3rQKzYY/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g29', url: 'https://media.giphy.com/media/26gscS5MDg4Xc0X3y/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g30', url: 'https://media.giphy.com/media/9G0lAnd9kQjdO/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g31', url: 'https://media.giphy.com/media/l1KsxStXzX3ZlvXpy/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g32', url: 'https://media.giphy.com/media/3o6EhGvxcjHgcsLuww/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g33', url: 'https://media.giphy.com/media/d45DkeNnwLgDx048/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g34', url: 'https://media.giphy.com/media/26ufcwY4ffWcV1CM0/giphy.gif', title: 'reaction vui fun happy excited phấn khích mood funny hài' },
  { id: 'g35', url: 'https://media.giphy.com/media/l3q2yuvcUZuTXbqr6/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g36', url: 'https://media.giphy.com/media/3o7aTfH9WDbgZDL4jC/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g37', url: 'https://media.giphy.com/media/l0IylOPJViYG1TZla/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g38', url: 'https://media.giphy.com/media/3oKIPf49C0F7ySIqxG/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g39', url: 'https://media.giphy.com/media/26HBvBf7NiwsGQz96/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g40', url: 'https://media.giphy.com/media/l1Ku9ZCUQzgIQxvTa/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g41', url: 'https://media.giphy.com/media/3oriNQKdzLpZ0g6Cna/giphy.gif', title: 'reaction animal động vật pet thú cưng cute dễ thương funny hài' },
  { id: 'g42', url: 'https://media.giphy.com/media/26gR0AOifZFv3c8s0/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g43', url: 'https://media.giphy.com/media/3o6wO8zu9d6ZvMlwUM/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g44', url: 'https://media.giphy.com/media/26tOZ42iNfUvQdvv6/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g45', url: 'https://media.giphy.com/media/3o7aCSPq6VVm2v7Ek8/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g46', url: 'https://media.giphy.com/media/xT0xeJpnsaBgDDSGRa/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g47', url: 'https://media.giphy.com/media/3oEjI5SUFQxKoNPLEX/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g48', url: 'https://media.giphy.com/media/l0Ex6EM7dJnlReC0U/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g49', url: 'https://media.giphy.com/media/26FmQoUmsKq4drAHy/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g50', url: 'https://media.giphy.com/media/3o75xEmpvYh7jVtoXu/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g51', url: 'https://media.giphy.com/media/l0MYC0EIXL3U2c1i0/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g52', url: 'https://media.giphy.com/media/3o7TKP4dOVNcBCAc6Q/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g53', url: 'https://media.giphy.com/media/26gN04WZEZTJmSFO8/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g54', url: 'https://media.giphy.com/media/l3q2wEsEJ2V5Y9Zrq/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g55', url: 'https://media.giphy.com/media/xT9IgzBmQIrOWOHueQ/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g56', url: 'https://media.giphy.com/media/l4pTdcif1pcUnCuv6/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
  { id: 'g57', url: 'https://media.giphy.com/media/26BoRD8G836XaXZDO/giphy.gif', title: 'reaction vui fun happy vui vẻ mood funny hài' },
  { id: 'g58', url: 'https://media.giphy.com/media/3o6EhMXhbdaGMxdvfO/giphy.gif', title: 'reaction vui fun happy vui vẻ cool ngầu mood funny hài' },
  { id: 'g59', url: 'https://media.giphy.com/media/26tnqRYo9F9YtFpyi/giphy.gif', title: 'reaction vui fun happy vui vẻ cute dễ thương funny hài' },
]

interface GiphyImage { fixed_width?: { url?: string }; original?: { url?: string } }
interface GiphyItem { id: string; title?: string; images: GiphyImage }

function normalize(list: GiphyItem[]): GifT[] {
  return list
    .map((g) => ({
      id: g.id,
      url: g.images?.fixed_width?.url || g.images?.original?.url || '',
      title: (g.title || 'GIF').replace(/ ?GIF/gi, '').trim() || 'GIF',
    }))
    .filter((g) => g.url)
}

/** Trộn ngẫu nhiên nhẹ (Fisher–Yates) để mỗi lần mở hub thấy bộ mới */
function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

/** Tìm GIF theo từ khoá; từ khoá rỗng = bộ thịnh hành ngẫu nhiên.
 *  Không khớp từ khoá nào → vẫn trả bộ tổng hợp ngẫu nhiên (KHÔNG bao giờ trả 0). */
export async function searchGifs(query: string): Promise<GifT[]> {
  const q = query.trim()
  // 1) Nếu có GIPHY_API_KEY thật → tìm online (key beta cũ đã bị Giphy chặn 403)
  if (GIPHY_KEY) {
    try {
      const ep = q
        ? `https://api.giphy.com/v1/gifs/search?api_key=${GIPHY_KEY}&limit=24&rating=pg-13&lang=vi&q=${encodeURIComponent(q)}`
        : `https://api.giphy.com/v1/gifs/trending?api_key=${GIPHY_KEY}&limit=24&rating=pg-13`
      const r = await fetch(ep, { signal: AbortSignal.timeout(6000) })
      if (r.ok) {
        const d = await r.json()
        const arr = normalize(Array.isArray(d.data) ? d.data : [])
        if (arr.length > 0) return arr
      }
    } catch { /* rơi xuống bộ nội bộ */ }
  }
  // 2) Bộ nội bộ: khớp từng từ khoá của câu tìm kiếm với tiêu đề
  const kw = q.toLowerCase()
  const words = kw.split(/\s+/).filter((w) => w.length >= 2)
  const hits = kw
    ? CURATED_GIFS.filter((g) => g.title.toLowerCase().includes(kw) || words.some((w) => g.title.toLowerCase().includes(w)))
    : []
  if (hits.length >= 6) return shuffle(hits).slice(0, 24)
  // 3) Không đủ khớp → trả bộ tổng hợp ngẫu nhiên (vẫn liên quan chủ đề nếu có 1-5 hit ưu tiên lên đầu)
  const rest = shuffle(CURATED_GIFS.filter((g) => !hits.includes(g)))
  return [...shuffle(hits), ...rest].slice(0, 24)
}
