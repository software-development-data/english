import { db } from '@/lib/db'

// Kiểm tra quyền vào phòng live: room riêng tư (private) cần đúng mật khẩu (host luôn vào được)
export async function verifyLiveAccess(liveId: string, userId: string, pw: string | null | undefined) {
  const live = await db.vxLive.findUnique({ where: { id: liveId } })
  if (!live) return { ok: false as const, status: 404, error: 'Buổi live không tồn tại' }
  if (live.visibility !== 'private' || live.hostId === userId) return { ok: true as const, live }
  if (pw != null && pw === live.password) return { ok: true as const, live }
  return { ok: false as const, status: 403, locked: true as const, error: 'Phòng live bảo mật — vui lòng nhập mật khẩu' }
}
