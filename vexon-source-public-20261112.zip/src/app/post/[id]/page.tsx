export const dynamic = 'force-dynamic'

import Link from 'next/link'
import { notFound } from 'next/navigation'
import { db } from '@/lib/db'
import { Lock, MessagesSquare, Newspaper } from 'lucide-react'

// Trang công khai cho MỘT bài viết — đích đến của nút "Chia sẻ liên kết"
// Link dạng /post/<id>: bài công khai xem được không cần đăng nhập,
// bài bạn bè / riêng tư hiện thông báo không có quyền xem.
function parseImages(s: string | null): string[] {
  if (!s) return []
  try { const v = JSON.parse(s); return Array.isArray(v) ? v.map(String) : [] } catch { return [] }
}

function timeAgoVi(d: Date): string {
  const s = Math.floor((Date.now() - d.getTime()) / 1000)
  if (s < 60) return 'Vừa xong'
  const m = Math.floor(s / 60)
  if (m < 60) return `${m} phút trước`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h} giờ trước`
  const days = Math.floor(h / 24)
  if (days < 7) return `${days} ngày trước`
  return d.toLocaleDateString('vi-VN', { day: 'numeric', month: 'numeric', year: 'numeric' })
}

export default async function PublicPostPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const post = await db.vxPost.findUnique({
    where: { id },
    include: {
      author: { select: { id: true, fullName: true, department: true, avatarColor: true } },
      page: { select: { id: true, name: true, avatar: true } },
      repostOf: {
        select: {
          id: true, content: true, images: true, createdAt: true,
          author: { select: { id: true, fullName: true, avatarColor: true } },
        },
      },
    },
  }).catch(() => null)

  if (!post) notFound()

  const canView = post.visibility === 'public' || post.visibility === ''
  const images = canView ? parseImages(post.images) : []
  const repostImages = canView && post.repostOf ? parseImages(post.repostOf.images) : []

  return (
    <div className="min-h-screen bg-stone-100">
      <header className="bg-gradient-to-r from-emerald-600 to-teal-600 px-4 py-3">
        <div className="mx-auto flex max-w-2xl items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/15"><Newspaper className="h-5 w-5 text-white" /></span>
          <div className="flex-1">
            <p className="text-base font-black leading-tight text-white">Vexon</p>
            <p className="text-[11px] text-emerald-100">Bài viết được chia sẻ từ Vexon</p>
          </div>
          <Link href="/" className="rounded-full bg-white px-4 py-1.5 text-sm font-bold text-emerald-700 shadow-sm transition-colors hover:bg-emerald-50" aria-label="Mở ứng dụng Vexon">Mở ứng dụng</Link>
        </div>
      </header>

      <main className="mx-auto max-w-2xl p-4">
        {!canView ? (
          <div className="rounded-2xl border bg-white p-10 text-center shadow-sm">
            <Lock className="mx-auto mb-3 h-10 w-10 text-stone-300" />
            <p className="text-base font-bold text-stone-800">Bài viết không công khai</p>
            <p className="mt-1 text-sm text-muted-foreground">Người đăng chỉ chia sẻ bài này cho bạn bè. Hãy đăng nhập Vexon để xem nếu bạn có quyền.</p>
          </div>
        ) : (
          <article className="rounded-2xl border bg-white shadow-sm">
            <div className="flex items-center gap-3 p-4 pb-3">
              {post.page?.avatar ? (
                <img src={post.page.avatar} alt="" className="h-11 w-11 rounded-full border object-cover" />
              ) : post.page ? (
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 font-black text-white">{post.page.name.charAt(0)}</span>
              ) : (
                <span className="flex h-11 w-11 items-center justify-center rounded-full text-base font-black text-white" style={{ background: post.author.avatarColor || '#10b981' }}>
                  {post.author.fullName.charAt(0).toUpperCase()}
                </span>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-stone-900">{post.page ? post.page.name : post.author.fullName}</p>
                <p className="text-xs text-muted-foreground">{timeAgoVi(post.createdAt)}{!post.page && post.author.department ? `, ${post.author.department}` : ''}</p>
              </div>
            </div>

            {post.background ? (
              <div className="mx-4 flex min-h-44 items-center justify-center rounded-lg p-6" style={{ backgroundImage: post.background }}>
                <p className="whitespace-pre-wrap text-center text-xl font-bold leading-snug text-white drop-shadow">{post.content}</p>
              </div>
            ) : post.content ? (
              <p className="whitespace-pre-wrap break-words px-4 pb-2 text-[15px] leading-relaxed text-stone-900">{post.content}</p>
            ) : null}

            {post.location && <p className="px-4 pt-1.5 text-xs text-muted-foreground">Địa điểm: {post.location}</p>}

            {images.length > 0 && (
              <div className={`mt-3 grid gap-1 px-4 ${images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
                {images.map((img, i) => (
                  img.startsWith('grad:') ? null : <img key={i} src={img} alt={`Ảnh ${i + 1} của bài viết`} className="max-h-[560px] w-full bg-stone-100 object-contain" />
                ))}
              </div>
            )}
            {post.videoUrl && <video src={post.videoUrl} controls className="mx-4 mb-3 mt-3 max-h-96 w-[calc(100%-32px)] rounded-lg bg-black" />}

            {/* Bài gốc khi được ĐĂNG LẠI (kiểu TikTok) */}
            {post.repostOf && (
              <div className="mx-4 mb-3 mt-3 overflow-hidden rounded-xl border bg-stone-50">
                <div className="flex items-center gap-2.5 p-3 pb-2">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-black text-white" style={{ background: post.repostOf.author.avatarColor || '#10b981' }}>
                    {post.repostOf.author.fullName.charAt(0).toUpperCase()}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-bold">{post.repostOf.author.fullName}</p>
                    <p className="text-[11px] text-muted-foreground">{timeAgoVi(post.repostOf.createdAt)}</p>
                  </div>
                </div>
                {post.repostOf.content && <p className="whitespace-pre-wrap break-words px-3 pb-2.5 text-sm text-stone-800">{post.repostOf.content}</p>}
                {repostImages.length > 0 && (
                  <div className={`grid gap-0.5 px-3 pb-3 ${repostImages.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
                    {repostImages.map((img, i) => (
                      img.startsWith('grad:') ? null : <img key={i} src={img} alt={`Ảnh bài gốc ${i + 1}`} className="max-h-56 w-full bg-stone-100 object-contain" />
                    ))}
                  </div>
                )}
              </div>
            )}

            <div className="border-t px-4 py-3">
              <p className="flex items-center gap-1.5 text-xs text-muted-foreground"><MessagesSquare className="h-3.5 w-3.5 text-emerald-600" /> Đăng nhập Vexon để thích, bình luận và chia sẻ bài viết này</p>
            </div>
          </article>
        )}

        <p className="py-6 text-center text-xs text-stone-400">Liên kết bài viết trên Vexon - Super App doanh nghiệp</p>
      </main>
    </div>
  )
}
