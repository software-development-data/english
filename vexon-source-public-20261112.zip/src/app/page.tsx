import VexonApp from '@/components/vexon/VexonApp'
import { redirect } from 'next/navigation'
import { parseVxView } from '@/lib/vx-views'

/**
 * Trang chủ Vexon — hỗ trợ deep-link ?view=<phân hệ>
 * Ví dụ: /?view=tools (Công cụ AI) · /?view=wallet (Ví Xu) · /?view=aichat → /chat
 */
export default async function Home({ searchParams }: { searchParams: Promise<{ view?: string }> }) {
  const { view } = await searchParams
  // Chatbot AI là trang riêng có link riêng
  if (view === 'aichat') redirect('/chat')
  return <VexonApp initialView={parseVxView(view)} />
}
