import type { Metadata } from 'next'
import VexonAI from '@/components/vexon/VexonAI'

export const metadata: Metadata = {
  title: 'Vexon AI — Chatbot tổng hợp mọi công cụ',
  description: 'Chatbot AI riêng của mạng lưới Vexon: chat mọi chủ đề, vẽ ảnh, nhìn ảnh trả lời, tìm kiếm & tổng hợp dữ liệu web — chỉ cần nhập câu lệnh, tự động xử lý.',
}

/** Trang Vexon AI — link riêng biệt: /chat */
export default function Chat() {
  return <VexonAI />
}
