'use client'

// ============ TRANG 404 DỄ THƯƠNG ============
// Nhân vật chibi robot Vexon động (mắt nhấp nháy, tay vẫy) + đếm ngược 5 giây tự về trang chủ.

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Home, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ChibiBot } from '@/components/vexon/SplashScreen'

export default function NotFound() {
  const router = useRouter()
  const [left, setLeft] = useState(5)

  useEffect(() => {
    const t = setInterval(() => setLeft((s) => (s > 0 ? s - 1 : 0)), 1000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    if (left === 0) router.replace('/')
  }, [left, router])

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-emerald-50 via-white to-teal-50 px-4 text-center">
      <div className="vx-splash-bob">
        <ChibiBot className="h-44 w-44" waving />
      </div>

      {/* Số 404 to bằng chữ khối, mỗi số một màu xanh emerald vui nhộn */}
      <p className="mt-2 flex items-end gap-1 font-black leading-none tracking-tight" aria-label="Lỗi 404">
        <span className="text-7xl text-emerald-600 vx-splash-bounce" style={{ animationDelay: '0ms' }}>4</span>
        <span className="text-8xl text-teal-600 vx-splash-bounce" style={{ animationDelay: '160ms' }}>0</span>
        <span className="text-7xl text-emerald-600 vx-splash-bounce" style={{ animationDelay: '320ms' }}>4</span>
      </p>

      <h1 className="mt-4 text-xl font-bold text-stone-800">Ôi, trang này đi lạc mất rồi!</h1>
      <p className="mt-1 max-w-sm text-sm text-stone-500">
        Robot chibi Vexon lục khắp nơi vẫn không tìm thấy trang bạn cần. Có thể liên kết đã cũ hoặc bị gỡ rồi.
      </p>

      <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
        <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => router.replace('/')}>
          <Home className="mr-1 h-4 w-4" /> Về trang chủ
        </Button>
        <Button variant="outline" className="border-teal-300 text-teal-700 hover:bg-teal-50" onClick={() => window.location.reload()}>
          <RefreshCw className="mr-1 h-4 w-4" /> Tải lại trang
        </Button>
      </div>

      <p className="mt-5 rounded-full border border-emerald-200 bg-white/80 px-4 py-1.5 text-xs font-semibold text-emerald-700 shadow-sm" role="status" aria-live="polite">
        Tự động về trang chủ sau {left} giây...
      </p>
    </main>
  )
}
