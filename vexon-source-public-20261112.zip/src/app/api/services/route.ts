import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET: Danh sách dịch vụ (để chọn khi đặt lịch)
export async function GET() {
  try {
    const services = await db.service.findMany({
      where: { active: true },
      orderBy: { name: 'asc' },
    })
    return NextResponse.json(services)
  } catch (e) {
    console.error('GET /api/services', e)
    return NextResponse.json({ error: 'Không tải được dịch vụ' }, { status: 500 })
  }
}
