import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET: Lịch sử nhập / xuất kho
export async function GET(req: NextRequest) {
  try {
    const limit = Number(req.nextUrl.searchParams.get('limit') || 100)
    const movements = await db.stockMovement.findMany({
      include: { product: { select: { name: true, sku: true } } },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })
    return NextResponse.json(movements)
  } catch (e) {
    console.error('GET /api/stock', e)
    return NextResponse.json({ error: 'Không tải được lịch sử kho' }, { status: 500 })
  }
}

// POST: Nhập / xuất kho
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { productId, type, quantity, note } = body
    const qty = Number(quantity)

    if (!productId || !type || !qty || qty <= 0) {
      return NextResponse.json({ error: 'Vui lòng chọn sản phẩm và số lượng hợp lệ (> 0)' }, { status: 400 })
    }
    if (!['IN', 'OUT'].includes(type)) {
      return NextResponse.json({ error: 'Loại thao tác không hợp lệ' }, { status: 400 })
    }

    const result = await db.$transaction(async (tx) => {
      const product = await tx.product.findUnique({ where: { id: productId } })
      if (!product) throw new Error('Sản phẩm không tồn tại')

      let newStock = product.stock
      if (type === 'IN') {
        newStock = product.stock + qty
      } else {
        if (product.stock < qty) {
          throw new Error(`Kho chỉ còn ${product.stock} ${product.name}, không thể xuất ${qty}`)
        }
        newStock = product.stock - qty
      }

      await tx.product.update({ where: { id: productId }, data: { stock: newStock } })
      return tx.stockMovement.create({
        data: {
          productId,
          type,
          quantity: qty,
          stockAfter: newStock,
          note: note || (type === 'IN' ? 'Nhập hàng từ nhà cung cấp' : 'Xuất kho'),
        },
      })
    })

    return NextResponse.json(result, { status: 201 })
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Không thực hiện được thao tác kho'
    console.error('POST /api/stock', e)
    return NextResponse.json({ error: msg }, { status: 400 })
  }
}
