import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// POST: Xử lý hàng đợi email nhắc lịch đến hạn (mô phỏng cron job)
export async function POST() {
  try {
    const due = await db.emailLog.updateMany({
      where: { status: 'queued', scheduledFor: { lte: new Date() } },
      data: { status: 'sent', sentAt: new Date() },
    })
    const pending = await db.emailLog.count({ where: { status: 'queued' } })
    return NextResponse.json({ sent: due.count, pending })
  } catch (e) {
    console.error('POST /api/reminders', e)
    return NextResponse.json({ error: 'Không xử lý được hàng đợi email' }, { status: 500 })
  }
}
