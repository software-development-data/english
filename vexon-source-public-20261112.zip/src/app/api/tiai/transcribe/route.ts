import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

/**
 * POST /api/tiai/transcribe — Giọng nói thành văn bản (ASR)
 * body: { audio: base64 (không kèm prefix data:) }
 */
export async function POST(req: NextRequest) {
  try {
    const { audio } = (await req.json()) as { audio?: string }
    if (!audio || !audio.trim()) {
      return NextResponse.json({ error: 'Thiếu tệp âm thanh' }, { status: 400 })
    }
    // base64 ~10MB tệp gốc → giới hạn để tránh nghẽn server
    if (audio.length > 14_000_000) {
      return NextResponse.json({ error: 'Tệp âm thanh quá lớn (tối đa ~10MB)' }, { status: 400 })
    }

    const zai = await ZAI.create()
    const res = await zai.audio.asr.create({ file_base64: audio })
    const text = (res as { text?: string })?.text ?? ''
    if (!text.trim()) {
      return NextResponse.json({ error: 'Không nghe rõ nội dung — thử ghi lại gần micro hơn nhé' }, { status: 502 })
    }
    return NextResponse.json({ text })
  } catch (e) {
    console.error('tiai/transcribe error:', e)
    return NextResponse.json({ error: 'Máy chủ AI bận, thử lại giúp mình nhé' }, { status: 500 })
  }
}
