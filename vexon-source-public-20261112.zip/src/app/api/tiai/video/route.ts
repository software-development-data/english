import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

/**
 * POST /api/tiai/video — Tạo task video AI từ mô tả
 * body: { prompt, quality: 'speed' | 'quality', duration?: number }
 * Trả về { taskId, status } — client poll GET ?taskId= đến khi SUCCESS rồi mới trừ Xu
 */
export async function POST(req: NextRequest) {
  try {
    const { prompt, quality, duration } = (await req.json()) as { prompt?: string; quality?: string; duration?: number }
    const p = (prompt || '').trim()
    if (p.length < 5) return NextResponse.json({ error: 'Mô tả video quá ngắn (tối thiểu 5 ký tự)' }, { status: 400 })
    if (p.length > 1500) return NextResponse.json({ error: 'Mô tả tối đa 1500 ký tự' }, { status: 400 })

    const zai = await ZAI.create()
    const task = await zai.video.generations.create({
      prompt: p,
      quality: quality === 'quality' ? 'quality' : 'speed',
      with_audio: false,
      fps: 30,
      duration: Math.min(10, Math.max(5, Number(duration) || 5)),
    })
    if (!task?.id) return NextResponse.json({ error: 'Không tạo được tác vụ video' }, { status: 502 })
    return NextResponse.json({ taskId: task.id, status: task.task_status || 'PROCESSING' })
  } catch (e) {
    console.error('tiai/video POST error:', e)
    return NextResponse.json({ error: 'Máy chủ AI bận, thử lại giúp mình nhé' }, { status: 500 })
  }
}

/**
 * GET /api/tiai/video?taskId=... — tra trạng thái & lấy kết quả video
 */
export async function GET(req: NextRequest) {
  try {
    const taskId = req.nextUrl.searchParams.get('taskId')
    if (!taskId) return NextResponse.json({ error: 'Thiếu taskId' }, { status: 400 })
    const zai = await ZAI.create()
    const result = await zai.async.result.query(taskId)
    const status = result?.task_status || 'PROCESSING'
    const url =
      result?.video_result?.[0]?.url ||
      result?.video_url ||
      result?.url ||
      (typeof result?.video === 'string' && result.video.startsWith('http') ? result.video : null)
    return NextResponse.json({ status, videoUrl: url })
  } catch (e) {
    console.error('tiai/video GET error:', e)
    return NextResponse.json({ error: 'Không tra được trạng thái video' }, { status: 500 })
  }
}
