import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

const SIZE_OPTIONS = ['1024x1024', '768x1344', '864x1152', '1344x768', '1152x864', '1440x720', '720x1440'] as const
type GenSize = (typeof SIZE_OPTIONS)[number]

export async function POST(req: NextRequest) {
  try {
    const { prompt, size } = (await req.json()) as { prompt?: string; size?: string }
    if (!prompt || !prompt.trim()) {
      return NextResponse.json({ error: 'Thiếu mô tả ảnh' }, { status: 400 })
    }
    const sz: GenSize = size && (SIZE_OPTIONS as readonly string[]).includes(size) ? (size as GenSize) : '1024x1024'
    const zai = await ZAI.create()
    const res = await zai.images.generations.create({ prompt: prompt.trim(), size: sz })
    const base64 = res.data?.[0]?.base64
    if (!base64) return NextResponse.json({ error: 'AI không trả về ảnh' }, { status: 502 })
    return NextResponse.json({ image: `data:image/png;base64,${base64}` })
  } catch (e) {
    console.error('tiai/generate error:', e)
    return NextResponse.json({ error: 'Máy chủ AI bận, thử lại giúp mình nhé' }, { status: 500 })
  }
}
