import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(req: NextRequest) {
  try {
    const { system, prompt } = (await req.json()) as { system?: string; prompt?: string }
    if (!prompt || !prompt.trim()) {
      return NextResponse.json({ error: 'Thiếu nội dung' }, { status: 400 })
    }
    const zai = await ZAI.create()
    const completion = await zai.chat.completions.create({
      messages: [
        ...(system ? [{ role: 'assistant' as const, content: system }] : []),
        { role: 'user' as const, content: prompt.trim() },
      ],
      thinking: { type: 'disabled' },
    })
    const text = completion.choices?.[0]?.message?.content
    if (!text) return NextResponse.json({ error: 'AI không trả về nội dung' }, { status: 502 })
    return NextResponse.json({ text })
  } catch (e) {
    console.error('tiai/chat error:', e)
    return NextResponse.json({ error: 'Máy chủ AI bận, thử lại giúp mình nhé' }, { status: 500 })
  }
}
