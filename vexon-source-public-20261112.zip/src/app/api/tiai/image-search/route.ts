import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

/**
 * POST /api/tiai/image-search — Tìm ảnh tham khảo thật từ web
 * body: { query, count? }
 * Trả về danh sách ảnh kèm nguồn gốc — chỉ dùng để tham khảo ý tưởng.
 */
export async function POST(req: NextRequest) {
  try {
    const { query, count } = (await req.json()) as { query?: string; count?: number }
    const q = (query || '').trim()
    if (q.length < 2) return NextResponse.json({ error: 'Nhập từ khóa tìm kiếm' }, { status: 400 })

    const zai = await ZAI.create()
    const res = await zai.images.search.create({ query: q, count: Math.min(20, Math.max(4, Number(count) || 12)) })
    const results = (res?.results || []).map((r) => ({
      url: r.original_url,
      caption: r.caption || '',
      source: r.source || '',
      width: r.original_width || '',
      height: r.original_height || '',
    }))
    if (results.length === 0) return NextResponse.json({ error: 'Không tìm thấy ảnh phù hợp' }, { status: 404 })
    return NextResponse.json({ results })
  } catch (e) {
    console.error('tiai/image-search error:', e)
    return NextResponse.json({ error: 'Máy chủ AI bận, thử lại giúp mình nhé' }, { status: 500 })
  }
}
