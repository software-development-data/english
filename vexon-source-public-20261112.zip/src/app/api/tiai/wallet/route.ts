export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { getTool } from '@/lib/tiai/tools'
import { getUsdVnd } from '@/lib/vx-fx'
import { fmtUsdFromXu } from '@/lib/format'

/** Mỗi tài khoản được 2 lượt miễn phí mỗi ngày — áp cho toàn bộ Công cụ AI & Vexon AI */
export const FREE_RUNS_PER_DAY = 2

function startOfToday(): Date {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d
}

async function freeLeftOf(userId: string): Promise<number> {
  const used = await db.vxToolJob.count({
    where: { userId, createdAt: { gte: startOfToday() }, cost: 0, status: 'success' },
  })
  return Math.max(0, FREE_RUNS_PER_DAY - used)
}

// GET /api/tiai/wallet — ví Xu CHUNG Vexon × Công cụ AI:
// số dư (VxUser.coins) + lượt miễn phí hôm nay + lịch sử giao dịch (VxCoinTx) + lịch sử dùng công cụ (VxToolJob)
export async function GET() {
  try {
    const me = await requireUser()
    const [meFull, jobs, txs, freeLeft] = await Promise.all([
      db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } }),
      db.vxToolJob.findMany({ where: { userId: me.id }, orderBy: { createdAt: 'desc' }, take: 100 }),
      db.vxCoinTx.findMany({ where: { userId: me.id }, orderBy: { createdAt: 'desc' }, take: 60 }),
      freeLeftOf(me.id),
    ])

    return NextResponse.json({
      xu: meFull?.coins || 0,
      freeLeft,
      freeRunsPerDay: FREE_RUNS_PER_DAY,
      txs: txs.map((t) => ({
        id: t.id,
        at: t.createdAt.getTime(),
        name: t.reason,
        xu: Math.abs(t.amount),
        kind: t.amount >= 0 ? ('topup' as const) : ('spend' as const),
      })),
      tasks: jobs.map((j) => {
        const tool = getTool(j.kind)
        return {
          id: j.id,
          at: j.createdAt.getTime(),
          toolSlug: j.kind,
          toolName: tool?.name || j.kind,
          status: j.status === 'failed' ? ('failed' as const) : ('success' as const),
          xu: j.cost,
        }
      }),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/tiai/wallet', e)
    return NextResponse.json({ error: 'Không tải được ví tiền' }, { status: 500 })
  }
}

// POST /api/tiai/wallet
//  - {action:'charge', slug}  → ưu tiên lượt miễn phí (2/ngày); hết lượt thì trừ Xu nguyên tử
//  - {action:'refund', slug}  → hoàn Xu của lần chạy thành công gần nhất khi xử lý lỗi
//  - {action:'failed', slug}  → ghi nhận lần chạy thất bại (không mất gì)
//  - {action:'topup', amount} → tạo yêu cầu nạp CHỜ DUYỆT (không cộng xu trực tiếp nữa —
//    chống gian lận: xu chỉ được cộng khi Ban Giám đốc duyệt ở /api/vx/wallet-tx PATCH)
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()

    if (body.action === 'charge') {
      const tool = getTool(String(body.slug || ''))
      if (!tool) return NextResponse.json({ error: 'Công cụ không tồn tại' }, { status: 400 })

      const freeLeft = await freeLeftOf(me.id)
      if (freeLeft > 0 || tool.price <= 0) {
        // Lượt miễn phí — không trừ Xu, ghi lịch sử chạy thành công
        const u = await db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } })
        await db.vxToolJob.create({
          data: { userId: me.id, kind: tool.slug, prompt: String(body.note || '').slice(0, 500), cost: 0, status: 'success' },
        })
        return NextResponse.json({ ok: true, free: true, coins: u?.coins ?? 0, freeLeft: Math.max(0, freeLeft - 1) })
      }

      // Hết lượt miễn phí — trừ Xu nguyên tử, chỉ thành công khi đủ số dư
      const res = await db.vxUser.updateMany({
        where: { id: me.id, coins: { gte: tool.price } },
        data: { coins: { decrement: tool.price } },
      })
      if (res.count === 0) {
        return NextResponse.json(
          { error: `Không đủ tiền — cần ${fmtUsdFromXu(tool.price, (await getUsdVnd()).rate)}. Đăng bài, điểm danh hoặc nạp qua QR ngân hàng để có thêm nhé!` },
          { status: 400 },
        )
      }
      const [user] = await Promise.all([
        db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } }),
        db.vxCoinTx.create({ data: { userId: me.id, amount: -tool.price, reason: `Dùng công cụ ${tool.name}` } }),
        db.vxToolJob.create({
          data: { userId: me.id, kind: tool.slug, prompt: String(body.note || '').slice(0, 500), cost: tool.price, status: 'success' },
        }),
      ])
      return NextResponse.json({ ok: true, coins: user?.coins ?? 0, freeLeft: 0 })
    }

    if (body.action === 'refund') {
      const tool = getTool(String(body.slug || ''))
      if (!tool) return NextResponse.json({ error: 'Công cụ không tồn tại' }, { status: 400 })
      // Tìm lần chạy thành công bị trừ Xu gần nhất (15 phút) của tool này
      const job = await db.vxToolJob.findFirst({
        where: { userId: me.id, kind: tool.slug, cost: { gt: 0 }, status: 'success', createdAt: { gte: new Date(Date.now() - 15 * 60 * 1000) } },
        orderBy: { createdAt: 'desc' },
      })
      if (!job) return NextResponse.json({ ok: true, coins: (await db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } }))?.coins ?? 0, refunded: false })
      const [user] = await Promise.all([
        db.vxUser.update({ where: { id: me.id }, data: { coins: { increment: job.cost } } }),
        db.vxCoinTx.create({ data: { userId: me.id, amount: job.cost, reason: `Hoàn tiền, ${tool.name} xử lý lỗi` } }),
        db.vxToolJob.update({ where: { id: job.id }, data: { status: 'failed', cost: 0, error: 'Xử lý thất bại — đã hoàn tiền' } }),
      ])
      return NextResponse.json({ ok: true, coins: user.coins, refunded: true })
    }

    if (body.action === 'failed') {
      const tool = getTool(String(body.slug || ''))
      if (!tool) return NextResponse.json({ error: 'Công cụ không tồn tại' }, { status: 400 })
      await db.vxToolJob.create({
        data: { userId: me.id, kind: tool.slug, prompt: '', cost: 0, status: 'failed', error: 'Xử lý thất bại — thử lại nhé' },
      })
      return NextResponse.json({ ok: true })
    }

    if (body.action === 'topup') {
      // ⚠️ KHÔNG cộng xu tức thời nữa — tạo giao dịch pending chờ Ban Giám đốc duyệt
      const amountXu = Math.min(1_000_000, Math.max(1, Math.round(Number(body.amount) || 0)))
      const amountVnd = amountXu * 100 // nạp 1 xu = 100đ
      const tx = await db.vxWalletTx.create({
        data: {
          userId: me.id,
          type: 'deposit',
          amountVnd,
          amountXu,
          proofCode: String(body.note || 'NAPXU app').slice(0, 60),
          bankName: 'Techcombank (QR)',
          status: 'pending',
        },
      })
      const u = await db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } })
      return NextResponse.json({ ok: true, pending: true, txId: tx.id, amountXu, amountVnd, coins: u?.coins ?? 0 })
    }

    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/tiai/wallet', e)
    return NextResponse.json({ error: 'Không xử lý được' }, { status: 500 })
  }
}
