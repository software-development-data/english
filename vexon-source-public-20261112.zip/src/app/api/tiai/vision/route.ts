import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

/**
 * POST /api/tiai/vision — Phân tích ảnh bằng AI (mô tả, OCR, nhận diện)
 * body: { image: dataUrl, question?: string }
 * Chỉ trừ Xu khi thành công (client tự gọi charge sau khi nhận 200)
 */
export async function POST(req: NextRequest) {
  try {
    const { image, question } = (await req.json()) as { image?: string; question?: string }
    if (!image || !image.startsWith('data:image/')) {
      return NextResponse.json({ error: 'Thiếu ảnh cần phân tích' }, { status: 400 })
    }
    if (image.length > 4_500_000) {
      return NextResponse.json({ error: 'Ảnh quá lớn — thử ảnh nhỏ hơn ~3MB' }, { status: 400 })
    }
    const q = (question || 'Hãy mô tả chi tiết bức ảnh này bằng tiếng Việt: nội dung chính, các đối tượng, chữ xuất hiện (nếu có) và bối cảnh.').trim()

    const zai = await ZAI.create()
    const completion = await zai.chat.completions.createVision({
      model: 'glm-4.5v',
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: q },
            { type: 'image_url', image_url: { url: image } },
          ],
        },
      ],
      thinking: { type: 'disabled' },
    })
    const text = completion?.choices?.[0]?.message?.content
    if (!text) return NextResponse.json({ error: 'AI không trả về nội dung' }, { status: 502 })
    return NextResponse.json({ text })
  } catch (e) {
    console.error('tiai/vision error:', e)
    return NextResponse.json({ error: 'Máy chủ AI bận, thử lại giúp mình nhé' }, { status: 500 })
  }
}
