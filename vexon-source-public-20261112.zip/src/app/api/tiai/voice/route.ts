import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { requireUser, AuthError } from '@/lib/vx-auth'

const VOICES = ['tongtong', 'chuichui', 'xiaochen', 'jam', 'kazi', 'douji', 'luodo'] as const
type Voice = (typeof VOICES)[number]

/**
 * POST /api/tiai/voice — Tạo giọng đọc AI từ văn bản (tiếng Việt & đa ngôn ngữ)
 * body: { text, voice, speed }
 *
 * FIX lỗi "một số giọng nói bị lỗi" & "không nhân bản được giọng nói":
 *  - Nhà cung cấp AI giới hạn tần suất (HTTP 429 Too many requests) trên QUOTA CHUNG —
 *    khi bấm tạo nhiều lần liên tiếp (thử từng giọng) request sau bị chặn ngay,
 *    giao diện chỉ hiện "Máy chủ AI bận" rất chung chung.
 *  - Giờ đây: mỗi user cách nhau tối thiểu 4 giây, tự động thử lại 2 lần khi gặp 429,
 *    lỗi còn lại trả thông báo RÕ RÀNG + retryAfter để client hiện đếm ngược.
 */
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const { text, voice, speed } = (await req.json()) as { text?: string; voice?: string; speed?: number }
    const t = (text ?? '').trim()
    if (!t) return NextResponse.json({ error: 'Thiếu nội dung văn bản' }, { status: 400 })
    if (t.length > 1024) return NextResponse.json({ error: 'Văn bản tối đa 1024 ký tự' }, { status: 400 })
    if (voice && !(VOICES as readonly string[]).includes(voice)) {
      return NextResponse.json({ error: `Giọng không hợp lệ — chọn 1 trong: ${VOICES.join(', ')}` }, { status: 400 })
    }
    const v: Voice = voice && (VOICES as readonly string[]).includes(voice) ? (voice as Voice) : 'tongtong'
    const sp = Math.min(2, Math.max(0.5, Number(speed) || 1))

    // Chặn tạo liên tục: quota TTS là chung, mỗi user cách nhau tối thiểu 4s để không dồn ứ
    const now = Date.now()
    const last = lastCall.get(me.id) ?? 0
    const waitMs = MIN_GAP_MS - (now - last)
    if (waitMs > 0) {
      return NextResponse.json(
        { error: `Bạn đang tạo giọng liên tục — đợi ${Math.ceil(waitMs / 1000)} giây rồi bấm lại nhé`, retryAfter: Math.ceil(waitMs / 1000) },
        { status: 429 },
      )
    }
    lastCall.set(me.id, now)

    const zai = await ZAI.create()
    // Thử tối đa 3 lần khi nhà cung cấp trả 429 (quá tải) — chờ tăng dần 3s → 8s
    let lastErr: unknown = null
    for (const backoff of [0, 3000, 8000]) {
      if (backoff) await sleep(backoff)
      try {
        const res = await zai.audio.tts.create({
          input: t,
          voice: v,
          speed: sp,
          response_format: 'wav',
          stream: false,
        })
        const arrayBuffer = await res.arrayBuffer()
        const base64 = Buffer.from(new Uint8Array(arrayBuffer)).toString('base64')
        if (!base64) return NextResponse.json({ error: 'AI không trả về âm thanh' }, { status: 502 })
        return NextResponse.json({ audio: `data:audio/wav;base64,${base64}` })
      } catch (e) {
        lastErr = e
        const msg = String((e as Error)?.message || '')
        // Chỉ thử lại khi bị giới hạn tần suất — lỗi khác dừng ngay cho đúng
        if (!msg.includes('429')) break
      }
    }
    console.error('tiai/voice error:', lastErr)
    return NextResponse.json(
      {
        error: 'Hệ thống giọng nói đang quá tải theo giới hạn của nhà cung cấp AI. Đợi khoảng 1 phút rồi thử lại nhé — văn bản của bạn vẫn giữ nguyên trong ô nhập.',
        retryAfter: 60,
      },
      { status: 503 },
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('tiai/voice error:', e)
    return NextResponse.json({ error: 'Máy chủ AI bận, thử lại giúp mình nhé' }, { status: 500 })
  }
}

const MIN_GAP_MS = 4000
const lastCall = new Map<string, number>()
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
