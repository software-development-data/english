import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

function genOrderCode() {
  const d = new Date()
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`
  const rand = Math.random().toString(36).slice(2, 5).toUpperCase()
  return `DH-${ymd}-${rand}`
}

// GET: Danh sách đơn hàng
export async function GET() {
  try {
    const orders = await db.order.findMany({
      include: { items: true },
      orderBy: { createdAt: 'desc' },
      take: 200,
    })
    return NextResponse.json(orders)
  } catch (e) {
    console.error('GET /api/orders', e)
    return NextResponse.json({ error: 'Không tải được đơn hàng' }, { status: 500 })
  }
}

// POST: Tạo đơn hàng (tự trừ kho)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { customerName, customerPhone, customerAddress, paymentMethod, note, items } = body

    if (!customerName || !customerPhone || !customerAddress) {
      return NextResponse.json({ error: 'Vui lòng điền đầy đủ họ tên, số điện thoại và địa chỉ' }, { status: 400 })
    }
    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: 'Giỏ hàng trống' }, { status: 400 })
    }
    if (!/^[0-9+\s.-]{8,15}$/.test(String(customerPhone))) {
      return NextResponse.json({ error: 'Số điện thoại không hợp lệ' }, { status: 400 })
    }

    const order = await db.$transaction(async (tx) => {
      let total = 0
      const lines: { productId: string; name: string; sku: string; price: number; quantity: number }[] = []

      for (const it of items) {
        const qty = Number(it.quantity)
        const product = await tx.product.findUnique({ where: { id: it.productId } })
        if (!product) throw new Error('Có sản phẩm không tồn tại, vui lòng làm mới giỏ hàng')
        if (product.stock < qty) {
          throw new Error(`"${product.name}" chỉ còn ${product.stock} sản phẩm trong kho`)
        }
        total += product.price * qty
        lines.push({ productId: product.id, name: product.name, sku: product.sku, price: product.price, quantity: qty })
      }

      const created = await tx.order.create({
        data: {
          code: genOrderCode(),
          customerName,
          customerPhone,
          customerAddress,
          paymentMethod: paymentMethod === 'BANK' ? 'BANK' : 'COD',
          note: note || null,
          total,
          items: { create: lines },
        },
        include: { items: true },
      })

      for (const line of lines) {
        const p = await tx.product.findUniqueOrThrow({ where: { id: line.productId } })
        const newStock = p.stock - line.quantity
        await tx.product.update({ where: { id: line.productId }, data: { stock: newStock } })
        await tx.stockMovement.create({
          data: {
            productId: line.productId,
            type: 'OUT',
            quantity: line.quantity,
            stockAfter: newStock,
            note: `Bán hàng - đơn ${created.code}`,
          },
        })
      }

      return created
    })

    return NextResponse.json(order, { status: 201 })
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Không tạo được đơn hàng'
    console.error('POST /api/orders', e)
    return NextResponse.json({ error: msg }, { status: 400 })
  }
}
