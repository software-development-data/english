import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const ORDER_STATUSES = ['pending', 'confirmed', 'shipping', 'done', 'cancelled']

// PATCH: Cập nhật trạng thái đơn hàng / thanh toán
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await req.json()
    const data: Record<string, unknown> = {}

    if (body.status !== undefined) {
      if (!ORDER_STATUSES.includes(body.status)) {
        return NextResponse.json({ error: 'Trạng thái không hợp lệ' }, { status: 400 })
      }
      data.status = body.status
    }
    if (body.paymentStatus !== undefined) {
      if (!['unpaid', 'paid'].includes(body.paymentStatus)) {
        return NextResponse.json({ error: 'Trạng thái thanh toán không hợp lệ' }, { status: 400 })
      }
      data.paymentStatus = body.paymentStatus
    }

    const order = await db.order.update({ where: { id }, data, include: { items: true } })
    return NextResponse.json(order)
  } catch (e) {
    console.error('PATCH /api/orders/[id]', e)
    return NextResponse.json({ error: 'Không cập nhật được đơn hàng' }, { status: 500 })
  }
}
