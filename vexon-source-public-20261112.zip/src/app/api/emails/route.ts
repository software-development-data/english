import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET: Hộp thư email (mô phỏng) — xác nhận / nhắc lịch đã gửi & đang chờ
export async function GET() {
  try {
    // Trước khi trả về, cập nhật các email đến hạn
    const due = await db.emailLog.updateMany({
      where: { status: 'queued', scheduledFor: { lte: new Date() } },
      data: { status: 'sent', sentAt: new Date() },
    })
    if (due.count > 0) console.log(`[emails] Đã gửi ${due.count} email đến hạn`)

    const emails = await db.emailLog.findMany({
      include: { appointment: { include: { service: true } } },
      orderBy: { createdAt: 'desc' },
      take: 100,
    })
    return NextResponse.json(emails)
  } catch (e) {
    console.error('GET /api/emails', e)
    return NextResponse.json({ error: 'Không tải được hộp thư' }, { status: 500 })
  }
}
