import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET: Danh sách sản phẩm (hỗ trợ tìm kiếm + lọc danh mục)
export async function GET(req: NextRequest) {
  try {
    const q = req.nextUrl.searchParams.get('q') || ''
    const category = req.nextUrl.searchParams.get('category') || ''

    const products = await db.product.findMany({
      where: {
        AND: [
          q ? { OR: [{ name: { contains: q } }, { sku: { contains: q } }] } : {},
          category ? { category } : {},
        ],
      },
      orderBy: { createdAt: 'desc' },
    })
    return NextResponse.json(products)
  } catch (e) {
    console.error('GET /api/products', e)
    return NextResponse.json({ error: 'Không tải được danh sách sản phẩm' }, { status: 500 })
  }
}

// POST: Thêm sản phẩm mới
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { name, sku, category, price, cost, stock, minStock, description, image } = body

    if (!name || !sku || price === undefined) {
      return NextResponse.json({ error: 'Vui lòng nhập tên, mã SKU và giá bán' }, { status: 400 })
    }

    const exists = await db.product.findUnique({ where: { sku } })
    if (exists) {
      return NextResponse.json({ error: `Mã SKU "${sku}" đã tồn tại` }, { status: 400 })
    }

    const product = await db.product.create({
      data: {
        name,
        sku,
        category: category || 'Khác',
        price: Number(price),
        cost: Number(cost || 0),
        stock: Number(stock || 0),
        minStock: Number(minStock || 5),
        description: description || null,
        image: image || null,
      },
    })

    if (product.stock > 0) {
      await db.stockMovement.create({
        data: {
          productId: product.id,
          type: 'IN',
          quantity: product.stock,
          stockAfter: product.stock,
          note: 'Nhập kho khi tạo sản phẩm',
        },
      })
    }

    return NextResponse.json(product, { status: 201 })
  } catch (e) {
    console.error('POST /api/products', e)
    return NextResponse.json({ error: 'Không tạo được sản phẩm' }, { status: 500 })
  }
}
