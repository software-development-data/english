import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PATCH: Cập nhật sản phẩm
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await req.json()
    const data: Record<string, unknown> = {}

    if (body.name !== undefined) data.name = body.name
    if (body.sku !== undefined) data.sku = body.sku
    if (body.category !== undefined) data.category = body.category
    if (body.price !== undefined) data.price = Number(body.price)
    if (body.cost !== undefined) data.cost = Number(body.cost)
    if (body.minStock !== undefined) data.minStock = Number(body.minStock)
    if (body.description !== undefined) data.description = body.description || null
    if (body.image !== undefined) data.image = body.image || null
    if (body.active !== undefined) data.active = body.active

    const product = await db.product.update({ where: { id }, data })
    return NextResponse.json(product)
  } catch (e) {
    console.error('PATCH /api/products/[id]', e)
    return NextResponse.json({ error: 'Không cập nhật được sản phẩm' }, { status: 500 })
  }
}

// DELETE: Xoá sản phẩm
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const used = await db.orderItem.findFirst({ where: { productId: id } })
    if (used) {
      // Đã có đơn hàng: chỉ ẩn sản phẩm khỏi cửa hàng
      await db.product.update({ where: { id }, data: { active: false } })
      return NextResponse.json({ ok: true, softDeleted: true })
    }
    await db.product.delete({ where: { id } })
    return NextResponse.json({ ok: true, softDeleted: false })
  } catch (e) {
    console.error('DELETE /api/products/[id]', e)
    return NextResponse.json({ error: 'Không xoá được sản phẩm' }, { status: 500 })
  }
}
