import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/vx-auth'
import { matchOssGroups } from '@/lib/tiai/oss-repos'

export const dynamic = 'force-dynamic'

const VIET_STOP = new Set(['và','hoặc','nhưng','của','các','được','cho','trong','với','trên','từ','một','những','này','đó','là','có','bạn','tôi','mình','gì','nào','ra','đi','đến','theo','khi','thì','để','về','sao','vậy','à','uh','ạ'])

/** Tách từ khoá cho tìm kiếm tương quan (tiếng Việt không dấu khoảng cách) */
function keywords(q: string): string[] {
  return q
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 1 && !VIET_STOP.has(w))
}

/** RAG: tìm các đoạn liên quan nhất trong tài liệu của người dùng */
async function retrieveContext(userId: string, question: string): Promise<{ context: string; docs: string[] } | null> {
  const docs = await db.vxKnowledgeDoc.findMany({
    where: { userId },
    select: { id: true, name: true, chunks: { select: { text: true } } },
    take: MAX_DOCS_SNAPSHOT,
  })
  if (docs.length === 0) return null
  const terms = keywords(question)
  if (terms.length === 0) return null
  const scored: { text: string; doc: string; score: number }[] = []
  for (const d of docs) {
    for (const c of d.chunks) {
      const lower = c.text.toLowerCase()
      let score = 0
      for (const t of terms) {
        let idx = 0, hits = 0
        while ((idx = lower.indexOf(t, idx)) !== -1 && hits < 8) { hits++; idx += t.length }
        score += hits * (t.length > 4 ? 2 : 1)
      }
      if (score > 0) scored.push({ text: c.text, doc: d.name, score })
    }
  }
  if (scored.length === 0) return null
  scored.sort((a, b) => b.score - a.score)
  const top = scored.slice(0, 4)
  const docNames = [...new Set(top.map((t) => t.doc))]
  const context = top.map((t, i) => `[${i + 1}] (tài liệu: ${t.doc})\n${t.text}`).join('\n---\n')
  return { context, docs: docNames }
}

const MAX_DOCS_SNAPSHOT = 12

const SYSTEM = `Bạn là "Vexon AI" — trợ lý siêu thông minh của siêu ứng dụng Vexon (một mạng lưới duy nhất: mạng xã hội + quản trị doanh nghiệp + Chatbot AI + Công cụ AI).
Bạn giỏi và sẵn sàng:
- Hỏi đáp mọi chủ đề, giải thích dễ hiểu, trả lời bằng tiếng Việt (trừ khi người dùng dùng ngôn ngữ khác).
- Soạn thảo: bài đăng mạng xã hội, caption, email, thông báo, mô tả sản phẩm, kịch bản video.
- Dịch thuật đa ngôn ngữ, tóm tắt, phân tích, tổng hợp dữ liệu, lập kế hoạch, ý tưởng kinh doanh.
- Hướng dẫn dùng Vexon: Kiếm tiền vào ví USD (điểm danh công việc, đăng bài, bình luận, hoàn thành việc, xem video, sáng kiến; điểm danh hàng ngày +$1,95/ngày), Nhóm, Bảng tin, Tin nhắn & nhóm chat (GIF hub — tìm, gửi và TẢI GIF RIÊNG lên dùng chung cả công ty), Livestream, Quản trị 360, Cửa hàng Vexon, Chatbot Vexon AI (/chat — link riêng) và Công cụ AI.
- Kinh tế ví USD: hội thoại với bạn MIỄN PHÍ; vẽ ảnh ≈$0,12, nhìn ảnh ≈$0,06, tìm web ≈$0,04 (giá tính theo ví chung, quy theo tỷ giá USD/VND thị trường thực tế); Công cụ AI tính tiền tương tự (mỗi tài khoản/thiết bị được 2 lượt miễn phí mỗi ngày, hết lượt mới trừ tiền, lỗi thì hoàn tiền). Có thể nạp tiền bằng quét QR ngân hàng (Techcombank) trong Ví tiền — nạp bằng USD, tự quy ra VND theo tỷ giá.
- Ví tiền USD là MỘT ví chung cho cả mạng lưới: mạng xã hội, Vexon AI và Công cụ AI cùng một số dư duy nhất, tính bằng đô la Mỹ.
Trả lời ngắn gọn, có cấu trúc (gạch đầu dòng khi cần), thân thiện.`

interface ChatMsg { role: 'user' | 'assistant'; content: string }

/**
 * POST /api/assistant — Trợ lý AI đa năng của Vexon
 * action=chat   { messages: ChatMsg[] }              → { text }         (hội thoại nhiều lượt)
 * action=vision { text, image }                      → { text }         (nhìn ảnh trả lời)
 * action=image  { prompt }                           → { image }        (vẽ ảnh trong chat)
 * action=search { query }                            → { text, sources} (tìm web + tổng hợp)
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const action = String(body.action || 'chat')
    const zai = await ZAI.create()

    if (action === 'chat') {
      const history: ChatMsg[] = Array.isArray(body.messages) ? body.messages.slice(-14) : []
      const last = history[history.length - 1]
      if (!last || last.role !== 'user' || !last.content.trim()) {
        return NextResponse.json({ error: 'Thiếu nội dung câu hỏi' }, { status: 400 })
      }

      // RAG — Vexon AI tự tra tài liệu riêng người dùng đã tải lên (kiểu AnythingLLM)
      let usedDocs: string[] = []
      let chatTurns: ChatMsg[] = history
      const me = await getSessionUser().catch(() => null)
      if (me) {
        const rag = await retrieveContext(me.id, last.content).catch(() => null)
        if (rag) {
          usedDocs = rag.docs
          chatTurns = [
            ...history.slice(0, -1),
            {
              role: 'user',
              content: `Dưới đây là các đoạn trích từ TÀI LIỆU RIÊNG của tôi. Nếu liên quan đến câu hỏi, hãy dựa vào chúng để trả lời và ghi rõ nguồn (tài liệu nào). Nếu không liên quan thì trả lời bình thường.\n\n=== TÀI LIỆU CỦA TÔI ===\n${rag.context}\n=== HẾT TÀI LIỆU ===\n\nCâu hỏi: ${last.content}`,
            },
          ]
        }
      }

      // Thư viện Nguồn mở AI (gifhub) — bot tự tư vấn repo kèm link khi câu hỏi liên quan
      const oss = matchOssGroups(last.content)
      let ossTurn = chatTurns
      if (oss.length > 0) {
        const ossCtx = oss
          .map((g) => `${g.title}:\n${g.repos.map((r) => `- ${r.name} (${r.url}) — ${r.desc} Ứng dụng: ${r.use}`).join('\n')}`)
          .join('\n\n')
        ossTurn = [
          ...chatTurns.slice(0, -1),
          {
            role: 'user',
            content: `Thư viện nguồn mở AI của Vexon có các dự án sau, hãy tư vấn dựa trên đây (kèm link GitHub):\n\n${ossCtx}\n\nCâu hỏi: ${last.content}`,
          },
        ]
      }

      const completion = await zai.chat.completions.create({
        messages: [
          { role: 'assistant' as const, content: SYSTEM },
          ...ossTurn.map((m) => ({ role: m.role, content: String(m.content).slice(0, 8000) })),
        ],
        thinking: { type: 'disabled' },
      })
      const text = completion?.choices?.[0]?.message?.content
      if (!text) return NextResponse.json({ error: 'AI không trả về nội dung' }, { status: 502 })
      return NextResponse.json({ text, usedDocs: usedDocs.length ? usedDocs : undefined, ossUsed: oss.length > 0 })
    }

    if (action === 'vision') {
      const image = String(body.image || '')
      const text = String(body.text || 'Mô tả chi tiết bức ảnh này.').trim()
      if (!image.startsWith('data:image/')) return NextResponse.json({ error: 'Thiếu ảnh' }, { status: 400 })
      if (image.length > 4_500_000) return NextResponse.json({ error: 'Ảnh quá lớn (tối đa ~3MB)' }, { status: 400 })
      const completion = await zai.chat.completions.createVision({
        model: 'glm-4.5v',
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: `${text} (trả lời bằng tiếng Việt)` },
              { type: 'image_url', image_url: { url: image } },
            ],
          },
        ],
        thinking: { type: 'disabled' },
      })
      const out = completion?.choices?.[0]?.message?.content
      if (!out) return NextResponse.json({ error: 'AI không trả về nội dung' }, { status: 502 })
      return NextResponse.json({ text: out })
    }

    if (action === 'image') {
      const prompt = String(body.prompt || '').trim()
      if (prompt.length < 3) return NextResponse.json({ error: 'Mô tả ảnh quá ngắn' }, { status: 400 })
      const res = await zai.images.generations.create({ prompt, size: '1024x1024' })
      const base64 = res?.data?.[0]?.base64
      if (!base64) return NextResponse.json({ error: 'AI không trả về ảnh' }, { status: 502 })
      return NextResponse.json({ image: `data:image/png;base64,${base64}` })
    }

    if (action === 'search') {
      const query = String(body.query || '').trim()
      if (query.length < 2) return NextResponse.json({ error: 'Thiếu từ khóa tìm kiếm' }, { status: 400 })
      const results = await zai.functions.invoke('web_search', { query, num: 8 })
      const items = (Array.isArray(results) ? results : []).slice(0, 8)
      const context = items
        .map((r, i) => `[${i + 1}] ${r.name}\nNguồn: ${r.url}\n${r.snippet}`)
        .join('\n\n')
      const completion = await zai.chat.completions.create({
        messages: [
          { role: 'assistant' as const, content: `${SYSTEM}\nBạn đang ở chế độ TÌM KIẾM WEB: dựa vào kết quả tìm kiếm bên dưới để trả lời, trích dẫn nguồn dạng [1][2] ở cuối câu liên quan.` },
          { role: 'user' as const, content: `KẾT QUẢ TÌM KIẾM cho "${query}":\n\n${context || '(không có kết quả)'}\n\nCÂU HỎI: ${query}` },
        ],
        thinking: { type: 'disabled' },
      })
      const text = completion?.choices?.[0]?.message?.content || 'Không tìm thấy thông tin phù hợp.'
      return NextResponse.json({
        text,
        sources: items.map((r) => ({ url: r.url, name: r.name })),
      })
    }

    return NextResponse.json({ error: 'Action không hợp lệ' }, { status: 400 })
  } catch (e) {
    console.error('assistant error:', e)
    return NextResponse.json({ error: 'Máy chủ AI bận, thử lại giúp mình nhé' }, { status: 500 })
  }
}
