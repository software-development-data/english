import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/reports?month=YYYY-MM  (mặc định tháng hiện tại, giờ VN)
export async function GET(req: NextRequest) {
  try {
    const monthParam = req.nextUrl.searchParams.get('month')
    const now = new Date()
    const y = monthParam ? Number(monthParam.split('-')[0]) : now.getFullYear()
    const m = monthParam ? Number(monthParam.split('-')[1]) : now.getMonth() + 1

    if (!y || !m || m < 1 || m > 12) {
      return NextResponse.json({ error: 'Tháng không hợp lệ (dạng YYYY-MM)' }, { status: 400 })
    }

    // Múi giờ VN (+07:00): tính đầu/cuối tháng theo UTC+7
    const start = new Date(Date.UTC(y, m - 1, 1, -7, 0, 0))
    const end = new Date(Date.UTC(y, m, 1, -7, 0, 0))

    const [orders, prevOrders, stockMovements, appointments, products, services] = await Promise.all([
      db.order.findMany({
        where: { createdAt: { gte: start, lt: end }, status: { not: 'cancelled' } },
        include: { items: true },
      }),
      db.order.findMany({
        where: { createdAt: { gte: new Date(Date.UTC(y, m - 2, 1, -7, 0, 0)), lt: start }, status: { not: 'cancelled' } },
      }),
      db.stockMovement.findMany({
        where: { createdAt: { gte: start, lt: end } },
        include: { product: { select: { name: true, sku: true } } },
        orderBy: { createdAt: 'desc' },
      }),
      db.appointment.findMany({
        where: { scheduledAt: { gte: start, lt: end } },
        include: { service: true },
      }),
      db.product.findMany({ orderBy: { stock: 'asc' } }),
      db.service.findMany(),
    ])

    // Doanh thu & lợi nhuận gộp
    let revenue = 0
    let cogs = 0
    let unitsSold = 0
    const productSales: Record<string, { name: string; quantity: number; revenue: number }> = {}
    for (const o of orders) {
      revenue += o.total
      for (const it of o.items) {
        unitsSold += it.quantity
        const key = it.productId
        if (!productSales[key]) productSales[key] = { name: it.name, quantity: 0, revenue: 0 }
        productSales[key].quantity += it.quantity
        productSales[key].revenue += it.price * it.quantity
        cogs += it.quantity * (products.find((p) => p.id === it.productId)?.cost ?? 0)
      }
    }

    const prevRevenue = prevOrders.reduce((s, o) => s + o.total, 0)
    const growth = prevRevenue > 0 ? ((revenue - prevRevenue) / prevRevenue) * 100 : null

    // Doanh thu theo ngày trong tháng (cho biểu đồ)
    const daysInMonth = new Date(Date.UTC(y, m, 0)).getUTCDate()
    const byDay: { day: string; revenue: number; orders: number }[] = []
    for (let d = 1; d <= daysInMonth; d++) {
      const dayStart = new Date(Date.UTC(y, m - 1, d, -7, 0, 0))
      const dayEnd = new Date(Date.UTC(y, m - 1, d + 1, -7, 0, 0))
      const dayOrders = orders.filter((o) => o.createdAt >= dayStart && o.createdAt < dayEnd)
      byDay.push({
        day: `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}`,
        revenue: dayOrders.reduce((s, o) => s + o.total, 0),
        orders: dayOrders.length,
      })
    }

    // Xuất / nhập kho trong tháng
    const inQty = stockMovements.filter((mv) => mv.type === 'IN').reduce((s, mv) => s + mv.quantity, 0)
    const outQty = stockMovements.filter((mv) => mv.type === 'OUT').reduce((s, mv) => s + mv.quantity, 0)

    // Tồn kho & giá trị kho
    const stockValue = products.reduce((s, p) => s + p.cost * p.stock, 0)
    const retailValue = products.reduce((s, p) => s + p.price * p.stock, 0)
    const lowStock = products.filter((p) => p.stock <= p.minStock && p.active)

    // Top 5 sản phẩm bán chạy
    const topProducts = Object.values(productSales).sort((a, b) => b.revenue - a.revenue).slice(0, 5)

    // Lịch hẹn trong tháng
    const apptDone = appointments.filter((a) => a.status === 'done').length
    const apptCancelled = appointments.filter((a) => a.status === 'cancelled').length

    // Doanh thu 6 tháng gần nhất (cho biểu đồ xu hướng)
    const trend: { month: string; revenue: number }[] = []
    for (let i = 5; i >= 0; i--) {
      const tStart = new Date(Date.UTC(y, m - 1 - i, 1, -7, 0, 0))
      const tEnd = new Date(Date.UTC(y, m - i, 1, -7, 0, 0))
      const tOrders = await db.order.findMany({
        where: { createdAt: { gte: tStart, lt: tEnd }, status: { not: 'cancelled' } },
        select: { total: true },
      })
      trend.push({
        month: `T${((m - 1 - i + 12) % 12) + 1}`,
        revenue: tOrders.reduce((s, o) => s + o.total, 0),
      })
    }

    return NextResponse.json({
      month: `${y}-${String(m).padStart(2, '0')}`,
      summary: {
        revenue,
        cogs,
        grossProfit: revenue - cogs,
        orderCount: orders.length,
        unitsSold,
        growth,
        inQty,
        outQty,
        stockValue,
        retailValue,
        productCount: products.length,
        lowStockCount: lowStock.length,
        appointmentCount: appointments.length,
        appointmentDone: apptDone,
        appointmentCancelled: apptCancelled,
        serviceCount: services.length,
      },
      byDay,
      trend,
      topProducts,
      lowStock: lowStock.map((p) => ({ id: p.id, name: p.name, sku: p.sku, stock: p.stock, minStock: p.minStock })),
      stockMovements: stockMovements.slice(0, 20),
      appointments: appointments
        .sort((a, b) => a.scheduledAt.getTime() - b.scheduledAt.getTime())
        .map((a) => ({ id: a.id, customerName: a.customerName, service: a.service.name, scheduledAt: a.scheduledAt, status: a.status })),
    })
  } catch (e) {
    console.error('GET /api/reports', e)
    return NextResponse.json({ error: 'Không tạo được báo cáo' }, { status: 500 })
  }
}
