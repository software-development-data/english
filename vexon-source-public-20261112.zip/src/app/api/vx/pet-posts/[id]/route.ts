export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/pet-posts/[id] — thả tim (toggle) hoặc bình luận bài viết thú cưng
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const post = await db.vxPetPost.findUnique({ where: { id }, include: { pet: { select: { id: true, name: true } } } })
    if (!post) return NextResponse.json({ error: 'Không tìm thấy bài viết' }, { status: 404 })
    const body = await req.json()
    if (body.action === 'like') {
      const existing = await db.vxPetLike.findUnique({ where: { postId_userId: { postId: id, userId: me.id } } })
      if (existing) {
        await db.vxPetLike.delete({ where: { id: existing.id } })
        const count = await db.vxPetLike.count({ where: { postId: id } })
        return NextResponse.json({ ok: true, likes: count, myLike: false })
      }
      await db.vxPetLike.create({ data: { postId: id, userId: me.id } })
      const count = await db.vxPetLike.count({ where: { postId: id } })
      return NextResponse.json({ ok: true, likes: count, myLike: true })
    }
    if (body.action === 'comment') {
      const content = String(body.content || '').trim().slice(0, 500)
      if (!content) return NextResponse.json({ error: 'Nhập nội dung bình luận' }, { status: 400 })
      const c = await db.vxPetComment.create({
        data: { postId: id, userId: me.id, content },
        include: { user: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true } } },
      })
      return NextResponse.json({ ok: true, comment: { id: c.id, content: c.content, createdAt: c.createdAt, user: c.user } })
    }
    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/pet-posts/[id]', e)
    return NextResponse.json({ error: 'Không thực hiện được' }, { status: 500 })
  }
}

// DELETE /api/vx/pet-posts/[id] — tác giả bài hoặc chủ thú cưng xoá bài
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const post = await db.vxPetPost.findUnique({ where: { id }, include: { pet: { select: { ownerId: true } } } })
    if (!post) return NextResponse.json({ error: 'Không tìm thấy bài viết' }, { status: 404 })
    if (post.authorId !== me.id && post.pet.ownerId !== me.id) return NextResponse.json({ error: 'Chỉ tác giả hoặc chủ thú cưng mới được xoá' }, { status: 403 })
    await db.vxPetPost.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/pet-posts/[id]', e)
    return NextResponse.json({ error: 'Không xoá được bài viết' }, { status: 500 })
  }
}
