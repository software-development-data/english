export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// GET /api/vx/candidate — CV số của tôi
export async function GET() {
  try {
    const me = await requireUser()
    const cv = await db.vxCandidate.findUnique({ where: { userId: me.id } })
    const appCount = await db.vxApplication.count({ where: { userId: me.id } })
    return NextResponse.json({
      cv: cv
        ? {
            headline: cv.headline, phone: cv.phone,
            skills: cv.skills ? JSON.parse(cv.skills) : [],
            experiences: cv.experiences ? JSON.parse(cv.experiences) : [],
            education: cv.education ? JSON.parse(cv.education) : [],
            desiredSalary: cv.desiredSalary, desiredLocation: cv.desiredLocation,
            updatedAt: cv.updatedAt,
          }
        : null,
      applicationCount: appCount,
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/candidate', e)
    return NextResponse.json({ error: 'Không tải được CV' }, { status: 500 })
  }
}

// PUT /api/vx/candidate — lưu CV số
export async function PUT(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const data = {
      headline: body.headline ? String(body.headline).slice(0, 120) : null,
      phone: body.phone ? String(body.phone).slice(0, 20) : null,
      skills: Array.isArray(body.skills) ? JSON.stringify(body.skills.map((s: unknown) => String(s).slice(0, 50)).slice(0, 30)) : null,
      experiences: Array.isArray(body.experiences) ? JSON.stringify(body.experiences.slice(0, 15)) : null,
      education: Array.isArray(body.education) ? JSON.stringify(body.education.slice(0, 10)) : null,
      desiredSalary: Number(body.desiredSalary) > 0 ? Math.round(Number(body.desiredSalary)) : null,
      desiredLocation: body.desiredLocation ? String(body.desiredLocation).slice(0, 120) : null,
    }
    await db.vxCandidate.upsert({ where: { userId: me.id }, create: { userId: me.id, ...data }, update: data })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PUT /api/vx/candidate', e)
    return NextResponse.json({ error: 'Không lưu được CV' }, { status: 500 })
  }
}
