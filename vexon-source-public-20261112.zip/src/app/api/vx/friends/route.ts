export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError, publicUser } from '@/lib/vx-auth'

const SELECT_USER = { id: true, username: true, fullName: true, role: true, avatarColor: true, avatarImage: true, bio: true }

// GET: danh sách bạn bè + lời mời đã nhận/đã gửi
export async function GET() {
  try {
    const me = await requireUser()

    const accepted = await db.vxFriendship.findMany({
      where: { status: 'accepted', OR: [{ requesterId: me.id }, { addresseeId: me.id }] },
      include: { requester: { select: SELECT_USER }, addressee: { select: SELECT_USER } },
    })
    // Kèm friendshipId để trang Bạn bè gọi action 'remove' (Hủy kết bạn) đúng lời hứa
    const friends = accepted.map((f) => {
      const u = f.requesterId === me.id ? f.addressee : f.requester
      return { ...u, friendshipId: f.id }
    })

    const received = await db.vxFriendship.findMany({
      where: { addresseeId: me.id, status: 'pending' },
      include: { requester: { select: SELECT_USER } },
    })

    const sent = await db.vxFriendship.findMany({
      where: { requesterId: me.id, status: 'pending' },
      include: { addressee: { select: SELECT_USER } },
    })

    return NextResponse.json({
      friends,
      requestsReceived: received.map((r) => ({ friendshipId: r.id, user: r.requester, createdAt: r.createdAt })),
      requestsSent: sent.map((r) => ({ friendshipId: r.id, user: r.addressee, createdAt: r.createdAt })),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/friends', e)
    return NextResponse.json({ error: 'Không tải được danh sách bạn bè' }, { status: 500 })
  }
}

// POST: { action: 'request' | 'accept' | 'decline' | 'remove' | 'follow' }
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const { action, userId, friendshipId } = await req.json()

    if (action === 'request') {
      if (!userId || userId === me.id) return NextResponse.json({ error: 'Người dùng không hợp lệ' }, { status: 400 })
      const existing = await db.vxFriendship.findFirst({
        where: {
          OR: [
            { requesterId: me.id, addresseeId: userId },
            { requesterId: userId, addresseeId: me.id },
          ],
        },
      })
      if (existing) {
        return NextResponse.json({ error: existing.status === 'accepted' ? 'Hai bạn đã là bạn bè' : 'Lời mời đang chờ xử lý' }, { status: 400 })
      }
      const fr = await db.vxFriendship.create({ data: { requesterId: me.id, addresseeId: userId, status: 'pending' } })
      await db.vxNotification.create({
        data: { userId, type: 'friend_request', content: `${me.fullName} đã gửi lời mời kết bạn` },
      })
      return NextResponse.json(fr, { status: 201 })
    }

    if (action === 'accept' || action === 'decline') {
      if (!friendshipId) return NextResponse.json({ error: 'Thiếu lời mời' }, { status: 400 })
      const fr = await db.vxFriendship.findUnique({ where: { id: friendshipId } })
      if (!fr || fr.addresseeId !== me.id || fr.status !== 'pending') {
        return NextResponse.json({ error: 'Lời mời không tồn tại' }, { status: 404 })
      }
      if (action === 'accept') {
        const updated = await db.vxFriendship.update({ where: { id: friendshipId }, data: { status: 'accepted' } })
        await db.vxNotification.create({
          data: { userId: fr.requesterId, type: 'friend_request', content: `${me.fullName} đã chấp nhận lời mời kết bạn` },
        })
        return NextResponse.json(updated)
      }
      return NextResponse.json(await db.vxFriendship.delete({ where: { id: friendshipId } }))
    }

    if (action === 'remove') {
      if (!friendshipId) return NextResponse.json({ error: 'Thiếu mối quan hệ' }, { status: 400 })
      const fr = await db.vxFriendship.findUnique({ where: { id: friendshipId } })
      if (!fr || (fr.requesterId !== me.id && fr.addresseeId !== me.id)) {
        return NextResponse.json({ error: 'Không tìm thấy' }, { status: 404 })
      }
      await db.vxFriendship.delete({ where: { id: friendshipId } })
      return NextResponse.json({ ok: true })
    }

    if (action === 'follow') {
      if (!userId || userId === me.id) return NextResponse.json({ error: 'Người dùng không hợp lệ' }, { status: 400 })
      const existing = await db.vxFollow.findUnique({ where: { followerId_followingId: { followerId: me.id, followingId: userId } } })
      if (existing) {
        await db.vxFollow.delete({ where: { id: existing.id } })
        return NextResponse.json({ following: false })
      }
      await db.vxFollow.create({ data: { followerId: me.id, followingId: userId } })
      return NextResponse.json({ following: true })
    }

    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/friends', e)
    return NextResponse.json({ error: 'Không thực hiện được thao tác' }, { status: 500 })
  }
}
