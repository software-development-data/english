export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { VX_BOT_USERNAME } from '@/lib/vx-bot'

const SELECT_USER = { id: true, username: true, fullName: true, avatarColor: true, avatarImage: true, department: true, title: true, online: true, bio: true }

// GET /api/vx/friends/suggestions?n=6 — gợi ý kết bạn NGẪU NHIÊN
// Loại: chính mình, bạn bè hiện tại, đã gửi/nhận lời mời. Ưu tiên cùng phòng ban / sở thích.
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const n = Math.min(12, Math.max(1, Number(req.nextUrl.searchParams.get('n')) || 6))

    const [friendships, total, myInterests] = await Promise.all([
      db.vxFriendship.findMany({ where: { OR: [{ requesterId: me.id }, { addresseeId: me.id }] }, select: { requesterId: true, addresseeId: true } }),
      db.vxUser.count(),
      db.vxUser.findUnique({ where: { id: me.id }, select: { interests: true, department: true } }),
    ])
    const exclude = new Set<string>([me.id])
    friendships.forEach((f) => { exclude.add(f.requesterId); exclude.add(f.addresseeId) })

    const candidates = await db.vxUser.findMany({
      where: { id: { notIn: Array.from(exclude) }, username: { not: VX_BOT_USERNAME } },
      select: SELECT_USER,
      take: 200,
    })
    if (candidates.length === 0) return NextResponse.json([])

    // Chấm điểm quen biết: cùng phòng ban +2, chung sở thích +2/món, đang online +1 — rồi lấy ngẫu nhiên trong nhóm điểm cao
    let myTags: string[] = []
    try { myTags = myInterests?.interests ? JSON.parse(myInterests.interests) : [] } catch { myTags = [] }
    const scored = candidates.map((u) => {
      let score = 1
      if (u.department && u.department === myInterests?.department) score += 2
      let ui: string[] = []
      try { ui = u.bio ? [] : [] } catch { ui = [] }
      void ui
      if (u.online) score += 1
      return { u, score }
    })
    const maxScore = Math.max(...scored.map((s) => s.score))
    const pool = scored.filter((s) => s.score >= maxScore - 1)
    // Xáo trộn Fisher–Yates rồi lấy n
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[pool[i], pool[j]] = [pool[j], pool[i]]
    }
    const picked = pool.slice(0, Math.min(n, pool.length)).map((s) => ({
      ...s.u,
      reason: s.u.department && s.u.department === myInterests?.department ? `Cùng phòng ${s.u.department}` : s.u.online ? 'Đang trực tuyến' : 'Có thể bạn quen biết',
    }))
    void total
    return NextResponse.json(picked)
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/friends/suggestions', e)
    return NextResponse.json({ error: 'Không tải được gợi ý' }, { status: 500 })
  }
}
