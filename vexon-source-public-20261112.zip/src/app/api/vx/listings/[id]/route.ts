export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// PATCH /api/vx/listings/[id] — chủ tin: đánh dấu đã bán / đăng lại / ẩn
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const body = await req.json()
    const status = String(body.status || '')
    if (!['active', 'sold', 'hidden'].includes(status)) {
      return NextResponse.json({ error: 'Trạng thái không hợp lệ' }, { status: 400 })
    }
    const own = await db.listing.findUnique({ where: { id }, select: { sellerId: true } })
    if (!own) return NextResponse.json({ error: 'Tin đăng không tồn tại' }, { status: 404 })
    if (own.sellerId !== me.id) return NextResponse.json({ error: 'Chỉ chủ tin đăng mới được sửa' }, { status: 403 })
    const updated = await db.listing.update({ where: { id }, data: { status } })
    return NextResponse.json({ ok: true, status: updated.status })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/listings/[id]', e)
    return NextResponse.json({ error: 'Không cập nhật được tin đăng' }, { status: 500 })
  }
}

// DELETE /api/vx/listings/[id] — chủ tin xoá tin
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const own = await db.listing.findUnique({ where: { id }, select: { sellerId: true } })
    if (!own) return NextResponse.json({ error: 'Tin đăng không tồn tại' }, { status: 404 })
    if (own.sellerId !== me.id) return NextResponse.json({ error: 'Chỉ chủ tin đăng mới được xoá' }, { status: 403 })
    await db.listing.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/listings/[id]', e)
    return NextResponse.json({ error: 'Không xoá được tin đăng' }, { status: 500 })
  }
}
