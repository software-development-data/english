export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELLER = { id: true, username: true, fullName: true, avatarColor: true, avatarImage: true }

// GET /api/vx/listings — tin đăng Chợ Vexon (kèm cờ isMine cho người đang đăng nhập)
export async function GET() {
  try {
    const me = await requireUser().catch(() => null)
    const rows = await db.listing.findMany({
      where: { status: { in: ['active', 'sold'] } },
      orderBy: { createdAt: 'desc' },
      take: 120,
      include: { seller: { select: SELLER } },
    })
    return NextResponse.json(
      rows.map((l) => ({
        id: l.id,
        title: l.title,
        price: l.price,
        category: l.category,
        image: l.image,
        description: l.description,
        location: l.location,
        status: l.status,
        createdAt: l.createdAt,
        seller: l.seller,
        isMine: me ? l.sellerId === me.id : false,
      })),
    )
  } catch (e) {
    console.error('GET /api/vx/listings', e)
    return NextResponse.json({ error: 'Không tải được Chợ Vexon' }, { status: 500 })
  }
}

// POST /api/vx/listings — người dùng thường tự đăng bán
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const title = String(body.title || '').trim()
    const price = Number(body.price)
    if (!title || !Number.isFinite(price) || price < 0) {
      return NextResponse.json({ error: 'Cần nhập tên sản phẩm và giá bán' }, { status: 400 })
    }
    const listing = await db.listing.create({
      data: {
        sellerId: me.id,
        title: title.slice(0, 120),
        price,
        category: String(body.category || 'Khác').slice(0, 40),
        image: typeof body.image === 'string' && body.image.startsWith('data:image') ? body.image.slice(0, 3_000_000) : null,
        description: String(body.description || '').slice(0, 2000) || null,
        location: String(body.location || '').slice(0, 120) || null,
      },
      include: { seller: { select: SELLER } },
    })
    return NextResponse.json({ ...listing, isMine: true }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/listings', e)
    return NextResponse.json({ error: 'Không đăng được tin bán' }, { status: 500 })
  }
}
