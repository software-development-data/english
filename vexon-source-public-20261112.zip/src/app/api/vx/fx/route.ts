export const dynamic = 'force-dynamic'

import { NextResponse } from 'next/server'
import { getUsdVndInfo } from '@/lib/vx-fx'

// GET /api/vx/fx — tỷ giá USD/VND hiện tại (AI tự động bám thị trường: đa nguồn dự phòng, cache 30 phút;
// trả kèm giá kỳ trước `prev` để client hiện chiều tăng/giảm; lỗi mạng trả tỷ giá dự phòng)
export async function GET() {
  try {
    const { rate, source, prev, updatedAt } = await getUsdVndInfo()
    return NextResponse.json({ usdVnd: rate, source, prev, updatedAt })
  } catch (e) {
    console.error('GET /api/vx/fx', e)
    return NextResponse.json({ usdVnd: 25655, source: 'fallback', prev: null, updatedAt: Date.now() })
  }
}
