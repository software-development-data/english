export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError, publicUser } from '@/lib/vx-auth'

// GET /api/vx/users/[id] — trang hồ sơ công khai (Hồ sơ năng lực cá nhân)
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const u = await db.vxUser.findUnique({
      where: { id },
      select: {
        id: true, username: true, fullName: true, role: true, department: true, title: true,
        avatarColor: true, avatarImage: true, coverImage: true, bio: true, hometown: true, education: true, birthday: true, phone: true, accountType: true, companyName: true, interests: true, settings: true,
        heightCm: true, weightKg: true, relationship: true, smoking: true, drinking: true, pets: true, gender: true,
        ethnicity: true, citizenId: true, taxCode: true,
        online: true, lastSeen: true, createdAt: true, email: true,
        locationName: true, locationVisible: true,
        _count: { select: { posts: true, videos: true, followers: true, followings: true, attendances: true } },
      },
    })
    if (!u) return NextResponse.json({ error: 'Không tìm thấy người dùng' }, { status: 404 })

    const friendship = await db.vxFriendship.findFirst({
      where: { OR: [{ requesterId: me.id, addresseeId: id }, { requesterId: id, addresseeId: me.id }] },
    })
    // Quyền riêng tư từng mục kiểu Facebook: bio/quê quán/học vấn/SĐT/chức vụ → Công khai | Bạn bè | Chỉ mình tôi
    // (năm sinh dùng birthdayVisibility riêng đã có từ trước; bản thân luôn thấy hết)
    const isMe = id === me.id
    const isFriend = friendship?.status === 'accepted'
    let prefs: { birthdayVisibility?: string; fieldVis?: Record<string, string> } = {}
    try { prefs = u.settings ? (JSON.parse(u.settings) as { birthdayVisibility?: string; fieldVis?: Record<string, string> }) : {} } catch { /* bỏ qua */ }
    const fvOf = (k: string): 'public' | 'friends' | 'private' => {
      const v = prefs.fieldVis?.[k]
      return v === 'friends' || v === 'private' ? v : 'public'
    }
    const canSee = (k: string) => isMe || fvOf(k) === 'public' || (fvOf(k) === 'friends' && isFriend)
    const hiddenFields: string[] = []
    const mask = (k: string, val: string | null | undefined): string | null => {
      if (canSee(k)) return val ?? null
      if (val) hiddenFields.push(k)
      return null
    }
    const hometownOut = mask('hometown', u.hometown)
    const educationOut = mask('education', u.education)
    const phoneOut = mask('phone', u.phone)
    const bioOut = mask('bio', u.bio)
    const titleOut = mask('job', u.title)
    const deptOut = mask('job', u.department)
    // Mục hẹn hò/xã giao cũng có quyền riêng tư riêng kiểu FB: chiều cao, cân nặng, tình trạng, lối sống, sở thích
    const interestsOut = canSee('interests') ? u.interests : (u.interests ? (hiddenFields.push('interests'), null) : null)
    const heightOut = mask('height', u.heightCm ? String(u.heightCm) : null)
    const weightOut = mask('weight', u.weightKg ? String(u.weightKg) : null)
    const relOut = mask('relationship', u.relationship)
    const smokeOut = mask('lifestyle', u.smoking)
    const drinkOut = mask('lifestyle', u.drinking)
    const petsOut = mask('lifestyle', u.pets)
    const genderOut = mask('gender', u.gender)
    // Hồ sơ mở rộng (tích hợp ra tab Giới thiệu): dân tộc, CCCD, mã số thuế — quyền riêng tư riêng kiểu FB
    const ethnicityOut = mask('ethnicity', u.ethnicity)
    const citizenIdOut = mask('citizenId', u.citizenId)
    const taxCodeOut = mask('taxCode', u.taxCode)
    const lifestyleAny = smokeOut || drinkOut || petsOut
    // Quyền riêng tư năm sinh: private = không ai thấy, friends = chỉ bạn bè thấy (bản thân luôn thấy)
    let birthdayPublic: Date | string | null = u.birthday
    if (!isMe) {
      const vis = prefs.birthdayVisibility
      if (vis === 'private' || (vis === 'friends' && !isFriend)) birthdayPublic = null
    }
    const company = u.accountType === 'business' ? await db.vxCompany.findUnique({ where: { ownerId: id }, select: { id: true, name: true, industry: true, ratingAvg: true, ratingCount: true, botEnabled: true } }) : null
    const cv = id === me.id ? await db.vxCandidate.findUnique({ where: { userId: id } }) : null

    // Ảnh từ bài viết (lưới ảnh kiểu Facebook) + bạn bè chung
    const [postImgs, friendsRaw] = await Promise.all([
      db.vxPost.findMany({ where: { authorId: id, images: { not: null } }, orderBy: { createdAt: 'desc' }, take: 24, select: { images: true } }),
      db.vxFriendship.findMany({
        where: { status: 'accepted', OR: [{ requesterId: id }, { addresseeId: id }] },
        take: 24,
        select: { requester: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true, title: true } }, addressee: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true, title: true } } },
      }),
    ])
    const photos: string[] = []
    for (const p of postImgs) {
      try {
        const arr = JSON.parse(p.images as string) as string[]
        for (const v of arr) {
          if (typeof v === 'string' && !v.startsWith('grad:')) photos.push(v)
          if (photos.length >= 18) break
        }
      } catch { /* bỏ qua */ }
      if (photos.length >= 18) break
    }
    const friends = friendsRaw.map((f) => (f.requester.id === id ? f.addressee : f.requester))

    return NextResponse.json({
      profile: {
        ...publicUser({ ...u, birthday: birthdayPublic, hometown: hometownOut, education: educationOut, phone: phoneOut, bio: bioOut, title: titleOut, department: deptOut, interests: interestsOut, heightCm: heightOut ? Number(heightOut) : null, weightKg: weightOut ? Number(weightOut) : null, relationship: relOut, smoking: smokeOut, drinking: drinkOut, pets: petsOut, gender: genderOut, ethnicity: ethnicityOut, citizenId: citizenIdOut, taxCode: taxCodeOut }),
        online: u.online,
        lastSeen: u.lastSeen,
        joinedAt: u.createdAt,
        locationName: u.locationVisible ? u.locationName : null,
        locationVisible: u.locationVisible,
        hiddenFields,
        lifestyleAny,
        // Thành viên doanh nghiệp (đã duyệt) → badge + quyền lợi hiển thị trên hồ sơ
        bizMember: await (async () => {
          const m = await db.vxBusinessMember.findFirst({ where: { userId: id, status: 'active' }, include: { company: { select: { id: true, name: true } } } })
          return m ? { companyId: m.company.id, companyName: m.company.name } : null
        })(),
        counts: { posts: u._count.posts, videos: u._count.videos, followers: u._count.followers, following: u._count.followings, attendanceDays: u._count.attendances },
        friendship: friendship ? (friendship.status === 'accepted' ? 'friends' : friendship.requesterId === me.id ? 'request_sent' : 'request_received') : null,
        friendshipId: friendship?.id ?? null,
        blocked: Boolean(await db.vxBlock.findUnique({ where: { blockerId_blockedId: { blockerId: me.id, blockedId: id } } })),
        company,
        cv: cv ? { headline: cv.headline, skills: cv.skills ? JSON.parse(cv.skills) : [] } : null,
      },
      isMe: id === me.id,
      photos,
      friends,
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/users/[id]', e)
    return NextResponse.json({ error: 'Không tải được hồ sơ' }, { status: 500 })
  }
}
