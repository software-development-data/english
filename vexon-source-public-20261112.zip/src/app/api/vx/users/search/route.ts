export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { VX_BOT_USERNAME } from '@/lib/vx-bot'

/**
 * Tìm kiếm bạn bè TOÀN QUỐC (Heesay-style) — không giới hạn khoảng cách.
 * Params:
 *  - q: từ khoá (tên / username / email)
 *  - filter: all | online (đang online) | recent (hoạt động trong 30 phút) | friends (bạn bè) | new (người mới tham gia)
 *  - ageMin / ageMax: lọc độ tuổi (18–99, kéo slider)
 *  - hMin / hMax: lọc chiều cao (cm, 140–200, kéo slider)
 *  - wMin / wMax: lọc cân nặng (kg, 40–120, kéo slider)
 *  - province: tỉnh/thành (34 tỉnh sau sáp nhập 2025)
 *  - maxKm: chỉ lấy người cách bạn tối đa X km (dùng vị trí GPS đã lưu của bạn)
 *  - limit: số kết quả (max 50)
 * Trả về kèm friend_status: none | accepted | pending_sent | pending_received và distanceKm (nếu có vị trí)
 */
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const sp = req.nextUrl.searchParams
    const q = (sp.get('q') || '').trim()
    const filter = sp.get('filter') || 'all'
    const ageMin = Number(sp.get('ageMin')) || 0
    const ageMax = Number(sp.get('ageMax')) || 0
    const hMin = Number(sp.get('hMin')) || 0
    const hMax = Number(sp.get('hMax')) || 0
    const wMin = Number(sp.get('wMin')) || 0
    const wMax = Number(sp.get('wMax')) || 0
    const province = (sp.get('province') || '').trim()
    const maxKm = Number(sp.get('maxKm')) || 0
    const limit = Math.min(Number(sp.get('limit')) || 30, 50)

    const now = Date.now()
    const ONLINE_MS = 75_000 // online: hoạt động trong ~75 giây (như code bạn đã làm ổn)
    const RECENT_MS = 30 * 60_000 // "offline khoảng 30 phút" = hoạt động trong nửa giờ

    // Chặn: loại người tôi chặn và người đã chặn tôi khỏi kết quả (kiểu Zalo)
    const blockRows = await db.vxBlock.findMany({
      where: { OR: [{ blockerId: me.id }, { blockedId: me.id }] },
      select: { blockerId: true, blockedId: true },
    })
    const blockedIds = [...new Set(blockRows.map((b) => (b.blockerId === me.id ? b.blockedId : b.blockerId)))]

    const where: Prisma.VxUserWhereInput = {
      id: { not: me.id, ...(blockedIds.length ? { notIn: blockedIds } : {}) },
      // Loại tài khoản bot hệ thống (Vexon Bot) khỏi kết quả tìm người
      username: { not: VX_BOT_USERNAME },
    }
    if (q) {
      where.OR = [
        { fullName: { contains: q } },
        { username: { contains: q } },
        { email: { contains: q } },
      ]
    }
    if (filter === 'online') {
      // Online = đang hoạt động + cả người offline trong vòng 30 phút (đúng yêu cầu: tính theo lần hoạt động cuối)
      where.lastSeen = { gte: new Date(now - RECENT_MS) }
    } else if (filter === 'friends') {
      const fr = await db.vxFriendship.findMany({
        where: { status: 'accepted', OR: [{ requesterId: me.id }, { addresseeId: me.id }] },
        select: { requesterId: true, addresseeId: true },
      })
      const friendIds = fr.map((f) => (f.requesterId === me.id ? f.addresseeId : f.requesterId)).filter((id) => !blockedIds.includes(id))
      if (friendIds.length === 0) return NextResponse.json({ users: [], total: 0 })
      where.id = { in: friendIds }
    }
    if (province) where.province = province

    // Khoảng cách: cần vị trí GPS đã lưu của mình (cùng cách /api/vx/nearby dùng) — LUÔN tính khoảng cách để hiện số m/km trên thẻ người
    const meFull = await db.vxUser.findUnique({ where: { id: me.id }, select: { latitude: true, longitude: true } })
    const myLat = meFull?.latitude ?? null
    const myLng = meFull?.longitude ?? null
    const haveGps = myLat != null && myLng != null

    // Lọc độ tuổi ngay ở DB nhờ birthday
    if (ageMin > 0 || ageMax > 0) {
      const today = new Date()
      const birthdayCond: Prisma.DateTimeNullableFilter = {}
      if (ageMin > 0) birthdayCond.lte = new Date(today.getFullYear() - ageMin, today.getMonth(), today.getDate(), 23, 59, 59)
      if (ageMax > 0) birthdayCond.gte = new Date(today.getFullYear() - ageMax - 1, today.getMonth(), today.getDate())
      if (Object.keys(birthdayCond).length) where.birthday = birthdayCond
    }

    // Lọc chiều cao / cân nặng ngay ở DB (cột số heightCm / weightKg) — người chưa nhập số đo sẽ không hiện khi bật lọc
    const hCond: Prisma.IntNullableFilter = {}
    if (hMin > 0) hCond.gte = hMin
    if (hMax > 0) hCond.lte = hMax
    if (Object.keys(hCond).length) where.heightCm = hCond
    const wCond: Prisma.IntNullableFilter = {}
    if (wMin > 0) wCond.gte = wMin
    if (wMax > 0) wCond.lte = wMax
    if (Object.keys(wCond).length) where.weightKg = wCond

    const users = await db.vxUser.findMany({
      where,
      select: {
        id: true, username: true, fullName: true, avatarColor: true, avatarImage: true,
        bio: true, accountType: true, lastSeen: true, birthday: true, province: true, createdAt: true,
        latitude: true, longitude: true, settings: true,
      },
      orderBy: filter === 'new' ? [{ createdAt: 'desc' }] : [{ lastSeen: 'desc' }],
      take: filter === 'friends' ? limit : limit * 3,
    })

    // Trạng thái quan hệ bạn bè cho tất cả kết quả
    const ids = users.map((u) => u.id)

    // Mô phỏng trạng thái hoạt động nhẹ (đồng bộ cách /api/vx/users đang làm) — demo sinh động
    const presenceUpdates: Promise<unknown>[] = []
    const presence = new Map<string, { online: boolean; lastSeen: Date }>()
    for (const u of users) {
      if (Math.random() < 0.3) {
        const toOnline = Math.random() < 0.7
        const ls = toOnline ? new Date() : new Date(now - Math.floor(Math.random() * 28 + 2) * 60_000)
        presence.set(u.id, { online: toOnline, lastSeen: ls })
        presenceUpdates.push(db.vxUser.update({ where: { id: u.id }, data: { online: toOnline, lastSeen: ls } }))
      }
    }
    if (presenceUpdates.length) await Promise.all(presenceUpdates)
    const friendships = await db.vxFriendship.findMany({
      where: {
        OR: [
          { requesterId: me.id, addresseeId: { in: ids } },
          { addresseeId: me.id, requesterId: { in: ids } },
        ],
      },
    })
    const frMap = new Map<string, { status: string; dir: 'sent' | 'received'; id: string }>()
    for (const f of friendships) {
      const other = f.requesterId === me.id ? f.addresseeId : f.requesterId
      frMap.set(other, { status: f.status, dir: f.requesterId === me.id ? 'sent' : 'received', id: f.id })
    }

    const ageOf = (b?: Date | string | null) => {
      if (!b) return null
      const d = new Date(b)
      const t = new Date()
      let age = t.getFullYear() - d.getFullYear()
      const m = t.getMonth() - d.getMonth()
      if (m < 0 || (m === 0 && t.getDate() < d.getDate())) age--
      return age
    }

    // Quyền riêng tư năm sinh: private = không ai thấy tuổi, friends = chỉ bạn bè thấy, còn lại công khai
    const bdayVisible = (vis: unknown, friendStatus?: string) => {
      if (vis === 'private') return false
      if (vis === 'friends') return friendStatus === 'accepted'
      return true
    }

    const activityLabel = (lastSeen: Date) => {
      const diff = now - new Date(lastSeen).getTime()
      if (diff <= ONLINE_MS) return { key: 'online', text: 'Đang hoạt động' }
      const mins = Math.floor(diff / 60_000)
      if (mins < 60) return { key: 'recent', text: `Hoạt động ${mins} phút trước` }
      const hours = Math.floor(mins / 60)
      if (hours < 24) return { key: 'today', text: `Hoạt động ${hours} giờ trước` }
      const days = Math.floor(hours / 24)
      return { key: 'old', text: `Hoạt động ${days} ngày trước` }
    }

type SearchUser = {
  id: string
  username: string
  fullName: string
  avatarColor: string
  avatarImage: string | null
  bio: string | null
  accountType: string
  age: number | null
  province: string | null
  online: boolean
  activity: string
  activityKey: 'online' | 'recent' | 'today' | 'old'
  lastSeenMs: number
  friendStatus: 'none' | 'accepted' | 'pending_sent' | 'pending_received'
  friendshipId: string | null
  distanceKm: number | null
}

    const haversine = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
      const R = 6371
      const dLat = ((lat2 - lat1) * Math.PI) / 180
      const dLng = ((lng2 - lng1) * Math.PI) / 180
      const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2
      return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    }

    const out = users
      .map((u) => {
        const fr = frMap.get(u.id)
        const p = presence.get(u.id)
        let act = activityLabel(p ? p.lastSeen : u.lastSeen)
        // Quyền riêng tư cá nhân: tắt hiện "Đang hoạt động" / thời gian hoạt động gần nhất
        let prefs: { showOnline?: boolean; showLastSeen?: boolean; birthdayVisibility?: string; fieldVis?: Record<string, string> } = {}
        try { prefs = u.settings ? JSON.parse(u.settings) : {} } catch { /* bỏ qua */ }
        if (prefs.showOnline === false && act.key === 'online') act = { key: 'old', text: 'Ngoại tuyến' }
        if (prefs.showLastSeen === false && act.key !== 'old') act = { key: 'old', text: 'Ngoại tuyến' }
        // Ẩn tuổi theo quyền riêng tư năm sinh của từng người
        const showAge = bdayVisible(prefs.birthdayVisibility, fr?.status)
        // Ẩn bio theo quyền riêng tư từng mục kiểu Facebook (bio: Bạn bè / Chỉ mình tôi)
        const fvBio = prefs.fieldVis?.bio
        const bioHidden = fvBio === 'private' || (fvBio === 'friends' && fr?.status !== 'accepted')
        // Nhãn "người mới tham gia" — tính từ ngày tạo tài khoản
        if (filter === 'new') {
          const days = Math.floor((now - new Date(u.createdAt).getTime()) / 86_400_000)
          act.text = days < 1 ? 'Mới tham gia, Hôm nay' : `Mới tham gia ${days} ngày trước`
        }
        const dist = haveGps && u.latitude != null && u.longitude != null
          ? Math.round(haversine(myLat as number, myLng as number, u.latitude, u.longitude) * 10) / 10
          : null
        const row: SearchUser = {
          id: u.id,
          username: u.username,
          fullName: u.fullName,
          avatarColor: u.avatarColor,
          avatarImage: u.avatarImage,
          bio: bioHidden ? null : u.bio,
          accountType: u.accountType,
          age: showAge ? ageOf(u.birthday) : null,
          province: u.province,
          online: act.key === 'online',
          activity: act.text,
          activityKey: act.key as SearchUser['activityKey'],
          lastSeenMs: Math.max(0, now - new Date(p ? p.lastSeen : u.lastSeen).getTime()),
          friendStatus: fr ? (fr.status === 'accepted' ? 'accepted' : fr.dir === 'sent' ? 'pending_sent' : 'pending_received') : 'none',
          friendshipId: fr?.id || null,
          distanceKm: dist,
        }
        return row
      })
      // Lọc khoảng cách theo vị trí thật (chỉ khi bật maxKm; còn lại luôn trả distanceKm để hiện m/km)
      .filter((u) => (maxKm > 0 && haveGps ? u.distanceKm != null && u.distanceKm <= maxKm : true))
      // Lọc Gần đây: chỉ người có khoảng cách GPS (kết quả gần nhất lên đầu)
      .filter((u) => (filter === 'near' ? u.distanceKm != null : true))
      // Lọc chính xác tuổi sau khi tính từ birthday (tránh lệ cận biên)
      .filter((u) => (ageMin > 0 ? (u.age ?? -1) >= ageMin : true) && (ageMax > 0 ? (u.age ?? -1) <= ageMax : true))
      // Ưu tiên r31: TAB ONLINE xếp thuần theo HOẠT ĐỘNG — đang hoạt động lên trước, người offline trong 30 phút
      // xếp sau (không nhân quyền bạn bè); các tab còn lại giữ ưu tiên bạn bè cũ. TRONG TỪNG NHÓM ai hoạt động
      // GẦN NHẤT lên đầu (không còn xếp theo tên)
      .sort((a, b) => (filter === 'new' ? 0 : filter === 'near' || (maxKm > 0 && haveGps)
        ? (a.distanceKm ?? 9999) - (b.distanceKm ?? 9999) || a.lastSeenMs - b.lastSeenMs
        : (() => {
          const rank = (x: SearchUser) => (filter === 'online'
            ? (x.online ? 0 : 1) // tab Online: chỉ nhìn hoạt động — người offline (dù là bạn bè) xếp sau
            : (x.friendStatus === 'accepted' ? 0 : x.online ? 1 : x.activityKey === 'recent' ? 2 : 3))
          return rank(a) - rank(b) || a.lastSeenMs - b.lastSeenMs || a.fullName.localeCompare(b.fullName, 'vi')
        })()))
      .slice(0, limit)

    return NextResponse.json({ users: out, total: out.length })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/users/search', e)
    return NextResponse.json({ error: 'Không tìm được người dùng' }, { status: 500 })
  }
}
