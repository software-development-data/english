export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// GET /api/vx/users?q= — danh sách người dùng (kèm phòng ban, online, lần cuối truy cập)
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const q = req.nextUrl.searchParams.get('q') || ''
    const users = await db.vxUser.findMany({
      where: q
        ? { OR: [{ username: { contains: q.toLowerCase() } }, { fullName: { contains: q } }] }
        : {},
      select: {
        id: true, username: true, fullName: true, role: true, department: true, title: true,
        avatarColor: true, avatarImage: true, bio: true, online: true, lastSeen: true,
      },
      take: 50,
      orderBy: [{ online: 'desc' }, { fullName: 'asc' }],
    })

    // Mô phỏng trạng thái online: người khác online offline ngẫu nhiên nhẹ
    const now = new Date()
    const updates: Promise<unknown>[] = []
    const result = users
      .filter((u) => u.id !== me.id)
      .map((u) => {
        if (Math.random() < 0.12) {
          const online = !u.online
          updates.push(db.vxUser.update({ where: { id: u.id }, data: { online, lastSeen: online ? now : new Date(now.getTime() - Math.floor(Math.random() * 40) * 60000) } }))
          return { ...u, online }
        }
        return u
      })
    await Promise.all(updates)

    // Cập nhật lastSeen của chính mình
    await db.vxUser.update({ where: { id: me.id }, data: { lastSeen: now, online: true } })

    return NextResponse.json(result)
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/users', e)
    return NextResponse.json({ error: 'Không tải được người dùng' }, { status: 500 })
  }
}
