export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { getUsdVnd } from '@/lib/vx-fx'
import { fmtUsdFromXu } from '@/lib/format'

const SELECT_USER = { id: true, username: true, fullName: true, avatarColor: true, role: true, department: true }

const TASK_FLOW: Record<string, string> = { backlog: 'todo', todo: 'doing', doing: 'review', review: 'done' }

function serialize(r: {
  id: string; type: string; title: string; description: string | null; status: string; priority: string
  assigneeId: string | null; assignee: { id: string; fullName: string; avatarColor: string } | null
  creator: { id: string; fullName: string; avatarColor: string }
  dueDate: Date | null; amount: number | null; category: string | null; location: string | null
  votes: number; voters: string | null; completedAt: Date | null; createdAt: Date
}) {
  return { ...r, voters: r.voters ? (JSON.parse(r.voters) as string[]) : [], dueDate: r.dueDate?.toISOString() || null, completedAt: r.completedAt?.toISOString() || null, createdAt: r.createdAt.toISOString() }
}

// PATCH /api/vx/ops/[id] — chuyển trạng thái / gán việc / vote sáng kiến
// Cày xu: hoàn thành công việc +20 xu cho người thực hiện
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const body = await req.json()
    const rec = await db.vxOpsRecord.findUnique({ where: { id }, include: { assignee: { select: SELECT_USER }, creator: { select: SELECT_USER } } })
    if (!rec) return NextResponse.json({ error: 'Không tìm thấy bản ghi' }, { status: 404 })

    // ---- Vote sáng kiến (mỗi người 1 phiếu, bỏ/hủy được) ----
    if (body.action === 'vote') {
      const voters: string[] = rec.voters ? JSON.parse(rec.voters) : []
      const has = voters.includes(me.id)
      const next = has ? voters.filter((v) => v !== me.id) : [...voters, me.id]
      const updated = await db.vxOpsRecord.update({ where: { id }, data: { voters: JSON.stringify(next), votes: next.length }, include: { assignee: { select: SELECT_USER }, creator: { select: SELECT_USER } } })
      return NextResponse.json({ record: serialize(updated) })
    }

    // ---- Cập nhật trạng thái đơn từ: duyệt/từ chối (manager/admin) ----
    if (['approved', 'rejected'].includes(body.status) && rec.type === 'leave') {
      if (!['admin', 'manager'].includes(me.role)) return NextResponse.json({ error: 'Chỉ Quản lý / Ban Giám đốc được duyệt đơn' }, { status: 403 })
      const updated = await db.vxOpsRecord.update({
        where: { id },
        data: { status: body.status, completedAt: body.status === 'approved' ? new Date() : null },
        include: { assignee: { select: SELECT_USER }, creator: { select: SELECT_USER } },
      })
      if (rec.createdById !== me.id) {
        await db.vxNotification.create({ data: { userId: rec.createdById, type: 'ops', content: `Đơn "${rec.title.slice(0, 50)}" đã được ${body.status === 'approved' ? 'DUYỆT' : 'TỪ CHỐI'}` } })
      }
      return NextResponse.json({ record: serialize(updated) })
    }

    // ---- Chuyển công việc trên bảng Kanban ----
    if (rec.type === 'task' && body.status) {
      const canMove = me.id === rec.createdById || me.id === rec.assigneeId || ['admin', 'manager'].includes(me.role)
      if (!canMove) return NextResponse.json({ error: 'Bạn không có quyền với công việc này' }, { status: 403 })
      const done = body.status === 'done'
      const updated = await db.vxOpsRecord.update({
        where: { id },
        data: { status: String(body.status), completedAt: done ? new Date() : null },
        include: { assignee: { select: SELECT_USER }, creator: { select: SELECT_USER } },
      })
      let reward = 0
      if (done && rec.status !== 'done' && rec.assigneeId) {
        reward = 20
        await db.vxUser.update({ where: { id: rec.assigneeId }, data: { coins: { increment: reward } } })
        await db.vxCoinTx.create({ data: { userId: rec.assigneeId, amount: reward, reason: `Hoàn thành công việc "${rec.title.slice(0, 40)}"` } })
        await db.vxNotification.create({ data: { userId: rec.assigneeId, type: 'coins', content: `Chúc mừng! Công việc "${rec.title.slice(0, 50)}" hoàn thành, +${fmtUsdFromXu(reward, (await getUsdVnd()).rate)}` } })
        if (rec.createdById !== rec.assigneeId) {
          await db.vxNotification.create({ data: { userId: rec.createdById, type: 'ops', content: `${rec.assignee?.fullName} đã hoàn thành: ${rec.title.slice(0, 50)}` } })
        }
      }
      return NextResponse.json({ record: serialize(updated), reward })
    }

    // ---- Cập nhật chung: gán người / hạn chót / ưu tiên ----
    const updated = await db.vxOpsRecord.update({
      where: { id },
      data: {
        assigneeId: body.assigneeId !== undefined ? (body.assigneeId ? String(body.assigneeId) : null) : undefined,
        dueDate: body.dueDate !== undefined ? (body.dueDate ? new Date(body.dueDate) : null) : undefined,
        priority: ['low', 'normal', 'high', 'urgent'].includes(body.priority) ? body.priority : undefined,
        title: body.title ? String(body.title).slice(0, 200) : undefined,
        description: body.description !== undefined ? (body.description ? String(body.description).slice(0, 2000) : null) : undefined,
      },
      include: { assignee: { select: SELECT_USER }, creator: { select: SELECT_USER } },
    })
    return NextResponse.json({ record: serialize(updated) })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/ops/[id]', e)
    return NextResponse.json({ error: 'Không cập nhật được' }, { status: 500 })
  }
}

// DELETE /api/vx/ops/[id] — người tạo hoặc Ban Giám đốc
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const rec = await db.vxOpsRecord.findUnique({ where: { id }, select: { createdById: true } })
    if (!rec) return NextResponse.json({ error: 'Không tìm thấy' }, { status: 404 })
    if (rec.createdById !== me.id && me.role !== 'admin') return NextResponse.json({ error: 'Không có quyền xóa' }, { status: 403 })
    await db.vxOpsRecord.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/ops/[id]', e)
    return NextResponse.json({ error: 'Không xóa được' }, { status: 500 })
  }
}
