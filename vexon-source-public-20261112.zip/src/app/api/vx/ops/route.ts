export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { getUsdVnd } from '@/lib/vx-fx'
import { fmtUsdFromXu } from '@/lib/format'

const SELECT_USER = { id: true, username: true, fullName: true, avatarColor: true, role: true, department: true }

export const OPS_TYPES = ['task', 'leave', 'finance', 'asset', 'document', 'meeting', 'idea', 'incident', 'visitor', 'travel', 'announce', 'kpi'] as const

function serialize(r: {
  id: string; type: string; title: string; description: string | null; status: string; priority: string
  assigneeId: string | null; assignee: { id: string; fullName: string; avatarColor: string } | null
  creator: { id: string; fullName: string; avatarColor: string }
  dueDate: Date | null; amount: number | null; category: string | null; location: string | null
  votes: number; voters: string | null; completedAt: Date | null; createdAt: Date
}) {
  return { ...r, voters: r.voters ? (JSON.parse(r.voters) as string[]) : [], dueDate: r.dueDate?.toISOString() || null, completedAt: r.completedAt?.toISOString() || null, createdAt: r.createdAt.toISOString() }
}

// GET /api/vx/ops?type=task — danh sách + thống kê tổng quan
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const type = req.nextUrl.searchParams.get('type') || 'task'
    if (!OPS_TYPES.includes(type as (typeof OPS_TYPES)[number])) {
      return NextResponse.json({ error: 'Loại không hợp lệ' }, { status: 400 })
    }
    const records = await db.vxOpsRecord.findMany({
      where: { type },
      orderBy: { createdAt: 'desc' },
      take: 200,
      include: { assignee: { select: SELECT_USER }, creator: { select: SELECT_USER } },
    })
    // Thống kê nhanh toàn hệ thống ERP
    const [myTasks, pendingLeaves, taskDone, taskTotal, financeAgg, openIdeas, openIncidents] = await Promise.all([
      db.vxOpsRecord.count({ where: { type: 'task', assigneeId: me.id, status: { not: 'done' } } }),
      db.vxOpsRecord.count({ where: { type: 'leave', status: 'pending' } }),
      db.vxOpsRecord.count({ where: { type: 'task', status: 'done' } }),
      db.vxOpsRecord.count({ where: { type: 'task' } }),
      db.vxOpsRecord.groupBy({ by: ['category'], where: { type: 'finance', category: { in: ['thu', 'chi'] } }, _sum: { amount: true } }),
      db.vxOpsRecord.count({ where: { type: 'idea', status: 'open' } }),
      db.vxOpsRecord.count({ where: { type: 'incident', status: 'open' } }),
    ])
    const thu = financeAgg.find((f) => f.category === 'thu')?._sum.amount || 0
    const chi = financeAgg.find((f) => f.category === 'chi')?._sum.amount || 0
    return NextResponse.json({
      records: records.map(serialize),
      stats: { myTasks, pendingLeaves, taskDone, taskTotal, financeIn: thu, financeOut: chi, balance: thu - chi, openIdeas, openIncidents },
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/ops', e)
    return NextResponse.json({ error: 'Không tải được dữ liệu quản trị' }, { status: 500 })
  }
}

// POST /api/vx/ops — tạo bản ghi quản trị (đăng sáng kiến được +10 xu)
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const type = String(body.type || '')
    const title = String(body.title || '').trim()
    if (!OPS_TYPES.includes(type as (typeof OPS_TYPES)[number])) return NextResponse.json({ error: 'Loại không hợp lệ' }, { status: 400 })
    if (!title) return NextResponse.json({ error: 'Nhập tiêu đề' }, { status: 400 })
    if (type === 'announce' && me.role !== 'admin') {
      return NextResponse.json({ error: 'Chỉ Ban Giám đốc được đăng bảng tin nội bộ' }, { status: 403 })
    }
    const record = await db.vxOpsRecord.create({
      data: {
        type,
        title: title.slice(0, 200),
        description: body.description ? String(body.description).slice(0, 2000) : null,
        status: body.status || (type === 'task' ? 'todo' : type === 'leave' ? 'pending' : 'open'),
        priority: ['low', 'normal', 'high', 'urgent'].includes(body.priority) ? body.priority : 'normal',
        assigneeId: body.assigneeId ? String(body.assigneeId) : null,
        dueDate: body.dueDate ? new Date(body.dueDate) : null,
        amount: Number(body.amount) > 0 ? Number(body.amount) : null,
        category: body.category ? String(body.category).slice(0, 60) : null,
        location: body.location ? String(body.location).slice(0, 200) : null,
        createdById: me.id,
      },
      include: { assignee: { select: SELECT_USER }, creator: { select: SELECT_USER } },
    })

    // Cày xu: đăng sáng kiến +10 xu (miễn phí — khuyến khích đóng góp ý tưởng)
    let reward = 0
    if (type === 'idea') {
      reward = 10
      await db.vxUser.update({ where: { id: me.id }, data: { coins: { increment: reward } } })
      await db.vxCoinTx.create({ data: { userId: me.id, amount: reward, reason: `Sáng kiến "${title.slice(0, 40)}" được ghi nhận` } })
      await db.vxNotification.create({ data: { userId: me.id, type: 'coins', content: `Bạn được +${fmtUsdFromXu(reward, (await getUsdVnd()).rate)} cho sáng kiến mới` } })
    }

    // Thông báo cho người được giao việc
    if (record.assigneeId && record.assigneeId !== me.id) {
      await db.vxNotification.create({
        data: { userId: record.assigneeId, type: 'ops', content: `${me.fullName} đã giao bạn công việc: ${title.slice(0, 60)}` },
      })
    }
    return NextResponse.json({ record: serialize(record), reward }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/ops', e)
    return NextResponse.json({ error: 'Không tạo được bản ghi' }, { status: 500 })
  }
}
