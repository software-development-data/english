export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { requireUser } from '@/lib/vx-auth'
import { db } from '@/lib/db'

// GET /api/vx/posts/trending — hashtag xu hướng từ bài viết gần đây (30 ngày)
// Trả top tag theo số bài dùng + tăng trưởng: { tag, count, recentCount }
export async function GET(req: NextRequest) {
  try {
    await requireUser()
    const since = new Date(Date.now() - 30 * 24 * 3600 * 1000)
    const posts = await db.vxPost.findMany({
      where: { archivedAt: null, createdAt: { gte: since }, content: { contains: '#' } },
      select: { content: true, createdAt: true },
      take: 500,
      orderBy: { createdAt: 'desc' },
    })

    const counts = new Map<string, { count: number; recent: number; last: number }>()
    const now = Date.now()
    for (const p of posts) {
      const tags = p.content.match(/#([\p{L}\p{N}_]{2,40})/gu) || []
      for (const raw of tags) {
        const tag = raw.slice(1).toLowerCase()
        if (/^\d+$/.test(tag)) continue // bỏ tag toàn số
        const rec = counts.get(tag) || { count: 0, recent: 0, last: 0 }
        rec.count++
        const age = now - new Date(p.createdAt).getTime()
        if (age < 7 * 24 * 3600 * 1000) rec.recent++
        rec.last = Math.max(rec.last, now - age)
        counts.set(tag, rec)
      }
    }

    const list = [...counts.entries()]
      .map(([tag, r]) => ({ tag, count: r.count, recentCount: r.recent }))
      .sort((a, b) => b.recentCount * 3 + b.count - (a.recentCount * 3 + a.count))
      .slice(0, 10)

    return NextResponse.json({ trending: list })
  } catch (e) {
    return NextResponse.json({ trending: [] }, { status: (e as Error).message.includes('Đăng nhập') ? 401 : 500 })
  }
}
