export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELECT_AUTHOR = { id: true, username: true, fullName: true, role: true, department: true, title: true, avatarColor: true, avatarImage: true, accountType: true, companyName: true }
const SELECT_CUSER = { id: true, username: true, fullName: true, role: true, avatarColor: true, accountType: true }

function parseJSON(s: string | null | undefined): unknown[] {
  if (!s) return []
  try {
    const v = JSON.parse(s)
    return Array.isArray(v) ? v : []
  } catch {
    return []
  }
}

// Cày xu: thưởng đăng bài +5 xu (tối đa 8 lần/ngày — chống spam)
async function rewardXu(userId: string, amount: number, reason: string, dailyCap: number) {
  const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0)
  const todayCount = await db.vxCoinTx.count({ where: { userId, reason: { startsWith: reason }, createdAt: { gte: startOfDay } } })
  if (todayCount >= dailyCap) return 0
  await db.vxUser.update({ where: { id: userId }, data: { coins: { increment: amount } } })
  await db.vxCoinTx.create({ data: { userId, amount, reason } })
  return amount
}

// GET /api/vx/posts?tab=all|hot|dept|announce|saved|archive — bảng tin theo bộ lọc + quyền riêng tư
// GET /api/vx/posts?author=<userId> — bài viết trên hồ sơ cá nhân (tab Bài viết)
// visibility: public → ai cũng thấy · friends → chỉ bạn bè của tác giả · private → chỉ tác giả
// tab=saved → bài tôi đã Lưu (Bookmark) · tab=archive → bài của TÔI đã chuyển vào Kho lưu trữ
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const tab = req.nextUrl.searchParams.get('tab') || 'all'
    const authorId = req.nextUrl.searchParams.get('author')

    // Danh sách bạn bè đã kết nối — dùng để lọc bài "Bạn bè"
    const fs = await db.vxFriendship.findMany({
      where: { status: 'accepted', OR: [{ requesterId: me.id }, { addresseeId: me.id }] },
      select: { requesterId: true, addresseeId: true },
    })
    const friendIds = new Set<string>()
    for (const f of fs) friendIds.add(f.requesterId === me.id ? f.addresseeId : f.requesterId)

    // Điều kiện where theo tab — mặc định ẩn bài đã lưu trữ và bài tôi chọn "Ẩn bài viết"
    const where: Record<string, unknown> = {}
    if (authorId) {
      where.authorId = authorId
      where.groupId = null
    }
    if (tab === 'saved') {
      where.flags = { some: { userId: me.id, saved: true } }
      where.archivedAt = null
    } else if (tab === 'archive') {
      where.authorId = me.id
      where.archivedAt = { not: null }
    } else {
      where.archivedAt = null
      where.flags = { none: { userId: me.id, hidden: true } }
    }

    const posts = await db.vxPost.findMany({
      where: where as never,
      include: {
        author: { select: SELECT_AUTHOR },
        page: { select: { id: true, name: true, avatar: true, category: true } },
        likes: { select: { userId: true, type: true } },
        flags: { where: { userId: me.id }, select: { saved: true, notified: true, hidden: true } },
        // Đăng lại kiểu TikTok: bài gốc đính kèm + bài đăng lại của TÔI (để bật/tắt nút Đăng lại)
        repostOf: {
          select: {
            id: true, content: true, background: true, images: true, videoUrl: true, createdAt: true,
            author: { select: SELECT_AUTHOR },
            page: { select: { id: true, name: true, avatar: true, category: true } },
          },
        },
        reposts: { where: { authorId: me.id }, select: { id: true } },
        comments: {
          where: { parentId: null },
          include: {
            user: { select: SELECT_CUSER },
            replies: { include: { user: { select: SELECT_CUSER } }, orderBy: { createdAt: 'asc' } },
          },
          orderBy: { createdAt: 'asc' },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 60,
    })

    let list = posts.filter((p) => {
      if (p.authorId === me.id) return true // bài của mình luôn thấy
      if (p.visibility === 'private') return false
      if (p.visibility === 'friends') return friendIds.has(p.authorId)
      return true // public
    })
    if (tab === 'announce') list = list.filter((p) => p.isAnnouncement)
    else if (tab === 'dept') list = list.filter((p) => p.author.department === me.department)
    else if (tab === 'hot') {
      list = [...list].sort((a, b) => {
        const score = (p: (typeof posts)[number]) =>
          p.likes.length + p.comments.reduce((n, c) => n + 1 + c.replies.length, 0)
        return score(b) - score(a)
      }).slice(0, 10)
    }

    return NextResponse.json(
      list.map((p) => {
        const reactions: Record<string, number> = {}
        let myReaction: string | null = null
        for (const l of p.likes) {
          reactions[l.type] = (reactions[l.type] || 0) + 1
          if (l.userId === me.id) myReaction = l.type
        }
        const commentCount = p.comments.reduce((n, c) => n + 1 + c.replies.length, 0)
        const f = p.flags[0]
        return {
          id: p.id,
          author: p.author,
          page: p.page,
          content: p.content,
          background: p.background,
          images: parseJSON(p.images as string | null),
          videoUrl: p.videoUrl,
          fileUrl: p.fileUrl,
          fileName: p.fileName,
          location: p.location,
          mentions: parseJSON(p.mentions as string | null),
          isAnnouncement: p.isAnnouncement,
          visibility: p.visibility || 'public',
          createdAt: p.createdAt,
          editedAt: p.editedAt,
          reactions,
          myReaction,
          commentCount,
          comments: p.comments,
          myFlag: { saved: f?.saved ?? false, notified: f?.notified ?? false, hidden: f?.hidden ?? false },
          repostOf: p.repostOf
            ? {
                id: p.repostOf.id,
                content: p.repostOf.content,
                background: p.repostOf.background,
                images: parseJSON(p.repostOf.images as string | null),
                videoUrl: p.repostOf.videoUrl,
                createdAt: p.repostOf.createdAt,
                author: p.repostOf.author,
                page: p.repostOf.page,
              }
            : null,
          myRepostId: p.reposts[0]?.id ?? null,
        }
      })
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/posts', e)
    return NextResponse.json({ error: 'Không tải được bảng tin' }, { status: 500 })
  }
}

// POST /api/vx/posts — đăng bài đa phương tiện
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const content = String(body.content || '').trim()
    const images = Array.isArray(body.images) ? body.images.slice(0, 6) : []
    // ĐĂNG LẠI (kiểu TikTok): chỉ cần repostOfId, không cần nội dung — bài gốc sẽ đính kèm
    const repostOfIdRaw = body.repostOfId ? String(body.repostOfId) : null
    let repostOfId: string | null = null
    if (repostOfIdRaw) {
      const original = await db.vxPost.findUnique({ where: { id: repostOfIdRaw } })
      if (!original) return NextResponse.json({ error: 'Bài viết gốc không tồn tại' }, { status: 404 })
      // Không cho đăng lại lồng nhau — luôn trỏ về bài gốc ban đầu
      repostOfId = original.repostOfId || original.id
    }
    if (!content && images.length === 0 && !body.videoUrl && !body.fileUrl && !body.background && !repostOfId) {
      return NextResponse.json({ error: 'Bài viết trống' }, { status: 400 })
    }
    // Chỉ Ban Giám đốc (admin) được đăng thông báo chính thức
    const isAnnouncement = Boolean(body.isAnnouncement) && me.role === 'admin'
    if (body.isAnnouncement && me.role !== 'admin') {
      return NextResponse.json({ error: 'Chỉ Ban Giám đốc được đăng thông báo chính thức' }, { status: 403 })
    }
    for (const img of images) {
      if (typeof img === 'string' && img.length > 2_000_000) {
        return NextResponse.json({ error: 'Ảnh quá lớn (tối đa ~1.5MB/ảnh)' }, { status: 400 })
      }
    }

    // Đăng bằng tư cách Fanpage (Trang) — chỉ chủ Trang
    let pageId: string | null = null
    if (body.pageId) {
      const page = await db.vxPage.findUnique({ where: { id: String(body.pageId) } })
      if (!page) return NextResponse.json({ error: 'Không tìm thấy Trang' }, { status: 404 })
      if (page.ownerId !== me.id && me.role !== 'admin') {
        return NextResponse.json({ error: 'Chỉ chủ Trang được đăng bài với tư cách Trang' }, { status: 403 })
      }
      pageId = page.id
    }

    const post = await db.vxPost.create({
      data: {
        authorId: me.id,
        pageId,
        content: content.slice(0, 5000),
        background: body.background || null,
        images: images.length ? JSON.stringify(images) : null,
        videoUrl: body.videoUrl || null,
        fileUrl: body.fileUrl || null,
        fileName: body.fileName || null,
        location: body.location ? String(body.location).slice(0, 200) : null,
        mentions: Array.isArray(body.mentions) && body.mentions.length ? JSON.stringify(body.mentions.slice(0, 10)) : null,
        isAnnouncement,
        visibility: ['public', 'friends', 'private'].includes(body.visibility) ? body.visibility : 'public',
        repostOfId,
      },
      include: {
        author: { select: SELECT_AUTHOR },
        page: { select: { id: true, name: true, avatar: true, category: true } },
        likes: { select: { userId: true, type: true } },
        repostOf: {
          select: {
            id: true, content: true, background: true, images: true, videoUrl: true, createdAt: true,
            author: { select: SELECT_AUTHOR },
            page: { select: { id: true, name: true, avatar: true, category: true } },
          },
        },
        comments: {
          where: { parentId: null },
          include: { user: { select: SELECT_CUSER }, replies: { include: { user: { select: SELECT_CUSER } } } },
        },
      },
    })

    // Cày xu: đăng bài được +5 xu (tối đa 8 bài/ngày) — đăng lại thuần không thưởng để tránh farm xu
    const pureRepost = Boolean(repostOfId) && !content && images.length === 0 && !body.videoUrl && !body.fileUrl && !body.background
    const reward = pureRepost ? null : await rewardXu(me.id, 5, 'Thưởng đăng bài', 8)

    return NextResponse.json(
      {
        id: post.id,
        reward,
        author: post.author,
        page: post.page,
        content: post.content,
        background: post.background,
        images: parseJSON(post.images as string | null),
        videoUrl: post.videoUrl,
        fileUrl: post.fileUrl,
        fileName: post.fileName,
        location: post.location,
        mentions: parseJSON(post.mentions as string | null),
        isAnnouncement: post.isAnnouncement,
        visibility: post.visibility || 'public',
        createdAt: post.createdAt,
        reactions: {},
        myReaction: null,
        commentCount: 0,
        comments: [],
        repostOf: post.repostOf
          ? {
              id: post.repostOf.id,
              content: post.repostOf.content,
              background: post.repostOf.background,
              images: parseJSON(post.repostOf.images as string | null),
              videoUrl: post.repostOf.videoUrl,
              createdAt: post.repostOf.createdAt,
              author: post.repostOf.author,
              page: post.repostOf.page,
            }
          : null,
        myRepostId: post.id,
      },
      { status: 201 }
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/posts', e)
    return NextResponse.json({ error: 'Không đăng được bài' }, { status: 500 })
  }
}
