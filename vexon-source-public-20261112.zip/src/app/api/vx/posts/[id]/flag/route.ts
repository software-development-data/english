export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/posts/[id]/flag — Lưu bài viết / Bật-tắt thông báo / Ẩn bài viết (kiểu Facebook)
// body: { saved?: boolean, notified?: boolean, hidden?: boolean } — chỉ truyền trường muốn đổi
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const post = await db.vxPost.findUnique({ where: { id } })
    if (!post) return NextResponse.json({ error: 'Bài viết không tồn tại' }, { status: 404 })

    const body = await req.json()
    const data: { saved?: boolean; notified?: boolean; hidden?: boolean } = {}
    if (typeof body.saved === 'boolean') data.saved = body.saved
    if (typeof body.notified === 'boolean') data.notified = body.notified
    if (typeof body.hidden === 'boolean') data.hidden = body.hidden
    if (Object.keys(data).length === 0) return NextResponse.json({ error: 'Không có gì để cập nhật' }, { status: 400 })

    const flag = await db.vxPostFlag.upsert({
      where: { postId_userId: { postId: id, userId: me.id } },
      update: data,
      create: { postId: id, userId: me.id, ...data },
    })
    return NextResponse.json({ ok: true, saved: flag.saved, notified: flag.notified, hidden: flag.hidden })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/posts/[id]/flag', e)
    return NextResponse.json({ error: 'Không cập nhật được cờ bài viết' }, { status: 500 })
  }
}
