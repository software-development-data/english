export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/posts/[id]/save — LƯU BÀI VIẾT (bookmark kiểu Facebook, toggle)
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const post = await db.vxPost.findUnique({ where: { id }, select: { id: true } })
    if (!post) return NextResponse.json({ error: 'Bài viết không tồn tại' }, { status: 404 })

    const existing = await db.vxSavedPost.findUnique({
      where: { postId_userId: { postId: id, userId: me.id } },
    })
    if (existing) {
      await db.vxSavedPost.delete({ where: { id: existing.id } })
      return NextResponse.json({ ok: true, saved: false })
    }
    await db.vxSavedPost.create({ data: { postId: id, userId: me.id } })
    return NextResponse.json({ ok: true, saved: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/posts/[id]/save', e)
    return NextResponse.json({ error: 'Không lưu được bài viết' }, { status: 500 })
  }
}
