export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const REACTION_TYPES = ['LIKE', 'LOVE', 'CARE', 'HAHA', 'WOW', 'SAD', 'ANGRY']

// POST /api/vx/posts/[id]/like  body: { type: 'LIKE'|'LOVE'|... } — toggle reaction
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const body = await req.json().catch(() => ({}))
    const type = REACTION_TYPES.includes(body.type) ? body.type : 'LIKE'

    const post = await db.vxPost.findUnique({ where: { id } })
    if (!post) return NextResponse.json({ error: 'Bài viết không tồn tại' }, { status: 404 })

    const existing = await db.vxPostLike.findUnique({
      where: { postId_userId: { postId: id, userId: me.id } },
    })

    let myReaction: string | null = type
    if (existing && existing.type === type) {
      // Bấm lại cùng loại -> bỏ reaction
      await db.vxPostLike.delete({ where: { id: existing.id } })
      myReaction = null
    } else if (existing) {
      // Đổi sang loại khác
      await db.vxPostLike.update({ where: { id: existing.id }, data: { type } })
    } else {
      await db.vxPostLike.create({ data: { postId: id, userId: me.id, type } })
    }

    // Đếm lại toàn bộ
    const likes = await db.vxPostLike.findMany({ where: { postId: id }, select: { type: true } })
    const reactions: Record<string, number> = {}
    for (const l of likes) reactions[l.type] = (reactions[l.type] || 0) + 1

    return NextResponse.json({ myReaction, reactions })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/posts/[id]/like', e)
    return NextResponse.json({ error: 'Không thả được cảm xúc' }, { status: 500 })
  }
}
