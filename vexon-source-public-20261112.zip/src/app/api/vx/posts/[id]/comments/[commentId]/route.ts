export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// PATCH /api/vx/posts/[id]/comments/[commentId] — sửa bình luận (chỉ tác giả bình luận)
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string; commentId: string }> }) {
  try {
    const me = await requireUser()
    const { commentId } = await params
    const comment = await db.vxComment.findUnique({ where: { id: commentId } })
    if (!comment || comment.postId !== (await params).id) {
      return NextResponse.json({ error: 'Không tìm thấy bình luận' }, { status: 404 })
    }
    if (comment.userId !== me.id) {
      return NextResponse.json({ error: 'Chỉ sửa được bình luận của bạn' }, { status: 403 })
    }

    const body = await req.json()
    const content = String(body.content || '').trim()
    if (!content) return NextResponse.json({ error: 'Nội dung bình luận trống' }, { status: 400 })

    const updated = await db.vxComment.update({
      where: { id: commentId },
      data: { content: content.slice(0, 1000), editedAt: new Date() },
    })
    return NextResponse.json({ id: updated.id, content: updated.content, editedAt: updated.editedAt })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/posts/[id]/comments/[commentId]', e)
    return NextResponse.json({ error: 'Không sửa được bình luận' }, { status: 500 })
  }
}

// DELETE /api/vx/posts/[id]/comments/[commentId] — xoá bình luận
// Quyền: tác giả bình luận · chủ bài viết · Ban Giám đốc (kiểu Facebook)
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string; commentId: string }> }) {
  try {
    const me = await requireUser()
    const { id, commentId } = await params
    const comment = await db.vxComment.findUnique({ where: { id: commentId }, select: { id: true, userId: true, postId: true } })
    if (!comment || comment.postId !== id) {
      return NextResponse.json({ error: 'Không tìm thấy bình luận' }, { status: 404 })
    }
    const post = await db.vxPost.findUnique({ where: { id }, select: { authorId: true } })
    const allowed = comment.userId === me.id || post?.authorId === me.id || me.role === 'admin'
    if (!allowed) {
      return NextResponse.json({ error: 'Không có quyền xoá bình luận này' }, { status: 403 })
    }

    await db.vxComment.delete({ where: { id: commentId } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/posts/[id]/comments/[commentId]', e)
    return NextResponse.json({ error: 'Không xoá được bình luận' }, { status: 500 })
  }
}
