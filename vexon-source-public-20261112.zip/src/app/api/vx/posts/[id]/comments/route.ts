export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELECT_CUSER = { id: true, username: true, fullName: true, role: true, avatarColor: true }

// Cày xu: bình luận +2 xu (tối đa 20 lần/ngày)
async function rewardXu(userId: string, amount: number, reason: string, dailyCap: number) {
  const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0)
  const todayCount = await db.vxCoinTx.count({ where: { userId, reason: { startsWith: reason }, createdAt: { gte: startOfDay } } })
  if (todayCount >= dailyCap) return 0
  await db.vxUser.update({ where: { id: userId }, data: { coins: { increment: amount } } })
  await db.vxCoinTx.create({ data: { userId, amount, reason } })
  return amount
}

// POST /api/vx/posts/[id]/comments — bình luận (lồng nhau, ảnh/GIF/sticker/audio)
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const body = await req.json()
    const content = String(body.content || '').trim()
    if (!content && !body.imageUrl && !body.sticker && !body.audioDur) {
      return NextResponse.json({ error: 'Bình luận trống' }, { status: 400 })
    }
    if (body.imageUrl && String(body.imageUrl).length > 2_000_000) {
      return NextResponse.json({ error: 'Ảnh quá lớn (tối đa ~1.5MB)' }, { status: 400 })
    }
    let parentId: string | null = null
    if (body.parentId) {
      const parent = await db.vxComment.findUnique({ where: { id: String(body.parentId) } })
      if (!parent || parent.postId !== id) {
        return NextResponse.json({ error: 'Bình luận cha không hợp lệ' }, { status: 400 })
      }
      parentId = parent.id
    }

    const comment = await db.vxComment.create({
      data: {
        postId: id,
        parentId,
        userId: me.id,
        content: content.slice(0, 1000),
        imageUrl: body.imageUrl || null,
        sticker: body.sticker || null,
        audioDur: Number(body.audioDur) > 0 ? Math.min(120, Math.round(Number(body.audioDur))) : null,
      },
      include: { user: { select: SELECT_CUSER }, replies: { include: { user: { select: SELECT_CUSER } } } },
    })

    // Thông báo cho chủ bài viết
    const post = await db.vxPost.findUnique({ where: { id }, select: { authorId: true } })
    if (post && post.authorId !== me.id) {
      await db.vxNotification.create({
        data: {
          userId: post.authorId,
          type: 'comment',
          content: `${me.fullName} đã bình luận bài viết của bạn`,
        },
      })
    }

    // Cày xu: bình luận +2 xu
    const reward = await rewardXu(me.id, 2, 'Thưởng bình luận', 20)

    return NextResponse.json({ ...comment, reward }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/posts/[id]/comments', e)
    return NextResponse.json({ error: 'Không gửi được bình luận' }, { status: 500 })
  }
}
