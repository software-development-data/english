export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// PATCH: sửa bài viết của chính mình (nút "Sửa bài" kiểu TTO — thích/bình luận/chia sẻ/sửa/xoá)
// Hoặc chuyển vào kho lưu trữ / đưa ra khỏi kho lưu trữ: body { archive: true|false } — không tính là "Đã sửa"
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const post = await db.vxPost.findUnique({ where: { id } })
    if (!post) return NextResponse.json({ error: 'Bài viết không tồn tại' }, { status: 404 })
    if (post.authorId !== me.id) return NextResponse.json({ error: 'Chỉ được sửa bài của chính mình' }, { status: 403 })

    const body = await req.json()

    // Lưu trữ / bỏ lưu trữ — riêng khỏi sửa nội dung
    if (typeof body.archive === 'boolean') {
      const updated = await db.vxPost.update({ where: { id }, data: { archivedAt: body.archive ? new Date() : null } })
      return NextResponse.json({ ok: true, archivedAt: updated.archivedAt })
    }

    const data: Record<string, unknown> = {}
    if (typeof body.content === 'string') {
      const content = body.content.trim()
      const hasMedia = Array.isArray(body.images) ? body.images.length > 0 : (post.images ? JSON.parse(post.images as unknown as string).length > 0 : false)
      if (!content && !hasMedia && !post.videoUrl && !post.fileUrl) {
        return NextResponse.json({ error: 'Bài viết cần có nội dung hoặc ảnh' }, { status: 400 })
      }
      data.content = content.slice(0, 3000)
    }
    if (body.location !== undefined) data.location = body.location ? String(body.location).slice(0, 120) : null
    if (typeof data.content === 'undefined' && data.location === undefined) {
      return NextResponse.json({ error: 'Không có gì để cập nhật' }, { status: 400 })
    }
    data.editedAt = new Date()

    const updated = await db.vxPost.update({ where: { id }, data })
    return NextResponse.json({ ok: true, content: updated.content, location: updated.location, editedAt: updated.editedAt })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/posts/[id]', e)
    return NextResponse.json({ error: 'Không sửa được bài viết' }, { status: 500 })
  }
}

// DELETE: xoá bài của chính mình
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const post = await db.vxPost.findUnique({ where: { id } })
    if (!post) return NextResponse.json({ error: 'Bài viết không tồn tại' }, { status: 404 })
    if (post.authorId !== me.id) return NextResponse.json({ error: 'Chỉ được xoá bài của chính mình' }, { status: 403 })
    await db.vxPost.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/posts/[id]', e)
    return NextResponse.json({ error: 'Không xoá được bài' }, { status: 500 })
  }
}
