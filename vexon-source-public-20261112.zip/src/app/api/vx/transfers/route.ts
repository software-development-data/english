export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { getUsdVnd } from '@/lib/vx-fx'
import { fmtUsdFromXu, usdToXu } from '@/lib/format'

export const MIN_TRANSFER_XU = 100 // ~$0,39 — chặn chuyển lẻ tẻ
export const MAX_TRANSFER_XU = 5_000_000 // trần an toàn mỗi lần chuyển

const USER_PICK = { fullName: true, username: true, avatarColor: true, avatarImage: true }

// GET /api/vx/transfers — lịch sử chuyển/nhận tiền của tôi (50 giao dịch gần nhất)
export async function GET() {
  try {
    const me = await requireUser()
    const rows = await db.vxTransfer.findMany({
      where: { OR: [{ fromUserId: me.id }, { toUserId: me.id }] },
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: { fromUser: { select: USER_PICK }, toUser: { select: USER_PICK } },
    })
    const txs = rows.map((t) => {
      const sent = t.fromUserId === me.id
      return {
        id: t.id,
        direction: sent ? 'sent' : 'received',
        amountXu: t.amountXu,
        message: t.message,
        createdAt: t.createdAt,
        counterparty: sent ? t.toUser : t.fromUser,
      }
    })
    return NextResponse.json({ txs })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/transfers', e)
    return NextResponse.json({ error: 'Không tải được lịch sử chuyển tiền' }, { status: 500 })
  }
}

// POST /api/vx/transfers — CHUYỂN TIỀN cho người dùng khác (tự do, 0 phí, đến ngay)
// body: { toUsername: 'hongnhung' | '@hongnhung', amountUsd?: number, amountXu?: number, message?: string }
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json().catch(() => ({}))
    const username = String(body.toUsername || '').trim().replace(/^@/, '').toLowerCase()
    if (!username) return NextResponse.json({ error: 'Nhập username người nhận (bắt đầu bằng @)' }, { status: 400 })

    // Số tiền: ưu tiên USD nhập tay → đổi ra xu theo tỷ giá hiện tại; hoặc gửi sẵn amountXu
    const rate = (await getUsdVnd()).rate
    let amountXu = Number(body.amountXu)
    if (body.amountUsd != null) {
      const usd = Number(body.amountUsd)
      if (!Number.isFinite(usd) || usd <= 0) return NextResponse.json({ error: 'Số tiền USD không hợp lệ' }, { status: 400 })
      amountXu = usdToXu(usd, rate)
    }
    amountXu = Math.round(amountXu)
    if (!Number.isFinite(amountXu) || amountXu <= 0) return NextResponse.json({ error: 'Số tiền không hợp lệ' }, { status: 400 })
    if (amountXu < MIN_TRANSFER_XU) return NextResponse.json({ error: `Tối thiểu ${fmtUsdFromXu(MIN_TRANSFER_XU, rate)} mỗi lần chuyển` }, { status: 400 })
    if (amountXu > MAX_TRANSFER_XU) return NextResponse.json({ error: `Tối đa ${fmtUsdFromXu(MAX_TRANSFER_XU, rate)} mỗi lần chuyển` }, { status: 400 })

    const recipient = await db.vxUser.findUnique({ where: { username } })
    if (!recipient) return NextResponse.json({ error: `Không tìm thấy người dùng "@${username}"` }, { status: 404 })
    if (recipient.id === me.id) return NextResponse.json({ error: 'Không thể chuyển tiền cho chính mình' }, { status: 400 })

    const message = body.message ? String(body.message).trim().slice(0, 140) : null

    // Giao dịch nguyên tố: trừ người gửi → cộng người nhận → lưu lượt chuyển → sổ giao dịch 2 phía → thông báo
    const result = await db.$transaction(async (tx) => {
      const sender = await tx.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } })
      if (!sender || sender.coins < amountXu) {
        throw new Error(`Không đủ tiền: bạn chỉ có ${fmtUsdFromXu(sender?.coins ?? 0, rate)}`)
      }
      await tx.vxUser.update({ where: { id: me.id }, data: { coins: { decrement: amountXu } } })
      await tx.vxUser.update({ where: { id: recipient.id }, data: { coins: { increment: amountXu } } })
      const transfer = await tx.vxTransfer.create({ data: { fromUserId: me.id, toUserId: recipient.id, amountXu, message } })
      await tx.vxCoinTx.createMany({
        data: [
          { userId: me.id, amount: -amountXu, reason: `Chuyển tiền cho @${recipient.username}${message ? ` — ${message.slice(0, 60)}` : ''}` },
          { userId: recipient.id, amount: amountXu, reason: `Nhận tiền từ @${me.username}${message ? ` — ${message.slice(0, 60)}` : ''}` },
        ],
      })
      await tx.vxNotification.create({
        data: { userId: recipient.id, type: 'transfer', content: `@${me.username} vừa chuyển ${fmtUsdFromXu(amountXu, rate)} cho bạn — xem ở Ví tiền` },
      })
      return transfer
    })

    const senderAfter = await db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } })
    return NextResponse.json({
      ok: true,
      transfer: { id: result.id, amountXu, usd: fmtUsdFromXu(amountXu, rate) },
      coins: senderAfter?.coins ?? 0,
      message: `Đã chuyển ${fmtUsdFromXu(amountXu, rate)} cho ${recipient.fullName} (@${recipient.username}) — 0 phí, đến ngay`,
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    if (e instanceof Error && e.message.startsWith('Không đủ tiền')) return NextResponse.json({ error: e.message }, { status: 400 })
    console.error('POST /api/vx/transfers', e)
    return NextResponse.json({ error: 'Không chuyển được tiền, thử lại nhé' }, { status: 500 })
  }
}
