export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

/** Tên chủ thẻ IN HOA không dấu như in trên thẻ thật: "Trần Thị Hồng Nhung" → "TRAN THI HONG NHUNG" */
function holderFromName(fullName: string): string {
  return fullName
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toUpperCase()
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 26)
}

// GET /api/vx/social-card — thẻ Vexon Pay của tôi (chỉ chủ thẻ xem được đủ số)
export async function GET() {
  try {
    const me = await requireUser()
    const card = await db.vxSocialCard.findUnique({ where: { userId: me.id } })
    return NextResponse.json({ card })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/social-card', e)
    return NextResponse.json({ error: 'Không tải được thẻ' }, { status: 500 })
  }
}

// POST /api/vx/social-card — MỞ THẺ Vexon Pay (mỗi user 1 thẻ, miễn phí)
export async function POST() {
  try {
    const me = await requireUser()
    const existing = await db.vxSocialCard.findUnique({ where: { userId: me.id } })
    if (existing) return NextResponse.json({ error: 'Bạn đã mở thẻ Vexon Pay rồi, mỗi người chỉ có 1 thẻ' }, { status: 400 })

    // Số thẻ 16 số đầu BIN 9704 (Vexon) — sinh ngẫu nhiên, đảm bảo không trùng
    let cardNumber = ''
    for (let i = 0; i < 5; i++) {
      cardNumber = '9704' + Array.from({ length: 12 }, () => Math.floor(Math.random() * 10)).join('')
      const dup = await db.vxSocialCard.findUnique({ where: { cardNumber } })
      if (!dup) break
      cardNumber = ''
    }
    if (!cardNumber) return NextResponse.json({ error: 'Không sinh được số thẻ, thử lại nhé' }, { status: 500 })

    const now = new Date()
    const card = await db.vxSocialCard.create({
      data: {
        userId: me.id,
        cardNumber,
        holder: holderFromName(me.fullName || me.username),
        expMonth: now.getMonth() + 1,
        expYear: now.getFullYear() + 4,
        cvv: String(Math.floor(100 + Math.random() * 900)),
      },
    })
    return NextResponse.json({ card }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/social-card', e)
    return NextResponse.json({ error: 'Không mở được thẻ' }, { status: 500 })
  }
}

// PATCH /api/vx/social-card — Đóng băng / Mở băng thẻ { action: 'freeze' | 'unfreeze' }
export async function PATCH(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json().catch(() => ({}))
    const action = body.action === 'freeze' ? 'frozen' : body.action === 'unfreeze' ? 'active' : null
    if (!action) return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })

    const card = await db.vxSocialCard.findUnique({ where: { userId: me.id } })
    if (!card) return NextResponse.json({ error: 'Bạn chưa mở thẻ Vexon Pay' }, { status: 404 })

    const updated = await db.vxSocialCard.update({ where: { userId: me.id }, data: { status: action } })
    return NextResponse.json({ card: updated })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/social-card', e)
    return NextResponse.json({ error: 'Không cập nhật được thẻ' }, { status: 500 })
  }
}
