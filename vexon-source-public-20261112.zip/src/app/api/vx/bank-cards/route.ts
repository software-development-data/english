export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELECT_CARD = {
  id: true, bankName: true, bankSwift: true, accountNumber: true, accountHolder: true, branch: true, isPrimary: true, status: true, note: true, createdAt: true,
}

// GET /api/vx/bank-cards → danh sách thẻ ngân hàng của tôi
export async function GET() {
  try {
    const me = await requireUser()
    const cards = await db.vxBankCard.findMany({ where: { userId: me.id }, orderBy: [{ isPrimary: 'desc' }, { createdAt: 'desc' }] })
    return NextResponse.json({ cards: cards.map((c) => ({ ...c, accountNumber: maskNum(c.accountNumber) })) })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/bank-cards', e)
    return NextResponse.json({ error: 'Không tải được thẻ' }, { status: 500 })
  }
}

// Ẩn số tài khoản khi hiển thị: chỉ hiện 4 số cuối, định dạng 1234
function maskNum(num: string): string {
  if (!num) return ''
  if (num.length <= 4) return num
  return '•'.repeat(Math.max(0, num.length - 4)) + num.slice(-4)
}

// POST /api/vx/bank-cards → thêm thẻ ngân hàng mới (mặc định thẻ đầu là primary)
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const bankName = String(body.bankName || '').trim().slice(0, 60)
    const bankSwift = body.bankSwift ? String(body.bankSwift).trim().slice(0, 12) : null
    const accountNumber = String(body.accountNumber || '').replace(/[^0-9]/g, '').slice(0, 24)
    const accountHolder = String(body.accountHolder || '').trim().slice(0, 80)
    const branch = body.branch ? String(body.branch).trim().slice(0, 80) : null
    const note = body.note ? String(body.note).trim().slice(0, 120) : null
    if (!bankName || !accountNumber || !accountHolder) {
      return NextResponse.json({ error: 'Nhập tên ngân hàng, số tài khoản và tên chủ tài khoản' }, { status: 400 })
    }
    if (accountNumber.length < 6) {
      return NextResponse.json({ error: 'Số tài khoản không hợp lệ' }, { status: 400 })
    }
    const count = await db.vxBankCard.count({ where: { userId: me.id } })
    if (count >= 10) {
      return NextResponse.json({ error: 'Bạn đã có tối đa 10 thẻ, vui lòng xoá bớt' }, { status: 400 })
    }
    const isFirst = count === 0
    const card = await db.vxBankCard.create({
      data: { userId: me.id, bankName, bankSwift, accountNumber, accountHolder, branch, note, isPrimary: isFirst, status: 'active' },
      select: SELECT_CARD,
    })
    return NextResponse.json({ card: { ...card, accountNumber: maskNum(card.accountNumber) } }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/bank-cards', e)
    return NextResponse.json({ error: 'Không lưu được thẻ' }, { status: 500 })
  }
}

// PATCH /api/vx/bank-cards → đặt thẻ mặc định hoặc cập nhật trạng thái
export async function PATCH(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const id = String(body.id || '')
    if (!id) return NextResponse.json({ error: 'Thiếu id thẻ' }, { status: 400 })
    const existing = await db.vxBankCard.findUnique({ where: { id } })
    if (!existing || existing.userId !== me.id) {
      return NextResponse.json({ error: 'Không tìm thấy thẻ' }, { status: 404 })
    }
    if (body.action === 'setPrimary') {
      await db.$transaction([
        db.vxBankCard.updateMany({ where: { userId: me.id }, data: { isPrimary: false } }),
        db.vxBankCard.update({ where: { id }, data: { isPrimary: true } }),
      ])
      return NextResponse.json({ ok: true })
    }
    if (body.action === 'disable' || body.action === 'enable') {
      await db.vxBankCard.update({ where: { id }, data: { status: body.action === 'disable' ? 'disabled' : 'active' } })
      return NextResponse.json({ ok: true })
    }
    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/bank-cards', e)
    return NextResponse.json({ error: 'Không cập nhật được thẻ' }, { status: 500 })
  }
}

// DELETE /api/vx/bank-cards → xoá thẻ (chỉ nếu không phải đang dùng cho giao dịch pending)
export async function DELETE(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const id = String(body.id || '')
    if (!id) return NextResponse.json({ error: 'Thiếu id thẻ' }, { status: 400 })
    const existing = await db.vxBankCard.findUnique({ where: { id } })
    if (!existing || existing.userId !== me.id) {
      return NextResponse.json({ error: 'Không tìm thấy thẻ' }, { status: 404 })
    }
    // Kiểm tra có giao dịch pending không
    const pendingTxs = await db.vxWalletTx.count({ where: { bankCardId: id, status: 'pending' } })
    if (pendingTxs > 0) {
      return NextResponse.json({ error: `Đang có ${pendingTxs} giao dịch chờ duyệt dùng thẻ này, vui lòng đợi admin xử lý` }, { status: 400 })
    }
    await db.vxBankCard.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/bank-cards', e)
    return NextResponse.json({ error: 'Không xoá được thẻ' }, { status: 500 })
  }
}
