export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

/**
 * GET /api/vx/discover — TRANG CHỦ: tìm kiếm người dùng toàn quốc (kiểu NearLink/Heesay)
 * Gộp logic từ code NearLink (index.php + ajax/connect-users.php) và Radar người gần:
 *  • tab=all   "Gần đây": NGƯỜI HOẠT ĐỘNG (≤75s) lên đầu → offline trong 30 phút xếp sau → còn lại cuối (r31)
 *  • tab=online: người hoạt động trong 30 phút — đang hoạt động lên trước, người vừa offline xếp sau
 *  • tab=new   "Mới tham gia": tài khoản tạo trong 7 ngày
 *  • q: tìm theo tên/username (không dấu vẫn khớp)
 *  • ageMin/ageMax: lọc độ tuổi theo ngày sinh
 *  • distMin/distMax (km): lọc khoảng cách — max 2500km ≈ cả nước, không truyền = không giới hạn
 *  • onlineOnly=1: chỉ người đang online
 *  • friendsOnly=1: chỉ bạn bè
 * Online = lastSeen trong 30 phút (age_seconds ≤ 1800) — đúng chuẩn file zip gửi kèm.
 */

const ACTIVE_WINDOW_MS = 75_000 // Đang hoạt động THẬT: có tương tác trong ~75 giây (đồng bộ /api/vx/users/search)
const ONLINE_WINDOW_MS = 30 * 60 * 1000 // 30 phút — mốc tối đa tính là "offline trong 30 phút"
const NEW_WINDOW_MS = 7 * 24 * 3600 * 1000 // 7 ngày

function haversine(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLng = ((lng2 - lng1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(a))
}

/** "Offline 45 phút" · "Online" — kiểu NearLink nl_short_time */
function offlineText(ms: number): string {
  const min = Math.floor(ms / 60000)
  if (min < 60) return `Offline ${min || 1} phút`
  const h = Math.floor(min / 60)
  if (h < 24) return `Offline ${h} giờ`
  const d = Math.floor(h / 24)
  return `Offline ${d} ngày`
}

function ageFromBirth(birthday?: string | Date | null): number {
  if (!birthday) return 0
  const b = new Date(birthday)
  if (isNaN(b.getTime())) return 0
  const now = new Date()
  let age = now.getFullYear() - b.getFullYear()
  const m = now.getMonth() - b.getMonth()
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) age--
  return age > 0 && age < 120 ? age : 0
}

export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const sp = req.nextUrl.searchParams
    const tab = ['all', 'online', 'new'].includes(sp.get('tab') || '') ? (sp.get('tab') as string) : 'all'
    const q = (sp.get('q') || '').trim().toLowerCase()
    const ageMin = Number(sp.get('ageMin') || 0)
    const ageMax = Number(sp.get('ageMax') || 99)
    const distMin = sp.get('distMin') != null ? Number(sp.get('distMin')) : null
    const distMax = sp.get('distMax') != null ? Number(sp.get('distMax')) : null
    const onlineOnly = sp.get('onlineOnly') === '1'
    const friendsOnly = sp.get('friendsOnly') === '1'

    // Heartbeat: mỗi lần mở Trang chủ là cập nhật mình đang hoạt động
    const now = new Date()
    await db.vxUser.update({ where: { id: me.id }, data: { lastSeen: now, online: true } })

    const meFull = await db.vxUser.findUnique({ where: { id: me.id } })

    // Quan hệ bạn bè + lời mời
    const [friendships, pendings] = await Promise.all([
      db.vxFriendship.findMany({ where: { status: 'accepted', OR: [{ requesterId: me.id }, { addresseeId: me.id }] } }),
      db.vxFriendship.findMany({ where: { status: 'pending', OR: [{ requesterId: me.id }, { addresseeId: me.id }] } }),
    ])
    const friendIds = new Set(friendships.map((f) => (f.requesterId === me.id ? f.addresseeId : f.requesterId)))
    const pendingFromMe = new Set(pendings.filter((f) => f.requesterId === me.id).map((f) => f.addresseeId))

    const users = await db.vxUser.findMany({
      where: { id: { not: me.id }, locationVisible: true },
      select: {
        id: true, username: true, fullName: true, role: true, department: true, title: true,
        avatarColor: true, avatarImage: true, bio: true, online: true, lastSeen: true,
        birthday: true, hometown: true, latitude: true, longitude: true, locationName: true,
        locationUpdatedAt: true, accountType: true, companyName: true, createdAt: true,
      },
    })

    const myLat = meFull?.latitude ?? null
    const myLng = meFull?.longitude ?? null
    const hasPos = myLat != null && myLng != null

    let people = users.map((u) => {
      const lastMs = Math.max(0, now.getTime() - new Date(u.lastSeen).getTime())
      const active = lastMs <= ACTIVE_WINDOW_MS // đang hoạt động thật (r31)
      const online = lastMs <= ONLINE_WINDOW_MS // trong vòng 30 phút (đang hoạt động + vừa offline)
      const age = ageFromBirth(u.birthday)
      let distanceKm: number | null = null
      if (hasPos && u.latitude != null && u.longitude != null) {
        distanceKm = Math.round(haversine(myLat as number, myLng as number, u.latitude, u.longitude) * 10) / 10
      }
      const isNew = now.getTime() - new Date(u.createdAt).getTime() <= NEW_WINDOW_MS
      return {
        id: u.id,
        fullName: u.fullName,
        username: u.username,
        avatarColor: u.avatarColor,
        avatarImage: u.avatarImage,
        bio: u.bio,
        hometown: u.hometown,
        locationName: u.locationName,
        department: u.department,
        title: u.title,
        accountType: u.accountType,
        companyName: u.companyName,
        age,
        active,
        online,
        lastSeenMs: lastMs,
        lastSeenMinutes: Math.floor(lastMs / 60000),
        // r31: chỉ người ĐANG HOẠT ĐỘNG (≤75s) mới mang nhãn "Online" — người im 2–30 phút hiện "Offline X phút"
        statusText: active ? 'Online' : offlineText(lastMs),
        distanceKm,
        distanceText:
          distanceKm == null
            ? hasPos
              ? 'Chưa có vị trí'
              : 'Toàn quốc'
            : distanceKm < 1
              ? `${Math.round(distanceKm * 1000)} m`
              : `${distanceKm.toLocaleString('vi-VN')} km`,
        isFriend: friendIds.has(u.id),
        pending: pendingFromMe.has(u.id),
        isNew,
        createdAt: u.createdAt,
      }
    })

    // Bộ lọc phía server (client vẫn lọc mượt thêm lần nữa)
    const norm = (s: string) =>
      s
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
    if (q) people = people.filter((u) => norm(u.fullName).includes(norm(q)) || norm(u.username).includes(norm(q)))
    if (onlineOnly) people = people.filter((u) => u.online)
    if (friendsOnly) people = people.filter((u) => u.isFriend)
    if (ageMin > 0 || ageMax < 99) people = people.filter((u) => u.age > 0 && u.age >= ageMin && u.age <= ageMax)
    if (distMin != null || distMax != null) {
      people = people.filter((u) => {
        if (u.distanceKm == null) return distMin == null || distMin <= 0 // không có vị trí: chỉ hiện khi không lọc cận dưới
        return u.distanceKm >= (distMin ?? 0) && u.distanceKm <= (distMax ?? Infinity)
      })
    }
    if (tab === 'online') people = people.filter((u) => u.online)
    if (tab === 'new') people = people.filter((u) => u.isNew)

    // Sắp xếp r31 — ƯU TIÊN NGƯỜI HOẠT ĐỘNG: bậc 0 đang hoạt động thật (≤75s) → bậc 1 offline trong 30 phút
    // → bậc 2 còn lại. Trong bậc 0/1 ai hoạt động GẦN NHẤT lên đầu; bậc 2 giữ cũ: gần → mới tham gia.
    const tier = (u: { active: boolean; online: boolean }) => (u.active ? 0 : u.online ? 1 : 2)
    people.sort((a, b) => {
      const ta = tier(a)
      const tb = tier(b)
      if (ta !== tb) return ta - tb
      if (tab === 'new' && a.isNew !== b.isNew) return a.isNew ? -1 : 1
      if (ta < 2 && a.lastSeenMs !== b.lastSeenMs) return a.lastSeenMs - b.lastSeenMs
      if (a.distanceKm != null && b.distanceKm != null && a.distanceKm !== b.distanceKm) return a.distanceKm - b.distanceKm
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    })

    return NextResponse.json({
      ok: true,
      hasPosition: hasPos,
      me: { hasLocation: !!meFull?.latitude, locationVisible: meFull?.locationVisible ?? true },
      count: people.length,
      people: people.slice(0, 200),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/discover', e)
    return NextResponse.json({ error: 'Không tải được danh sách người dùng' }, { status: 500 })
  }
}
