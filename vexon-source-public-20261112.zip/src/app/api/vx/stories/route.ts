export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// GET /api/vx/stories — danh sách story còn hạn (tự xoá story quá 24h)
export async function GET() {
  try {
    const me = await requireUser()
    // Dọn dẹp story hết hạn
    await db.vxStory.deleteMany({ where: { expiresAt: { lt: new Date() } } })

    const stories = await db.vxStory.findMany({
      include: {
        author: { select: { id: true, username: true, fullName: true, avatarColor: true } },
      },
      orderBy: { createdAt: 'asc' },
    })

    type StoryOut = Omit<typeof stories[number], 'hearts'> & { likeCount: number; likedByMe: boolean }
    // Gộp theo tác giả, story mới nhất lên đầu (kèm số tim + tôi đã thả chưa) — hearts là JSON array userId
    const groups = new Map<string, { author: (typeof stories)[number]['author']; stories: StoryOut[] }>()
    for (const s of stories) {
      if (!groups.has(s.authorId)) groups.set(s.authorId, { author: s.author, stories: [] })
      let hearts: string[] = []
      try { hearts = s.hearts ? JSON.parse(s.hearts) : [] } catch { hearts = [] }
      const { hearts: _omit, ...rest } = s
      void _omit
      groups.get(s.authorId)!.stories.push({
        ...(rest as StoryOut),
        likeCount: hearts.length,
        likedByMe: hearts.includes(me.id),
      })
    }
    const list = [...groups.values()]
    list.sort((a, b) => (a.stories[0].createdAt < b.stories[0].createdAt ? 1 : -1))
    return NextResponse.json(list)
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/stories', e)
    return NextResponse.json({ error: 'Không tải được stories' }, { status: 500 })
  }
}

// POST /api/vx/stories — đăng story (tự xoá sau 24h)
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const content = String(body.content || '').trim()
    if (!content && !body.media) {
      return NextResponse.json({ error: 'Story cần có nội dung hoặc ảnh/video' }, { status: 400 })
    }
    if (body.media && String(body.media).length > 3_000_000) {
      return NextResponse.json({ error: 'Ảnh/video quá lớn (tối đa ~2MB)' }, { status: 400 })
    }
    const story = await db.vxStory.create({
      data: {
        authorId: me.id,
        content: content.slice(0, 300) || null,
        media: body.media || null,
        bg: String(body.bg || '#0d9488,#ec4899').slice(0, 40),
        expiresAt: new Date(Date.now() + 24 * 3600 * 1000),
      },
      include: { author: { select: { id: true, username: true, fullName: true, avatarColor: true } } },
    })
    return NextResponse.json(story, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/stories', e)
    return NextResponse.json({ error: 'Không đăng được story' }, { status: 500 })
  }
}
