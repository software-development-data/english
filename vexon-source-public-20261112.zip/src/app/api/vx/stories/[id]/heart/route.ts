export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/stories/[id]/heart — thả/bỏ tim story (toggle)
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const story = await db.vxStory.findUnique({ where: { id }, select: { id: true, hearts: true, authorId: true } })
    if (!story) return NextResponse.json({ error: 'Story không tồn tại' }, { status: 404 })

    const ids: string[] = story.hearts ? JSON.parse(story.hearts) : []
    const has = ids.includes(me.id)
    const next = has ? ids.filter((x) => x !== me.id) : [...ids, me.id]
    await db.vxStory.update({ where: { id }, data: { hearts: JSON.stringify(next) } })

    // Báo chủ story lần đầu được thả tim
    if (!has && story.authorId !== me.id) {
      const author = await db.vxUser.findUnique({ where: { id: story.authorId }, select: { id: true } })
      if (author) {
        await db.vxNotification.create({ data: { userId: author.id, type: 'like', content: `${me.fullName} đã thả tim story của bạn` } })
      }
    }
    return NextResponse.json({ ok: true, liked: !has, count: next.length })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/stories/[id]/heart', e)
    return NextResponse.json({ error: 'Không thả tim được story' }, { status: 500 })
  }
}
