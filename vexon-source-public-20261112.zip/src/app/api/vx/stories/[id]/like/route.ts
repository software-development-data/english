export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/stories/[id]/like — thả/bỏ tim story (nút tương tác trong trình xem tin)
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const story = await db.vxStory.findUnique({ where: { id } })
    if (!story) return NextResponse.json({ error: 'Story không tồn tại hoặc đã hết hạn' }, { status: 404 })

    const existing = await db.vxStoryLike.findUnique({
      where: { storyId_userId: { storyId: id, userId: me.id } },
    })

    if (existing) {
      await db.vxStoryLike.delete({ where: { id: existing.id } })
    } else {
      await db.vxStoryLike.create({ data: { storyId: id, userId: me.id } })
    }

    const count = await db.vxStoryLike.count({ where: { storyId: id } })
    return NextResponse.json({ liked: !existing, count })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/stories/[id]/like', e)
    return NextResponse.json({ error: 'Không thả tim được story' }, { status: 500 })
  }
}
