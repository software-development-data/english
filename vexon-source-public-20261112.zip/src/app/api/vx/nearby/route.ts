export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError, publicUser } from '@/lib/vx-auth'
import { VX_BOT_USERNAME } from '@/lib/vx-bot'

// Khoảng cách Haversine (km) giữa 2 toạ độ
function haversine(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLng = ((lng2 - lng1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(a))
}

// PATCH /api/vx/nearby — cập nhật toạ độ thật của tôi (định vị tự động) + chế độ ẩn/hiện
export async function PATCH(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const data: Record<string, unknown> = { locationUpdatedAt: new Date() }
    if (typeof body.latitude === 'number' && typeof body.longitude === 'number') {
      data.latitude = body.latitude
      data.longitude = body.longitude
    }
    if (typeof body.locationName === 'string') data.locationName = body.locationName.slice(0, 120)
    if (typeof body.locationVisible === 'boolean') data.locationVisible = body.locationVisible
    const user = await db.vxUser.update({ where: { id: me.id }, data, select: { latitude: true, longitude: true, locationName: true, locationVisible: true, locationUpdatedAt: true } })
    return NextResponse.json({ ok: true, location: user })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/nearby', e)
    return NextResponse.json({ error: 'Không cập nhật được vị trí' }, { status: 500 })
  }
}

// GET /api/vx/nearby?radius=5&industry=&onlyFriends=1&accountType=
// Radar người gần đây: dùng toạ độ của tôi (nếu có) để tính khoảng cách thật
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const sp = req.nextUrl.searchParams
    const radiusKm = Math.min(100, Math.max(0.5, Number(sp.get('radius') || 10)))
    const industry = sp.get('industry') || ''
    const onlyFriends = sp.get('onlyFriends') === '1'
    const accType = sp.get('accountType') || ''

    const meFull = await db.vxUser.findUnique({ where: { id: me.id } })
    const friendships = await db.vxFriendship.findMany({
      where: {
        status: 'accepted',
        OR: [{ requesterId: me.id }, { addresseeId: me.id }],
      },
    })
    const friendIds = new Set(friendships.map((f) => (f.requesterId === me.id ? f.addresseeId : f.requesterId)))
    const pendingSet = new Set(
      (
        await db.vxFriendship.findMany({
          where: { status: 'pending', OR: [{ requesterId: me.id }, { addresseeId: me.id }] },
        })
      ).map((f) => (f.requesterId === me.id ? f.addresseeId : f.requesterId))
    )

    const users = await db.vxUser.findMany({
      where: {
        id: { not: me.id },
        // Loại tài khoản bot hệ thống (Vexon Bot) khỏi radar người gần
        username: { not: VX_BOT_USERNAME },
        locationVisible: true,
        latitude: { not: null },
        longitude: { not: null },
      },
      select: {
        id: true, username: true, fullName: true, role: true, department: true, title: true,
        avatarColor: true, bio: true, accountType: true, companyName: true, interests: true, birthday: true, settings: true,
        latitude: true, longitude: true, locationName: true, locationUpdatedAt: true, online: true,
      },
    })

    const myLat = meFull?.latitude ?? null
    const myLng = meFull?.longitude ?? null

    const people = users
      .map((u) => {
        const distance = myLat != null && myLng != null ? haversine(myLat, myLng, u.latitude as number, u.longitude as number) : null
        // Quyền riêng tư năm sinh: private = không ai thấy, friends = chỉ bạn bè thấy
        let birthday = u.birthday
        try {
          const prefs = u.settings ? (JSON.parse(u.settings) as { birthdayVisibility?: string }) : {}
          const vis = prefs.birthdayVisibility
          if (vis === 'private' || (vis === 'friends' && !friendIds.has(u.id))) birthday = null
        } catch { /* bỏ qua */ }
        return {
          ...publicUser(u),
          birthday,
          distanceKm: distance != null ? Math.round(distance * 10) / 10 : null,
          locationName: u.locationName,
          locationUpdatedAt: u.locationUpdatedAt,
          online: u.online,
          isFriend: friendIds.has(u.id),
          pending: pendingSet.has(u.id),
        }
      })
      .filter((u) => u.distanceKm == null || u.distanceKm <= radiusKm)
      .filter((u) => (onlyFriends ? u.isFriend : true))
      .filter((u) => (accType ? u.accountType === accType : true))
      .filter((u) => {
        if (!industry) return true
        const q = industry.toLowerCase()
        return (u.companyName || '').toLowerCase().includes(q) || (u.department || '').toLowerCase().includes(q)
      })
      .sort((a, b) => (a.distanceKm ?? 9999) - (b.distanceKm ?? 9999))

    // Ping chào hỏi tôi nhận gần đây (24h)
    const pings = await db.vxNearbyPing.findMany({
      where: { toUserId: me.id, createdAt: { gte: new Date(Date.now() - 24 * 3600 * 1000) } },
      include: { fromUser: { select: { id: true, fullName: true, avatarColor: true, accountType: true, companyName: true } } },
      orderBy: { createdAt: 'desc' },
      take: 30,
    })

    return NextResponse.json({
      me: myLat != null && myLng != null ? { latitude: myLat, longitude: myLng, hasLocation: true } : { hasLocation: false },
      radiusKm,
      people,
      pings: pings.map((p) => ({ id: p.id, message: p.message, createdAt: p.createdAt, from: p.fromUser })),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/nearby', e)
    return NextResponse.json({ error: 'Không tải được radar' }, { status: 500 })
  }
}

// POST /api/vx/nearby — gửi tín hiệu chào hỏi (ping) tới người ở gần
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const toUserId = String(body.toUserId || '')
    const message = String(body.message || 'Xin chào! Mình tìm thấy bạn qua Radar Vexon.').slice(0, 300)
    if (!toUserId || toUserId === me.id) return NextResponse.json({ error: 'Người nhận không hợp lệ' }, { status: 400 })
    const target = await db.vxUser.findUnique({ where: { id: toUserId } })
    if (!target) return NextResponse.json({ error: 'Không tìm thấy người dùng' }, { status: 404 })

    await db.vxNearbyPing.create({ data: { fromUserId: me.id, toUserId, message } })
    await db.vxNotification.create({
      data: { userId: toUserId, type: 'ping', content: `${me.fullName} đã gửi tín hiệu chào: ${message.slice(0, 80)}` },
    })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/nearby', e)
    return NextResponse.json({ error: 'Không gửi được tín hiệu' }, { status: 500 })
  }
}
