export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const PIPELINE = ['applied', 'screening', 'interview', 'trial', 'offered', 'rejected']
const PIPELINE_VI: Record<string, string> = { applied: 'Ứng tuyển', screening: 'Sàng lọc', interview: 'Phỏng vấn', trial: 'Thử việc', offered: 'Trúng tuyển', rejected: 'Loại' }

// GET /api/vx/applications?jobId= (nhà tuyển dụng xem ứng viên) | ?mine=1 (ứng viên xem hồ sơ đã nộp)
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const sp = req.nextUrl.searchParams

    if (sp.get('mine') === '1') {
      const apps = await db.vxApplication.findMany({
        where: { userId: me.id },
        include: { job: { include: { company: { select: { id: true, name: true, industry: true, owner: { select: { avatarColor: true } } } } } } },
        orderBy: { updatedAt: 'desc' },
      })
      return NextResponse.json({ applications: apps.map((a) => ({ id: a.id, status: a.status, statusVi: PIPELINE_VI[a.status], interviewAt: a.interviewAt, note: a.note, createdAt: a.createdAt, job: { id: a.job.id, title: a.job.title, location: a.job.location, company: a.job.company } })) })
    }

    const jobId = sp.get('jobId') || ''
    const job = await db.vxJob.findUnique({ where: { id: jobId }, include: { company: true } })
    if (!job) return NextResponse.json({ error: 'Không tìm thấy tin' }, { status: 404 })
    if (job.company.ownerId !== me.id) return NextResponse.json({ error: 'Chỉ nhà tuyển dụng được xem ứng viên' }, { status: 403 })

    const apps = await db.vxApplication.findMany({
      where: { jobId },
      include: { user: { select: { id: true, username: true, fullName: true, avatarColor: true, department: true, title: true, accountType: true } } },
      orderBy: { createdAt: 'desc' },
    })
    return NextResponse.json({
      job: { id: job.id, title: job.title, status: job.status },
      applications: apps.map((a) => ({
        id: a.id, coverNote: a.coverNote, cv: a.cvSnapshot ? JSON.parse(a.cvSnapshot) : null,
        status: a.status, statusVi: PIPELINE_VI[a.status], interviewAt: a.interviewAt, note: a.note, createdAt: a.createdAt,
        user: a.user,
      })),
      pipeline: PIPELINE,
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/applications', e)
    return NextResponse.json({ error: 'Không tải được hồ sơ ứng tuyển' }, { status: 500 })
  }
}

// PATCH /api/vx/applications — nhà tuyển dụng chuyển phễu: applied → screening → interview → trial → offered/rejected
export async function PATCH(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const applicationId = String(body.applicationId || '')
    const status = String(body.status || '')

    const app = await db.vxApplication.findUnique({ where: { id: applicationId }, include: { job: { include: { company: true } } } })
    if (!app) return NextResponse.json({ error: 'Không tìm thấy hồ sơ' }, { status: 404 })
    if (app.job.company.ownerId !== me.id) return NextResponse.json({ error: 'Không có quyền' }, { status: 403 })
    if (!PIPELINE.includes(status)) return NextResponse.json({ error: 'Trạng thái không hợp lệ' }, { status: 400 })

    const interviewAt = body.interviewAt ? new Date(body.interviewAt) : null
    await db.vxApplication.update({
      where: { id: applicationId },
      data: { status, interviewAt: status === 'interview' && interviewAt ? interviewAt : app.interviewAt, note: body.note ? String(body.note).slice(0, 500) : app.note },
    })
    await db.vxNotification.create({
      data: {
        userId: app.userId,
        type: 'job_status',
        content:
          status === 'interview' && interviewAt
            ? `Bạn được mời phỏng vấn vị trí "${app.job.title}" lúc ${interviewAt.toLocaleString('vi-VN')}`
            : `Hồ sơ ứng tuyển "${app.job.title}" chuyển sang trạng thái: ${PIPELINE_VI[status]}`,
      },
    })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/applications', e)
    return NextResponse.json({ error: 'Không cập nhật được' }, { status: 500 })
  }
}
