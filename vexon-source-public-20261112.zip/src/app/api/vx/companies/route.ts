export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// GET /api/vx/companies?q=&industry=&mine=1 — danh bạ doanh nghiệp (B2B)
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const sp = req.nextUrl.searchParams
    const q = (sp.get('q') || '').toLowerCase()
    const industry = sp.get('industry') || ''

    if (sp.get('mine') === '1') {
      const mine = await db.vxCompany.findUnique({
        where: { ownerId: me.id },
        include: {
          portfolio: true,
          // Thành viên doanh nghiệp: đơn chờ duyệt + danh sách chính thức (chủ công ty quản lý)
          members: { orderBy: { createdAt: 'desc' }, include: { user: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarImage: true, title: true, online: true } } } },
          _count: { select: { jobs: true, reviews: true } },
        },
      })
      return NextResponse.json({ myCompany: mine })
    }

    const industries = await db.vxCompany.findMany({ select: { industry: true }, distinct: ['industry'] })

    const companies = await db.vxCompany.findMany({
      where: {
        AND: [
          q ? { OR: [{ name: { contains: q } }, { about: { contains: q } }, { industry: { contains: q } }] } : {},
          industry ? { industry } : {},
        ].filter((c) => 'OR' in c || 'industry' in c),
      },
      include: {
        owner: { select: { fullName: true, avatarColor: true, online: true } },
        _count: { select: { portfolio: true, jobs: true, reviews: true, members: true } },
      },
      orderBy: { ratingAvg: 'desc' },
    })

    return NextResponse.json({
      industries: industries.map((i) => i.industry),
      companies: companies.map((c) => ({
        id: c.id, name: c.name, industry: c.industry, size: c.size, website: c.website, address: c.address,
        foundedYear: c.foundedYear, about: c.about, vision: c.vision,
        services: c.services ? JSON.parse(c.services) : [],
        ratingAvg: Math.round(c.ratingAvg * 10) / 10, ratingCount: c.ratingCount,
        botEnabled: c.botEnabled, botName: c.botName,
        owner: c.owner,
        portfolioCount: c._count.portfolio, jobCount: c._count.jobs, reviewCount: c._count.reviews, memberCount: c._count.members,
      })),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/companies', e)
    return NextResponse.json({ error: 'Không tải được danh bạ doanh nghiệp' }, { status: 500 })
  }
}

// POST /api/vx/companies — tạo/cập nhật hồ sơ năng lực công ty của tôi (chỉ tài khoản doanh nghiệp)
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const meFull = await db.vxUser.findUnique({ where: { id: me.id } })
    if (meFull?.accountType !== 'business') {
      return NextResponse.json({ error: 'Chỉ tài khoản DOANH NGHIỆP mới có hồ sơ công ty. Hãy đăng ký tài khoản doanh nghiệp.' }, { status: 403 })
    }
    const body = await req.json()
    const name = String(body.name || meFull.companyName || '').trim()
    if (!name) return NextResponse.json({ error: 'Thiếu tên công ty' }, { status: 400 })

    const botRules = Array.isArray(body.botRules)
      ? JSON.stringify(
          (body.botRules as { keywords: string[]; reply: string }[])
            .filter((r) => r.reply?.trim())
            .map((r) => ({ keywords: (r.keywords || []).filter(Boolean), reply: String(r.reply).slice(0, 500) }))
        )
      : undefined

    const data = {
      name,
      industry: String(body.industry || 'Xây dựng').slice(0, 60),
      size: String(body.size || '10-50').slice(0, 30),
      website: body.website ? String(body.website).slice(0, 200) : null,
      address: body.address ? String(body.address).slice(0, 200) : null,
      foundedYear: Number(body.foundedYear) > 1900 ? Math.round(Number(body.foundedYear)) : null,
      taxId: body.taxId ? String(body.taxId).slice(0, 40) : null,
      about: body.about ? String(body.about).slice(0, 2000) : null,
      vision: body.vision ? String(body.vision).slice(0, 1000) : null,
      services: Array.isArray(body.services) ? JSON.stringify(body.services.map((s: unknown) => String(s).slice(0, 60)).slice(0, 12)) : undefined,
      botEnabled: typeof body.botEnabled === 'boolean' ? body.botEnabled : undefined,
      botName: body.botName ? String(body.botName).slice(0, 60) : undefined,
      botGreeting: body.botGreeting ? String(body.botGreeting).slice(0, 500) : undefined,
      botFallback: body.botFallback ? String(body.botFallback).slice(0, 500) : undefined,
      ...(botRules ? { botRules } : {}),
    }

    const company = await db.vxCompany.upsert({
      where: { ownerId: me.id },
      create: { ownerId: me.id, ...data } as never,
      update: data,
    })
    await db.vxUser.update({ where: { id: me.id }, data: { companyName: name } })
    return NextResponse.json({ ok: true, company })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/companies', e)
    return NextResponse.json({ error: 'Không lưu được hồ sơ công ty' }, { status: 500 })
  }
}
