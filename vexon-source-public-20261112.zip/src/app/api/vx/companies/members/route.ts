export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// Chức vụ trong doanh nghiệp — cấp quản lý được quyền duyệt thành viên / thêm thành viên
export const VX_ROLES = ['Giám đốc', 'Phó giám đốc', 'Trưởng phòng', 'Nhân viên'] as const
// Giám đốc, Phó giám đốc, Trưởng phòng: duyệt đơn xin gia nhập + thêm thành viên mới
const LEADERSHIP = ['Giám đốc', 'Phó giám đốc', 'Trưởng phòng']
// Giám đốc, Phó giám đốc (và chủ công ty): xoá thành viên, gán chức vụ
const HIGH_MANAGEMENT = ['Giám đốc', 'Phó giám đốc']

type MemberRow = { id: string; userId: string; status: string; role: string; createdAt: Date; user: { id: string; fullName: string; username: string; avatarColor: string; avatarImage: string | null; title: string | null; online: boolean } | null }

// Quyền của người gọi API với 1 công ty: chủ công ty hoặc thành viên chính thức (kèm chức vụ nếu có)
async function myPower(companyId: string, meId: string) {
  const company = await db.vxCompany.findUnique({ where: { id: companyId }, select: { id: true, name: true, ownerId: true } })
  if (!company) return null
  if (company.ownerId === meId) return { company, isOwner: true, myRole: 'Giám đốc', isLeader: true, isHigh: true }
  const m = await db.vxBusinessMember.findUnique({ where: { companyId_userId: { companyId, userId: meId } } })
  if (!m || m.status !== 'active') return { company, isOwner: false, myRole: null, isLeader: false, isHigh: false }
  return {
    company,
    isOwner: false,
    myRole: m.role,
    isLeader: LEADERSHIP.includes(m.role),
    isHigh: HIGH_MANAGEMENT.includes(m.role),
  }
}

// GET /api/vx/companies/members?self=1 — quyền lợi thành viên doanh nghiệp của tôi
// GET /api/vx/companies/members?companyId=... — danh sách thành viên (chủ công ty hoặc thành viên chính thức)
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    if (req.nextUrl.searchParams.get('self') === '1') {
      const membership = await db.vxBusinessMember.findFirst({
        where: { userId: me.id, status: { in: ['pending', 'active'] } },
        include: { company: { select: { id: true, name: true, industry: true, ownerId: true } } },
      })
      return NextResponse.json({ membership })
    }
    const companyId = req.nextUrl.searchParams.get('companyId') || ''
    if (!companyId) return NextResponse.json({ error: 'Thiếu tham số' }, { status: 400 })
    const power = await myPower(companyId, me.id)
    if (!power) return NextResponse.json({ error: 'Không tìm thấy doanh nghiệp' }, { status: 404 })
    if (!power.isOwner && !power.isLeader && power.myRole === null) {
      return NextResponse.json({ error: 'Bạn cần là thành viên doanh nghiệp để xem danh sách này' }, { status: 403 })
    }
    const rows = await db.vxBusinessMember.findMany({
      where: { companyId },
      orderBy: [{ createdAt: 'desc' }],
      include: { user: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarImage: true, title: true, online: true } } },
    })
    return NextResponse.json({
      company: power.company,
      myRole: power.myRole,
      isOwner: power.isOwner,
      canApprove: power.isLeader,
      canManage: power.isHigh || power.isOwner,
      members: rows.map((r: MemberRow) => ({ id: r.id, userId: r.userId, status: r.status, role: r.role, createdAt: r.createdAt, user: r.user })),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/companies/members', e)
    return NextResponse.json({ error: 'Không tải được thành viên' }, { status: 500 })
  }
}

// POST /api/vx/companies/members — GIÁM ĐỐC (hoặc phó giám đốc/trưởng phòng/chủ công ty) THÊM THÀNH VIÊN TRỰC TIẾP
// body: { companyId, userId, role? }
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const companyId = String(body.companyId || '')
    const userId = String(body.userId || '')
    const role = VX_ROLES.includes(body.role) && body.role !== 'Giám đốc' ? String(body.role) : 'Nhân viên'
    if (!companyId || !userId) return NextResponse.json({ error: 'Thiếu companyId hoặc userId' }, { status: 400 })

    const power = await myPower(companyId, me.id)
    if (!power) return NextResponse.json({ error: 'Không tìm thấy doanh nghiệp' }, { status: 404 })
    if (!power.isLeader) return NextResponse.json({ error: 'Chỉ Giám đốc, Phó giám đốc hoặc Trưởng phòng mới thêm được thành viên' }, { status: 403 })

    const target = await db.vxUser.findUnique({ where: { id: userId } })
    if (!target) return NextResponse.json({ error: 'Không tìm thấy người dùng' }, { status: 404 })
    if (target.id === power.company.ownerId) return NextResponse.json({ error: 'Người này đã là chủ doanh nghiệp' }, { status: 400 })
    if (target.accountType === 'business') return NextResponse.json({ error: 'Tài khoản doanh nghiệp không thể là thành viên của doanh nghiệp khác' }, { status: 400 })
    const other = await db.vxBusinessMember.findFirst({ where: { userId, status: { in: ['pending', 'active'] } }, include: { company: { select: { name: true } } } })
    if (other) {
      return NextResponse.json({ error: other.status === 'pending' ? `${target.fullName} đang chờ duyệt ở ${other.company.name}` : `${target.fullName} đã là thành viên của ${other.company.name}` }, { status: 400 })
    }

    await db.vxBusinessMember.create({ data: { companyId, userId, status: 'active', role } })
    await db.vxNotification.create({
      data: { userId, type: 'business_member', content: `${me.fullName} đã thêm bạn vào ${power.company.name} với chức vụ ${role}. Bạn là thành viên chính thức: x2 thưởng điểm danh mỗi ngày, badge nhân viên, ưu đãi công cụ AI.` },
    }).catch(() => {})
    return NextResponse.json({ ok: true, message: `Đã thêm ${target.fullName} vào ${power.company.name} (chức vụ ${role})` })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/companies/members', e)
    return NextResponse.json({ error: 'Không thêm được thành viên' }, { status: 500 })
  }
}

// PATCH /api/vx/companies/members — GIÁM ĐỐC / PHÓ GIÁM ĐỐC / TRƯỞNG PHÒNG duyệt thành viên
// body: { memberId, action: 'approve' | 'reject' | 'remove' | 'set-role', role? }
export async function PATCH(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const memberId = String(body.memberId || '')
    const action = ['approve', 'reject', 'remove', 'set-role'].includes(body.action) ? body.action : null
    if (!memberId || !action) return NextResponse.json({ error: 'Thiếu memberId hoặc hành động' }, { status: 400 })

    const member = await db.vxBusinessMember.findUnique({
      where: { id: memberId },
      include: { company: { select: { id: true, name: true, ownerId: true } }, user: { select: { fullName: true } } },
    })
    if (!member) return NextResponse.json({ error: 'Không tìm thấy thành viên' }, { status: 404 })

    const power = await myPower(member.companyId, me.id)
    if (!power) return NextResponse.json({ error: 'Không tìm thấy doanh nghiệp' }, { status: 404 })
    const isApprover = power.isOwner || power.isLeader
    const isManager = power.isOwner || power.isHigh

    if (action === 'approve' || action === 'reject') {
      // "Người xin tham gia sẽ được giám đốc hoặc các chức vụ dưới giám đốc duyệt"
      if (!isApprover) return NextResponse.json({ error: 'Chỉ Giám đốc, Phó giám đốc, Trưởng phòng hoặc chủ doanh nghiệp mới duyệt được thành viên' }, { status: 403 })
      if (member.status !== 'pending') return NextResponse.json({ error: 'Yêu cầu này đã được xử lý' }, { status: 400 })
      if (action === 'approve') {
        // Khi duyệt có thể gán chức vụ ngay (trừ Giám đốc — chỉ chủ công ty gán được)
        const wanted = VX_ROLES.includes(body.role) ? String(body.role) : 'Nhân viên'
        const role = wanted === 'Giám đốc' && !power.isOwner ? 'Nhân viên' : wanted
        await Promise.all([
          db.vxBusinessMember.update({ where: { id: memberId }, data: { status: 'active', role } }),
          db.vxNotification.create({ data: { userId: member.userId, type: 'business_member', content: `Chúc mừng! Bạn đã là THÀNH VIÊN CHÍNH THỨC của ${member.company.name} với chức vụ ${role}: x2 thưởng điểm danh mỗi ngày, badge nhân viên trên hồ sơ, ưu đãi công cụ AI.` } }),
        ])
        return NextResponse.json({ ok: true, message: `Đã duyệt ${member.user.fullName} vào ${member.company.name} (chức vụ ${role})` })
      }
      await db.vxBusinessMember.delete({ where: { id: memberId } })
      return NextResponse.json({ ok: true, message: 'Đã từ chối yêu cầu gia nhập' })
    }

    if (action === 'remove') {
      if (!isManager) return NextResponse.json({ error: 'Chỉ Giám đốc, Phó giám đốc hoặc chủ doanh nghiệp mới xoá được thành viên' }, { status: 403 })
      await db.vxBusinessMember.delete({ where: { id: memberId } })
      return NextResponse.json({ ok: true, message: `Đã xoá ${member.user.fullName} khỏi ${member.company.name}` })
    }

    // set-role: gán chức vụ cho thành viên chính thức
    if (!isManager) return NextResponse.json({ error: 'Chỉ Giám đốc, Phó giám đốc hoặc chủ doanh nghiệp mới gán được chức vụ' }, { status: 403 })
    if (member.status !== 'active') return NextResponse.json({ error: 'Chỉ gán chức vụ cho thành viên chính thức' }, { status: 400 })
    if (!VX_ROLES.includes(body.role)) return NextResponse.json({ error: 'Chức vụ không hợp lệ' }, { status: 400 })
    if (body.role === 'Giám đốc' && !power.isOwner) return NextResponse.json({ error: 'Chỉ chủ doanh nghiệp mới gán chức vụ Giám đốc được' }, { status: 403 })
    await db.vxBusinessMember.update({ where: { id: memberId }, data: { role: String(body.role) } })
    return NextResponse.json({ ok: true, message: `Chức vụ của ${member.user.fullName} là ${body.role}` })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/companies/members', e)
    return NextResponse.json({ error: 'Không xử lý được thành viên' }, { status: 500 })
  }
}
