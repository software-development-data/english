export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/companies/join — GIA NHẬP DOANH NGHIỆP (xin gia nhập → chủ công ty duyệt → hưởng quyền lợi)
// body: { companyId, action: 'join' | 'leave' | 'cancel' }
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const companyId = String(body.companyId || '')
    const action = String(body.action || 'join')
    if (!companyId) return NextResponse.json({ error: 'Thiếu companyId' }, { status: 400 })

    const company = await db.vxCompany.findUnique({ where: { id: companyId } })
    if (!company) return NextResponse.json({ error: 'Không tìm thấy doanh nghiệp' }, { status: 404 })
    if (company.ownerId === me.id) return NextResponse.json({ error: 'Bạn là chủ doanh nghiệp này rồi, không cần gia nhập' }, { status: 400 })

    if (action === 'leave' || action === 'cancel') {
      const existing = await db.vxBusinessMember.findUnique({ where: { companyId_userId: { companyId, userId: me.id } } })
      if (!existing) return NextResponse.json({ error: 'Bạn chưa gia nhập doanh nghiệp này' }, { status: 400 })
      await db.vxBusinessMember.delete({ where: { id: existing.id } })
      return NextResponse.json({ ok: true, message: action === 'leave' ? `Đã rời khỏi ${company.name}, mất quyền lợi thành viên` : 'Đã huỷ yêu cầu gia nhập' })
    }

    if (action !== 'join') return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
    if (me.accountType === 'business') return NextResponse.json({ error: 'Tài khoản doanh nghiệp không gia nhập doanh nghiệp khác' }, { status: 400 })

    // Mỗi thành viên chỉ thuộc 1 doanh nghiệp cùng lúc (đây chính là "công ty" của họ)
    const myOther = await db.vxBusinessMember.findFirst({ where: { userId: me.id, status: { in: ['pending', 'active'] } }, include: { company: { select: { name: true } } } })
    if (myOther) {
      return NextResponse.json({ error: myOther.status === 'pending' ? `Bạn đang chờ duyệt ở ${myOther.company.name} — hãy huỷ trước khi xin doanh nghiệp khác` : `Bạn đang là thành viên của ${myOther.company.name} — rời khỏi đó trước khi gia nhập doanh nghiệp mới` }, { status: 400 })
    }

    const member = await db.vxBusinessMember.upsert({
      where: { companyId_userId: { companyId, userId: me.id } },
      create: { companyId, userId: me.id, status: 'pending' },
      update: { status: 'pending' },
    })
    await db.vxNotification.create({
      data: { userId: company.ownerId, type: 'business_member', content: `${me.fullName} (@${me.username}) xin gia nhập ${company.name} — duyệt trong mục Doanh nghiệp → Thành viên` },
    }).catch(() => {})
    return NextResponse.json({ ok: true, membership: member, message: `Đã gửi yêu cầu gia nhập ${company.name}. Giám đốc hoặc các chức vụ quản lý duyệt xong bạn sẽ hưởng quyền lợi: x2 thưởng điểm danh, badge nhân viên, ưu đãi công cụ AI.` })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/companies/join', e)
    return NextResponse.json({ error: 'Không xử lý được yêu cầu gia nhập' }, { status: 500 })
  }
}
