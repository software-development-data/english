export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// GET /api/vx/companies/[id] — chi tiết hồ sơ doanh nghiệp + portfolio + đánh giá + tin tuyển dụng
// + số thành viên và trạng thái gia nhập của tôi (nút "Xin gia nhập doanh nghiệp")
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const company = await db.vxCompany.findUnique({
      where: { id },
      include: {
        owner: { select: { id: true, fullName: true, username: true, avatarColor: true, online: true, accountType: true, companyName: true } },
        portfolio: { orderBy: { createdAt: 'desc' } },
        reviews: { include: { author: { select: { id: true, fullName: true, avatarColor: true } } }, orderBy: { createdAt: 'desc' } },
        jobs: { where: { status: 'open' }, orderBy: { createdAt: 'desc' } },
        members: { where: { status: 'active' }, select: { id: true, userId: true, status: true, role: true, user: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true, title: true, online: true } } } },
      },
    })
    if (!company) return NextResponse.json({ error: 'Không tìm thấy công ty' }, { status: 404 })
    const { members, ...rest } = company
    const myMembership = members.find((m) => m.userId === me.id) || (await db.vxBusinessMember.findUnique({ where: { companyId_userId: { companyId: id, userId: me.id } } }))
    return NextResponse.json({
      company: {
        ...rest,
        services: rest.services ? JSON.parse(rest.services) : [],
        botRules: rest.botRules ? JSON.parse(rest.botRules) : [],
        memberCount: members.length,
        members: members.map((m) => ({ ...m.user, role: m.role })),
        myMembership: myMembership ? { id: myMembership.id, status: myMembership.status } : null,
      },
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/companies/[id]', e)
    return NextResponse.json({ error: 'Không tải được công ty' }, { status: 500 })
  }
}
