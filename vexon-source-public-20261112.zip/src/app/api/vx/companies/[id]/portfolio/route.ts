export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/companies/[id]/portfolio — thêm hạng mục hồ sơ năng lực (chủ công ty)
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const company = await db.vxCompany.findUnique({ where: { id } })
    if (!company || company.ownerId !== me.id) return NextResponse.json({ error: 'Chỉ chủ công ty được thêm hồ sơ năng lực' }, { status: 403 })

    const body = await req.json()
    const title = String(body.title || '').trim()
    if (!title) return NextResponse.json({ error: 'Thiếu tiêu đề' }, { status: 400 })
    if (body.media && String(body.media).length > 2_000_000) return NextResponse.json({ error: 'Ảnh/video quá lớn (tối đa ~1.5MB)' }, { status: 400 })

    const item = await db.vxPortfolioItem.create({
      data: {
        companyId: id,
        title: title.slice(0, 120),
        category: String(body.category || 'Công trình').slice(0, 60),
        kind: ['image', 'video', 'doc'].includes(body.kind) ? body.kind : 'image',
        media: body.media ? String(body.media) : null,
        year: Number(body.year) > 1990 ? Math.round(Number(body.year)) : null,
        description: body.description ? String(body.description).slice(0, 800) : null,
      },
    })
    return NextResponse.json({ ok: true, item }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST portfolio', e)
    return NextResponse.json({ error: 'Không thêm được hạng mục' }, { status: 500 })
  }
}

// DELETE /api/vx/companies/[id]/portfolio?itemId= — xoá hạng mục
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const company = await db.vxCompany.findUnique({ where: { id } })
    if (!company || company.ownerId !== me.id) return NextResponse.json({ error: 'Không có quyền' }, { status: 403 })
    const itemId = req.nextUrl.searchParams.get('itemId') || ''
    await db.vxPortfolioItem.delete({ where: { id: itemId } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE portfolio', e)
    return NextResponse.json({ error: 'Không xoá được hạng mục' }, { status: 500 })
  }
}
