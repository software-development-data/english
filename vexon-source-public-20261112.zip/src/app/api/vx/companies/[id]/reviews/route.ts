export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/companies/[id]/reviews — đánh giá uy tín công ty (B2B rating), 1 lần/người (upsert)
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const company = await db.vxCompany.findUnique({ where: { id } })
    if (!company) return NextResponse.json({ error: 'Không tìm thấy công ty' }, { status: 404 })
    if (company.ownerId === me.id) return NextResponse.json({ error: 'Không thể đánh giá công ty của chính mình' }, { status: 400 })

    const body = await req.json()
    const rating = Math.min(5, Math.max(1, Math.round(Number(body.rating) || 5)))
    const comment = String(body.comment || '').slice(0, 600)

    await db.vxCompanyReview.upsert({
      where: { companyId_authorId: { companyId: id, authorId: me.id } },
      create: { companyId: id, authorId: me.id, rating, comment },
      update: { rating, comment },
    })

    const agg = await db.vxCompanyReview.aggregate({ where: { companyId: id }, _avg: { rating: true }, _count: { rating: true } })
    await db.vxCompany.update({
      where: { id },
      data: { ratingAvg: Math.round((agg._avg.rating || 0) * 10) / 10, ratingCount: agg._count.rating },
    })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST reviews', e)
    return NextResponse.json({ error: 'Không lưu được đánh giá' }, { status: 500 })
  }
}
