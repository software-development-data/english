export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { getUsdVnd } from '@/lib/vx-fx'
import { fmtUsdFromXu } from '@/lib/format'

// ── TỶ LỆ r30: MỌI TIỀN NẠP/RÚT ĐỀU TÍNH BẰNG USD ────────────────
// Nạp:  user nhập $X → chuyển khoản ${'{'}round(X × tỷ giá sống){'}'}đ vào TK ngân hàng → ví được cộng đúng $X
// Rút:  user nhập $Y → nhận ${'{'}round(Y × tỷ giá sống × 0,9){'}'}đ về ngân hàng (trừ thuế 10%) — hết thời “1 xu = 1đ”
export const DEPOSIT_VND_PER_XU = 100 // nội bộ: 1 xu ghi sổ = 100đ (không còn hiển thị)
export const WITHDRAW_TAX_RATE = 0.1
export const MIN_DEPOSIT_VND = 5_000
export const MAX_DEPOSIT_VND = 100_000_000
export const MIN_WITHDRAW_USD = 2
export const MAX_WITHDRAW_USD = 40_000

const fmt = (n: number) => n.toLocaleString('vi-VN')

function notif(userId: string, type: string, content: string) {
  return db.vxNotification.create({ data: { userId, type, content } })
}

// GET: lịch sử nạp/rút của tôi — ?admin=1 để Ban Giám đốc xem toàn bộ (kèm tên người dùng)
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const adminScope = req.nextUrl.searchParams.get('admin') === '1' && me.role === 'admin'

    const txs = await db.vxWalletTx.findMany({
      where: adminScope ? {} : { userId: me.id },
      orderBy: { createdAt: 'desc' },
      take: 100,
      include: { user: { select: { id: true, username: true, fullName: true, avatarColor: true, email: true, coins: true } } },
    })
    const balance = await db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } })

    return NextResponse.json({
      coins: balance?.coins ?? 0,
      rates: {
        depositVndPerXu: DEPOSIT_VND_PER_XU,
        withdrawTaxRate: WITHDRAW_TAX_RATE,
        minDepositVnd: MIN_DEPOSIT_VND,
        maxDepositVnd: MAX_DEPOSIT_VND,
        minWithdrawUsd: MIN_WITHDRAW_USD,
        maxWithdrawUsd: MAX_WITHDRAW_USD,
      },
      txs: txs.map((t) => ({
        id: t.id,
        type: t.type,
        amountVnd: t.amountVnd,
        amountXu: t.amountXu,
        taxVnd: t.taxVnd,
        proofCode: t.proofCode,
        bankName: t.bankName,
        accountNumber: t.accountNumber,
        accountHolder: t.accountHolder,
        status: t.status,
        coinsBefore: t.coinsBefore,
        coinsAfter: t.coinsAfter,
        adminNote: t.adminNote,
        reviewedAt: t.reviewedAt,
        createdAt: t.createdAt,
        user: adminScope ? t.user : undefined,
      })),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/wallet-tx', e)
    return NextResponse.json({ error: 'Không tải được lịch sử nạp/rút' }, { status: 500 })
  }
}

// POST: tạo yêu cầu NẠP hoặc RÚT — đều ở trạng thái pending, KHÔNG cộng xu tại đây
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()

    // ── NẠP TIỀN: user nhập số USD muốn có trong ví → chuyển khoản VND tương ứng vào TK web rồi báo mã REF ──
    if (body.action === 'deposit') {
      const rate = (await getUsdVnd()).rate
      const usdIn = Number(body.amountUsd) || 0
      const vnd = usdIn > 0 ? Math.round(usdIn * rate) : Math.round(Number(body.amountVnd) || 0)
      if (vnd < MIN_DEPOSIT_VND) return NextResponse.json({ error: `Nạp tối thiểu $0,20 (≈ ${fmt(MIN_DEPOSIT_VND)}đ)` }, { status: 400 })
      if (vnd > MAX_DEPOSIT_VND) return NextResponse.json({ error: `Nạp tối đa ${fmt(MAX_DEPOSIT_VND)}đ mỗi giao dịch` }, { status: 400 })
      const proofCode = String(body.proofCode || '').trim()
      if (proofCode.length < 4) return NextResponse.json({ error: 'Nhập nội dung chuyển khoản (mã NAPXU + tên đăng nhập) để đối soát' }, { status: 400 })

      const xu = Math.floor(vnd / DEPOSIT_VND_PER_XU)
      if (xu <= 0) return NextResponse.json({ error: `Số tiền quá nhỏ — tối thiểu ${fmt(DEPOSIT_VND_PER_XU)}đ mới ghi được sổ ví` }, { status: 400 })

      // DUY NHẤT tạo giao dịch pending — KHÔNG đụng vào coins
      const tx = await db.vxWalletTx.create({
        data: {
          userId: me.id,
          type: 'deposit',
          amountVnd: vnd,
          amountXu: xu,
          proofCode,
          bankName: String(body.bankName || 'Techcombank'),
          accountNumber: body.accountNumber ? String(body.accountNumber).slice(0, 30) : null,
          accountHolder: body.accountHolder ? String(body.accountHolder).slice(0, 80) : null,
          status: 'pending',
        },
      })
      return NextResponse.json({ ok: true, tx: { id: tx.id, amountVnd: vnd, amountXu: xu, status: tx.status } }, { status: 201 })
    }

    // ── RÚT TIỀN: nhập số USD → đổi theo tỷ giá sống, giữ chỗ ngay (trừ số dư), admin duyệt mới chuyển VND; từ chối thì hoàn 100% ──
    if (body.action === 'withdraw') {
      const rate = (await getUsdVnd()).rate
      const usd = Number(body.amountUsd) || (Number(body.amountXu) > 0 ? (Number(body.amountXu) * DEPOSIT_VND_PER_XU) / rate : 0)
      if (usd < MIN_WITHDRAW_USD) return NextResponse.json({ error: `Rút tối thiểu $2,00` }, { status: 400 })
      if (usd > MAX_WITHDRAW_USD) return NextResponse.json({ error: `Rút tối đa $40.000 mỗi giao dịch` }, { status: 400 })
      const xu = Math.round((usd * rate) / DEPOSIT_VND_PER_XU) // ghi sổ nội bộ theo xu
      if (xu < 100) return NextResponse.json({ error: 'Số tiền rút quá nhỏ' }, { status: 400 })

      const bankName = String(body.bankName || '').trim()
      const accountNumber = String(body.accountNumber || '').trim()
      const accountHolder = String(body.accountHolder || '').trim()
      if (!bankName || !accountNumber || !accountHolder) {
        return NextResponse.json({ error: 'Nhập đầy đủ ngân hàng, số tài khoản và chủ tài khoản nhận tiền' }, { status: 400 })
      }

      const grossVnd = Math.round(usd * rate)
      const taxVnd = Math.round(grossVnd * WITHDRAW_TAX_RATE)
      const netVnd = grossVnd - taxVnd

      // Trừ xu NGAY (giữ chỗ) — chống rút trùng trong lúc chờ duyệt; từ chối sẽ hoàn lại 100%
      const meFull = await db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } })
      const res = await db.vxUser.updateMany({ where: { id: me.id, coins: { gte: xu } }, data: { coins: { decrement: xu } } })
      if (res.count === 0) return NextResponse.json({ error: 'Không đủ tiền trong ví' }, { status: 400 })

      const [tx] = await Promise.all([
        db.vxWalletTx.create({
          data: {
            userId: me.id,
            type: 'withdraw',
            amountVnd: netVnd,
            amountXu: xu,
            taxVnd,
            bankName,
            accountNumber,
            accountHolder,
            status: 'pending',
            coinsBefore: meFull?.coins ?? null,
            coinsAfter: (meFull?.coins ?? 0) - xu,
          },
        }),
        db.vxCoinTx.create({ data: { userId: me.id, amount: -xu, reason: `Rút tiền về ngân hàng ${fmtUsdFromXu(xu, rate)} (giữ chỗ chờ duyệt)` } }),
        notif(me.id, 'coins', `Đã gửi yêu cầu rút ${fmtUsdFromXu(xu, rate)} ≈ ${fmt(netVnd)}đ (thuế 10%: ${fmt(taxVnd)}đ) — chờ Ban Giám đốc duyệt`),
      ])

      const user = await db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } })
      return NextResponse.json({ ok: true, tx: { id: tx.id, amountXu: xu, grossVnd, taxVnd, netVnd, status: tx.status }, coins: user?.coins ?? 0 }, { status: 201 })
    }

    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/wallet-tx', e)
    return NextResponse.json({ error: 'Không tạo được giao dịch' }, { status: 500 })
  }
}

// PATCH (chỉ Ban Giám đốc): duyệt / từ chối — xu NẠP chỉ được cộng ở ĐÂY
export async function PATCH(req: NextRequest) {
  try {
    const me = await requireUser()
    if (me.role !== 'admin') return NextResponse.json({ error: 'Chỉ Ban Giám đốc được duyệt giao dịch' }, { status: 403 })

    const { id, decision, note } = await req.json()
    const txId = String(id || '')
    const approve = decision === 'approve'
    const adminNote = String(note || '').slice(0, 200)

    const tx = await db.vxWalletTx.findUnique({ where: { id: txId } })
    if (!tx) return NextResponse.json({ error: 'Giao dịch không tồn tại' }, { status: 404 })
    if (tx.status !== 'pending') return NextResponse.json({ error: 'Giao dịch này đã được xử lý rồi' }, { status: 400 })

    if (tx.type === 'deposit') {
      const rate = (await getUsdVnd()).rate
      if (approve) {
        // DUY NHẤT nơi cộng tiền cho nạp chuyển khoản — nguyên tử, ghi sổ trước/sau, thông báo
        const coins = await db.$transaction(async (trx) => {
          const before = await trx.vxUser.findUnique({ where: { id: tx.userId }, select: { coins: true } })
          const after = await trx.vxUser.update({ where: { id: tx.userId }, data: { coins: { increment: tx.amountXu } } })
          await trx.vxCoinTx.create({ data: { userId: tx.userId, amount: tx.amountXu, reason: `Nạp tiền qua chuyển khoản (đã duyệt) — ${fmt(tx.amountVnd)}đ, mã ${tx.proofCode || '—'}` } })
          await trx.vxWalletTx.update({ where: { id: tx.id }, data: { status: 'approved', adminId: me.id, adminNote, reviewedAt: new Date(), coinsBefore: before?.coins ?? null, coinsAfter: after.coins } })
          await trx.vxNotification.create({ data: { userId: tx.userId, type: 'coins', content: `Nạp tiền thành công: +${fmtUsdFromXu(tx.amountXu, rate)} cho ${fmt(tx.amountVnd)}đ đã được Ban Giám đốc duyệt` } })
          return after.coins
        })
        return NextResponse.json({ ok: true, status: 'approved', coins })
      }
      await Promise.all([
        db.vxWalletTx.update({ where: { id: tx.id }, data: { status: 'rejected', adminId: me.id, adminNote: adminNote || 'Không tìm thấy giao dịch chuyển khoản', reviewedAt: new Date() } }),
        notif(tx.userId, 'coins', `Yêu cầu nạp ${fmtUsdFromXu(tx.amountXu, rate)} bị từ chối${adminNote ? `: ${adminNote}` : ''} — vui lòng kiểm tra lại chuyển khoản`),
      ])
      return NextResponse.json({ ok: true, status: 'rejected' })
    }

    // withdraw — duyệt = chuyển tiền ngoài hệ thống; từ chối = hoàn 100% số đã giữ chỗ
    const rate = (await getUsdVnd()).rate
    if (approve) {
      await Promise.all([
        db.vxWalletTx.update({ where: { id: tx.id }, data: { status: 'approved', adminId: me.id, adminNote, reviewedAt: new Date() } }),
        notif(tx.userId, 'coins', `Yêu cầu rút ${fmtUsdFromXu(tx.amountXu, rate)} đã duyệt — ${fmt(tx.amountVnd)}đ sẽ được chuyển tới ${tx.bankName} ${tx.accountNumber}${adminNote ? ` (${adminNote})` : ''}`),
      ])
      return NextResponse.json({ ok: true, status: 'approved' })
    }
    const [user] = await Promise.all([
      db.vxUser.update({ where: { id: tx.userId }, data: { coins: { increment: tx.amountXu } } }),
      db.vxCoinTx.create({ data: { userId: tx.userId, amount: tx.amountXu, reason: `Hoàn tiền từ yêu cầu rút bị từ chối (${fmtUsdFromXu(tx.amountXu, rate)})` } }),
      db.vxWalletTx.update({ where: { id: tx.id }, data: { status: 'rejected', adminId: me.id, adminNote: adminNote || 'Thông tin nhận tiền chưa hợp lệ', reviewedAt: new Date(), coinsBefore: tx.coinsBefore, coinsAfter: tx.coinsBefore } }),
      notif(tx.userId, 'coins', `Yêu cầu rút ${fmtUsdFromXu(tx.amountXu, rate)} bị từ chối${adminNote ? `: ${adminNote}` : ''} — đã hoàn lại ${fmtUsdFromXu(tx.amountXu, rate)} vào ví`),
    ])
    return NextResponse.json({ ok: true, status: 'rejected', coins: user.coins })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/wallet-tx', e)
    return NextResponse.json({ error: 'Không duyệt được giao dịch' }, { status: 500 })
  }
}
