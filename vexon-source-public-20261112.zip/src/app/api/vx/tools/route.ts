export const dynamic = 'force-dynamic'
export const maxDuration = 120

import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { getUsdVnd } from '@/lib/vx-fx'
import { fmtUsdFromXu } from '@/lib/format'

// Bảng giá Xu — CHỈ TRỪ XU KHI XỬ LÝ THÀNH CÔNG
export const TOOL_PRICES: Record<string, number> = {
  generate: 5, // Tạo ảnh theo yêu cầu
  edit: 9, // Chỉnh sửa theo yêu cầu
}

const SIZES = ['1024x1024', '768x1344', '864x1152', '1344x768', '1152x864', '1440x720', '720x1440']

// GET /api/vx/tools — giá + lịch sử sử dụng công cụ của tôi
export async function GET() {
  try {
    const me = await requireUser()
    const [meFull, jobs] = await Promise.all([
      db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } }),
      db.vxToolJob.findMany({ where: { userId: me.id }, orderBy: { createdAt: 'desc' }, take: 24 }),
    ])
    return NextResponse.json({ prices: TOOL_PRICES, coins: meFull?.coins || 0, jobs })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/tools', e)
    return NextResponse.json({ error: 'Không tải được công cụ' }, { status: 500 })
  }
}

// POST /api/vx/tools — chạy công cụ AI { kind: 'generate'|'edit', prompt, size?, image? (dataUrl) }
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const kind = body.kind === 'edit' ? 'edit' : 'generate'
    const prompt = String(body.prompt || '').trim()
    const size = SIZES.includes(body.size) ? body.size : '1024x1024'
    const cost = TOOL_PRICES[kind]
    const image = body.image ? String(body.image) : null

    if (!prompt) return NextResponse.json({ error: 'Vui lòng mô tả bằng tiếng Việt bạn muốn tạo/sửa gì' }, { status: 400 })
    if (kind === 'edit' && (!image || !image.startsWith('data:image/'))) {
      return NextResponse.json({ error: 'Chỉnh sửa cần đính kèm 1 ảnh' }, { status: 400 })
    }
    if (image && image.length > 3_500_000) {
      return NextResponse.json({ error: 'Ảnh quá lớn (tối đa ~2.5MB). Hãy nén ảnh ở công cụ miễn phí rồi thử lại.' }, { status: 400 })
    }

    // Kiểm tra số dư TRƯỚC, nhưng chỉ trừ xu SAU khi xử lý thành công
    const acc = await db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } })
    if (!acc || acc.coins < cost) {
      return NextResponse.json({ error: `Không đủ tiền! Cần ${fmtUsdFromXu(cost, (await getUsdVnd()).rate)} — nhận thêm ở Ví tiền (điểm danh, xem video mỗi ngày).` }, { status: 400 })
    }

    const zai = await ZAI.create()
    let resultBase64: string
    try {
      if (kind === 'generate') {
        const res = await zai.images.generations.create({ prompt: `${prompt}, chất lượng cao, chi tiết`, size })
        resultBase64 = res.data[0].base64
      } else {
        const res = await zai.images.generations.edit({ prompt: `${prompt}, giữ các phần khác nguyên như ảnh gốc`, image: image as string, size })
        resultBase64 = res.data[0].base64
      }
      if (!resultBase64) throw new Error('AI không trả về ảnh')
    } catch (aiErr) {
      // THẤT BẠI: không trừ Xu, ghi lịch sử failed để tra cứu
      await db.vxToolJob.create({
        data: { userId: me.id, kind, prompt: prompt.slice(0, 500), size, cost: 0, status: 'failed', error: aiErr instanceof Error ? aiErr.message.slice(0, 300) : 'Lỗi không xác định' },
      })
      return NextResponse.json({ error: `AI xử lý thất bại — KHÔNG trừ tiền. Thử lại nhé! (${aiErr instanceof Error ? aiErr.message.slice(0, 120) : 'lỗi'})` }, { status: 502 })
    }

    // THÀNH CÔNG: mới trừ Xu + ghi giao dịch + lưu lịch sử
    const dataUrl = `data:image/png;base64,${resultBase64}`
    const [user] = await Promise.all([
      db.vxUser.update({ where: { id: me.id }, data: { coins: { decrement: cost } } }),
      db.vxCoinTx.create({ data: { userId: me.id, amount: -cost, reason: kind === 'generate' ? `Tạo ảnh AI: ${prompt.slice(0, 40)}` : `Sửa ảnh AI: ${prompt.slice(0, 40)}` } }),
      db.vxToolJob.create({ data: { userId: me.id, kind, prompt: prompt.slice(0, 500), size, cost, status: 'success', resultUrl: dataUrl } }),
    ])
    return NextResponse.json({ ok: true, resultUrl: dataUrl, spent: cost, coins: user.coins })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/tools', e)
    return NextResponse.json({ error: 'Không xử lý được yêu cầu' }, { status: 500 })
  }
}
