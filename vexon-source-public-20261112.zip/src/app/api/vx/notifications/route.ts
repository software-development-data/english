export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// GET: thông báo của tôi (kèm số chưa đọc)
export async function GET() {
  try {
    const me = await requireUser()
    const notifications = await db.vxNotification.findMany({
      where: { userId: me.id },
      orderBy: { createdAt: 'desc' },
      take: 30,
    })
    return NextResponse.json({ notifications, unread: notifications.filter((n) => !n.read).length })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/notifications', e)
    return NextResponse.json({ error: 'Không tải được thông báo' }, { status: 500 })
  }
}

// PATCH: đánh dấu đã đọc tất cả
export async function PATCH() {
  try {
    const me = await requireUser()
    await db.vxNotification.updateMany({ where: { userId: me.id, read: false }, data: { read: true } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/notifications', e)
    return NextResponse.json({ error: 'Không cập nhật được' }, { status: 500 })
  }
}
