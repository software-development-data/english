export const dynamic = 'force-dynamic'

import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { ensureBotConversation, ensureVexonBot } from '@/lib/vx-bot'

// POST /api/vx/bot — đảm bảo chatbox Vexon Bot tồn tại cho user hiện tại
// (gọi 1 lần sau đăng nhập; trả về id hội thoại để app có thể mở trực tiếp)
export async function POST() {
  try {
    const me = await requireUser()
    const conversationId = await ensureBotConversation(me.id)
    const bot = await ensureVexonBot()
    return NextResponse.json({
      conversationId,
      bot: bot ? { id: bot.id, fullName: bot.fullName, avatarColor: bot.avatarColor, username: bot.username } : null,
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/bot', e)
    return NextResponse.json({ error: 'Không tạo được chatbox Vexon Bot' }, { status: 500 })
  }
}

// GET /api/vx/bot — thông tin bot (dùng cho hiển thị)
export async function GET() {
  try {
    const bot = await ensureVexonBot()
    if (!bot) return NextResponse.json({ bot: null })
    return NextResponse.json({
      bot: { id: bot.id, username: bot.username, fullName: bot.fullName, avatarColor: bot.avatarColor, title: bot.title, bio: bot.bio },
    })
  } catch {
    return NextResponse.json({ bot: null })
  }
}
