export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { verifyLiveAccess } from '@/lib/vx-live'

const SELECT_USER = { id: true, username: true, fullName: true, role: true, avatarColor: true }

// GET: chi tiết phòng live — phòng bảo mật trả { locked: true } nếu chưa có/sai mật khẩu
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const pw = req.nextUrl.searchParams.get('pw')
    const access = await verifyLiveAccess(id, me.id, pw)
    if (!access.ok) {
      if (access.locked) {
        const live = await db.vxLive.findUnique({ where: { id }, select: { host: { select: SELECT_USER } } })
        return NextResponse.json({ locked: true, requiresPassword: true, host: live?.host || null })
      }
      return NextResponse.json({ error: access.error }, { status: access.status })
    }
    const live = await db.vxLive.findUnique({
      where: { id },
      include: { host: { select: SELECT_USER }, _count: { select: { chats: true } } },
    })
    if (!live) return NextResponse.json({ error: 'Buổi live không tồn tại' }, { status: 404 })
    return NextResponse.json({ ...live, password: undefined, isPrivate: live.visibility === 'private' })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/lives/[id]', e)
    return NextResponse.json({ error: 'Không tải được buổi live' }, { status: 500 })
  }
}

// PATCH: kết thúc live (chỉ host)
export async function PATCH(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const live = await db.vxLive.findUnique({ where: { id } })
    if (!live) return NextResponse.json({ error: 'Buổi live không tồn tại' }, { status: 404 })
    if (live.hostId !== me.id) return NextResponse.json({ error: 'Chỉ chủ phòng mới được kết thúc live' }, { status: 403 })
    const updated = await db.vxLive.update({
      where: { id },
      data: { status: 'ended', endedAt: new Date() },
      include: { host: { select: SELECT_USER } },
    })
    return NextResponse.json(updated)
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/lives/[id]', e)
    return NextResponse.json({ error: 'Không cập nhật được' }, { status: 500 })
  }
}
