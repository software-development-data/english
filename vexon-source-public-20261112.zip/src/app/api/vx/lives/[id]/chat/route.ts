export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { verifyLiveAccess } from '@/lib/vx-live'

const SELECT_USER = { id: true, username: true, fullName: true, role: true, avatarColor: true }

// GET: chat của buổi live (phòng bảo mật cần ?pw=)
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const access = await verifyLiveAccess(id, me.id, req.nextUrl.searchParams.get('pw'))
    if (!access.ok) return NextResponse.json({ error: access.error, locked: access.locked }, { status: access.status })
    const chats = await db.vxLiveChat.findMany({
      where: { liveId: id },
      include: { user: { select: SELECT_USER } },
      orderBy: { createdAt: 'asc' },
      take: 100,
    })
    return NextResponse.json(chats)
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/lives/[id]/chat', e)
    return NextResponse.json({ error: 'Không tải được chat' }, { status: 500 })
  }
}

// POST: gửi chat vào buổi live (phòng bảo mật cần pw trong body)
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const body = await req.json()
    const access = await verifyLiveAccess(id, me.id, body.pw)
    if (!access.ok) return NextResponse.json({ error: access.error, locked: access.locked }, { status: access.status })
    if (access.live.status !== 'live') return NextResponse.json({ error: 'Buổi live đã kết thúc' }, { status: 400 })

    const { content } = body
    if (!content || !String(content).trim()) return NextResponse.json({ error: 'Nội dung trống' }, { status: 400 })

    const chat = await db.vxLiveChat.create({
      data: { liveId: id, userId: me.id, content: String(content).trim().slice(0, 300) },
      include: { user: { select: SELECT_USER } },
    })
    return NextResponse.json(chat, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/lives/[id]/chat', e)
    return NextResponse.json({ error: 'Không gửi được chat' }, { status: 500 })
  }
}
