export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { botNotify } from '@/lib/vx-bot'
import { verifyLiveAccess } from '@/lib/vx-live'
import { getUsdVnd } from '@/lib/vx-fx'
import { fmtUsdFromXu } from '@/lib/format'

// GET /api/vx/lives/[id]/gift — danh mục quà + bảng xếp hạng người tặng (phòng bảo mật cần ?pw=)
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const access = await verifyLiveAccess(id, me.id, req.nextUrl.searchParams.get('pw'))
    if (!access.ok) return NextResponse.json({ error: access.error, locked: access.locked }, { status: access.status })
    const [gifts, leaderboard, meFull] = await Promise.all([
      db.vxGift.findMany({ orderBy: { cost: 'asc' } }),
      db.vxLiveGift.groupBy({
        by: ['fromUserId'],
        where: { liveId: id },
        _sum: { cost: true },
        orderBy: { _sum: { cost: 'desc' } },
        take: 5,
      }),
      db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true } }),
    ])
    const users = await db.vxUser.findMany({ where: { id: { in: leaderboard.map((l) => l.fromUserId) } }, select: { id: true, fullName: true, avatarColor: true } })
    return NextResponse.json({
      gifts,
      myCoins: meFull?.coins || 0,
      leaderboard: leaderboard.map((l, i) => ({ rank: i + 1, user: users.find((u) => u.id === l.fromUserId), totalCoins: l._sum.cost || 0 })),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET gift catalog', e)
    return NextResponse.json({ error: 'Không tải được quà' }, { status: 500 })
  }
}

// POST /api/vx/lives/[id]/gift — tặng quà: trừ xu người tặng, cộng xu host, ghi lịch sử + tin hệ thống
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const body = await req.json()
    const access = await verifyLiveAccess(id, me.id, body.pw)
    if (!access.ok) return NextResponse.json({ error: access.error, locked: access.locked }, { status: access.status })
    const live = access.live
    if (live.hostId === me.id) return NextResponse.json({ error: 'Host không tự tặng quà cho chính mình' }, { status: 400 })

    const gift = await db.vxGift.findUnique({ where: { code: String(body.giftCode || '') } })
    if (!gift) return NextResponse.json({ error: 'Quà không tồn tại' }, { status: 404 })
    const qty = Math.min(99, Math.max(1, Math.round(Number(body.qty) || 1)))
    const total = gift.cost * qty
    const rate = (await getUsdVnd()).rate

    const sender = await db.vxUser.findUnique({ where: { id: me.id } })
    if (!sender || sender.coins < total) {
      return NextResponse.json({ error: `Không đủ tiền! Cần ${fmtUsdFromXu(total, rate)} — hãy xem video & điểm danh hàng ngày để nhận thêm.` }, { status: 400 })
    }

    // Phí nền tảng 30% — host chỉ nhận 70% giá trị quà (chống lạm phát xu)
    const hostReceives = Math.floor(total * 0.7)
    const platformFee = total - hostReceives
    const [, , host] = await Promise.all([
      db.vxUser.update({ where: { id: me.id }, data: { coins: { decrement: total } } }),
      db.vxCoinTx.create({ data: { userId: me.id, amount: -total, reason: `Tặng ${gift.name} x${qty} trong live "${live.title.slice(0, 40)}"` } }),
      db.vxUser.update({ where: { id: live.hostId }, data: { coins: { increment: hostReceives } } }),
    ])
    await db.vxCoinTx.create({ data: { userId: live.hostId, amount: hostReceives, reason: `Nhận quà ${gift.name} x${qty} từ ${sender.fullName} (70% sau phí nền tảng 30%)` } })
    if (platformFee > 0) {
      await db.vxCoinTx.create({ data: { userId: live.hostId, amount: 0, reason: `Phí nền tảng 30% từ quà ${gift.name} x${qty}: -${fmtUsdFromXu(platformFee, rate)}` } })
    }
    await db.vxLiveGift.create({
      data: { liveId: id, fromUserId: me.id, toUserId: live.hostId, giftCode: gift.code, giftName: gift.name, emoji: gift.emoji, cost: gift.cost, qty },
    })
    await db.vxLiveChat.create({
      data: { liveId: id, userId: me.id, content: `${sender.fullName} tặng ${gift.name} x${qty} (+${fmtUsdFromXu(total, rate)} cho host!)` },
    })
    await db.vxNotification.create({ data: { userId: live.hostId, type: 'gift', content: `${sender.fullName} tặng bạn ${gift.name} x${qty} (+${fmtUsdFromXu(hostReceives, rate)} sau phí 30%)` } })
    // Chatbox Vexon Bot: thông báo quà tặng ngay trong phần Tin nhắn của host
    await botNotify(
      live.hostId,
      `${sender.fullName} vừa tặng bạn ${gift.name} x${qty} trong phiên live "${live.title.slice(0, 60)}" (+${fmtUsdFromXu(total, rate)} vào Ví tiền). Mở lại phiên live hoặc Danh sách thông báo để cảm ơn người tặng nhé!`,
      'gift',
    )

    return NextResponse.json({ ok: true, spent: total, hostReceives, hostCoins: host.coins })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST gift', e)
    return NextResponse.json({ error: 'Không tặng được quà' }, { status: 500 })
  }
}
