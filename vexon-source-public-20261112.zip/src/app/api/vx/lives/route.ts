export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELECT_USER = { id: true, username: true, fullName: true, role: true, avatarColor: true }

// GET: danh sách phòng live (không bao giờ trả mật khẩu)
export async function GET() {
  try {
    await requireUser()
    const lives = await db.vxLive.findMany({
      include: { host: { select: SELECT_USER }, _count: { select: { chats: true } } },
      orderBy: [{ status: 'asc' }, { startedAt: 'desc' }],
      take: 50,
    })
    return NextResponse.json(lives.map((l) => ({ ...l, password: undefined, isPrivate: l.visibility === 'private' })))
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/lives', e)
    return NextResponse.json({ error: 'Không tải được danh sách live' }, { status: 500 })
  }
}

// POST: tạo phòng live { title, sourceVideoUrl, visibility: 'public'|'private', password? }
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const { title, sourceVideoUrl, visibility, password } = await req.json()
    if (!title || !String(title).trim()) return NextResponse.json({ error: 'Vui lòng nhập tiêu đề buổi live' }, { status: 400 })
    if (!sourceVideoUrl) return NextResponse.json({ error: 'Vui lòng chọn video phát trực tiếp' }, { status: 400 })

    // Chế độ live: công khai hoặc bảo mật (yêu cầu mật khẩu khi vào xem)
    const isPrivate = visibility === 'private'
    const pw = password ? String(password).trim() : ''
    if (isPrivate && pw.length < 4) {
      return NextResponse.json({ error: 'Live bảo mật cần mật khẩu tối thiểu 4 ký tự' }, { status: 400 })
    }

    const live = await db.vxLive.create({
      data: {
        hostId: me.id,
        title: String(title).trim().slice(0, 200),
        sourceVideoUrl,
        visibility: isPrivate ? 'private' : 'public',
        password: isPrivate ? pw.slice(0, 30) : null,
      },
      include: { host: { select: SELECT_USER } },
    })

    // Thông báo cho người theo dõi kênh
    const followers = await db.vxFollow.findMany({ where: { followingId: me.id } })
    if (followers.length > 0) {
      await db.vxNotification.createMany({
        data: followers.map((f) => ({
          userId: f.followerId,
          type: 'live',
          content: `${me.fullName} đang phát trực tiếp: ${live.title}`,
        })),
      })
    }
    return NextResponse.json(live, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/lives', e)
    return NextResponse.json({ error: 'Không tạo được buổi live' }, { status: 500 })
  }
}
