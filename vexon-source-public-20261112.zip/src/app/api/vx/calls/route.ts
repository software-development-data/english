export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/calls  body: { conversationId, kind: 'voice'|'video', duration: giây }
// Ghi lại cuộc gọi dưới dạng tin nhắn hệ thống trong hội thoại
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const { conversationId, kind, duration } = await req.json()
    const membership = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: String(conversationId), userId: me.id } },
    })
    if (!membership) return NextResponse.json({ error: 'Không có quyền' }, { status: 403 })

    const sec = Math.max(0, Math.round(Number(duration) || 0))
    const mm = String(Math.floor(sec / 60)).padStart(2, '0')
    const ss = String(sec % 60).padStart(2, '0')
    const label = kind === 'meeting' ? 'Cuộc họp nhóm' : kind === 'video' ? 'Cuộc gọi video' : 'Cuộc gọi thoại'
    const detail = sec > 0 ? `${label}, ${mm}:${ss}` : `${label}, Không trả lời`

    const message = await db.vxMessage.create({
      data: {
        conversationId: String(conversationId),
        senderId: me.id,
        content: detail,
        type: 'call',
        duration: sec,
        status: 'seen',
      },
      include: { sender: { select: { id: true, username: true, fullName: true, role: true, avatarColor: true } } },
    })

    return NextResponse.json(
      {
        id: message.id,
        content: message.content,
        type: 'call',
        duration: message.duration,
        status: 'seen',
        unsent: false,
        pinned: false,
        reactions: {},
        createdAt: message.createdAt,
        senderId: me.id,
        sender: message.sender,
        replyTo: null,
      },
      { status: 201 }
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/calls', e)
    return NextResponse.json({ error: 'Không ghi được cuộc gọi' }, { status: 500 })
  }
}
