export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { getUsdVnd } from '@/lib/vx-fx'
import { fmtUsdFromXu } from '@/lib/format'

// Giá nâng cấp tài khoản DOANH NGHIỆP bằng xu (nộp đơn → chờ admin duyệt; từ chối hoàn xu 100%)
export const UPGRADE_COST = 500

// GET /api/vx/business-upgrade — trạng thái đơn nâng cấp của tôi + cấu hình phí
// (?admin=1 — ADMIN: danh sách toàn bộ đơn để duyệt)
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    if (me.role === 'admin' && req.nextUrl.searchParams.get('admin') === '1') {
      const apps = await db.vxBusinessApplication.findMany({ orderBy: { createdAt: 'desc' }, take: 100, include: { user: { select: { fullName: true, username: true, avatarColor: true, avatarImage: true, accountType: true, coins: true } } } })
      return NextResponse.json({ adminList: apps, cost: UPGRADE_COST })
    }
    const app = await db.vxBusinessApplication.findUnique({ where: { userId: me.id } })
    return NextResponse.json({
      cost: UPGRADE_COST,
      accountType: me.accountType,
      application: app,
      pendingCount: me.role === 'admin' ? await db.vxBusinessApplication.count({ where: { status: 'pending' } }) : undefined,
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/business-upgrade', e)
    return NextResponse.json({ error: 'Không tải được trạng thái nâng cấp' }, { status: 500 })
  }
}

// POST /api/vx/business-upgrade — nộp đơn nâng cấp (trừ xu, chờ admin duyệt)
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json().catch(() => ({}))
    const companyName = String(body.companyName || '').trim().slice(0, 120)
    if (!companyName) return NextResponse.json({ error: 'Nhập tên công ty để nộp đơn nâng cấp' }, { status: 400 })

    if (me.accountType === 'business') return NextResponse.json({ error: 'Tài khoản của bạn đã là doanh nghiệp' }, { status: 400 })
    const existing = await db.vxBusinessApplication.findUnique({ where: { userId: me.id } })
    if (existing?.status === 'pending') return NextResponse.json({ error: 'Bạn đã có đơn đang chờ admin duyệt, vui lòng kiên nhẫn' }, { status: 400 })
    if (existing?.status === 'approved') return NextResponse.json({ error: 'Đơn của bạn đã được duyệt' }, { status: 400 })

    const meFull = await db.vxUser.findUnique({ where: { id: me.id } })
    if (!meFull || meFull.coins < UPGRADE_COST) {
      const rate = (await getUsdVnd()).rate
      return NextResponse.json({ error: `Không đủ tiền: cần ${fmtUsdFromXu(UPGRADE_COST, rate)}, bạn đang có ${fmtUsdFromXu(meFull?.coins ?? 0, rate)}. Nhận thêm ở Ví tiền (điểm danh, đăng bài, xem video...) nhé!` }, { status: 400 })
    }

    // Trừ xu + tạo đơn chờ duyệt (mỗi giao dịch có ghi rõ lý do)
    const [user] = await Promise.all([
      db.vxUser.update({ where: { id: me.id }, data: { coins: { decrement: UPGRADE_COST } } }),
      db.vxCoinTx.create({ data: { userId: me.id, amount: -UPGRADE_COST, reason: 'Phí nộp đơn nâng cấp tài khoản doanh nghiệp (hoàn 100% nếu bị từ chối)' } }),
      db.vxBusinessApplication.upsert({
        where: { userId: me.id },
        create: {
          userId: me.id,
          companyName,
          taxId: body.taxId ? String(body.taxId).slice(0, 40) : null,
          industry: body.industry ? String(body.industry).slice(0, 60) : null,
          xuPaid: UPGRADE_COST,
          status: 'pending',
        },
        update: { companyName, taxId: body.taxId ? String(body.taxId).slice(0, 40) : null, industry: body.industry ? String(body.industry).slice(0, 60) : null, xuPaid: UPGRADE_COST, status: 'pending', note: null, reviewedAt: null },
      }),
    ])
    // Thông báo cho toàn bộ admin (Ban Giám đốc) duyệt đơn
    const admins = await db.vxUser.findMany({ where: { role: 'admin' }, select: { id: true } })
    if (admins.length) {
      await db.vxNotification.createMany({
        data: admins.map((a) => ({ userId: a.id, type: 'business_upgrade', content: `${me.fullName} (@${me.username}) nộp đơn nâng cấp DOANH NGHIỆP "${companyName}" — duyệt trong Cài đặt → Duyệt doanh nghiệp` })),
      }).catch(() => {})
    }
    const app = await db.vxBusinessApplication.findUnique({ where: { userId: me.id } })
    return NextResponse.json({ ok: true, coins: user.coins, application: app, message: `Đã nộp đơn nâng cấp DOANH NGHIỆP "${companyName}", trừ ${fmtUsdFromXu(UPGRADE_COST, (await getUsdVnd()).rate)}. Vui lòng chờ admin duyệt (từ chối sẽ hoàn 100% vào ví).` })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/business-upgrade', e)
    return NextResponse.json({ error: 'Không nộp được đơn nâng cấp' }, { status: 500 })
  }
}

// PATCH /api/vx/business-upgrade — ADMIN duyệt / từ chối đơn nâng cấp { id, action: approve|reject, note? }
export async function PATCH(req: NextRequest) {
  try {
    const me = await requireUser()
    if (me.role !== 'admin') return NextResponse.json({ error: 'Chỉ Ban Giám đốc (admin) mới duyệt được đơn' }, { status: 403 })
    const body = await req.json()
    const id = String(body.id || '')
    const action = body.action === 'approve' ? 'approve' : body.action === 'reject' ? 'reject' : null
    if (!id || !action) return NextResponse.json({ error: 'Thiếu id hoặc hành động' }, { status: 400 })

    const app = await db.vxBusinessApplication.findUnique({ where: { id }, include: { user: { select: { id: true, fullName: true, accountType: true, role: true, title: true } } } })
    if (!app) return NextResponse.json({ error: 'Không tìm thấy đơn' }, { status: 404 })
    if (app.status !== 'pending') return NextResponse.json({ error: `Đơn này đã được xử lý (${app.status})` }, { status: 400 })

    if (action === 'approve') {
      // Duyệt: nâng cấp tài khoản, giữ lại xu đã nộp, bật vai trò quản lý doanh nghiệp
      await Promise.all([
        db.vxBusinessApplication.update({ where: { id }, data: { status: 'approved', note: body.note ? String(body.note).slice(0, 300) : 'Đã duyệt bởi Ban Giám đốc', reviewedAt: new Date() } }),
        db.vxUser.update({
          where: { id: app.userId },
          data: {
            accountType: 'business',
            companyName: app.companyName,
            ...(app.user.role === 'employee' ? { role: 'manager' } : {}),
            ...(app.user.title === 'Nhân viên' ? { title: 'Đại diện doanh nghiệp' } : {}),
          },
        }),
        db.vxNotification.create({ data: { userId: app.userId, type: 'business_upgrade', content: `Chúc mừng! Đơn nâng cấp DOANH NGHIỆP "${app.companyName}" đã được DUYỆT. Bạn có hồ sơ năng lực công ty, bot trả lời khách, đăng tuyển dụng + quyền lợi doanh nghiệp.` } }),
      ])
      return NextResponse.json({ ok: true, message: `Đã duyệt doanh nghiệp "${app.companyName}" cho ${app.user.fullName}` })
    }

    // Từ chối: hoàn 100% tiền đã nộp
    const rate = (await getUsdVnd()).rate
    await Promise.all([
      db.vxBusinessApplication.update({ where: { id }, data: { status: 'rejected', note: body.note ? String(body.note).slice(0, 300) : 'Đơn không đạt yêu cầu, bạn có thể nộp lại', reviewedAt: new Date() } }),
      db.vxUser.update({ where: { id: app.userId }, data: { coins: { increment: app.xuPaid } } }),
      db.vxCoinTx.create({ data: { userId: app.userId, amount: app.xuPaid, reason: `Hoàn tiền đơn nâng cấp doanh nghiệp bị từ chối (${app.companyName})` } }),
      db.vxNotification.create({ data: { userId: app.userId, type: 'business_upgrade', content: `Đơn nâng cấp DOANH NGHIỆP "${app.companyName}" bị từ chối. ${body.note ? String(body.note).slice(0, 200) + ' ' : ''}Đã hoàn ${fmtUsdFromXu(app.xuPaid, rate)}, bạn có thể nộp đơn lại.` } }),
    ])
    return NextResponse.json({ ok: true, message: `Đã từ chối đơn của ${app.user.fullName}, hoàn ${fmtUsdFromXu(app.xuPaid, rate)}` })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/business-upgrade', e)
    return NextResponse.json({ error: 'Không xử lý được đơn' }, { status: 500 })
  }
}
