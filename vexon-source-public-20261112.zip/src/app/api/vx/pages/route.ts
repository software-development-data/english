export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// GET /api/vx/pages — Trang của tôi + Khám phá (kiểu Facebook Pages)
export async function GET() {
  try {
    const me = await requireUser()

    const pages = await db.vxPage.findMany({
      include: {
        owner: { select: { id: true, fullName: true, avatarColor: true } },
        followers: { select: { userId: true } },
        _count: { select: { posts: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    })

    const shaped = pages.map((p) => ({
      id: p.id,
      name: p.name,
      category: p.category,
      bio: p.bio,
      avatar: p.avatar,
      cover: p.cover,
      verified: p.verified,
      owner: p.owner,
      // Trang thú cưng (fanpage riêng cho pet)
      petSpecies: p.petSpecies ?? null,
      petBreed: p.petBreed ?? null,
      petGender: p.petGender ?? null,
      petBirthday: p.petBirthday ?? null,
      followerCount: p.followers.length,
      postCount: p._count.posts,
      isOwner: p.ownerId === me.id,
      isFollowing: p.followers.some((f) => f.userId === me.id),
      createdAt: p.createdAt,
    }))

    return NextResponse.json({
      mine: shaped.filter((p) => p.isOwner),
      discover: shaped.filter((p) => !p.isOwner),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/pages', e)
    return NextResponse.json({ error: 'Không tải được Trang' }, { status: 500 })
  }
}

// POST /api/vx/pages — tạo Trang (Fanpage) mới
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const name = String(body.name || '').trim()
    if (!name) return NextResponse.json({ error: 'Nhập tên Trang' }, { status: 400 })
    for (const key of ['avatar', 'cover'] as const) {
      if (body[key] && String(body[key]).length > 2_000_000) {
        return NextResponse.json({ error: 'Ảnh quá lớn (tối đa ~1.5MB)' }, { status: 400 })
      }
    }

    const page = await db.vxPage.create({
      data: {
        name: name.slice(0, 80),
        category: String(body.category || 'Doanh nghiệp địa phương').slice(0, 60),
        bio: body.bio ? String(body.bio).trim().slice(0, 300) : null,
        avatar: body.avatar || null,
        cover: body.cover || null,
        // Trang thú cưng: loài/giống/giới tính/sinh nhật (category = "Thú cưng")
        petSpecies: body.petSpecies ? String(body.petSpecies).trim().slice(0, 40) : null,
        petBreed: body.petBreed ? String(body.petBreed).trim().slice(0, 60) : null,
        petGender: body.petGender ? String(body.petGender).trim().slice(0, 10) : null,
        petBirthday: body.petBirthday ? String(body.petBirthday).trim().slice(0, 30) : null,
        ownerId: me.id,
      },
    })

    // Chủ Trang tự động theo dõi Trang của mình
    await db.vxPageFollow.create({ data: { pageId: page.id, userId: me.id } })

    return NextResponse.json({ id: page.id }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/pages', e)
    return NextResponse.json({ error: 'Không tạo được Trang' }, { status: 500 })
  }
}
