export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELECT_AUTHOR = { id: true, username: true, fullName: true, role: true, department: true, title: true, avatarColor: true, avatarImage: true, accountType: true, companyName: true }
const SELECT_CUSER = { id: true, username: true, fullName: true, role: true, avatarColor: true, accountType: true }

function parseJSON(s: string | null | undefined): unknown[] {
  if (!s) return []
  try {
    const v = JSON.parse(s)
    return Array.isArray(v) ? v : []
  } catch {
    return []
  }
}

function shapePost(p: {
  id: string; content: string; background: string | null; images: string | null
  videoUrl: string | null; fileUrl: string | null; fileName: string | null
  location: string | null; mentions: string | null; isAnnouncement: boolean
  visibility: string; createdAt: Date; editedAt: Date | null
  likes: { userId: string; type: string }[]
  comments: { id: string; content: string; sticker: string | null; imageUrl: string | null; audioDur: number | null; createdAt: Date; user: { id: string; fullName: string; avatarColor: string }; parentId: string | null; replies: unknown[] }[]
}) {
  const reactions: Record<string, number> = {}
  let myReaction: string | null = null
  for (const l of p.likes) {
    reactions[l.type] = (reactions[l.type] || 0) + 1
  }
  return {
    id: p.id,
    content: p.content,
    background: p.background,
    images: parseJSON(p.images as string | null),
    videoUrl: p.videoUrl,
    fileUrl: p.fileUrl,
    fileName: p.fileName,
    location: p.location,
    mentions: parseJSON(p.mentions as string | null),
    isAnnouncement: p.isAnnouncement,
    visibility: p.visibility || 'public',
    createdAt: p.createdAt,
    editedAt: p.editedAt,
    reactions,
    commentCount: p.comments.reduce((n, c) => n + 1 + c.replies.length, 0),
    comments: p.comments,
  }
}

// GET /api/vx/pages/[id] — chi tiết Trang + bài đăng của Trang
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params

    const page = await db.vxPage.findUnique({
      where: { id },
      include: {
        owner: { select: { id: true, fullName: true, avatarColor: true } },
        followers: { select: { userId: true } },
        posts: {
          orderBy: { createdAt: 'desc' },
          take: 30,
          include: {
            likes: { select: { userId: true, type: true } },
            comments: {
              where: { parentId: null },
              include: { user: { select: SELECT_CUSER }, replies: { include: { user: { select: SELECT_CUSER } }, orderBy: { createdAt: 'asc' } } },
              orderBy: { createdAt: 'asc' },
            },
          },
        },
      },
    })
    if (!page) return NextResponse.json({ error: 'Không tìm thấy Trang' }, { status: 404 })

    return NextResponse.json({
      id: page.id,
      name: page.name,
      category: page.category,
      bio: page.bio,
      avatar: page.avatar,
      cover: page.cover,
      verified: page.verified,
      owner: page.owner,
      // Trang thú cưng (fanpage riêng cho pet)
      petSpecies: page.petSpecies ?? null,
      petBreed: page.petBreed ?? null,
      petGender: page.petGender ?? null,
      petBirthday: page.petBirthday ?? null,
      isOwner: page.ownerId === me.id,
      isFollowing: page.followers.some((f) => f.userId === me.id),
      followerCount: page.followers.length,
      createdAt: page.createdAt,
      posts: page.posts.map((p) => ({
        ...shapePost(p),
        author: { ...page.owner, pageAsAuthor: true },
        page: { id: page.id, name: page.name, avatar: page.avatar },
      })),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/pages/[id]', e)
    return NextResponse.json({ error: 'Không tải được Trang' }, { status: 500 })
  }
}

// PATCH /api/vx/pages/[id] — chủ Trang sửa thông tin Trang
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const page = await db.vxPage.findUnique({ where: { id } })
    if (!page) return NextResponse.json({ error: 'Không tìm thấy Trang' }, { status: 404 })
    if (page.ownerId !== me.id && me.role !== 'admin') {
      return NextResponse.json({ error: 'Chỉ chủ Trang được chỉnh sửa' }, { status: 403 })
    }

    const body = await req.json()
    const data: Record<string, unknown> = {}
    if (body.name !== undefined) {
      const name = String(body.name).trim()
      if (!name) return NextResponse.json({ error: 'Tên Trang không được trống' }, { status: 400 })
      data.name = name.slice(0, 80)
    }
    if (body.category !== undefined) data.category = String(body.category).slice(0, 60)
    if (body.bio !== undefined) data.bio = String(body.bio).trim().slice(0, 300) || null
    // Trang thú cưng: sửa loài/giống/giới tính/sinh nhật
    if (body.petSpecies !== undefined) data.petSpecies = body.petSpecies ? String(body.petSpecies).trim().slice(0, 40) : null
    if (body.petBreed !== undefined) data.petBreed = body.petBreed ? String(body.petBreed).trim().slice(0, 60) : null
    if (body.petGender !== undefined) data.petGender = body.petGender ? String(body.petGender).trim().slice(0, 10) : null
    if (body.petBirthday !== undefined) data.petBirthday = body.petBirthday ? String(body.petBirthday).trim().slice(0, 30) : null
    if (body.avatar !== undefined) {
      if (body.avatar && String(body.avatar).length > 2_000_000) return NextResponse.json({ error: 'Ảnh đại diện quá lớn' }, { status: 400 })
      data.avatar = body.avatar || null
    }
    if (body.cover !== undefined) {
      if (body.cover && String(body.cover).length > 2_000_000) return NextResponse.json({ error: 'Ảnh bìa quá lớn' }, { status: 400 })
      data.cover = body.cover || null
    }

    await db.vxPage.update({ where: { id }, data })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/pages/[id]', e)
    return NextResponse.json({ error: 'Không lưu được Trang' }, { status: 500 })
  }
}

// DELETE /api/vx/pages/[id] — chủ Trang xoá Trang
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const page = await db.vxPage.findUnique({ where: { id } })
    if (!page) return NextResponse.json({ error: 'Không tìm thấy Trang' }, { status: 404 })
    if (page.ownerId !== me.id && me.role !== 'admin') {
      return NextResponse.json({ error: 'Chỉ chủ Trang được xoá' }, { status: 403 })
    }
    await db.vxPage.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/pages/[id]', e)
    return NextResponse.json({ error: 'Không xoá được Trang' }, { status: 500 })
  }
}
