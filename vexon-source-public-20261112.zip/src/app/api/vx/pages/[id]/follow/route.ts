export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/pages/[id]/follow — theo dõi / bỏ theo dõi Trang (toggle)
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const page = await db.vxPage.findUnique({ where: { id } })
    if (!page) return NextResponse.json({ error: 'Không tìm thấy Trang' }, { status: 404 })

    const existing = await db.vxPageFollow.findUnique({
      where: { pageId_userId: { pageId: id, userId: me.id } },
    })

    if (existing) {
      await db.vxPageFollow.delete({ where: { id: existing.id } })
      const count = await db.vxPageFollow.count({ where: { pageId: id } })
      return NextResponse.json({ following: false, followerCount: count })
    }

    await db.vxPageFollow.create({ data: { pageId: id, userId: me.id } })
    // Thông báo cho chủ Trang
    if (page.ownerId !== me.id) {
      await db.vxNotification.create({
        data: { userId: page.ownerId, type: 'page_follow', content: `${me.fullName} đã theo dõi Trang "${page.name}"` },
      }).catch(() => {})
    }
    const count = await db.vxPageFollow.count({ where: { pageId: id } })
    return NextResponse.json({ following: true, followerCount: count })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/pages/[id]/follow', e)
    return NextResponse.json({ error: 'Không theo dõi được Trang' }, { status: 500 })
  }
}
