export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// GET /api/vx/pets/[id]/posts — bài viết trên trang thú cưng
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const posts = await db.vxPetPost.findMany({
      where: { petId: id },
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: {
        author: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true } },
        pet: { select: { name: true, avatarColor: true, avatarImage: true } },
        likes: { select: { userId: true } },
        comments: { orderBy: { createdAt: 'asc' }, include: { user: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true } } } },
      },
    })
    return NextResponse.json(posts.map((p) => ({
      id: p.id, petId: p.petId, petName: p.pet.name, petAvatarColor: p.pet.avatarColor, petAvatarImage: p.pet.avatarImage,
      content: p.content, images: p.images ? JSON.parse(p.images) : [], createdAt: p.createdAt,
      author: p.author, likes: p.likes.length, myLike: p.likes.some((l) => l.userId === me.id),
      comments: p.comments.map((c) => ({ id: c.id, content: c.content, createdAt: c.createdAt, user: c.user })),
    })))
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/pets/[id]/posts', e)
    return NextResponse.json({ error: 'Không tải được bài viết thú cưng' }, { status: 500 })
  }
}

// POST /api/vx/pets/[id]/posts — chủ thú cưng đăng bài lên trang của bé (kiểu fanpage)
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const pet = await db.vxPet.findUnique({ where: { id } })
    if (!pet) return NextResponse.json({ error: 'Không tìm thấy thú cưng' }, { status: 404 })
    if (pet.ownerId !== me.id) return NextResponse.json({ error: 'Chỉ chủ thú cưng mới được đăng bài cho bé' }, { status: 403 })
    const body = await req.json()
    const content = String(body.content || '').trim().slice(0, 1000)
    const images: string[] = Array.isArray(body.images)
      ? body.images.filter((i: unknown) => typeof i === 'string' && i.startsWith('data:image/')).slice(0, 6)
      : []
    if (!content && images.length === 0) return NextResponse.json({ error: 'Viết vài dòng hoặc gắn ảnh cho bé nhé!' }, { status: 400 })
    const post = await db.vxPetPost.create({
      data: { petId: id, authorId: me.id, content, images: images.length ? JSON.stringify(images) : null },
      include: { author: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true } } },
    })
    return NextResponse.json({ ok: true, post: { id: post.id, petId: post.petId, petName: pet.name, petAvatarColor: pet.avatarColor, petAvatarImage: pet.avatarImage, content: post.content, images, createdAt: post.createdAt, author: post.author, likes: 0, myLike: false, comments: [] } })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/pets/[id]/posts', e)
    return NextResponse.json({ error: 'Không đăng được bài cho thú cưng' }, { status: 500 })
  }
}
