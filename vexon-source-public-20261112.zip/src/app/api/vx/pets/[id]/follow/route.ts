export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/pets/[id]/follow — bấm 1 lần: theo dõi / bỏ theo dõi trang thú cưng (kiểu fanpage)
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const pet = await db.vxPet.findUnique({ where: { id } })
    if (!pet) return NextResponse.json({ error: 'Không tìm thấy thú cưng' }, { status: 404 })
    if (pet.ownerId === me.id) return NextResponse.json({ error: 'Chủ của bé luôn theo dõi bé rồi!' }, { status: 400 })
    const existing = await db.vxPetFollow.findUnique({ where: { petId_followerId: { petId: id, followerId: me.id } } })
    if (existing) {
      await db.vxPetFollow.delete({ where: { id: existing.id } })
      return NextResponse.json({ ok: true, isFollowing: false })
    }
    await db.vxPetFollow.create({ data: { petId: id, followerId: me.id } })
    return NextResponse.json({ ok: true, isFollowing: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/pets/[id]/follow', e)
    return NextResponse.json({ error: 'Không theo dõi được thú cưng' }, { status: 500 })
  }
}
