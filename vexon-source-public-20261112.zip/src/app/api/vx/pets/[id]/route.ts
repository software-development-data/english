export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SPECIES = ['Chó', 'Mèo', 'Chim', 'Cá', 'Thỏ', 'Khác']

// GET /api/vx/pets/[id] — trang cá nhân của 1 thú cưng (kiểu fanpage): thông tin + bài viết + tim/bình luận
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const pet = await db.vxPet.findUnique({
      where: { id },
      include: {
        owner: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true } },
        _count: { select: { follows: true, posts: true } },
        follows: { where: { followerId: me.id }, select: { id: true } },
      },
    })
    if (!pet) return NextResponse.json({ error: 'Không tìm thấy thú cưng' }, { status: 404 })
    const posts = await db.vxPetPost.findMany({
      where: { petId: id },
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: {
        author: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true } },
        likes: { select: { userId: true } },
        comments: { orderBy: { createdAt: 'asc' }, include: { user: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true } } } },
      },
    })
    return NextResponse.json({
      pet: {
        id: pet.id, name: pet.name, species: pet.species, breed: pet.breed, gender: pet.gender,
        birthday: pet.birthday, bio: pet.bio, avatarColor: pet.avatarColor, avatarImage: pet.avatarImage,
        coverImage: pet.coverImage, createdAt: pet.createdAt, owner: pet.owner,
        followers: pet._count.follows, postCount: pet._count.posts,
        isFollowing: pet.follows.length > 0, isOwner: pet.ownerId === me.id,
      },
      posts: posts.map((p) => ({
        id: p.id, content: p.content, images: p.images ? JSON.parse(p.images) : [], createdAt: p.createdAt,
        author: p.author, petName: pet.name,
        likes: p.likes.length, myLike: p.likes.some((l) => l.userId === me.id),
        comments: p.comments.map((c) => ({ id: c.id, content: c.content, createdAt: c.createdAt, user: c.user })),
      })),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/pets/[id]', e)
    return NextResponse.json({ error: 'Không tải được trang thú cưng' }, { status: 500 })
  }
}

// PATCH /api/vx/pets/[id] — chủ thú cưng sửa thông tin bé
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const pet = await db.vxPet.findUnique({ where: { id } })
    if (!pet) return NextResponse.json({ error: 'Không tìm thấy thú cưng' }, { status: 404 })
    if (pet.ownerId !== me.id) return NextResponse.json({ error: 'Chỉ chủ thú cưng mới được sửa' }, { status: 403 })
    const body = await req.json()
    const data: Record<string, unknown> = {}
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim().slice(0, 40)
    if (typeof body.species === 'string' && SPECIES.includes(body.species)) data.species = body.species
    if (typeof body.breed === 'string') data.breed = body.breed.trim().slice(0, 60) || null
    if (typeof body.gender === 'string') data.gender = ['Đực', 'Cái'].includes(body.gender) ? body.gender : null
    if (typeof body.bio === 'string') data.bio = body.bio.trim().slice(0, 300) || null
    if (typeof body.birthday === 'string') data.birthday = body.birthday ? new Date(body.birthday) : null
    if (typeof body.avatarColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(body.avatarColor)) data.avatarColor = body.avatarColor
    if (typeof body.avatarImage === 'string' && body.avatarImage.startsWith('data:image/')) {
      if (body.avatarImage.length > 2_000_000) return NextResponse.json({ error: 'Ảnh đại diện quá lớn' }, { status: 400 })
      data.avatarImage = body.avatarImage
    }
    if (body.avatarImage === null) data.avatarImage = null
    if (typeof body.coverImage === 'string' && body.coverImage.startsWith('data:image/')) {
      if (body.coverImage.length > 2_400_000) return NextResponse.json({ error: 'Ảnh bìa quá lớn' }, { status: 400 })
      data.coverImage = body.coverImage
    }
    if (body.coverImage === null) data.coverImage = null
    await db.vxPet.update({ where: { id }, data })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/pets/[id]', e)
    return NextResponse.json({ error: 'Không lưu được thông tin thú cưng' }, { status: 500 })
  }
}

// DELETE /api/vx/pets/[id] — chủ xoá trang thú cưng (xoá cascade bài viết/tim/bình luận/theo dõi)
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const pet = await db.vxPet.findUnique({ where: { id } })
    if (!pet) return NextResponse.json({ error: 'Không tìm thấy thú cưng' }, { status: 404 })
    if (pet.ownerId !== me.id) return NextResponse.json({ error: 'Chỉ chủ thú cưng mới được xoá' }, { status: 403 })
    await db.vxPet.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/pets/[id]', e)
    return NextResponse.json({ error: 'Không xoá được trang thú cưng' }, { status: 500 })
  }
}
