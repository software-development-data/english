export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SPECIES = ['Chó', 'Mèo', 'Chim', 'Cá', 'Thỏ', 'Khác']

// GET /api/vx/pets?mine=1 — danh sách thú cưng (mặc định: khám phá tất cả; mine=1: pets của tôi)
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const mine = req.nextUrl.searchParams.get('mine') === '1'
    const pets = await db.vxPet.findMany({
      where: mine ? { ownerId: me.id } : {},
      orderBy: { createdAt: 'desc' },
      take: 60,
      include: {
        owner: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true } },
        _count: { select: { follows: true, posts: true } },
        follows: { where: { followerId: me.id }, select: { id: true } },
      },
    })
    return NextResponse.json(pets.map((p) => ({
      id: p.id, name: p.name, species: p.species, breed: p.breed, gender: p.gender,
      birthday: p.birthday, bio: p.bio, avatarColor: p.avatarColor, avatarImage: p.avatarImage,
      coverImage: p.coverImage, createdAt: p.createdAt,
      owner: p.owner, followers: p._count.follows, postCount: p._count.posts,
      isFollowing: p.follows.length > 0, isOwner: p.ownerId === me.id,
    })))
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/pets', e)
    return NextResponse.json({ error: 'Không tải được danh sách thú cưng' }, { status: 500 })
  }
}

// POST /api/vx/pets — tạo trang cá nhân cho thú cưng của tôi
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const name = String(body.name || '').trim().slice(0, 40)
    if (!name) return NextResponse.json({ error: 'Nhập tên bé nào!' }, { status: 400 })
    const species = SPECIES.includes(String(body.species)) ? String(body.species) : 'Khác'
    const data: Record<string, unknown> = {
      ownerId: me.id, name, species,
      breed: typeof body.breed === 'string' ? body.breed.trim().slice(0, 60) || null : null,
      gender: ['Đực', 'Cái'].includes(String(body.gender)) ? String(body.gender) : null,
      bio: typeof body.bio === 'string' ? body.bio.trim().slice(0, 300) || null : null,
    }
    if (typeof body.birthday === 'string' && body.birthday) data.birthday = new Date(body.birthday)
    if (typeof body.avatarColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(body.avatarColor)) data.avatarColor = body.avatarColor
    if (typeof body.avatarImage === 'string' && body.avatarImage.startsWith('data:image/')) {
      if (body.avatarImage.length > 2_000_000) return NextResponse.json({ error: 'Ảnh đại diện quá lớn (tối đa ~1.5MB)' }, { status: 400 })
      data.avatarImage = body.avatarImage
    }
    if (typeof body.coverImage === 'string' && body.coverImage.startsWith('data:image/')) {
      if (body.coverImage.length > 2_400_000) return NextResponse.json({ error: 'Ảnh bìa quá lớn (tối đa ~1.8MB)' }, { status: 400 })
      data.coverImage = body.coverImage
    }
    const pet = await db.vxPet.create({ data: data as never })
    return NextResponse.json({ ok: true, pet: { ...pet, followers: 0, postCount: 0, isFollowing: false, isOwner: true } })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/pets', e)
    return NextResponse.json({ error: 'Không tạo được trang thú cưng' }, { status: 500 })
  }
}
