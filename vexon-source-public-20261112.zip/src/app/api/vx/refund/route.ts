export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { getUsdVnd } from '@/lib/vx-fx'
import { fmtUsdFromXu } from '@/lib/format'

// GET /api/vx/refund → danh sách yêu cầu hoàn tiền của tôi
// ?admin=1 → toàn bộ (admin duyệt)
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const url = new URL(req.url)
    const adminMode = url.searchParams.get('admin') === '1'

    if (adminMode) {
      if (me.role !== 'admin') return NextResponse.json({ error: 'Chỉ Ban Giám đốc mới được truy cập' }, { status: 403 })
      const adminList = await db.vxRefundRequest.findMany({
        orderBy: { createdAt: 'desc' },
        take: 200,
        include: {
          user: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarImage: true } },
          walletTx: { select: { id: true, amountVnd: true, amountXu: true, type: true, status: true, bankName: true, accountNumber: true, accountHolder: true, xuUsedLog: true } },
          messages: { orderBy: { createdAt: 'asc' } },
        },
      })
      return NextResponse.json({ adminList })
    }

    const refunds = await db.vxRefundRequest.findMany({
      where: { userId: me.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: { messages: { orderBy: { createdAt: 'asc' } } },
    })
    return NextResponse.json({ refunds })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/refund', e)
    return NextResponse.json({ error: 'Không tải được' }, { status: 500 })
  }
}

// POST /api/vx/refund → user tạo yêu cầu hoàn tiền cho một giao dịch nạp (chỉ được nếu tx đã approved và chưa tiêu xu)
// Body: { walletTxId, reason }
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const walletTxId = String(body.walletTxId || '')
    const reason = String(body.reason || '').trim()
    if (!walletTxId) return NextResponse.json({ error: 'Thiếu giao dịch nạp' }, { status: 400 })
    if (!reason) return NextResponse.json({ error: 'Nhập lý do hoàn tiền' }, { status: 400 })
    if (reason.length > 500) return NextResponse.json({ error: 'Lý do quá dài (tối đa 500 ký tự)' }, { status: 400 })

    const tx = await db.vxWalletTx.findUnique({ where: { id: walletTxId } })
    if (!tx || tx.userId !== me.id) {
      return NextResponse.json({ error: 'Không tìm thấy giao dịch' }, { status: 404 })
    }
    if (tx.type !== 'deposit') {
      return NextResponse.json({ error: 'Chỉ hoàn tiền được cho giao dịch nạp, không cho giao dịch rút' }, { status: 400 })
    }
    if (tx.status !== 'approved') {
      return NextResponse.json({ error: 'Chỉ được hoàn tiền cho giao dịch nạp đã duyệt' }, { status: 400 })
    }
    // Kiểm tra đã có yêu cầu hoàn pending chưa
    const existingPending = await db.vxRefundRequest.findFirst({ where: { walletTxId, status: 'pending' } })
    if (existingPending) {
      return NextResponse.json({ error: 'Đã có yêu cầu hoàn tiền đang chờ admin xử lý cho giao dịch này' }, { status: 400 })
    }
    // Kiểm tra đã tiêu xu chưa: nếu có bất kỳ giao dịch VxCoinTx nào mang dấu "-" (trừ xu) sau khi nạp được duyệt → đã dùng → không hoàn
    if (tx.reviewedAt) {
      const spentSince = await db.vxCoinTx.aggregate({
        where: {
          userId: me.id,
          amount: { lt: 0 },
          createdAt: { gte: tx.reviewedAt },
          // loại trừ lý do rút tiền (vì rút đã qua VxWalletTx riêng, không tính là "tiêu") — phủ cả bản ghi cũ "Rút xu"
          NOT: { OR: [{ reason: { contains: 'Rút tiền' } }, { reason: { contains: 'Rút xu' } }] },
        },
        _sum: { amount: true },
      })
      const totalSpentXu = Math.abs(spentSince._sum.amount || 0)
      if (totalSpentXu > 0) {
        return NextResponse.json({ error: `Bạn đã tiêu ${fmtUsdFromXu(totalSpentXu, (await getUsdVnd()).rate)} kể từ khi nạp được duyệt, không thể hoàn tiền. Liên hệ admin qua chatbox nếu cần hỗ trợ đặc biệt.` }, { status: 400 })
      }
    }
    // Tạo yêu cầu hoàn + thêm 1 tin nhắn system
    const refund = await db.$transaction(async (txdb) => {
      const r = await txdb.vxRefundRequest.create({
        data: {
          userId: me.id, walletTxId, reason,
          refundVnd: tx.amountVnd, // hoàn 100% tiền nạp gốc
          status: 'pending',
        },
      })
      await txdb.vxRefundMessage.create({
        data: {
          refundRequestId: r.id, senderId: me.id, role: 'system',
          content: `Yêu cầu hoàn ${tx.amountVnd.toLocaleString('vi-VN')}đ cho giao dịch nạp ${fmtUsdFromXu(tx.amountXu, (await getUsdVnd()).rate)} (REF ${tx.proofCode || '-'}). Lý do: ${reason}`,
        },
      })
      await txdb.vxNotification.create({
        data: { userId: me.id, type: 'wallet', content: `Đã gửi yêu cầu hoàn tiền ${tx.amountVnd.toLocaleString('vi-VN')}đ. Admin sẽ xử lý trong 7 ngày.` },
      })
      return r
    })
    return NextResponse.json({ refund, message: 'Đã gửi yêu cầu hoàn tiền, admin xử lý trong 7 ngày' }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/refund', e)
    return NextResponse.json({ error: 'Không gửi được yêu cầu' }, { status: 500 })
  }
}

// PATCH /api/vx/refund →
//  - user gửi tin nhắn chatbox: { refundRequestId, action:'sendMsg', content }
//  - admin duyệt/từ chối: { refundRequestId, action:'approve'|'reject', adminNote? }
export async function PATCH(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const refundRequestId = String(body.refundRequestId || '')
    if (!refundRequestId) return NextResponse.json({ error: 'Thiếu yêu cầu' }, { status: 400 })
    const action = String(body.action || '')

    if (action === 'sendMsg') {
      const content = String(body.content || '').trim().slice(0, 800)
      if (!content) return NextResponse.json({ error: 'Nhập nội dung tin nhắn' }, { status: 400 })
      const r = await db.vxRefundRequest.findUnique({ where: { id: refundRequestId } })
      if (!r) return NextResponse.json({ error: 'Không tìm thấy yêu cầu' }, { status: 404 })
      if (r.userId !== me.id && me.role !== 'admin') {
        return NextResponse.json({ error: 'Không có quyền' }, { status: 403 })
      }
      // Nếu user gửi khi đã kết thúc → từ chối
      if (r.userId === me.id && r.status !== 'pending') {
        return NextResponse.json({ error: 'Yêu cầu đã kết thúc, không gửi được tin nhắn' }, { status: 400 })
      }
      const role = me.role === 'admin' ? 'admin' : 'user'
      const msg = await db.vxRefundMessage.create({
        data: { refundRequestId, senderId: me.id, role, content },
      })
      // Nếu admin gửi → thông báo cho user
      if (role === 'admin') {
        await db.vxNotification.create({
          data: { userId: r.userId, type: 'wallet', content: `Admin phản hồi trong chatbox hỗ trợ hoàn tiền: ${content.slice(0, 100)}` },
        })
      }
      return NextResponse.json({ msg }, { status: 201 })
    }

    if (action === 'approve' || action === 'reject') {
      if (me.role !== 'admin') return NextResponse.json({ error: 'Chỉ Ban Giám đốc mới được duyệt' }, { status: 403 })
      const r = await db.vxRefundRequest.findUnique({ where: { id: refundRequestId }, include: { walletTx: true } })
      if (!r) return NextResponse.json({ error: 'Không tìm thấy yêu cầu' }, { status: 404 })
      if (r.status !== 'pending') {
        return NextResponse.json({ error: `Yêu cầu đã được xử lý (${r.status})` }, { status: 400 })
      }
      const adminNote = body.adminNote ? String(body.adminNote).slice(0, 300) : null

      if (action === 'approve') {
        // Kiểm tra lại: user chưa tiêu xu từ nạp gốc (dựa trên VxCoinTx sau ngày duyệt nạp)
        if (r.walletTx && r.walletTx.reviewedAt) {
          const spentSince = await db.vxCoinTx.aggregate({
            where: {
              userId: r.userId,
              amount: { lt: 0 },
              createdAt: { gte: r.walletTx.reviewedAt },
              NOT: { OR: [{ reason: { contains: 'Rút tiền' } }, { reason: { contains: 'Rút xu' } }] },
            },
            _sum: { amount: true },
          })
          const totalSpent = Math.abs(spentSince._sum.amount || 0)
          if (totalSpent > 0) {
            return NextResponse.json({ error: `User đã tiêu ${fmtUsdFromXu(totalSpent, (await getUsdVnd()).rate)} từ nạp gốc, không thể hoàn tiền` }, { status: 400 })
          }
        }
        await db.$transaction(async (txdb) => {
          await txdb.vxRefundRequest.update({ where: { id: refundRequestId }, data: { status: 'approved', adminId: me.id, adminNote, reviewedAt: new Date() } })
          // Hoàn tiền: trừ xu đã cộng vào ví + log
          if (r.walletTx && r.walletTx.amountXu > 0) {
            await txdb.vxUser.update({ where: { id: r.userId }, data: { coins: { decrement: r.walletTx.amountXu } } })
            await txdb.vxCoinTx.create({ data: { userId: r.userId, amount: -r.walletTx.amountXu, reason: `Hoàn tiền nạp ${r.refundVnd.toLocaleString('vi-VN')}đ (admin duyệt) — trừ lại ${fmtUsdFromXu(r.walletTx.amountXu, (await getUsdVnd()).rate)}` } })
          }
          await txdb.vxRefundMessage.create({ data: { refundRequestId, senderId: me.id, role: 'system', content: `Admin đã DUYỆT hoàn tiền ${r.refundVnd.toLocaleString('vi-VN')}đ. Tiền sẽ chuyển vào thẻ ngân hàng của bạn trong 1-3 ngày làm việc. Số tiền tương ứng (${fmtUsdFromXu(r.walletTx?.amountXu || 0, (await getUsdVnd()).rate)}) đã bị trừ khỏi ví.` } })
          await txdb.vxNotification.create({ data: { userId: r.userId, type: 'wallet', content: `Yêu cầu hoàn tiền ${r.refundVnd.toLocaleString('vi-VN')}đ đã được admin DUYỆT. Tiền sẽ chuyển vào thẻ trong 1-3 ngày làm việc.` } })
        })
        return NextResponse.json({ ok: true, message: 'Đã duyệt hoàn tiền' })
      }

      // Reject
      await db.$transaction([
        db.vxRefundRequest.update({ where: { id: refundRequestId }, data: { status: 'rejected', adminId: me.id, adminNote, reviewedAt: new Date() } }),
        db.vxRefundMessage.create({ data: { refundRequestId, senderId: me.id, role: 'system', content: `Admin đã TỪ CHỐI yêu cầu hoàn tiền${adminNote ? `: ${adminNote}` : ''}.` } }),
        db.vxNotification.create({ data: { userId: r.userId, type: 'wallet', content: `Yêu cầu hoàn tiền bị TỪ CHỐI${adminNote ? `: ${adminNote}` : ''}.` } }),
      ])
      return NextResponse.json({ ok: true, message: 'Đã từ chối hoàn tiền, thông báo cho user' })
    }

    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/refund', e)
    return NextResponse.json({ error: 'Không xử lý được' }, { status: 500 })
  }
}
