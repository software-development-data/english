export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser } from '@/lib/vx-auth'

/**
 * Chặn / bỏ chặn người dùng (kiểu Zalo/Facebook)
 *  - GET  : danh sách người tôi đã chặn
 *  - POST : { userId, action: 'block' | 'unblock' }
 * Sau khi chặn: 2 bên không thấy nhau trong tìm kiếm, không nhắn tin được cho nhau.
 */
export async function GET() {
  try {
    const me = await requireUser()
    const rows = await db.vxBlock.findMany({
      where: { blockerId: me.id },
      include: { blocked: { select: { id: true, username: true, fullName: true, avatarColor: true, avatarImage: true } } },
      orderBy: { createdAt: 'desc' },
    })
    return NextResponse.json({ blocked: rows.map((r) => r.blocked) })
  } catch {
    return NextResponse.json({ error: 'Không tải được danh sách chặn' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json().catch(() => ({}))
    const userId = String(body.userId || '')
    const action = body.action === 'unblock' ? 'unblock' : 'block'
    if (!userId || userId === me.id) return NextResponse.json({ error: 'Không hợp lệ' }, { status: 400 })

    if (action === 'block') {
      await db.vxBlock.upsert({
        where: { blockerId_blockedId: { blockerId: me.id, blockedId: userId } },
        create: { blockerId: me.id, blockedId: userId },
        update: {},
      })
      return NextResponse.json({ ok: true, blocked: true })
    }
    await db.vxBlock.deleteMany({ where: { blockerId: me.id, blockedId: userId } })
    return NextResponse.json({ ok: true, blocked: false })
  } catch {
    return NextResponse.json({ error: 'Không thực hiện được' }, { status: 500 })
  }
}
