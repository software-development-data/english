export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// Cày xu: đăng bài trong nhóm +5 xu (tối đa 8 lần/ngày, chung hạn mức với bảng tin)
async function rewardXu(userId: string, amount: number, reason: string, dailyCap: number) {
  const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0)
  const todayCount = await db.vxCoinTx.count({ where: { userId, reason: { startsWith: reason }, createdAt: { gte: startOfDay } } })
  if (todayCount >= dailyCap) return 0
  await db.vxUser.update({ where: { id: userId }, data: { coins: { increment: amount } } })
  await db.vxCoinTx.create({ data: { userId, amount, reason } })
  return amount
}

// GET /api/vx/groups/[id]/posts — bài đăng trong nhóm
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireUser()
    const { id } = await params
    const posts = await db.vxPost.findMany({
      where: { groupId: id },
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: {
        author: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true } },
        likes: { select: { userId: true, type: true } },
        comments: { include: { user: { select: { id: true, fullName: true, avatarColor: true } } } },
      },
    })
    return NextResponse.json(posts.map((p) => ({
      id: p.id,
      author: p.author,
      content: p.content,
      images: p.images ? JSON.parse(p.images) : [],
      createdAt: p.createdAt.toISOString(),
      likes: p.likes,
      comments: p.comments.map((c) => ({ id: c.id, content: c.content, user: c.user, createdAt: c.createdAt.toISOString() })),
    })))
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/groups/[id]/posts', e)
    return NextResponse.json({ error: 'Không tải được bài đăng' }, { status: 500 })
  }
}

// POST /api/vx/groups/[id]/posts — đăng bài vào nhóm (thành viên, +5 xu)
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const body = await req.json()
    const content = String(body.content || '').trim()
    const images = Array.isArray(body.images) ? body.images.slice(0, 4) : []
    if (!content && images.length === 0) return NextResponse.json({ error: 'Bài viết trống' }, { status: 400 })
    if (images.some((i: unknown) => typeof i === 'string' && i.length > 2_000_000)) {
      return NextResponse.json({ error: 'Ảnh quá lớn (tối đa ~1.5MB/ảnh)' }, { status: 400 })
    }
    const member = await db.vxGroupMember.findUnique({ where: { groupId_userId: { groupId: id, userId: me.id } } })
    if (!member) return NextResponse.json({ error: 'Bạn chưa tham gia nhóm này' }, { status: 403 })

    const post = await db.vxPost.create({
      data: {
        authorId: me.id,
        groupId: id,
        content: content.slice(0, 5000),
        images: images.length ? JSON.stringify(images) : null,
      },
      include: { author: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true } } },
    })

    // Thông báo cho thành viên khác
    const members = await db.vxGroupMember.findMany({ where: { groupId: id, userId: { not: me.id } }, select: { userId: true }, take: 60 })
    if (members.length) {
      await db.vxNotification.createMany({
        data: members.map((m) => ({ userId: m.userId, type: 'group', content: `${me.fullName} đã đăng bài mới trong nhóm` })),
      })
    }

    const reward = await rewardXu(me.id, 5, 'Thưởng đăng bài nhóm', 8)
    return NextResponse.json({
      id: post.id, author: post.author, content: post.content, images, createdAt: post.createdAt.toISOString(), likes: [], comments: [], reward,
    }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/groups/[id]/posts', e)
    return NextResponse.json({ error: 'Không đăng được bài' }, { status: 500 })
  }
}
