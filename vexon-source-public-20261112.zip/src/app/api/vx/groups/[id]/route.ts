export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELECT_USER = { id: true, username: true, fullName: true, avatarColor: true, avatarImage: true, department: true, title: true, online: true, role: true }

// GET /api/vx/groups/[id] — chi tiết nhóm + thành viên + bài đăng
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const group = await db.vxGroup.findUnique({
      where: { id },
      include: {
        creator: { select: SELECT_USER },
        members: { include: { user: { select: SELECT_USER } }, orderBy: { joinedAt: 'asc' } },
        posts: {
          orderBy: { createdAt: 'desc' },
          take: 50,
          include: {
            author: { select: { id: true, fullName: true, avatarColor: true, avatarImage: true, accountType: true, companyName: true } },
            likes: { select: { userId: true, type: true } },
            comments: {
              include: { user: { select: { id: true, fullName: true, avatarColor: true } } },
              orderBy: { createdAt: 'asc' },
            },
          },
        },
      },
    })
    if (!group) return NextResponse.json({ error: 'Nhóm không tồn tại' }, { status: 404 })

    const isMember = group.members.some((m) => m.userId === me.id)
    // Nhóm riêng tư: chỉ thành viên xem nội dung
    if (group.privacy === 'private' && !isMember) {
      return NextResponse.json({
        id: group.id, name: group.name, avatar: group.avatar, avatarImage: group.avatarImage, description: group.description,
        privacy: group.privacy, creator: group.creator, memberCount: group.members.length,
        myRole: null, joined: false,
        members: [], posts: [], locked: true,
      })
    }

    return NextResponse.json({
      id: group.id,
      name: group.name,
      avatar: group.avatar,
      avatarImage: group.avatarImage,
      description: group.description,
      privacy: group.privacy,
      creator: group.creator,
      memberCount: group.members.length,
      myRole: group.members.find((m) => m.userId === me.id)?.role || null,
      joined: isMember,
      members: group.members.map((m) => ({ ...m.user, memberRole: m.role })),
      posts: group.posts.map((p) => ({
        id: p.id,
        author: p.author,
        content: p.content,
        images: p.images ? JSON.parse(p.images) : [],
        createdAt: p.createdAt.toISOString(),
        likes: p.likes,
        comments: p.comments.map((c) => ({
          id: c.id,
          content: c.content,
          user: c.user,
          createdAt: c.createdAt.toISOString(),
        })),
        commentCount: p.comments.length,
      })),
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/groups/[id]', e)
    return NextResponse.json({ error: 'Không tải được nhóm' }, { status: 500 })
  }
}

// PATCH /api/vx/groups/[id] — tham gia / rời nhóm / cập nhật / thêm thành viên
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const body = await req.json()
    const group = await db.vxGroup.findUnique({ where: { id }, include: { members: true } })
    if (!group) return NextResponse.json({ error: 'Nhóm không tồn tại' }, { status: 404 })
    const myRole = group.members.find((m) => m.userId === me.id)?.role

    // Tham gia nhóm
    if (body.action === 'join') {
      if (myRole) return NextResponse.json({ ok: true })
      if (group.privacy === 'private' && group.createdById !== me.id && !['admin'].includes(me.role)) {
        return NextResponse.json({ error: 'Nhóm riêng tư — chỉ được vào theo lời mời' }, { status: 403 })
      }
      await db.vxGroupMember.create({ data: { groupId: id, userId: me.id } })
      return NextResponse.json({ ok: true, joined: true })
    }

    // Rời nhóm (chủ nhóm không rời được — phải xóa nhóm)
    if (body.action === 'leave') {
      if (myRole === 'owner') return NextResponse.json({ error: 'Chủ nhóm không thể rời — dùng Xóa nhóm' }, { status: 400 })
      await db.vxGroupMember.deleteMany({ where: { groupId: id, userId: me.id } })
      return NextResponse.json({ ok: true, joined: false })
    }

    // Mời thành viên {action:'invite', userIds}
    if (body.action === 'invite' && Array.isArray(body.userIds)) {
      if (!myRole) return NextResponse.json({ error: 'Chỉ thành viên mới mời được' }, { status: 403 })
      // SQLite không hỗ trợ skipDuplicates — lọc người đã trong nhóm trước
      const existing = await db.vxGroupMember.findMany({
        where: { groupId: id, userId: { in: body.userIds.slice(0, 50) } },
        select: { userId: true },
      })
      const newIds: string[] = body.userIds.slice(0, 50).filter((uid: string) => !existing.some((e) => e.userId === uid))
      if (newIds.length > 0) {
        await db.vxGroupMember.createMany({
          data: newIds.map((uid: string) => ({ groupId: id, userId: uid })),
        })
      }
      await db.vxNotification.createMany({
        data: newIds.map((uid: string) => ({ userId: uid, type: 'group', content: `${me.fullName} đã thêm bạn vào nhóm "${group.name}"` })),
      })
      return NextResponse.json({ ok: true })
    }

    // Cập nhật thông tin nhóm (chủ nhóm / admin nhóm)
    if (myRole !== 'owner' && me.role !== 'admin') return NextResponse.json({ error: 'Không có quyền' }, { status: 403 })
    const updated = await db.vxGroup.update({
      where: { id },
      data: {
        name: body.name ? String(body.name).slice(0, 120) : undefined,
        description: body.description !== undefined ? String(body.description).slice(0, 500) : undefined,
        privacy: ['public', 'private'].includes(body.privacy) ? body.privacy : undefined,
        avatar: typeof body.avatar === 'string' ? body.avatar.slice(0, 8) : undefined,
        avatarImage: body.avatarImage !== undefined
          ? (body.avatarImage && String(body.avatarImage).length <= 2_000_000 ? body.avatarImage : null)
          : undefined,
      },
    })
    return NextResponse.json({ ok: true, group: updated })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/groups/[id]', e)
    return NextResponse.json({ error: 'Không cập nhật được nhóm' }, { status: 500 })
  }
}

// DELETE /api/vx/groups/[id] — chủ nhóm hoặc Ban Giám đốc
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const group = await db.vxGroup.findUnique({ where: { id }, select: { createdById: true, name: true } })
    if (!group) return NextResponse.json({ error: 'Không tìm thấy' }, { status: 404 })
    if (group.createdById !== me.id && me.role !== 'admin') return NextResponse.json({ error: 'Chỉ chủ nhóm được xóa' }, { status: 403 })
    await db.vxGroup.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/groups/[id]', e)
    return NextResponse.json({ error: 'Không xóa được' }, { status: 500 })
  }
}
