export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELECT_USER = { id: true, username: true, fullName: true, avatarColor: true, avatarImage: true, department: true, online: true }
// Biểu tượng nhóm là key hình vector (đồng bộ GROUP_ICON_ITEMS) — không dùng kí tự emoji
const GROUP_ICON_KEYS = ['members', 'message', 'building', 'crane', 'rocket', 'party', 'football', 'food', 'megaphone', 'laptop', 'wrench', 'chart', 'leaf']

// GET /api/vx/groups?tab=mine|discover — nhóm của tôi / khám phá
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const tab = req.nextUrl.searchParams.get('tab') || 'mine'

    const where = tab === 'mine' ? { members: { some: { userId: me.id } } } : {}
    const groups = await db.vxGroup.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 100,
      include: {
        creator: { select: SELECT_USER },
        members: { include: { user: { select: SELECT_USER } } },
        _count: { select: { posts: true } },
      },
    })

    const list = groups.map((g) => ({
      id: g.id,
      name: g.name,
      avatar: g.avatar,
      avatarImage: g.avatarImage,
      description: g.description,
      privacy: g.privacy,
      creator: g.creator,
      memberCount: g.members.length,
      postCount: g._count.posts,
      myRole: g.members.find((m) => m.userId === me.id)?.role || null,
      joined: g.members.some((m) => m.userId === me.id),
      members: g.members.slice(0, 8).map((m) => m.user),
    }))
    return NextResponse.json(list)
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/groups', e)
    return NextResponse.json({ error: 'Không tải được nhóm' }, { status: 500 })
  }
}

// POST /api/vx/groups — tạo nhóm (body: {name, avatar?, description?, privacy?})
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const name = String(body.name || '').trim()
    if (!name) return NextResponse.json({ error: 'Nhập tên nhóm' }, { status: 400 })
    const avatar = GROUP_ICON_KEYS.includes(body.avatar) ? body.avatar : 'members'
    const group = await db.vxGroup.create({
      data: {
        name: name.slice(0, 120),
        avatar,
        description: body.description ? String(body.description).slice(0, 500) : null,
        privacy: body.privacy === 'private' ? 'private' : 'public',
        createdById: me.id,
        members: { create: { userId: me.id, role: 'owner' } },
      },
      include: { members: { include: { user: { select: SELECT_USER } } } },
    })
    return NextResponse.json({ id: group.id, name: group.name }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/groups', e)
    return NextResponse.json({ error: 'Không tạo được nhóm' }, { status: 500 })
  }
}
