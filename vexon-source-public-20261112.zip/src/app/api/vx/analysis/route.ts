export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

interface ColStat {
  name: string
  type: 'number' | 'text'
  min?: number
  max?: number
  avg?: number
  sum?: number
  distinct?: number
  top?: { v: string; c: number }[]
}

function detectDelimiter(lines: string[]): string {
  const sample = lines.slice(0, 5).join('\n')
  const counts: Record<string, number> = { ',': 0, ';': 0, '\t': 0, '|': 0 }
  for (const [d, c] of Object.entries(counts)) {
    counts[d] = sample.split(d).length - 1
  }
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][1] > 0 ? Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0] : ','
}

function splitCSVLine(line: string, delim: string): string[] {
  const out: string[] = []
  let cur = ''
  let inQuote = false
  for (let i = 0; i < line.length; i++) {
    const ch = line[i]
    if (ch === '"') {
      if (inQuote && line[i + 1] === '"') {
        cur += '"'
        i++
      } else inQuote = !inQuote
    } else if (ch === delim && !inQuote) {
      out.push(cur.trim())
      cur = ''
    } else cur += ch
  }
  out.push(cur.trim())
  return out
}

function analyzeTable(headers: string[], rows: string[][]): ColStat[] {
  return headers.map((name, i) => {
    const values = rows.map((r) => (r[i] ?? '').trim()).filter((v) => v !== '')
    const nums = values.map((v) => {
      const t = v.replace(/,(?=\d{3}\b)/g, '').replace(/[^\d.-]/g, '')
      return t === '' || t === '-' || t === '.' ? NaN : Number(t)
    })
    const numericRatio = values.length > 0 ? nums.filter((n) => !Number.isNaN(n) && Number.isFinite(n)).length / values.length : 0
    if (numericRatio > 0.8 && values.length > 0) {
      const valid = nums.filter((n) => !Number.isNaN(n) && Number.isFinite(n))
      const sum = valid.reduce((a, b) => a + b, 0)
      return {
        name,
        type: 'number' as const,
        min: Math.min(...valid),
        max: Math.max(...valid),
        avg: Math.round((sum / valid.length) * 100) / 100,
        sum: Math.round(sum * 100) / 100,
      }
    }
    const freq = new Map<string, number>()
    for (const v of values) freq.set(v, (freq.get(v) || 0) + 1)
    const top = [...freq.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([v, c]) => ({ v, c }))
    return { name, type: 'text' as const, distinct: freq.size, top }
  })
}

// GET /api/vx/analysis — lịch sử phân tích
export async function GET() {
  try {
    const me = await requireUser()
    const list = await db.vxFileAnalysis.findMany({
      where: { userId: me.id },
      orderBy: { createdAt: 'desc' },
      take: 20,
    })
    return NextResponse.json(
      list.map((f) => ({ ...f, summary: JSON.parse(f.summary) }))
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/analysis', e)
    return NextResponse.json({ error: 'Không tải được lịch sử' }, { status: 500 })
  }
}

// POST /api/vx/analysis  body: { name, content, size? } — phân tích file CSV/JSON
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const name = String(body.name || 'file').slice(0, 200)
    const content = String(body.content || '')
    if (!content.trim()) return NextResponse.json({ error: 'File rỗng hoặc không đọc được nội dung' }, { status: 400 })
    if (content.length > 3_000_000) return NextResponse.json({ error: 'File quá lớn (tối đa ~2MB)' }, { status: 400 })

    const isJson = name.toLowerCase().endsWith('.json') || content.trim().startsWith('[') || content.trim().startsWith('{')
    let headers: string[] = []
    let rows: string[][] = []

    if (isJson) {
      let data: unknown
      try {
        data = JSON.parse(content)
      } catch {
        return NextResponse.json({ error: 'JSON không hợp lệ' }, { status: 400 })
      }
      const arr = Array.isArray(data) ? data : [data]
      const objRows = arr.filter((r) => typeof r === 'object' && r !== null && !Array.isArray(r)) as Record<string, unknown>[]
      if (objRows.length === 0) return NextResponse.json({ error: 'JSON cần là mảng object hoặc object' }, { status: 400 })
      headers = [...new Set(objRows.flatMap((r) => Object.keys(r)))].slice(0, 30)
      rows = objRows.slice(0, 5000).map((r) => headers.map((h) => String(r[h] ?? '')))
    } else {
      const lines = content.split(/\r?\n/).filter((l) => l.trim() !== '')
      if (lines.length < 2) return NextResponse.json({ error: 'CSV cần ít nhất dòng tiêu đề + 1 dòng dữ liệu' }, { status: 400 })
      const delim = detectDelimiter(lines)
      headers = splitCSVLine(lines[0], delim).slice(0, 30)
      rows = lines.slice(1).slice(0, 5000).map((l) => splitCSVLine(l, delim))
    }

    const stats = analyzeTable(headers, rows)
    const record = await db.vxFileAnalysis.create({
      data: {
        userId: me.id,
        name,
        kind: isJson ? 'json' : 'csv',
        size: Number(body.size) > 0 ? Math.round(Number(body.size)) : content.length,
        rows: rows.length,
        columns: headers.length,
        summary: JSON.stringify({ columns: stats, preview: rows.slice(0, 10) }),
      },
    })

    return NextResponse.json({ ...record, summary: JSON.parse(record.summary) }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/analysis', e)
    return NextResponse.json({ error: 'Không phân tích được file' }, { status: 500 })
  }
}

// DELETE /api/vx/analysis?id=... — xoá khỏi lịch sử
export async function DELETE(req: NextRequest) {
  try {
    const me = await requireUser()
    const id = req.nextUrl.searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'Thiếu id' }, { status: 400 })
    const rec = await db.vxFileAnalysis.findUnique({ where: { id } })
    if (!rec || rec.userId !== me.id) return NextResponse.json({ error: 'Không tìm thấy bản ghi' }, { status: 404 })
    await db.vxFileAnalysis.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    return NextResponse.json({ error: 'Không xoá được' }, { status: 500 })
  }
}
