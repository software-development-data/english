export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { getUsdVnd } from '@/lib/vx-fx'
import { fmtUsdFromXu } from '@/lib/format'

const WORK_START = '08:00' // giờ bắt đầu ca (giống hệ thống PHP gốc)
const VN_TZ = 'Asia/Ho_Chi_Minh'

function nowVN() {
  return new Date(new Date().toLocaleString('en-US', { timeZone: VN_TZ }))
}

// GET: ?scope=me (lịch sử của tôi) | ?scope=today (toàn công ty hôm nay, admin/manager) | ?scope=month&month=YYYY-MM
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const scope = req.nextUrl.searchParams.get('scope') || 'me'
    const todayVN = nowVN().toISOString().slice(0, 10)

    if (scope === 'today') {
      if (!['admin', 'manager'].includes(me.role)) {
        return NextResponse.json({ error: 'Chỉ quản lý trở lên mới xem được' }, { status: 403 })
      }
      const users = await db.vxUser.findMany({
        select: { id: true, fullName: true, username: true, role: true, avatarColor: true, attendances: { where: { workDate: todayVN } } },
        orderBy: [{ role: 'asc' }, { fullName: 'asc' }],
      })
      const monthParam = req.nextUrl.searchParams.get('month') || todayVN.slice(0, 7)
      const monthStart = `${monthParam}-01`
      const [y, m] = monthParam.split('-').map(Number)
      const nextMonth = m === 12 ? `${y + 1}-01-01` : `${y}-${String(m + 1).padStart(2, '0')}-01`
      const monthRecords = await db.vxAttendance.findMany({
        where: { workDate: { gte: monthStart, lt: nextMonth } },
        include: { user: { select: { id: true, fullName: true } } },
      })
      const perUser = users.map((u) => {
        const recs = monthRecords.filter((r) => r.userId === u.id)
        return {
          id: u.id,
          fullName: u.fullName,
          username: u.username,
          role: u.role,
          avatarColor: u.avatarColor,
          today: u.attendances[0] || null,
          monthStats: {
            present: recs.filter((r) => r.status === 'present').length,
            late: recs.filter((r) => r.status === 'late').length,
            totalDays: recs.length,
          },
        }
      })
      return NextResponse.json({ date: todayVN, users: perUser })
    }

    // scope=me: lịch sử 60 lần gần nhất + trạng thái hôm nay
    const [history, today] = await Promise.all([
      db.vxAttendance.findMany({ where: { userId: me.id }, orderBy: { workDate: 'desc' }, take: 60 }),
      db.vxAttendance.findUnique({ where: { userId_workDate: { userId: me.id, workDate: todayVN } } }),
    ])
    return NextResponse.json({ date: todayVN, today, history })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/attendance', e)
    return NextResponse.json({ error: 'Không tải được chấm công' }, { status: 500 })
  }
}

// POST: { action: 'checkin' | 'checkout' }
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const { action } = await req.json()
    const now = nowVN()
    const todayVN = now.toISOString().slice(0, 10)
    const timeStr = now.toTimeString().slice(0, 5)

    if (action === 'checkin') {
      const existing = await db.vxAttendance.findUnique({ where: { userId_workDate: { userId: me.id, workDate: todayVN } } })
      if (existing?.checkIn) {
        return NextResponse.json({ error: `Bạn đã điểm danh vào lúc ${existing.checkIn} hôm nay` }, { status: 400 })
      }
      const [h, m] = timeStr.split(':').map(Number)
      const [wh, wm] = WORK_START.split(':').map(Number)
      const lateMinutes = Math.max(0, h * 60 + m - (wh * 60 + wm))
      const record = await db.vxAttendance.upsert({
        where: { userId_workDate: { userId: me.id, workDate: todayVN } },
        update: { checkIn: timeStr, status: lateMinutes > 0 ? 'late' : 'present', lateMinutes },
        create: { userId: me.id, workDate: todayVN, checkIn: timeStr, status: lateMinutes > 0 ? 'late' : 'present', lateMinutes },
      })
      // Cày xu: điểm danh làm việc được cộng 10 xu (chỉ lần đầu trong ngày)
      if (!existing?.checkIn) {
        const user = await db.vxUser.update({ where: { id: me.id }, data: { coins: { increment: 10 } } })
        await db.vxCoinTx.create({ data: { userId: me.id, amount: 10, reason: 'Thưởng điểm danh làm việc' } })
        const rate = (await getUsdVnd()).rate
        return NextResponse.json({ record, message: `Đã điểm danh vào lúc ${timeStr}${lateMinutes > 0 ? ` (muộn ${lateMinutes} phút)` : ''} · +${fmtUsdFromXu(10, rate)} (còn ${fmtUsdFromXu(user.coins, rate)})` })
      }
      return NextResponse.json({ record, message: `Đã điểm danh vào lúc ${timeStr}${lateMinutes > 0 ? ` (muộn ${lateMinutes} phút)` : ''}` })
    }

    if (action === 'checkout') {
      const existing = await db.vxAttendance.findUnique({ where: { userId_workDate: { userId: me.id, workDate: todayVN } } })
      if (!existing?.checkIn) {
        return NextResponse.json({ error: 'Bạn chưa điểm danh vào hôm nay' }, { status: 400 })
      }
      if (existing.checkOut) {
        return NextResponse.json({ error: `Bạn đã điểm danh ra lúc ${existing.checkOut}` }, { status: 400 })
      }
      const record = await db.vxAttendance.update({ where: { id: existing.id }, data: { checkOut: timeStr } })
      return NextResponse.json({ record, message: `Đã điểm danh ra lúc ${timeStr}` })
    }

    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/attendance', e)
    return NextResponse.json({ error: 'Không điểm danh được' }, { status: 500 })
  }
}
