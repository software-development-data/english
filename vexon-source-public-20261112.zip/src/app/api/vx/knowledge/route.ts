export const dynamic = 'force-dynamic'
export const maxDuration = 60

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const MAX_DOCS = 12
const MAX_CHARS = 400_000 // ~2 triệu ký tự tổng cho mọi tài liệu
const CHUNK = 900
const OVERLAP = 120

function splitChunks(text: string): string[] {
  const clean = text.replace(/\r/g, '').replace(/\n{3,}/g, '\n\n').trim()
  if (!clean) return []
  const out: string[] = []
  let i = 0
  while (i < clean.length && out.length < 2000) {
    out.push(clean.slice(i, i + CHUNK))
    i += CHUNK - OVERLAP
  }
  return out
}

/** Trích chữ từ PDF bằng pdfjs-dist (chạy server, không cần worker) */
async function pdfToText(buf: ArrayBuffer): Promise<string> {
  const pdfjs = (await import('pdfjs-dist/legacy/build/pdf.mjs')) as unknown as {
    getDocument: (src: { data: Uint8Array; isEvalSupported?: boolean; useSystemFonts?: boolean }) => { promise: Promise<PdfDoc> }
  }
  type PdfDoc = { numPages: number; getPage: (n: number) => Promise<{ getTextContent: () => Promise<{ items: { str?: string }[] }> }> }
  const doc = await pdfjs.getDocument({ data: new Uint8Array(buf), isEvalSupported: false, useSystemFonts: false }).promise
  const pages: string[] = []
  for (let p = 1; p <= Math.min(doc.numPages, 120); p++) {
    const page = await doc.getPage(p)
    const content = await page.getTextContent()
    pages.push(content.items.map((it) => it.str || '').join(' '))
  }
  return pages.join('\n\n')
}

// GET /api/vx/knowledge — danh sách tài liệu của tôi
export async function GET() {
  try {
    const me = await requireUser()
    const docs = await db.vxKnowledgeDoc.findMany({
      where: { userId: me.id },
      orderBy: { createdAt: 'desc' },
      include: { _count: { select: { chunks: true } } },
    })
    return NextResponse.json(
      docs.map((d) => ({ id: d.id, name: d.name, kind: d.kind, sizeChars: d.sizeChars, chunks: d._count.chunks, createdAt: d.createdAt })),
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/knowledge', e)
    return NextResponse.json({ error: 'Không tải được tài liệu' }, { status: 500 })
  }
}

// POST /api/vx/knowledge — tải lên tài liệu (FormData: file | name+text) làm kiến thức riêng cho Vexon AI
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const count = await db.vxKnowledgeDoc.count({ where: { userId: me.id } })
    if (count >= MAX_DOCS) {
      return NextResponse.json({ error: `Tối đa ${MAX_DOCS} tài liệu — xoá bớt để tải lên nhé` }, { status: 400 })
    }

    let name = ''
    let kind = 'paste'
    let text = ''

    const ct = req.headers.get('content-type') || ''
    if (ct.includes('multipart/form-data')) {
      const form = await req.formData()
      const file = form.get('file')
      if (!(file instanceof File)) return NextResponse.json({ error: 'Thiếu tệp tài liệu' }, { status: 400 })
      if (file.size > 8 * 1024 * 1024) return NextResponse.json({ error: 'Tệp quá lớn (tối đa 8MB)' }, { status: 400 })
      name = file.name
      const lower = name.toLowerCase()
      if (lower.endsWith('.pdf')) {
        kind = 'pdf'
        text = await pdfToText(await file.arrayBuffer())
      } else if (/\.(txt|md|csv|json|log|xml|html?)$/.test(lower)) {
        kind = lower.endsWith('.md') ? 'md' : lower.match(/\.([a-z]+)$/)?.[1] || 'txt'
        text = await file.text()
      } else {
        return NextResponse.json({ error: 'Chỉ hỗ trợ .pdf .txt .md .csv .json .log — hoặc dán thẳng nội dung' }, { status: 400 })
      }
    } else {
      const body = await req.json()
      name = String(body.name || '').trim() || 'Tài liệu dán tay'
      text = String(body.text || '')
    }

    text = text.replace(/\u0000/g, '').trim()
    if (text.length < 20) return NextResponse.json({ error: 'Nội dung quá ngắn hoặc không trích được chữ' }, { status: 400 })
    if (text.length > MAX_CHARS) text = text.slice(0, MAX_CHARS)

    const chunks = splitChunks(text)
    if (chunks.length === 0) return NextResponse.json({ error: 'Không có nội dung để học' }, { status: 400 })

    const doc = await db.vxKnowledgeDoc.create({
      data: {
        userId: me.id,
        name: name.slice(0, 120),
        kind,
        sizeChars: text.length,
        chunks: { create: chunks.map((t, idx) => ({ idx, text: t })) },
      },
      include: { _count: { select: { chunks: true } } },
    })
    return NextResponse.json({ id: doc.id, name: doc.name, kind: doc.kind, sizeChars: doc.sizeChars, chunks: doc._count.chunks, createdAt: doc.createdAt }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/knowledge', e)
    return NextResponse.json({ error: 'Không tải được tài liệu lên' }, { status: 500 })
  }
}
