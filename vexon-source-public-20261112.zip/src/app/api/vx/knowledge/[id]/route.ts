export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// DELETE /api/vx/knowledge/[id] — xoá tài liệu của chính mình
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const doc = await db.vxKnowledgeDoc.findUnique({ where: { id }, select: { userId: true } })
    if (!doc) return NextResponse.json({ error: 'Tài liệu không tồn tại' }, { status: 404 })
    if (doc.userId !== me.id) return NextResponse.json({ error: 'Chỉ chủ tài liệu mới được xoá' }, { status: 403 })
    await db.vxKnowledgeDoc.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/knowledge/[id]', e)
    return NextResponse.json({ error: 'Không xoá được tài liệu' }, { status: 500 })
  }
}
