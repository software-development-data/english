export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, hashPassword, setSessionCookie, clearSessionCookie, verifyPassword, publicUser } from '@/lib/vx-auth'

// GET: thông tin user hiện tại
export async function GET() {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ user: null })
  return NextResponse.json({ user: publicUser(user) })
}


// POST: { action: 'register' | 'login' | 'logout' }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const action = body.action

    if (action === 'logout') {
      await clearSessionCookie()
      return NextResponse.json({ ok: true })
    }

    // Đổi mật khẩu (từ Cài đặt → Bảo mật)
    if (action === 'change-password') {
      const { currentPassword, newPassword } = body as { currentPassword?: string; newPassword?: string }
      if (!currentPassword || !newPassword) {
        return NextResponse.json({ error: 'Vui lòng nhập đủ mật khẩu hiện tại và mật khẩu mới' }, { status: 400 })
      }
      if (String(newPassword).length < 6) {
        return NextResponse.json({ error: 'Mật khẩu mới tối thiểu 6 ký tự' }, { status: 400 })
      }
      const me = await getSessionUser()
      if (!me) return NextResponse.json({ error: 'Chưa đăng nhập' }, { status: 401 })
      const full = await db.vxUser.findUnique({ where: { id: me.id }, select: { passwordHash: true } })
      if (!full || !verifyPassword(String(currentPassword), full.passwordHash)) {
        return NextResponse.json({ error: 'Mật khẩu hiện tại không đúng' }, { status: 400 })
      }
      await db.vxUser.update({ where: { id: me.id }, data: { passwordHash: hashPassword(String(newPassword)) } })
      return NextResponse.json({ ok: true })
    }

    if (action === 'login') {
      const { username, password } = body
      if (!username || !password) {
        return NextResponse.json({ error: 'Vui lòng nhập tên đăng nhập và mật khẩu' }, { status: 400 })
      }
      const user = await db.vxUser.findFirst({
        where: { OR: [{ username: username.toLowerCase().trim() }, { email: username.toLowerCase().trim() }] },
      })
      if (!user || !verifyPassword(password, user.passwordHash)) {
        return NextResponse.json({ error: 'Sai tên đăng nhập hoặc mật khẩu' }, { status: 401 })
      }
      await setSessionCookie(user.id)
      return NextResponse.json({ user: publicUser(user) })
    }

    if (action === 'register') {
      // Đăng ký gọn: chỉ Họ và tên + Email + Mật khẩu.
      // Tên người dùng được sinh tự động từ email — sau này đổi được TỐI ĐA 1 LẦN trong Hồ sơ.
      // Ai cũng bắt đầu là tài khoản cá nhân; vào mạng xã hội rồi mới xin gia nhập / được công ty thêm vào.
      const { email, password, fullName } = body
      if (!email || !password || !fullName) {
        return NextResponse.json({ error: 'Vui lòng điền đầy đủ thông tin' }, { status: 400 })
      }
      if (password.length < 6) {
        return NextResponse.json({ error: 'Mật khẩu tối thiểu 6 ký tự' }, { status: 400 })
      }
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(email))) {
        return NextResponse.json({ error: 'Email không hợp lệ' }, { status: 400 })
      }
      const emailNorm = String(email).toLowerCase().trim()
      const emailExists = await db.vxUser.findUnique({ where: { email: emailNorm } })
      if (emailExists) {
        return NextResponse.json({ error: 'Email đã tồn tại' }, { status: 400 })
      }

      // Sinh tên người dùng duy nhất: phần trước @ của email, chỉ giữ a-z 0-9 _ . (tối thiểu 3 ký tự, kèm số ngẫu nhiên tránh trùng)
      const base = emailNorm.split('@')[0].replace(/[^a-z0-9_.]/g, '').slice(0, 14)
      const seed = base.length >= 3 ? base : `user${base || ''}`
      let un = seed
      for (let i = 0; i < 12; i++) {
        const cand = i === 0 ? seed : `${seed}${Math.floor(1000 + Math.random() * 9000)}`
        const taken = await db.vxUser.findUnique({ where: { username: cand } })
        if (!taken) { un = cand; break }
        if (i === 11) un = `${seed}${Date.now().toString().slice(-6)}`
      }

      const colors = ['#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4', '#ef4444', '#84cc16']
      const user = await db.vxUser.create({
        data: {
          username: un,
          email: emailNorm,
          passwordHash: hashPassword(String(password)),
          fullName: String(fullName).trim().slice(0, 80),
          role: 'employee',
          title: 'Thành viên',
          accountType: 'personal',
          avatarColor: colors[Math.floor(Math.random() * colors.length)],
        },
      })
      await setSessionCookie(user.id)
      return NextResponse.json({ user: publicUser(user) }, { status: 201 })
    }

    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
  } catch (e) {
    console.error('POST /api/vx/auth', e)
    return NextResponse.json({ error: 'Có lỗi xảy ra, vui lòng thử lại' }, { status: 500 })
  }
}
