export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError, publicUser } from '@/lib/vx-auth'

// Các mục hồ sơ có quyền riêng tư riêng kiểu Facebook (mặc định: công khai)
// Gồm cả mục hẹn hò/xã giao: chiều cao, cân nặng, tình trạng quan hệ, lối sống (rượu bia/thuốc lá/thú cưng), sở thích
// Gồm cả mục mở rộng: dân tộc, CCCD, mã số thuế
const FIELD_VIS_KEYS = ['bio', 'gender', 'hometown', 'education', 'phone', 'job', 'height', 'weight', 'relationship', 'lifestyle', 'interests', 'ethnicity', 'citizenId', 'taxCode'] as const
type FieldVisValue = 'public' | 'friends' | 'private'

function mergeFieldVis(oldVal: unknown, inVal: unknown): Record<FieldVisValue | string, string> {
  const old = (oldVal && typeof oldVal === 'object' && !Array.isArray(oldVal) ? oldVal : {}) as Record<string, unknown>
  const inc = (inVal && typeof inVal === 'object' && !Array.isArray(inVal) ? inVal : {}) as Record<string, unknown>
  const out: Record<string, string> = {}
  for (const k of FIELD_VIS_KEYS) {
    const v = inc[k] ?? old[k]
    out[k] = v === 'friends' || v === 'private' ? v : 'public'
  }
  return out
}


// PATCH /api/vx/profile — chỉnh sửa hồ sơ của tôi (tên, bio, sở thích, ẩn/hiện vị trí...)
export async function PATCH(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const data: Record<string, unknown> = {}
    // TÊN NGƯỜI DÙNG — chỉ được đổi TỐI ĐA 1 LẦN (đếm ở usernameChanges)
    if (typeof body.username === 'string' && body.username.trim()) {
      const newUn = body.username.toLowerCase().trim()
      if (newUn !== me.username) {
        if ((me.usernameChanges ?? 0) >= 1) {
          return NextResponse.json({ error: 'Bạn đã dùng lượt đổi tên người dùng duy nhất rồi' }, { status: 400 })
        }
        if (!/^[a-z0-9_.]{3,20}$/.test(newUn)) {
          return NextResponse.json({ error: 'Tên người dùng: 3-20 ký tự (a-z, 0-9, _ .)' }, { status: 400 })
        }
        const taken = await db.vxUser.findUnique({ where: { username: newUn } })
        if (taken) {
          return NextResponse.json({ error: 'Tên người dùng đã có người dùng' }, { status: 400 })
        }
        data.username = newUn
        data.usernameChanges = { increment: 1 }
      }
    }
    if (typeof body.fullName === 'string' && body.fullName.trim()) data.fullName = body.fullName.trim().slice(0, 80)
    if (typeof body.bio === 'string') data.bio = body.bio.slice(0, 300)
    if (typeof body.hometown === 'string') data.hometown = body.hometown.slice(0, 120)
    if (typeof body.education === 'string') data.education = body.education.slice(0, 120)
    if (typeof body.birthday === 'string') data.birthday = body.birthday ? new Date(body.birthday) : null
    if (typeof body.phone === 'string') data.phone = body.phone.slice(0, 20)
    if (typeof body.department === 'string') data.department = body.department.slice(0, 60)
    if (typeof body.title === 'string') data.title = body.title.slice(0, 60)
    if (typeof body.avatarColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(body.avatarColor)) data.avatarColor = body.avatarColor
    if (Array.isArray(body.interests)) data.interests = JSON.stringify(body.interests.map((i: unknown) => String(i).slice(0, 40)).slice(0, 10))
    // Hồ sơ hẹn hò + xã giao (chiều cao, cân nặng, tình trạng, lối sống) — thêm cho mạng xã hội tìm người yêu
    if (body.heightCm !== undefined) {
      const h = Math.round(Number(body.heightCm))
      data.heightCm = body.heightCm === null || body.heightCm === '' ? null : h >= 80 && h <= 250 ? h : null
    }
    if (body.weightKg !== undefined) {
      const w = Math.round(Number(body.weightKg))
      data.weightKg = body.weightKg === null || body.weightKg === '' ? null : w >= 20 && w <= 400 ? w : null
    }
    if (typeof body.relationship === 'string') data.relationship = body.relationship.slice(0, 40)
    if (body.relationship === null) data.relationship = null
    if (typeof body.smoking === 'string') data.smoking = body.smoking.slice(0, 40)
    if (body.smoking === null) data.smoking = null
    if (typeof body.drinking === 'string') data.drinking = body.drinking.slice(0, 40)
    if (body.drinking === null) data.drinking = null
    if (typeof body.pets === 'string') data.pets = body.pets.slice(0, 80)
    if (body.pets === null) data.pets = null
    // Giới tính (Nam | Nữ | Khác) — chọn từ danh sách hoặc nhập
    if (typeof body.gender === 'string') data.gender = body.gender.slice(0, 20)
    if (body.gender === null) data.gender = null
    // Hồ sơ mở rộng: dân tộc, CCCD, mã số thuế (cũng có quyền riêng tư riêng)
    if (typeof body.ethnicity === 'string') data.ethnicity = body.ethnicity.slice(0, 40)
    if (body.ethnicity === null) data.ethnicity = null
    if (typeof body.citizenId === 'string') data.citizenId = body.citizenId.replace(/[^0-9]/g, '').slice(0, 12)
    if (body.citizenId === null) data.citizenId = null
    if (typeof body.taxCode === 'string') data.taxCode = body.taxCode.replace(/[^0-9]/g, '').slice(0, 20)
    if (body.taxCode === null) data.taxCode = null
    if (typeof body.locationVisible === 'boolean') data.locationVisible = body.locationVisible
    if (typeof body.locationName === 'string') data.locationName = body.locationName.slice(0, 120)
    // Ảnh đại diện / ảnh bìa kiểu Facebook (dataUrl, giới hạn ~1.5MB)
    if (typeof body.avatarImage === 'string' && body.avatarImage.startsWith('data:image/')) {
      if (body.avatarImage.length > 2_000_000) return NextResponse.json({ error: 'Ảnh đại diện quá lớn (tối đa ~1.5MB)' }, { status: 400 })
      data.avatarImage = body.avatarImage
    }
    if (body.avatarImage === null) data.avatarImage = null
    if (typeof body.coverImage === 'string' && body.coverImage.startsWith('data:image/')) {
      if (body.coverImage.length > 2_400_000) return NextResponse.json({ error: 'Ảnh bìa quá lớn (tối đa ~1.8MB)' }, { status: 400 })
      data.coverImage = body.coverImage
    }
    if (body.coverImage === null) data.coverImage = null
    if (typeof body.coverColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(body.coverColor)) data.coverImage = null
    // Cài đặt (giao diện ngày/đêm, hiệu ứng 4 mùa, thông báo, quyền riêng tư hiển thị trạng thái...)
    if (body.settings && typeof body.settings === 'object' && !Array.isArray(body.settings)) {
      const s = body.settings as Record<string, unknown>
      // Gộp với cài đặt cũ để không mất key (fontSize, showOnline, showLastSeen...)
      let old: Record<string, unknown> = {}
      try { old = me.settings ? (JSON.parse(me.settings) as Record<string, unknown>) : {} } catch { /* bỏ qua */ }
      data.settings = JSON.stringify({
        ...old,
        // Nhận cả 'theme' lẫn 'mode' (client vx-theme gửi mode, đồng bộ login gửi theme)
        theme: s.theme === 'night' || s.mode === 'night' ? 'night' : s.theme === 'day' || s.mode === 'day' ? 'day' : (typeof old.theme === 'string' ? old.theme : 'day'),
        effect: ['auto', 'spring', 'summer', 'autumn', 'winter', 'rain', 'off'].includes(String(s.effect)) ? s.effect : (typeof old.effect === 'string' ? old.effect : 'auto'),
        effectsOn: typeof s.effectsOn === 'boolean' ? s.effectsOn : old.effectsOn !== false,
        notifSound: typeof s.notifSound === 'boolean' ? s.notifSound : old.notifSound !== false,
        fontSize: ['small', 'medium', 'large'].includes(String(s.fontSize)) ? s.fontSize : (['small', 'medium', 'large'].includes(String(old.fontSize)) ? old.fontSize : 'medium'),
        showOnline: typeof s.showOnline === 'boolean' ? s.showOnline : old.showOnline !== false,
        showLastSeen: typeof s.showLastSeen === 'boolean' ? s.showLastSeen : old.showLastSeen !== false,
        // Quyền riêng tư năm sinh: công khai | bạn bè | riêng tư
        birthdayVisibility: ['public', 'friends', 'private'].includes(String(s.birthdayVisibility)) ? s.birthdayVisibility : (typeof old.birthdayVisibility === 'string' && ['public', 'friends', 'private'].includes(String(old.birthdayVisibility)) ? old.birthdayVisibility : 'public'),
        // Quyền riêng tư TỪNG MỤC hồ sơ kiểu Facebook: bio / hometown / education / phone / job → public | friends | private
        fieldVis: mergeFieldVis(old.fieldVis, s.fieldVis),
      })
    }

    // NÂNG CẤP DOANH NGHIỆP giờ là quy trình: nộp đơn tốn xu → chờ admin duyệt ở /api/vx/business-upgrade
    // (không còn nâng cấp tức thời ở đây; khối cũ upgradeBusiness đã dời đi)

    const user = await db.vxUser.update({ where: { id: me.id }, data })
    const fresh = await db.vxUser.findUnique({ where: { id: me.id } })
    return NextResponse.json({ ok: true, user: publicUser(fresh ?? user) })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/profile', e)
    return NextResponse.json({ error: 'Không lưu được hồ sơ' }, { status: 500 })
  }
}
