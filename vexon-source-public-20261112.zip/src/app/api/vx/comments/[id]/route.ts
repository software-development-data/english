export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// PATCH /api/vx/comments/[id] — SỬA bình luận (chỉ chủ bình luận)
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const c = await db.vxComment.findUnique({ where: { id } })
    if (!c) return NextResponse.json({ error: 'Bình luận không tồn tại' }, { status: 404 })
    if (c.userId !== me.id) return NextResponse.json({ error: 'Chỉ sửa được bình luận của mình' }, { status: 403 })

    const body = await req.json()
    const content = String(body.content || '').trim()
    if (!content && !c.imageUrl && !c.sticker) return NextResponse.json({ error: 'Nội dung không được trống' }, { status: 400 })

    const updated = await db.vxComment.update({
      where: { id },
      data: { content: content.slice(0, 1000) },
      include: { user: { select: { id: true, username: true, fullName: true, role: true, avatarColor: true } } },
    })
    return NextResponse.json({ ...updated, edited: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/comments/[id]', e)
    return NextResponse.json({ error: 'Không sửa được bình luận' }, { status: 500 })
  }
}

// DELETE /api/vx/comments/[id] — XOÁ bình luận (chủ bình luận hoặc chủ bài viết)
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const c = await db.vxComment.findUnique({ where: { id }, include: { post: { select: { authorId: true } } } })
    if (!c) return NextResponse.json({ error: 'Bình luận không tồn tại' }, { status: 404 })
    if (c.userId !== me.id && c.post.authorId !== me.id && me.role !== 'admin') {
      return NextResponse.json({ error: 'Không có quyền xoá bình luận này' }, { status: 403 })
    }

    // Xoá cả replies con (cascade đã xử lý, xoá đệ quy cho chắc)
    await db.vxComment.deleteMany({ where: { parentId: id } })
    await db.vxComment.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/comments/[id]', e)
    return NextResponse.json({ error: 'Không xoá được bình luận' }, { status: 500 })
  }
}
