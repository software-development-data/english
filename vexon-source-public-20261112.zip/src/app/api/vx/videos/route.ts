export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { writeFile, mkdir } from 'fs/promises'
import path from 'path'
import { randomBytes } from 'crypto'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELECT_USER = { id: true, username: true, fullName: true, role: true, avatarColor: true }

// GET: feed video (của mọi kênh, mới nhất trước)
export async function GET() {
  try {
    const me = await requireUser()
    const videos = await db.vxVideo.findMany({
      include: {
        user: { select: SELECT_USER },
        likes: { select: { userId: true } },
        comments: { include: { user: { select: SELECT_USER } }, orderBy: { createdAt: 'desc' }, take: 20 },
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    })
    const follows = await db.vxFollow.findMany({ where: { followerId: me.id }, select: { followingId: true } })
    const followingIds = new Set(follows.map((f) => f.followingId))
    return NextResponse.json(
      videos.map((v) => ({
        id: v.id,
        user: v.user,
        caption: v.caption,
        url: v.url,
        views: v.views,
        createdAt: v.createdAt,
        likeCount: v.likes.length,
        likedByMe: v.likes.some((l) => l.userId === me.id),
        commentCount: v.comments.length,
        comments: v.comments.map((c) => ({ id: c.id, content: c.content, createdAt: c.createdAt, user: c.user })),
        following: followingIds.has(v.userId),
      }))
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/videos', e)
    return NextResponse.json({ error: 'Không tải được video' }, { status: 500 })
  }
}

// POST: đăng video (multipart: file + caption)
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const form = await req.formData()
    const file = form.get('file') as File | null
    const caption = String(form.get('caption') || '').trim()

    if (!file || file.size === 0) return NextResponse.json({ error: 'Vui lòng chọn file video' }, { status: 400 })
    if (!file.type.startsWith('video/')) return NextResponse.json({ error: 'Chỉ chấp nhận file video' }, { status: 400 })
    if (file.size > 60 * 1024 * 1024) return NextResponse.json({ error: 'Video tối đa 60MB' }, { status: 400 })
    if (!caption) return NextResponse.json({ error: 'Vui lòng nhập mô tả' }, { status: 400 })

    const ext = (file.name.split('.').pop() || 'mp4').toLowerCase().replace(/[^a-z0-9]/g, '') || 'mp4'
    const filename = `vx_${Date.now()}_${randomBytes(4).toString('hex')}.${ext}`
    const dir = path.join(process.cwd(), 'public', 'uploads', 'videos')
    await mkdir(dir, { recursive: true })
    await writeFile(path.join(dir, filename), Buffer.from(await file.arrayBuffer()))

    const video = await db.vxVideo.create({
      data: { userId: me.id, caption: caption.slice(0, 300), url: `/uploads/videos/${filename}` },
      include: { user: { select: SELECT_USER }, likes: true, comments: true },
    })
    return NextResponse.json(
      { id: video.id, user: video.user, caption: video.caption, url: video.url, views: 0, likeCount: 0, likedByMe: false, commentCount: 0, comments: [], following: false },
      { status: 201 }
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/videos', e)
    return NextResponse.json({ error: 'Không đăng được video' }, { status: 500 })
  }
}
