export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELECT_USER = { id: true, username: true, fullName: true, role: true, avatarColor: true }

// POST: bình luận video
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const video = await db.vxVideo.findUnique({ where: { id } })
    if (!video) return NextResponse.json({ error: 'Video không tồn tại' }, { status: 404 })
    const { content } = await req.json()
    if (!content || !String(content).trim()) return NextResponse.json({ error: 'Nội dung trống' }, { status: 400 })

    const comment = await db.vxVideoComment.create({
      data: { videoId: id, userId: me.id, content: String(content).trim().slice(0, 500) },
      include: { user: { select: SELECT_USER } },
    })
    if (video.userId !== me.id) {
      await db.vxNotification.create({
        data: { userId: video.userId, type: 'comment', content: `${me.fullName} đã bình luận video của bạn` },
      })
    }
    const count = await db.vxVideoComment.count({ where: { videoId: id } })
    return NextResponse.json({ ...comment, commentCount: count }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/videos/[id]/comments', e)
    return NextResponse.json({ error: 'Không gửi được bình luận' }, { status: 500 })
  }
}
