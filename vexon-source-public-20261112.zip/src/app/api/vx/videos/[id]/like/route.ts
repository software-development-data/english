export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST: thích / bỏ thích video
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const video = await db.vxVideo.findUnique({ where: { id } })
    if (!video) return NextResponse.json({ error: 'Video không tồn tại' }, { status: 404 })

    const existing = await db.vxVideoLike.findUnique({
      where: { videoId_userId: { videoId: id, userId: me.id } },
    })
    if (existing) {
      await db.vxVideoLike.delete({ where: { id: existing.id } })
    } else {
      await db.vxVideoLike.create({ data: { videoId: id, userId: me.id } })
      if (video.userId !== me.id) {
        await db.vxNotification.create({
          data: { userId: video.userId, type: 'like', content: `${me.fullName} đã thích video của bạn` },
        })
      }
    }
    const count = await db.vxVideoLike.count({ where: { videoId: id } })
    return NextResponse.json({ liked: !existing, likeCount: count })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/videos/[id]/like', e)
    return NextResponse.json({ error: 'Không thực hiện được' }, { status: 500 })
  }
}
