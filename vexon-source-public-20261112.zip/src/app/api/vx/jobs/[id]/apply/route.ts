export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/jobs/[id]/apply — ứng tuyển 1-click (kèm CV số)
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const job = await db.vxJob.findUnique({ where: { id }, include: { company: true } })
    if (!job) return NextResponse.json({ error: 'Không tìm thấy tin tuyển dụng' }, { status: 404 })
    if (job.company.ownerId === me.id) return NextResponse.json({ error: 'Không thể ứng tuyển vào công ty của chính mình' }, { status: 400 })

    const existing = await db.vxApplication.findUnique({ where: { jobId_userId: { jobId: id, userId: me.id } } })
    if (existing) return NextResponse.json({ error: 'Bạn đã ứng tuyển vị trí này rồi' }, { status: 400 })

    const body = await req.json().catch(() => ({}))
    const cv = await db.vxCandidate.findUnique({ where: { userId: me.id } })

    await db.vxApplication.create({
      data: {
        jobId: id,
        userId: me.id,
        coverNote: body.coverNote ? String(body.coverNote).slice(0, 1000) : null,
        cvSnapshot: cv ? JSON.stringify({ headline: cv.headline, skills: cv.skills, experiences: cv.experiences, education: cv.education, phone: cv.phone, desiredSalary: cv.desiredSalary }) : null,
      },
    })
    await db.vxNotification.create({
      data: { userId: job.company.ownerId, type: 'job_apply', content: `${me.fullName} vừa ứng tuyển vị trí "${job.title}"` },
    })
    return NextResponse.json({ ok: true }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST apply', e)
    return NextResponse.json({ error: 'Không ứng tuyển được' }, { status: 500 })
  }
}
