export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// GET /api/vx/jobs?q=&industry=&workType=&mine=1 — cổng tìm kiếm việc làm
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const sp = req.nextUrl.searchParams
    const q = (sp.get('q') || '').toLowerCase()
    const workType = sp.get('workType') || ''

    if (sp.get('mine') === '1') {
      const myCompany = await db.vxCompany.findUnique({ where: { ownerId: me.id }, include: { jobs: { orderBy: { createdAt: 'desc' }, include: { _count: { select: { applications: true } } } } } })
      return NextResponse.json({
        myJobs: (myCompany?.jobs || []).map((j) => ({ ...j, applicantCount: j._count.applications })),
        companyName: myCompany?.name || null,
      })
    }

    const myApplications = await db.vxApplication.findMany({ where: { userId: me.id }, select: { jobId: true, status: true } })
    const appliedMap = new Map(myApplications.map((a) => [a.jobId, a.status]))

    const jobs = await db.vxJob.findMany({
      where: {
        status: 'open',
        AND: [
          q ? { OR: [{ title: { contains: q } }, { description: { contains: q } }, { location: { contains: q } }, { company: { is: { name: { contains: q } } } }, { company: { is: { industry: { contains: q } } } }] } : {},
          workType ? { workType } : {},
        ].filter((c) => 'OR' in c || 'workType' in c),
      },
      include: { company: { select: { id: true, name: true, industry: true, size: true, ratingAvg: true, ratingCount: true, address: true, owner: { select: { avatarColor: true } } } }, _count: { select: { applications: true } } },
      orderBy: { createdAt: 'desc' },
    })

    const industries = await db.vxJob.findMany({ select: { company: { select: { industry: true } } }, distinct: ['companyId'] })

    return NextResponse.json({
      jobs: jobs.map((j) => ({
        id: j.id, title: j.title, location: j.location, workType: j.workType,
        salaryMin: j.salaryMin, salaryMax: j.salaryMax, experience: j.experience,
        description: j.description, requirements: j.requirements ? JSON.parse(j.requirements) : [],
        benefits: j.benefits ? JSON.parse(j.benefits) : [],
        createdAt: j.createdAt,
        company: { ...j.company, ratingAvg: Math.round(j.company.ratingAvg * 10) / 10 },
        applicantCount: j._count.applications,
        myStatus: appliedMap.get(j.id) || null,
      })),
      industries: [...new Set(industries.map((i) => i.company.industry))],
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/jobs', e)
    return NextResponse.json({ error: 'Không tải được tin tuyển dụng' }, { status: 500 })
  }
}

// POST /api/vx/jobs — doanh nghiệp đăng tin tuyển dụng
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const company = await db.vxCompany.findUnique({ where: { ownerId: me.id } })
    if (!company) return NextResponse.json({ error: 'Chỉ tài khoản doanh nghiệp đã tạo hồ sơ mới đăng tin' }, { status: 403 })

    const body = await req.json()
    const title = String(body.title || '').trim()
    if (!title || !String(body.description || '').trim()) return NextResponse.json({ error: 'Thiếu chức danh hoặc mô tả' }, { status: 400 })

    const job = await db.vxJob.create({
      data: {
        companyId: company.id,
        title: title.slice(0, 120),
        location: String(body.location || 'Tại văn phòng').slice(0, 120),
        workType: ['full_time', 'part_time', 'remote', 'contract'].includes(body.workType) ? body.workType : 'full_time',
        salaryMin: Math.max(0, Math.round(Number(body.salaryMin) || 0)),
        salaryMax: Math.max(0, Math.round(Number(body.salaryMax) || 0)),
        experience: String(body.experience || 'Không yêu cầu').slice(0, 80),
        description: String(body.description).slice(0, 3000),
        requirements: Array.isArray(body.requirements) ? JSON.stringify(body.requirements.map((r: unknown) => String(r).slice(0, 200)).slice(0, 15)) : null,
        benefits: Array.isArray(body.benefits) ? JSON.stringify(body.benefits.map((b: unknown) => String(b).slice(0, 200)).slice(0, 15)) : null,
      },
    })
    return NextResponse.json({ ok: true, job }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/jobs', e)
    return NextResponse.json({ error: 'Không đăng được tin' }, { status: 500 })
  }
}
