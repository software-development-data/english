export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELECT_SENDER = { id: true, username: true, fullName: true, role: true, avatarColor: true }

// POST /api/vx/messages/[id]/forward  body: { conversationId } — chuyển tiếp tin nhắn
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const { conversationId } = await req.json()

    const message = await db.vxMessage.findUnique({ where: { id }, include: { sender: { select: SELECT_SENDER } } })
    if (!message) return NextResponse.json({ error: 'Tin nhắn không tồn tại' }, { status: 404 })

    const membership = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: String(conversationId), userId: me.id } },
    })
    if (!membership) return NextResponse.json({ error: 'Không có quyền gửi vào hội thoại đích' }, { status: 403 })

    const originName = message.sender.id === me.id ? 'bản thân' : message.sender.fullName

    const copy = await db.vxMessage.create({
      data: {
        conversationId: String(conversationId),
        senderId: me.id,
        content: message.content,
        type: message.type,
        fileUrl: message.fileUrl,
        fileName: message.fileName,
        fileSize: message.fileSize,
        duration: message.duration,
        forwardedFrom: originName,
        status: 'sent',
      },
      include: { sender: { select: SELECT_SENDER }, replyTo: { include: { sender: { select: { fullName: true } } } } },
    })

    return NextResponse.json(
      {
        id: copy.id,
        content: copy.content,
        type: copy.type,
        fileUrl: copy.fileUrl,
        fileName: copy.fileName,
        fileSize: copy.fileSize,
        duration: copy.duration,
        forwardedFrom: copy.forwardedFrom,
        reactions: {},
        status: copy.status,
        unsent: copy.unsent,
        pinned: copy.pinned,
        createdAt: copy.createdAt,
        senderId: copy.senderId,
        sender: copy.sender,
        replyTo: null,
      },
      { status: 201 }
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/messages/[id]/forward', e)
    return NextResponse.json({ error: 'Không chuyển tiếp được' }, { status: 500 })
  }
}
