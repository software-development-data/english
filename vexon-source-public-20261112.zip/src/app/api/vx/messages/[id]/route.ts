export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// PATCH /api/vx/messages/[id] — reaction / thu hồi / ghim
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const body = await req.json()
    const message = await db.vxMessage.findUnique({ where: { id } })
    if (!message) return NextResponse.json({ error: 'Tin nhắn không tồn tại' }, { status: 404 })
    const membership = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: message.conversationId, userId: me.id } },
    })
    if (!membership) return NextResponse.json({ error: 'Không có quyền' }, { status: 403 })

    const action = String(body.action || '')

    if (action === 'react') {
      // Reaction key: LOVE/LIKE/HAHA... (dữ liệu cũ lưu emoji vẫn hiển thị được)
      const emoji = String(body.emoji || 'LOVE').slice(0, 12)
      const map = message.reactions ? JSON.parse(message.reactions) : {}
      const names: string[] = map[emoji] || []
      const idx = names.indexOf(me.fullName)
      if (idx >= 0) names.splice(idx, 1)
      else names.push(me.fullName)
      if (names.length === 0) delete map[emoji]
      else map[emoji] = names
      const updated = await db.vxMessage.update({
        where: { id },
        data: { reactions: JSON.stringify(map) },
      })
      return NextResponse.json({ reactions: JSON.parse(updated.reactions || '{}') })
    }

    if (action === 'unsend') {
      if (message.senderId !== me.id) {
        return NextResponse.json({ error: 'Chỉ thu hồi được tin nhắn của chính mình' }, { status: 403 })
      }
      await db.vxMessage.update({ where: { id }, data: { unsent: true, content: '', fileUrl: null, reactions: null } })
      return NextResponse.json({ ok: true })
    }

    if (action === 'pin') {
      const updated = await db.vxMessage.update({ where: { id }, data: { pinned: !message.pinned } })
      return NextResponse.json({ pinned: updated.pinned })
    }

    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/messages/[id]', e)
    return NextResponse.json({ error: 'Không thực hiện được' }, { status: 500 })
  }
}

// DELETE /api/vx/messages/[id] — thật ra chỉ thả reaction nhanh ❤️ (không xoá dữ liệu)
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return PATCH(req, { params })
}
