export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const SELECT_MEMBER = {
  id: true, username: true, fullName: true, role: true, department: true, avatarColor: true, online: true, lastSeen: true,
}
const SELECT_SENDER = { id: true, username: true, fullName: true, role: true, avatarColor: true }

// GET /api/vx/conversations — danh sách hội thoại của tôi
export async function GET() {
  try {
    const me = await requireUser()
    const memberships = await db.vxConversationMember.findMany({
      where: { userId: me.id },
      include: {
        conversation: {
          include: {
            members: { include: { user: { select: SELECT_MEMBER } } },
            messages: { orderBy: { createdAt: 'desc' }, take: 30, include: { sender: { select: SELECT_SENDER } } },
            topics: { select: { id: true } },
          },
        },
      },
    })

    // Tin nhắn tự xóa (kiểu TTO): xoá tin đã quá hạn của hội thoại có bật tự xóa
    const nowMs = Date.now()
    for (const m of memberships) {
      if (m.autoDeleteHours > 0) {
        const cutoff = new Date(nowMs - m.autoDeleteHours * 3600 * 1000)
        await db.vxMessage.deleteMany({ where: { conversationId: m.conversationId, createdAt: { lt: cutoff } } })
      }
    }

    const list = memberships
      .map(({ conversation, lastReadAt, role, pinned, hidden, muted, autoDeleteHours }) => {
        const others = conversation.members.filter((m) => m.userId !== me.id)
        const last = conversation.messages[0] || null
        const unread = conversation.messages.filter(
          (m) => m.senderId !== me.id && m.createdAt > lastReadAt
        ).length
        const pinnedCount = conversation.messages.filter((m) => m.pinned).length
        const name = conversation.isGroup
          ? conversation.name || 'Nhóm chat'
          : others[0]?.user.fullName || 'Cuộc trò chuyện'
        return {
          id: conversation.id,
          isGroup: conversation.isGroup,
          isForum: conversation.isForum,
          avatar: conversation.avatar,
          avatarImage: conversation.avatarImage,
          description: conversation.description,
          topicCount: conversation.topics ? conversation.topics.length : 0,
          name,
          myRole: role,
          partner: conversation.isGroup ? null : others[0]?.user || null,
          members: conversation.members.map((m) => ({ ...m.user, memberRole: m.role })),
          lastMessage: last
            ? {
                content: last.unsent ? 'Tin nhắn đã thu hồi' : last.content,
                type: last.type,
                createdAt: last.createdAt,
                senderId: last.senderId,
                senderName: last.sender.fullName,
              }
            : null,
          pinnedCount,
          unread,
          pinned,
          hidden,
          muted,
          autoDeleteHours,
          lastAt: last?.createdAt || conversation.createdAt,
        }
      })
      // Ghim hội thoại lên đầu (kiểu Telegram/Zalo), còn lại theo tin mới nhất
      .sort((a, b) => (a.pinned === b.pinned ? (a.lastAt < b.lastAt ? 1 : -1) : a.pinned ? -1 : 1))

    return NextResponse.json(list)
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/conversations', e)
    return NextResponse.json({ error: 'Không tải được hội thoại' }, { status: 500 })
  }
}

// POST /api/vx/conversations  body: { userIds: string[], name?, avatar?, description?, isForum? }
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const { userIds, name, avatar, description, isForum } = await req.json()
    if (!Array.isArray(userIds) || userIds.length === 0) {
      return NextResponse.json({ error: 'Chọn ít nhất 1 người' }, { status: 400 })
    }
    const isGroup = Boolean(name && String(name).trim()) || userIds.length > 1
    const forum = isGroup && Boolean(isForum)

    // Nhắn riêng: tái sử dụng hội thoại 1-1 đã có
    if (!isGroup) {
      const mine = await db.vxConversationMember.findMany({
        where: { userId: me.id },
        include: { conversation: { include: { members: true } } },
      })
      const target = String(userIds[0])
      const existing = mine.find(
        (m) =>
          !m.conversation.isGroup &&
          m.conversation.members.length === 2 &&
          m.conversation.members.some((mm) => mm.userId === target)
      )
      if (existing) return NextResponse.json({ id: existing.conversation.id })
    }

    const conv = await db.vxConversation.create({
      data: {
        isGroup,
        name: isGroup ? String(name || '').trim().slice(0, 80) || null : null,
        avatar: isGroup && avatar ? String(avatar).slice(0, 4) : null,
        description: isGroup && description ? String(description).trim().slice(0, 300) : null,
        isForum: forum,
        // "Tổng hợp" là mục mặc định ảo (tin topicId=null) — không tạo topic thật
        members: {
          create: [
            { userId: me.id, role: isGroup ? 'admin' : 'member' },
            ...userIds.map((id: string) => ({ userId: String(id), role: 'member' })),
          ],
        },
      },
    })
    return NextResponse.json({ id: conv.id }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/conversations', e)
    return NextResponse.json({ error: 'Không tạo được hội thoại' }, { status: 500 })
  }
}
