export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// PATCH /api/vx/conversations/[id] — cập nhật nhóm: tên, avatar emoji/ảnh, mô tả, bật/tắt Chủ đề, ghim hội thoại
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const membership = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: me.id } },
    })
    if (!membership) return NextResponse.json({ error: 'Không có quyền sửa nhóm này' }, { status: 403 })

    const body = await req.json()

    // Ghim/bỏ ghim hội thoại — áp dụng cho cả 1-1 và nhóm (kiểu Telegram/Zalo)
    if (body.pin !== undefined) {
      await db.vxConversationMember.update({
        where: { id: membership.id },
        data: { pinned: Boolean(body.pin) },
      })
      return NextResponse.json({ ok: true, pinned: Boolean(body.pin) })
    }

    // Cài đặt hội thoại kiểu TTO inbox v32: ẩn / tắt thông báo / tự xóa (theo từng thành viên)
    if (body.hidden !== undefined || body.muted !== undefined || body.autoDeleteHours !== undefined) {
      const data: Record<string, unknown> = {}
      if (body.hidden !== undefined) data.hidden = Boolean(body.hidden)
      if (body.muted !== undefined) data.muted = Boolean(body.muted)
      if (body.autoDeleteHours !== undefined) {
        const hours = Math.max(0, Math.min(24 * 30, Math.round(Number(body.autoDeleteHours) || 0)))
        data.autoDeleteHours = hours
      }
      await db.vxConversationMember.update({ where: { id: membership.id }, data })
      return NextResponse.json({ ok: true, ...data })
    }

    // Xóa lịch sử trò chuyện (cả hai phía, kiểu "Xóa lịch sử trò chuyện" TTO)
    if (body.clearHistory === true) {
      await db.vxMessage.deleteMany({ where: { conversationId: id } })
      await db.vxTopic.deleteMany({ where: { conversationId: id } })
      return NextResponse.json({ ok: true })
    }

    const conv = await db.vxConversation.findUnique({ where: { id } })
    if (!conv || !conv.isGroup) return NextResponse.json({ error: 'Chỉ nhóm chat mới chỉnh sửa được' }, { status: 400 })

    const data: Record<string, unknown> = {}

    if (body.name !== undefined) {
      const name = String(body.name).trim().slice(0, 80)
      if (!name) return NextResponse.json({ error: 'Tên nhóm không được trống' }, { status: 400 })
      data.name = name
    }
    if (body.avatar !== undefined) data.avatar = body.avatar ? String(body.avatar).slice(0, 4) : null
    if (body.avatarImage !== undefined) {
      if (body.avatarImage && String(body.avatarImage).length > 2_000_000) {
        return NextResponse.json({ error: 'Ảnh nhóm quá lớn (tối đa ~1.5MB)' }, { status: 400 })
      }
      data.avatarImage = body.avatarImage || null
    }
    if (body.description !== undefined) data.description = String(body.description).trim().slice(0, 300) || null

    // "Tổng hợp" luôn là mục ảo (tin topicId=null) — bật forum không cần tạo topic thật
    if (body.isForum !== undefined) data.isForum = Boolean(body.isForum)

    await db.vxConversation.update({ where: { id }, data })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/conversations/[id]', e)
    return NextResponse.json({ error: 'Không cập nhật được nhóm' }, { status: 500 })
  }
}

// DELETE /api/vx/conversations/[id] — Rời nhóm (kiểu TTO group-manage)
//  · Nhóm 1-1: chỉ ẩn hội thoại phía tôi (hidden=true)
//  · Nhóm chat: thành viên rời tự do; trưởng nhóm phải chuyển quyền trước; trưởng nhóm cuối cùng → giải tán nhóm
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const conv = await db.vxConversation.findUnique({ where: { id }, include: { members: true } })
    if (!conv) return NextResponse.json({ error: 'Không tìm thấy hội thoại' }, { status: 404 })

    const membership = conv.members.find((m) => m.userId === me.id)
    if (!membership) return NextResponse.json({ error: 'Bạn không ở trong hội thoại này' }, { status: 403 })

    if (!conv.isGroup) {
      // 1-1 — ẩn hội thoại phía tôi (kiểu "Xóa hội thoại" TTO)
      await db.vxConversationMember.update({ where: { id: membership.id }, data: { hidden: true } })
      return NextResponse.json({ ok: true, mode: 'hidden' })
    }

    const others = conv.members.filter((m) => m.userId !== me.id)
    if (others.length === 0) {
      // Ở một mình → giải tán nhóm
      await db.vxConversation.delete({ where: { id } })
      return NextResponse.json({ ok: true, mode: 'dissolved' })
    }
    if (membership.role === 'admin') {
      // Trưởng nhóm phải chuyển quyền trước (kiểu TTO: hand over admin before leaving)
      return NextResponse.json({ error: 'Bạn là trưởng nhóm — hãy chuyển quyền trưởng nhóm cho 1 thành viên khác trước khi rời nhóm' }, { status: 403 })
    }
    await db.vxConversationMember.delete({ where: { id: membership.id } })
    return NextResponse.json({ ok: true, mode: 'left' })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/conversations/[id]', e)
    return NextResponse.json({ error: 'Không rời được nhóm' }, { status: 500 })
  }
}
