export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError, companyBotReply } from '@/lib/vx-auth'
import { VX_BOT_USERNAME, vexonBotAiReply } from '@/lib/vx-bot'

const SELECT_SENDER = { id: true, username: true, fullName: true, role: true, avatarColor: true, accountType: true, companyName: true }
const SELECT_MEMBER = { id: true, username: true, fullName: true, role: true, department: true, avatarColor: true, online: true, lastSeen: true, accountType: true, companyName: true }

const BOT_REPLIES = [
  'Ok anh/chị nhé!',
  'Đã nhận được, tôi kiểm tra và phản hồi ngay.',
  'Ok, chiều họp nhớ có mặt đầy đủ nhé',
  'Được, tôi sẽ xử lý ngay đây.',
  'Thông tin nhận được rồi nha, cảm ơn nhiều!',
  'Hay quá! Để tôi báo lại lãnh đạo.',
  'Ok nha, trễ nữa tôi gửi tài liệu cho xem trước.',
]

// GET /api/vx/conversations/[id]/messages
// - Cập nhật trạng thái tin nhắn của tôi: sent -> delivered (2s) -> seen (7s)
// - Bot đồng nghiệp tự trả lời sau ~9s nếu tin cuối là của tôi
// - Trả kèm cờ typing để hiển thị "Đang soạn tin..."
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const membership = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: me.id } },
    })
    if (!membership) return NextResponse.json({ error: 'Không có quyền xem hội thoại này' }, { status: 403 })

    const now = Date.now()
    let typing = false

    const lastMine = await db.vxMessage.findFirst({
      where: { conversationId: id, senderId: me.id },
      orderBy: { createdAt: 'desc' },
    })
    const lastAny = await db.vxMessage.findFirst({
      where: { conversationId: id },
      orderBy: { createdAt: 'desc' },
    })

    if (lastMine && lastAny && lastAny.id === lastMine.id) {
      const age = now - lastMine.createdAt.getTime()
      // Cập nhật trạng thái theo thời gian (mô phỏng người nhận)
      if (lastMine.status === 'sent' && age > 2000) {
        await db.vxMessage.update({ where: { id: lastMine.id }, data: { status: 'delivered' } })
      }
      if (lastMine.status !== 'seen' && age > 7000) {
        await db.vxMessage.updateMany({ where: { conversationId: id, senderId: me.id, status: { not: 'seen' } }, data: { status: 'seen' } })
      }
      // Bot trả lời sau 9 giây
      if (age > 9000) {
        const others = await db.vxConversationMember.findMany({
          where: { conversationId: id, userId: { not: me.id } },
          include: { user: { select: SELECT_SENDER } },
        })
        // Chatbox Vexon Bot: hội thoại 1-1 với bot hệ thống -> AI trả lời thật
        const botMember = others.length === 1 && others[0].user.username === VX_BOT_USERNAME ? others[0].user : null
        if (botMember) {
          const aiText = await vexonBotAiReply(lastMine.content)
          if (aiText) {
            await db.vxMessage.create({
              data: { conversationId: id, senderId: botMember.id, content: aiText, status: 'delivered' },
            })
          }
        } else if (others.length > 0) {
          const responder = others[Math.floor(Math.random() * others.length)].user
          const count = await db.vxMessage.count({ where: { conversationId: id } })
          let replyContent = BOT_REPLIES[count % BOT_REPLIES.length]
          // Bot riêng của công ty: chat 1-1 với tài khoản doanh nghiệp -> trả lời theo từ khoá
          if (others.length === 1 && responder.accountType === 'business') {
            const bot = await companyBotReply(responder.id, lastMine.content)
            if (bot) replyContent = bot.reply
          }
          await db.vxMessage.create({
            data: {
              conversationId: id,
              senderId: responder.id,
              content: replyContent,
              status: 'delivered',
            },
          })
        }
      } else if (age > 2500) {
        typing = true
      }
    }

    const [messages, conversation] = await Promise.all([
      db.vxMessage.findMany({
        where: { conversationId: id },
        include: {
          sender: { select: SELECT_SENDER },
          replyTo: { include: { sender: { select: { fullName: true } } } },
        },
        orderBy: { createdAt: 'asc' },
        take: 200,
      }),
      db.vxConversation.findUnique({
        where: { id },
        include: { members: { include: { user: { select: SELECT_MEMBER } } } },
      }),
    ])

    await db.vxConversationMember.update({
      where: { conversationId_userId: { conversationId: id, userId: me.id } },
      data: { lastReadAt: new Date() },
    })

    return NextResponse.json({
      messages: messages.map((m) => ({
        id: m.id,
        content: m.content,
        type: m.type,
        topicId: m.topicId,
        fileUrl: m.fileUrl,
        fileName: m.fileName,
        fileSize: m.fileSize,
        duration: m.duration,
        forwardedFrom: m.forwardedFrom,
        reactions: m.reactions ? JSON.parse(m.reactions) : {},
        status: m.status,
        unsent: m.unsent,
        pinned: m.pinned,
        createdAt: m.createdAt,
        senderId: m.senderId,
        sender: m.sender,
        replyTo: m.replyTo
          ? { id: m.replyTo.id, senderName: m.replyTo.sender.fullName, content: m.replyTo.unsent ? 'Tin nhắn đã thu hồi' : m.replyTo.content, type: m.replyTo.type }
          : null,
      })),
      members: conversation?.members.map((m) => ({ ...m.user, memberRole: m.role })) || [],
      typing,
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/conversations/[id]/messages', e)
    return NextResponse.json({ error: 'Không tải được tin nhắn' }, { status: 500 })
  }
}

// POST /api/vx/conversations/[id]/messages — gửi tin nhắn đa phương tiện
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const membership = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: me.id } },
    })
    if (!membership) return NextResponse.json({ error: 'Không có quyền gửi tin vào hội thoại này' }, { status: 403 })

    // Chặn tin nhắn giữa 2 người đã chặn nhau (kiểu Zalo — chỉ áp dụng chat 1-1, nhóm không chặn)
    const conv = await db.vxConversation.findUnique({ where: { id }, select: { isGroup: true, members: { select: { userId: true } } } })
    if (conv && !conv.isGroup) {
      const otherId = conv.members.find((m) => m.userId !== me.id)?.userId
      if (otherId) {
        const blockRow = await db.vxBlock.findFirst({
          where: { OR: [{ blockerId: me.id, blockedId: otherId }, { blockerId: otherId, blockedId: me.id }] },
        })
        if (blockRow) {
          const iBlocked = blockRow.blockerId === me.id
          return NextResponse.json(
            { error: iBlocked ? 'Bạn đã chặn người này, bỏ chặn để tiếp tục nhắn tin' : 'Bạn không thể nhắn tin cho người này' },
            { status: 403 },
          )
        }
      }
    }

    const body = await req.json()
    const type = ['text', 'image', 'gif', 'file', 'voice', 'sticker', 'call'].includes(body.type) ? body.type : 'text'
    const content = String(body.content || '').trim()
    if (type === 'text' && !content) {
      return NextResponse.json({ error: 'Tin nhắn trống' }, { status: 400 })
    }
    if ((type === 'image' || type === 'gif' || type === 'file') && body.fileUrl && String(body.fileUrl).length > 2_500_000) {
      return NextResponse.json({ error: 'File quá lớn (tối đa ~1.5MB trong demo)' }, { status: 400 })
    }

    const message = await db.vxMessage.create({
      data: {
        conversationId: id,
        senderId: me.id,
        topicId: body.topicId ? String(body.topicId) : null,
        content: content.slice(0, 2000) || (type === 'sticker' ? String(body.content || 'smile') : content),
        type,
        fileUrl: body.fileUrl || null,
        fileName: body.fileName ? String(body.fileName).slice(0, 200) : null,
        fileSize: Number(body.fileSize) > 0 ? Math.round(Number(body.fileSize)) : null,
        duration: Number(body.duration) > 0 ? Math.round(Number(body.duration)) : null,
        replyToId: body.replyToId ? String(body.replyToId) : null,
        forwardedFrom: body.forwardedFrom ? String(body.forwardedFrom).slice(0, 100) : null,
        status: 'sent',
      },
      include: {
        sender: { select: SELECT_SENDER },
        replyTo: { include: { sender: { select: { fullName: true } } } },
      },
    })
    await db.vxConversationMember.update({
      where: { conversationId_userId: { conversationId: id, userId: me.id } },
      data: { lastReadAt: new Date() },
    })

    return NextResponse.json(
      {
        id: message.id,
        content: message.content,
        type: message.type,
        topicId: message.topicId,
        fileUrl: message.fileUrl,
        fileName: message.fileName,
        fileSize: message.fileSize,
        duration: message.duration,
        forwardedFrom: message.forwardedFrom,
        reactions: {},
        status: message.status,
        unsent: message.unsent,
        pinned: message.pinned,
        createdAt: message.createdAt,
        senderId: message.senderId,
        sender: message.sender,
        replyTo: message.replyTo
          ? { id: message.replyTo.id, senderName: message.replyTo.sender.fullName, content: message.replyTo.content, type: message.replyTo.type }
          : null,
      },
      { status: 201 }
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/conversations/[id]/messages', e)
    return NextResponse.json({ error: 'Không gửi được tin nhắn' }, { status: 500 })
  }
}
