export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// PATCH /api/vx/conversations/[id]/topics/[topicId] — đổi tên / đổi icon chủ đề
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string; topicId: string }> }) {
  try {
    const me = await requireUser()
    const { id, topicId } = await params
    const membership = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: me.id } },
    })
    if (!membership || (membership.role !== 'admin' && membership.role !== 'mod')) {
      return NextResponse.json({ error: 'Chỉ trưởng/phó nhóm mới sửa được chủ đề' }, { status: 403 })
    }

    const topic = await db.vxTopic.findFirst({ where: { id: topicId, conversationId: id } })
    if (!topic) return NextResponse.json({ error: 'Không tìm thấy chủ đề' }, { status: 404 })

    const body = await req.json()
    const data: Record<string, unknown> = {}
    if (body.name !== undefined) {
      const name = String(body.name).trim().slice(0, 60)
      if (!name) return NextResponse.json({ error: 'Tên chủ đề không được trống' }, { status: 400 })
      data.name = name
    }
    if (body.icon !== undefined) data.icon = String(body.icon).slice(0, 24) || 'chat'

    await db.vxTopic.update({ where: { id: topicId }, data })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/conversations/[id]/topics/[topicId]', e)
    return NextResponse.json({ error: 'Không sửa được chủ đề' }, { status: 500 })
  }
}

// DELETE — xoá chủ đề (tin nhắn trong chủ đề được chuyển về "Tổng hợp")
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string; topicId: string }> }) {
  try {
    const me = await requireUser()
    const { id, topicId } = await params
    const membership = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: me.id } },
    })
    if (!membership || membership.role !== 'admin') {
      return NextResponse.json({ error: 'Chỉ trưởng nhóm mới xoá được chủ đề' }, { status: 403 })
    }

    const topic = await db.vxTopic.findFirst({ where: { id: topicId, conversationId: id } })
    if (!topic) return NextResponse.json({ error: 'Không tìm thấy chủ đề' }, { status: 404 })

    // Chuyển tin nhắn về "Tổng hợp" rồi mới xoá
    await db.vxMessage.updateMany({ where: { topicId }, data: { topicId: null } })
    await db.vxTopic.delete({ where: { id: topicId } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/conversations/[id]/topics/[topicId]', e)
    return NextResponse.json({ error: 'Không xoá được chủ đề' }, { status: 500 })
  }
}
