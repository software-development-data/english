export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// GET /api/vx/conversations/[id]/topics — danh sách chủ đề (kiểu forum Telegram)
// Trả kèm: số tin nhắn, tin nhắn cuối. "Tổng hợp" = các tin không thuộc chủ đề nào
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const membership = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: me.id } },
    })
    if (!membership) return NextResponse.json({ error: 'Không có quyền xem nhóm này' }, { status: 403 })

    const conv = await db.vxConversation.findUnique({
      where: { id },
      include: {
        topics: {
          include: {
            messages: { orderBy: { createdAt: 'desc' }, take: 1, include: { sender: { select: { fullName: true } } } },
          },
          orderBy: { createdAt: 'asc' },
        },
      },
    })
    if (!conv) return NextResponse.json({ error: 'Không tìm thấy hội thoại' }, { status: 404 })

    const generalCount = await db.vxMessage.count({ where: { conversationId: id, topicId: null } })
    const generalLast = await db.vxMessage.findFirst({
      where: { conversationId: id, topicId: null },
      orderBy: { createdAt: 'desc' },
      include: { sender: { select: { fullName: true } } },
    })

    const topics = [
      {
        id: null,
        name: 'Tổng hợp',
        icon: 'chat',
        messageCount: generalCount,
        lastMessage: generalLast
          ? { content: generalLast.unsent ? 'Tin nhắn đã thu hồi' : generalLast.content, senderName: generalLast.sender.fullName, createdAt: generalLast.createdAt }
          : null,
      },
      ...conv.topics.map((t) => ({
        id: t.id,
        name: t.name,
        icon: t.icon,
        messageCount: 0,
        lastMessage: t.messages[0]
          ? { content: t.messages[0].unsent ? 'Tin nhắn đã thu hồi' : t.messages[0].content, senderName: t.messages[0].sender.fullName, createdAt: t.messages[0].createdAt }
          : null,
      })),
    ]

    // Đếm chính xác số tin từng topic
    const counts = await db.vxMessage.groupBy({
      by: ['topicId'],
      where: { conversationId: id, topicId: { not: null } },
      _count: { topicId: true },
    })
    const countMap = new Map(counts.map((c) => [c.topicId, c._count.topicId]))
    for (const t of topics) {
      if (t.id) t.messageCount = countMap.get(t.id) ?? 0
    }

    return NextResponse.json({ isForum: conv.isForum, topics })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/conversations/[id]/topics', e)
    return NextResponse.json({ error: 'Không tải được chủ đề' }, { status: 500 })
  }
}

// POST /api/vx/conversations/[id]/topics — tạo chủ đề mới { name, icon? }
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const membership = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: me.id } },
    })
    if (!membership) return NextResponse.json({ error: 'Không có quyền tạo chủ đề' }, { status: 403 })

    const conv = await db.vxConversation.findUnique({ where: { id } })
    if (!conv || !conv.isGroup) return NextResponse.json({ error: 'Chỉ nhóm chat mới có chủ đề' }, { status: 400 })

    if (!conv.isForum) {
      await db.vxConversation.update({ where: { id }, data: { isForum: true } })
    }

    const body = await req.json()
    const name = String(body.name || '').trim().slice(0, 60)
    if (!name) return NextResponse.json({ error: 'Nhập tên chủ đề' }, { status: 400 })

    const existing = await db.vxTopic.findFirst({ where: { conversationId: id, name } })
    if (existing) return NextResponse.json({ error: 'Chủ đề này đã có rồi' }, { status: 409 })

    const topic = await db.vxTopic.create({
      data: { conversationId: id, name, icon: String(body.icon || 'chat').slice(0, 24), createdById: me.id },
    })
    return NextResponse.json({ id: topic.id, name: topic.name, icon: topic.icon, messageCount: 0, lastMessage: null }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/conversations/[id]/topics', e)
    return NextResponse.json({ error: 'Không tạo được chủ đề' }, { status: 500 })
  }
}
