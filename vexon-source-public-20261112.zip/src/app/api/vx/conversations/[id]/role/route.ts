export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// POST /api/vx/conversations/[id]/role  body: { userId, role: 'admin'|'mod'|'member' }
// Chỉ trưởng nhóm (admin) được phân quyền.
// role='admin' = CHUYỂN QUYỀN TRƯỞNG NHÓM (chuyển nhượng): người nhận lên admin,
// trưởng nhóm cũ tự động hạ xuống thành viên — nhóm luôn có đúng 1 trưởng nhóm,
// nhờ đó trưởng nhóm cũ rời nhóm được (kiểu TTO group-manage).
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const { userId, role } = await req.json()
    if (!['admin', 'mod', 'member'].includes(role)) {
      return NextResponse.json({ error: 'Vai trò không hợp lệ' }, { status: 400 })
    }
    if (role === 'admin' && userId === me.id) {
      return NextResponse.json({ error: 'Bạn đã là trưởng nhóm' }, { status: 400 })
    }
    const myMembership = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: me.id } },
    })
    if (!myMembership || myMembership.role !== 'admin') {
      return NextResponse.json({ error: 'Chỉ trưởng nhóm mới phân quyền được' }, { status: 403 })
    }
    const target = await db.vxConversationMember.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: String(userId) } },
    })
    if (!target) return NextResponse.json({ error: 'Thành viên không tồn tại' }, { status: 404 })

    if (role === 'admin') {
      // Chuyển nhượng quyền: 1 giao dịch — người nhận lên trưởng nhóm, mình hạ thành viên
      await db.$transaction([
        db.vxConversationMember.update({ where: { id: target.id }, data: { role: 'admin' } }),
        db.vxConversationMember.update({ where: { id: myMembership.id }, data: { role: 'member' } }),
      ])
      return NextResponse.json({ ok: true, role: 'admin', transferred: true })
    }

    await db.vxConversationMember.update({
      where: { id: target.id },
      data: { role },
    })
    return NextResponse.json({ ok: true, role })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/conversations/[id]/role', e)
    return NextResponse.json({ error: 'Không đổi được vai trò' }, { status: 500 })
  }
}
