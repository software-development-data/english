export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

const DAILY_BONUS = 50
const VIDEO_REWARD = 5
const ATTENDANCE_REWARD = 10

// GET /api/vx/wallet — số dư xu + lịch sử giao dịch + thống kê quà
export async function GET() {
  try {
    const me = await requireUser()
    const [meFull, txs, giftsSentAgg, giftsRecvAgg] = await Promise.all([
      db.vxUser.findUnique({ where: { id: me.id }, select: { coins: true, lastBonusAt: true, accountType: true } }),
      db.vxCoinTx.findMany({ where: { userId: me.id }, orderBy: { createdAt: 'desc' }, take: 60 }),
      db.vxLiveGift.aggregate({ where: { fromUserId: me.id }, _sum: { cost: true }, _count: true }),
      db.vxLiveGift.aggregate({ where: { toUserId: me.id }, _sum: { cost: true }, _count: true }),
    ])

    const now = Date.now()
    const last = meFull?.lastBonusAt?.getTime() || 0
    const canClaimBonus = now - last > 20 * 3600 * 1000

    // QUYỀN LỢI THÀNH VIÊN DOANH NGHIỆP: điểm danh hàng ngày x2 cho thành viên đã được chủ công ty duyệt
    const membership = await db.vxBusinessMember.findFirst({ where: { userId: me.id, status: 'active' }, include: { company: { select: { name: true } } } })
    const dailyBonus = membership ? DAILY_BONUS * 2 : DAILY_BONUS

    return NextResponse.json({
      coins: meFull?.coins || 0,
      accountType: meFull?.accountType,
      canClaimBonus,
      nextBonusInMin: canClaimBonus ? 0 : Math.ceil((20 * 3600 * 1000 - (now - last)) / 60000),
      bizMembership: membership ? { companyName: membership.company.name } : null,
      earnRules: [
        { action: 'daily', label: membership ? `Điểm danh hàng ngày (x2 quyền lợi thành viên ${membership.company.name})` : 'Điểm danh hàng ngày', coins: dailyBonus },
        { action: 'attendance', label: 'Điểm danh làm việc', coins: ATTENDANCE_REWARD },
        { action: 'post', label: 'Đăng bài bảng tin (tối đa 8/ngày)', coins: 5 },
        { action: 'comment', label: 'Bình luận (tối đa 20/ngày)', coins: 2 },
        { action: 'video', label: 'Xem video (mỗi video 1 lần/ngày)', coins: VIDEO_REWARD },
        { action: 'task', label: 'Hoàn thành công việc (Kanban)', coins: 20 },
        { action: 'idea', label: 'Đăng sáng kiến', coins: 10 },
        { action: 'gift', label: 'Nhận quà từ người xem khi livestream', coins: '100%' },
      ],
      txs,
      giftsSent: { total: giftsSentAgg._count, coins: giftsSentAgg._sum.cost || 0 },
      giftsReceived: { total: giftsRecvAgg._count, coins: giftsRecvAgg._sum.cost || 0 },
    })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/wallet', e)
    return NextResponse.json({ error: 'Không tải được ví' }, { status: 500 })
  }
}

// POST /api/vx/wallet — cày xu: {action:'daily_bonus'} | {action:'video_reward', videoId}
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()

    if (body.action === 'daily_bonus') {
      const meFull = await db.vxUser.findUnique({ where: { id: me.id } })
      const last = meFull?.lastBonusAt?.getTime() || 0
      if (Date.now() - last <= 20 * 3600 * 1000) {
        return NextResponse.json({ error: 'Bạn đã nhận thưởng rồi, quay lại sau nhé!' }, { status: 400 })
      }
      // Thành viên doanh nghiệp (đã duyệt) nhận x2 xu — quyền lợi công ty
      const membership = await db.vxBusinessMember.findFirst({ where: { userId: me.id, status: 'active' }, include: { company: { select: { name: true } } } })
      const bonus = membership ? DAILY_BONUS * 2 : DAILY_BONUS
      const [user] = await Promise.all([
        db.vxUser.update({ where: { id: me.id }, data: { coins: { increment: bonus }, lastBonusAt: new Date() } }),
        db.vxCoinTx.create({ data: { userId: me.id, amount: bonus, reason: membership ? `Thưởng điểm danh hàng ngày (x2 quyền lợi thành viên ${membership.company.name})` : 'Thưởng điểm danh hàng ngày' } }),
      ])
      return NextResponse.json({ ok: true, coins: user.coins, earned: bonus })
    }

    if (body.action === 'video_reward') {
      const videoId = String(body.videoId || '')
      if (!videoId) return NextResponse.json({ error: 'Thiếu video' }, { status: 400 })
      const reason = `watch:${videoId}`
      const today = new Date().toDateString()
      const existing = await db.vxCoinTx.findFirst({
        where: { userId: me.id, reason: { startsWith: reason }, createdAt: { gte: new Date(today) } },
      })
      if (existing) return NextResponse.json({ ok: false, message: 'Đã nhận thưởng cho video này hôm nay' })
      const user = await db.vxUser.update({ where: { id: me.id }, data: { coins: { increment: VIDEO_REWARD } } })
      await db.vxCoinTx.create({ data: { userId: me.id, amount: VIDEO_REWARD, reason: `Thưởng xem video (${videoId.slice(-6)})` } })
      return NextResponse.json({ ok: true, coins: user.coins, earned: VIDEO_REWARD })
    }

    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/wallet', e)
    return NextResponse.json({ error: 'Không xử lý được' }, { status: 500 })
  }
}
