export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { searchGifs } from '@/lib/gif'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'
import { writeFile, mkdir } from 'fs/promises'
import path from 'path'
import { randomBytes } from 'crypto'

/**
 * GIFHub r32 — tìm & TẢI GIF LÊN dùng chung cả công ty.
 * GET  /api/vx/gif?q=...  → { gifs, uploads }
 *   • gifs: kết quả tìm kiếm như cũ (Giphy key thật nếu có, không thì bộ nội bộ) —
 *     GIF do người dùng tải lên mà khớp từ khoá được GHÉP LÊN ĐẦU để mọi nơi cũ dùng API này đều thấy.
 *   • uploads: riêng mảng GIF cả công ty tải lên (mới nhất trước, tối đa 12, khớp q nếu có).
 * POST /api/vx/gif        → đăng GIF lên hub (2 kiểu):
 *   • multipart: file (.gif, ≤ 8MB) + title  → lưu vào public/uploads/gifs/
 *   • JSON: { url, title }                   → dán link GIF http(s) ngoài
 * title là tên + từ khoá tìm kiếm (bắt buộc) — không dấu vẫn tìm được.
 */

const SELECT_UPLOADER = { select: { fullName: true } }

const MAX_GIF_BYTES = 8 * 1024 * 1024 // 8MB

/** Bỏ dấu để tìm không dấu vẫn khớp (vd "an mung" → "ăn mừng") */
const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')

export async function GET(req: NextRequest) {
  const q = (req.nextUrl.searchParams.get('q') || '').trim().slice(0, 60)
  try {
    const [gifs, rows] = await Promise.all([
      searchGifs(q),
      db.vxGif.findMany({ orderBy: { createdAt: 'desc' }, take: 100, include: { uploader: SELECT_UPLOADER } }),
    ])
    const kw = norm(q)
    const words = kw.split(/\s+/).filter((w) => w.length >= 2)
    const matched = kw
      ? rows.filter((g) => {
          const t = norm(`${g.title}`)
          return t.includes(kw) || words.some((w) => t.includes(w))
        })
      : rows
    const mapUp = (g: (typeof rows)[number]) => ({ id: g.id, url: g.url, title: g.title, uploader: g.uploader?.fullName || 'Vexon' })
    const uploads = matched.slice(0, 12).map(mapUp)
    // Ghép GIF tải lên khớp từ khoá lên đầu kết quả (không trùng URL) — picker cũ/VexonAI tự thấy
    const seen = new Set(uploads.map((u) => u.url))
    const merged = [...uploads, ...gifs.filter((g) => !seen.has(g.url))].slice(0, 24)
    return NextResponse.json({ gifs: merged, uploads })
  } catch {
    return NextResponse.json({ gifs: [], uploads: [] })
  }
}

export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const ct = req.headers.get('content-type') || ''
    let url = ''
    let title = ''

    if (ct.includes('multipart/form-data')) {
      // Kiểu 1: tải file GIF thật lên server (như route videos)
      const form = await req.formData()
      const file = form.get('file') as File | null
      title = String(form.get('title') || '').trim()
      if (!file || file.size === 0) return NextResponse.json({ error: 'Vui lòng chọn file GIF' }, { status: 400 })
      const isGif = file.type === 'image/gif' || /\.gif$/i.test(file.name)
      if (!isGif) return NextResponse.json({ error: 'Chỉ chấp nhận file GIF (đuôi .gif)' }, { status: 400 })
      if (file.size > MAX_GIF_BYTES) return NextResponse.json({ error: 'GIF tối đa 8MB' }, { status: 400 })
      if (!title) return NextResponse.json({ error: 'Vui lòng nhập tên/từ khoá cho GIF' }, { status: 400 })
      const filename = `vxgif_${Date.now()}_${randomBytes(4).toString('hex')}.gif`
      const dir = path.join(process.cwd(), 'public', 'uploads', 'gifs')
      await mkdir(dir, { recursive: true })
      await writeFile(path.join(dir, filename), Buffer.from(await file.arrayBuffer()))
      url = `/uploads/gifs/${filename}`
    } else {
      // Kiểu 2: dán link GIF ngoài (http/https)
      const body = (await req.json().catch(() => ({}))) as { url?: unknown; title?: unknown }
      url = String(body.url || '').trim()
      title = String(body.title || '').trim()
      if (!/^https?:\/\/\S+$/i.test(url) || url.length > 500 || /\s/.test(url)) {
        return NextResponse.json({ error: 'Link GIF không hợp lệ (phải là http/https)' }, { status: 400 })
      }
      if (!title) return NextResponse.json({ error: 'Vui lòng nhập tên/từ khoá cho GIF' }, { status: 400 })
    }

    const gif = await db.vxGif.create({
      data: { uploaderId: me.id, url, title: title.slice(0, 120) },
      include: { uploader: SELECT_UPLOADER },
    })
    return NextResponse.json(
      { ok: true, gif: { id: gif.id, url: gif.url, title: gif.title, uploader: gif.uploader?.fullName || 'Vexon' } },
      { status: 201 }
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/gif', e)
    return NextResponse.json({ error: 'Không tải được GIF lên hub' }, { status: 500 })
  }
}
