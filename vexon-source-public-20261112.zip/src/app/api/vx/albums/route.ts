export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

function parseJSON(s: string | null | undefined): string[] {
  if (!s) return []
  try {
    const v = JSON.parse(s)
    return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : []
  } catch {
    return []
  }
}

// GET /api/vx/albums — album của tôi (kèm số ảnh; ?full=1 trả cả danh sách ảnh)
export async function GET(req: NextRequest) {
  try {
    const me = await requireUser()
    const full = req.nextUrl.searchParams.get('full') === '1'
    const albums = await db.vxAlbum.findMany({
      where: { userId: me.id },
      orderBy: { createdAt: 'desc' },
    })
    return NextResponse.json(
      albums.map((a) => {
        const photos = parseJSON(a.photos as string | null)
        return {
          id: a.id, name: a.name, count: photos.length,
          cover: photos[0] || null, createdAt: a.createdAt,
          ...(full ? { photos } : {}),
        }
      })
    )
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('GET /api/vx/albums', e)
    return NextResponse.json({ error: 'Không tải được album' }, { status: 500 })
  }
}

// POST /api/vx/albums — tạo album ảnh (kiểu Facebook)
export async function POST(req: NextRequest) {
  try {
    const me = await requireUser()
    const body = await req.json()
    const name = String(body.name || '').trim()
    const photos = Array.isArray(body.photos) ? body.photos.filter((x: unknown) => typeof x === 'string') : []
    if (!name) return NextResponse.json({ error: 'Album cần có tên' }, { status: 400 })
    if (photos.length === 0) return NextResponse.json({ error: 'Thêm ít nhất 1 ảnh vào album' }, { status: 400 })
    if (photos.length > 30) return NextResponse.json({ error: 'Tối đa 30 ảnh mỗi album' }, { status: 400 })
    for (const img of photos) {
      if (img.length > 2_000_000) return NextResponse.json({ error: 'Ảnh quá lớn (tối đa ~1.5MB/ảnh)' }, { status: 400 })
    }

    const album = await db.vxAlbum.create({
      data: { userId: me.id, name: name.slice(0, 80), photos: JSON.stringify(photos) },
    })
    return NextResponse.json({ id: album.id, name: album.name, count: photos.length }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('POST /api/vx/albums', e)
    return NextResponse.json({ error: 'Không tạo được album' }, { status: 500 })
  }
}
