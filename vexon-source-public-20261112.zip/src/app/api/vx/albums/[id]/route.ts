export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/vx-auth'

// PATCH /api/vx/albums/[id] — đổi tên album hoặc thêm ảnh
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const album = await db.vxAlbum.findUnique({ where: { id } })
    if (!album || album.userId !== me.id) return NextResponse.json({ error: 'Không tìm thấy album' }, { status: 404 })

    const body = await req.json()
    const data: Record<string, unknown> = {}
    if (body.name !== undefined) {
      const name = String(body.name).trim().slice(0, 80)
      if (!name) return NextResponse.json({ error: 'Tên album không được trống' }, { status: 400 })
      data.name = name
    }
    if (Array.isArray(body.addPhotos)) {
      const existing: string[] = (() => {
        try {
          const v = JSON.parse((album.photos as string | null) || '[]')
          return Array.isArray(v) ? v : []
        } catch {
          return []
        }
      })()
      const adding = body.addPhotos.filter((x: unknown) => typeof x === 'string')
      for (const img of adding) {
        if (img.length > 2_000_000) return NextResponse.json({ error: 'Ảnh quá lớn (tối đa ~1.5MB/ảnh)' }, { status: 400 })
      }
      const merged = [...existing, ...adding].slice(0, 30)
      data.photos = JSON.stringify(merged)
    }
    await db.vxAlbum.update({ where: { id }, data })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('PATCH /api/vx/albums/[id]', e)
    return NextResponse.json({ error: 'Không cập nhật được album' }, { status: 500 })
  }
}

// DELETE /api/vx/albums/[id] — xoá album (chủ nhân mới được xoá)
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const me = await requireUser()
    const { id } = await params
    const album = await db.vxAlbum.findUnique({ where: { id } })
    if (!album || album.userId !== me.id) return NextResponse.json({ error: 'Không tìm thấy album' }, { status: 404 })
    await db.vxAlbum.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof AuthError) return NextResponse.json({ error: e.message }, { status: 401 })
    console.error('DELETE /api/vx/albums/[id]', e)
    return NextResponse.json({ error: 'Không xoá được album' }, { status: 500 })
  }
}
