import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

function fmtVN(d: Date) {
  return d.toLocaleString('vi-VN', { weekday: 'long', hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'Asia/Ho_Chi_Minh' })
}

// GET: Danh sách lịch hẹn (kèm tự xử lý email nhắc lịch đến hạn)
export async function GET(req: NextRequest) {
  try {
    const status = req.nextUrl.searchParams.get('status')
    await processDueReminders()
    const appointments = await db.appointment.findMany({
      where: status ? { status } : {},
      include: { service: true, emails: { orderBy: { createdAt: 'desc' } } },
      orderBy: { scheduledAt: 'asc' },
      take: 200,
    })
    return NextResponse.json(appointments)
  } catch (e) {
    console.error('GET /api/appointments', e)
    return NextResponse.json({ error: 'Không tải được lịch hẹn' }, { status: 500 })
  }
}

// POST: Đặt lịch hẹn mới (tự gửi email xác nhận + lên lịch email nhắc)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { customerName, customerPhone, customerEmail, serviceId, scheduledAt, note } = body

    if (!customerName || !customerPhone || !customerEmail || !serviceId || !scheduledAt) {
      return NextResponse.json({ error: 'Vui lòng điền đầy đủ thông tin bắt buộc' }, { status: 400 })
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(customerEmail))) {
      return NextResponse.json({ error: 'Email không hợp lệ' }, { status: 400 })
    }

    const when = new Date(scheduledAt)
    if (isNaN(when.getTime())) {
      return NextResponse.json({ error: 'Thời gian hẹn không hợp lệ' }, { status: 400 })
    }
    if (when.getTime() < Date.now() - 60_000) {
      return NextResponse.json({ error: 'Không thể đặt lịch trong quá khứ' }, { status: 400 })
    }

    const service = await db.service.findUnique({ where: { id: serviceId } })
    if (!service) {
      return NextResponse.json({ error: 'Dịch vụ không tồn tại' }, { status: 400 })
    }

    // Kiểm tra trùng giờ (cùng dịch vụ, cách nhau theo thời lượng)
    const overlapping = await db.appointment.findFirst({
      where: {
        serviceId,
        status: { in: ['scheduled', 'confirmed'] },
        scheduledAt: {
          gte: new Date(when.getTime() - (service.durationMin - 1) * 60_000),
          lte: new Date(when.getTime() + (service.durationMin - 1) * 60_000),
        },
      },
    })
    if (overlapping) {
      return NextResponse.json({ error: 'Khung giờ này đã có khách hẹn, vui lòng chọn giờ khác' }, { status: 400 })
    }

    const appointment = await db.appointment.create({
      data: {
        customerName,
        customerPhone,
        customerEmail,
        serviceId,
        scheduledAt: when,
        note: note || null,
      },
      include: { service: true },
    })

    // Email xác nhận (gửi ngay)
    await db.emailLog.create({
      data: {
        appointmentId: appointment.id,
        to: customerEmail,
        subject: `Xác nhận lịch hẹn - ${service.name}`,
        body:
          `Xin chào ${customerName},\n\n` +
          `Lịch hẹn của bạn đã được ghi nhận:\n` +
          `• Dịch vụ: ${service.name}\n` +
          `• Thời gian: ${fmtVN(when)}\n` +
          `• Thời lượng dự kiến: ${service.durationMin} phút\n\n` +
          `Vui lòng đến sớm 5 phút. Cần đổi lịch, liên hệ hotline 1900-6868.\n\n` +
          `Trân trọng,\nVexon Store`,
        type: 'confirmation',
        status: 'sent',
        scheduledFor: new Date(),
        sentAt: new Date(),
      },
    })

    // Email nhắc lịch (24h trước, nếu còn tương lai)
    const remindAt = new Date(when.getTime() - 24 * 60 * 60 * 1000)
    if (remindAt.getTime() > Date.now()) {
      await db.emailLog.create({
        data: {
          appointmentId: appointment.id,
          to: customerEmail,
          subject: `Nhắc lịch: ${service.name} - ngày mai`,
          body:
            `Xin chào ${customerName},\n\n` +
            `Nhắc bạn lịch hẹn "${service.name}" sẽ diễn ra lúc ${fmtVN(when)}.\n` +
            `Đừng quên đến đúng giờ nhé!\n\nTrân trọng,\nVexon Store`,
          type: 'reminder',
          status: 'queued',
          scheduledFor: remindAt,
        },
      })
    }

    return NextResponse.json(appointment, { status: 201 })
  } catch (e) {
    console.error('POST /api/appointments', e)
    return NextResponse.json({ error: 'Không đặt được lịch hẹn' }, { status: 500 })
  }
}

// Đánh dấu các email nhắc lịch đến hạn là "đã gửi" (mô phỏng hàng đợi email)
async function processDueReminders() {
  try {
    const due = await db.emailLog.updateMany({
      where: { status: 'queued', scheduledFor: { lte: new Date() } },
      data: { status: 'sent', sentAt: new Date() },
    })
    if (due.count > 0) console.log(`[reminders] Đã gửi ${due.count} email nhắc lịch đến hạn`)
  } catch (e) {
    console.error('processDueReminders', e)
  }
}
