import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PATCH: Cập nhật trạng thái lịch hẹn (huỷ lịch => huỷ luôn email nhắc)
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await req.json()
    if (!['scheduled', 'confirmed', 'done', 'cancelled'].includes(body.status)) {
      return NextResponse.json({ error: 'Trạng thái không hợp lệ' }, { status: 400 })
    }

    const appointment = await db.appointment.update({
      where: { id },
      data: { status: body.status },
      include: { service: true },
    })

    if (body.status === 'cancelled') {
      await db.emailLog.updateMany({
        where: { appointmentId: id, status: 'queued' },
        data: { status: 'cancelled' },
      })
      if (appointment.customerEmail) {
        await db.emailLog.create({
          data: {
            appointmentId: id,
            to: appointment.customerEmail,
            subject: `Huỷ lịch hẹn - ${appointment.service.name}`,
            body: `Xin chào ${appointment.customerName},\n\nLịch hẹn "${appointment.service.name}" của bạn đã được huỷ. Rất mong được đón bạn vào lần khác!\n\nVexon Store`,
            type: 'cancelled',
            status: 'sent',
            scheduledFor: new Date(),
            sentAt: new Date(),
          },
        })
      }
    }

    return NextResponse.json(appointment)
  } catch (e) {
    console.error('PATCH /api/appointments/[id]', e)
    return NextResponse.json({ error: 'Không cập nhật được lịch hẹn' }, { status: 500 })
  }
}
