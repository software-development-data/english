import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Vexon — Super App Quản trị Doanh nghiệp All-in-One",
  description:
    "Super App All-in-One: quản trị 360 (công việc, đơn từ, tài chính, tài sản, họp, sáng kiến), mạng xã hội nội bộ, tin nhắn nhóm + GIF, video TikTok, livestream tặng quà, điểm danh, tuyển dụng, hồ sơ doanh nghiệp, Công cụ AI & Vexon AI (link riêng /chat) — một ví Xu duy nhất, 2 lượt miễn phí mỗi ngày, nạp Xu bằng QR ngân hàng.",
  keywords: ["vexon", "quản trị doanh nghiệp", "mạng xã hội nội bộ", "tạo nhóm", "lưu bài viết", "livestream", "ví usd", "công cụ ai", "vietqr"],
  authors: [{ name: "Vexon - Super App Doanh nghiệp" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi" suppressHydrationWarning>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}>
        {children}
        <Toaster position="top-center" richColors />
      </body>
    </html>
  );
}
